let __$$app$$__ = __$$hmAppManager$$__.currentApp;
let __$$module$$__ = __$$app$$__.current;
__$$module$$__.module = DeviceRuntimeCore.WatchFace({
  onInit() {

    // Create widgets, timers, call functions here

  },
  onDestroy() {

    // On destroy, remove if not required

  }
});
