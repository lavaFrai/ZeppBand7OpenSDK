(() => {

{content}

})();
