#!/usr/bin/env node
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// node_modules/y18n/build/index.cjs
var require_build = __commonJS({
  "node_modules/y18n/build/index.cjs"(exports, module2) {
    "use strict";
    var fs3 = require("fs");
    var util = require("util");
    var path = require("path");
    var shim2;
    var Y18N2 = class {
      constructor(opts) {
        opts = opts || {};
        this.directory = opts.directory || "./locales";
        this.updateFiles = typeof opts.updateFiles === "boolean" ? opts.updateFiles : true;
        this.locale = opts.locale || "en";
        this.fallbackToLanguage = typeof opts.fallbackToLanguage === "boolean" ? opts.fallbackToLanguage : true;
        this.cache = /* @__PURE__ */ Object.create(null);
        this.writeQueue = [];
      }
      __(...args) {
        if (typeof arguments[0] !== "string") {
          return this._taggedLiteral(arguments[0], ...arguments);
        }
        const str2 = args.shift();
        let cb = function() {
        };
        if (typeof args[args.length - 1] === "function")
          cb = args.pop();
        cb = cb || function() {
        };
        if (!this.cache[this.locale])
          this._readLocaleFile();
        if (!this.cache[this.locale][str2] && this.updateFiles) {
          this.cache[this.locale][str2] = str2;
          this._enqueueWrite({
            directory: this.directory,
            locale: this.locale,
            cb
          });
        } else {
          cb();
        }
        return shim2.format.apply(shim2.format, [this.cache[this.locale][str2] || str2].concat(args));
      }
      __n() {
        const args = Array.prototype.slice.call(arguments);
        const singular = args.shift();
        const plural = args.shift();
        const quantity = args.shift();
        let cb = function() {
        };
        if (typeof args[args.length - 1] === "function")
          cb = args.pop();
        if (!this.cache[this.locale])
          this._readLocaleFile();
        let str2 = quantity === 1 ? singular : plural;
        if (this.cache[this.locale][singular]) {
          const entry = this.cache[this.locale][singular];
          str2 = entry[quantity === 1 ? "one" : "other"];
        }
        if (!this.cache[this.locale][singular] && this.updateFiles) {
          this.cache[this.locale][singular] = {
            one: singular,
            other: plural
          };
          this._enqueueWrite({
            directory: this.directory,
            locale: this.locale,
            cb
          });
        } else {
          cb();
        }
        const values = [str2];
        if (~str2.indexOf("%d"))
          values.push(quantity);
        return shim2.format.apply(shim2.format, values.concat(args));
      }
      setLocale(locale) {
        this.locale = locale;
      }
      getLocale() {
        return this.locale;
      }
      updateLocale(obj) {
        if (!this.cache[this.locale])
          this._readLocaleFile();
        for (const key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            this.cache[this.locale][key] = obj[key];
          }
        }
      }
      _taggedLiteral(parts, ...args) {
        let str2 = "";
        parts.forEach(function(part, i) {
          const arg = args[i + 1];
          str2 += part;
          if (typeof arg !== "undefined") {
            str2 += "%s";
          }
        });
        return this.__.apply(this, [str2].concat([].slice.call(args, 1)));
      }
      _enqueueWrite(work) {
        this.writeQueue.push(work);
        if (this.writeQueue.length === 1)
          this._processWriteQueue();
      }
      _processWriteQueue() {
        const _this = this;
        const work = this.writeQueue[0];
        const directory = work.directory;
        const locale = work.locale;
        const cb = work.cb;
        const languageFile = this._resolveLocaleFile(directory, locale);
        const serializedLocale = JSON.stringify(this.cache[locale], null, 2);
        shim2.fs.writeFile(languageFile, serializedLocale, "utf-8", function(err) {
          _this.writeQueue.shift();
          if (_this.writeQueue.length > 0)
            _this._processWriteQueue();
          cb(err);
        });
      }
      _readLocaleFile() {
        let localeLookup = {};
        const languageFile = this._resolveLocaleFile(this.directory, this.locale);
        try {
          if (shim2.fs.readFileSync) {
            localeLookup = JSON.parse(shim2.fs.readFileSync(languageFile, "utf-8"));
          }
        } catch (err) {
          if (err instanceof SyntaxError) {
            err.message = "syntax error in " + languageFile;
          }
          if (err.code === "ENOENT")
            localeLookup = {};
          else
            throw err;
        }
        this.cache[this.locale] = localeLookup;
      }
      _resolveLocaleFile(directory, locale) {
        let file = shim2.resolve(directory, "./", locale + ".json");
        if (this.fallbackToLanguage && !this._fileExistsSync(file) && ~locale.lastIndexOf("_")) {
          const languageFile = shim2.resolve(directory, "./", locale.split("_")[0] + ".json");
          if (this._fileExistsSync(languageFile))
            file = languageFile;
        }
        return file;
      }
      _fileExistsSync(file) {
        return shim2.exists(file);
      }
    };
    function y18n$1(opts, _shim) {
      shim2 = _shim;
      const y18n4 = new Y18N2(opts);
      return {
        __: y18n4.__.bind(y18n4),
        __n: y18n4.__n.bind(y18n4),
        setLocale: y18n4.setLocale.bind(y18n4),
        getLocale: y18n4.getLocale.bind(y18n4),
        updateLocale: y18n4.updateLocale.bind(y18n4),
        locale: y18n4.locale
      };
    }
    var nodePlatformShim = {
      fs: {
        readFileSync: fs3.readFileSync,
        writeFile: fs3.writeFile
      },
      format: util.format,
      resolve: path.resolve,
      exists: (file) => {
        try {
          return fs3.statSync(file).isFile();
        } catch (err) {
          return false;
        }
      }
    };
    var y18n3 = (opts) => {
      return y18n$1(opts, nodePlatformShim);
    };
    module2.exports = y18n3;
  }
});

// node_modules/yargs-parser/build/index.cjs
var require_build2 = __commonJS({
  "node_modules/yargs-parser/build/index.cjs"(exports, module2) {
    "use strict";
    var util = require("util");
    var path = require("path");
    var fs3 = require("fs");
    function camelCase2(str2) {
      const isCamelCase = str2 !== str2.toLowerCase() && str2 !== str2.toUpperCase();
      if (!isCamelCase) {
        str2 = str2.toLowerCase();
      }
      if (str2.indexOf("-") === -1 && str2.indexOf("_") === -1) {
        return str2;
      } else {
        let camelcase = "";
        let nextChrUpper = false;
        const leadingHyphens = str2.match(/^-+/);
        for (let i = leadingHyphens ? leadingHyphens[0].length : 0; i < str2.length; i++) {
          let chr = str2.charAt(i);
          if (nextChrUpper) {
            nextChrUpper = false;
            chr = chr.toUpperCase();
          }
          if (i !== 0 && (chr === "-" || chr === "_")) {
            nextChrUpper = true;
          } else if (chr !== "-" && chr !== "_") {
            camelcase += chr;
          }
        }
        return camelcase;
      }
    }
    function decamelize2(str2, joinString) {
      const lowercase = str2.toLowerCase();
      joinString = joinString || "-";
      let notCamelcase = "";
      for (let i = 0; i < str2.length; i++) {
        const chrLower = lowercase.charAt(i);
        const chrString = str2.charAt(i);
        if (chrLower !== chrString && i > 0) {
          notCamelcase += `${joinString}${lowercase.charAt(i)}`;
        } else {
          notCamelcase += chrString;
        }
      }
      return notCamelcase;
    }
    function looksLikeNumber2(x) {
      if (x === null || x === void 0)
        return false;
      if (typeof x === "number")
        return true;
      if (/^0x[0-9a-f]+$/i.test(x))
        return true;
      if (/^0[^.]/.test(x))
        return false;
      return /^[-]?(?:\d+(?:\.\d*)?|\.\d+)(e[-+]?\d+)?$/.test(x);
    }
    function tokenizeArgString2(argString) {
      if (Array.isArray(argString)) {
        return argString.map((e) => typeof e !== "string" ? e + "" : e);
      }
      argString = argString.trim();
      let i = 0;
      let prevC = null;
      let c = null;
      let opening = null;
      const args = [];
      for (let ii = 0; ii < argString.length; ii++) {
        prevC = c;
        c = argString.charAt(ii);
        if (c === " " && !opening) {
          if (!(prevC === " ")) {
            i++;
          }
          continue;
        }
        if (c === opening) {
          opening = null;
        } else if ((c === "'" || c === '"') && !opening) {
          opening = c;
        }
        if (!args[i])
          args[i] = "";
        args[i] += c;
      }
      return args;
    }
    var DefaultValuesForTypeKey2;
    (function(DefaultValuesForTypeKey3) {
      DefaultValuesForTypeKey3["BOOLEAN"] = "boolean";
      DefaultValuesForTypeKey3["STRING"] = "string";
      DefaultValuesForTypeKey3["NUMBER"] = "number";
      DefaultValuesForTypeKey3["ARRAY"] = "array";
    })(DefaultValuesForTypeKey2 || (DefaultValuesForTypeKey2 = {}));
    var mixin3;
    var YargsParser2 = class {
      constructor(_mixin) {
        mixin3 = _mixin;
      }
      parse(argsInput, options) {
        const opts = Object.assign({
          alias: void 0,
          array: void 0,
          boolean: void 0,
          config: void 0,
          configObjects: void 0,
          configuration: void 0,
          coerce: void 0,
          count: void 0,
          default: void 0,
          envPrefix: void 0,
          narg: void 0,
          normalize: void 0,
          string: void 0,
          number: void 0,
          __: void 0,
          key: void 0
        }, options);
        const args = tokenizeArgString2(argsInput);
        const inputIsString = typeof argsInput === "string";
        const aliases = combineAliases2(Object.assign(/* @__PURE__ */ Object.create(null), opts.alias));
        const configuration = Object.assign({
          "boolean-negation": true,
          "camel-case-expansion": true,
          "combine-arrays": false,
          "dot-notation": true,
          "duplicate-arguments-array": true,
          "flatten-duplicate-arrays": true,
          "greedy-arrays": true,
          "halt-at-non-option": false,
          "nargs-eats-options": false,
          "negation-prefix": "no-",
          "parse-numbers": true,
          "parse-positional-numbers": true,
          "populate--": false,
          "set-placeholder-key": false,
          "short-option-groups": true,
          "strip-aliased": false,
          "strip-dashed": false,
          "unknown-options-as-args": false
        }, opts.configuration);
        const defaults = Object.assign(/* @__PURE__ */ Object.create(null), opts.default);
        const configObjects = opts.configObjects || [];
        const envPrefix = opts.envPrefix;
        const notFlagsOption = configuration["populate--"];
        const notFlagsArgv = notFlagsOption ? "--" : "_";
        const newAliases = /* @__PURE__ */ Object.create(null);
        const defaulted = /* @__PURE__ */ Object.create(null);
        const __ = opts.__ || mixin3.format;
        const flags = {
          aliases: /* @__PURE__ */ Object.create(null),
          arrays: /* @__PURE__ */ Object.create(null),
          bools: /* @__PURE__ */ Object.create(null),
          strings: /* @__PURE__ */ Object.create(null),
          numbers: /* @__PURE__ */ Object.create(null),
          counts: /* @__PURE__ */ Object.create(null),
          normalize: /* @__PURE__ */ Object.create(null),
          configs: /* @__PURE__ */ Object.create(null),
          nargs: /* @__PURE__ */ Object.create(null),
          coercions: /* @__PURE__ */ Object.create(null),
          keys: []
        };
        const negative = /^-([0-9]+(\.[0-9]+)?|\.[0-9]+)$/;
        const negatedBoolean = new RegExp("^--" + configuration["negation-prefix"] + "(.+)");
        [].concat(opts.array || []).filter(Boolean).forEach(function(opt) {
          const key = typeof opt === "object" ? opt.key : opt;
          const assignment = Object.keys(opt).map(function(key2) {
            const arrayFlagKeys = {
              boolean: "bools",
              string: "strings",
              number: "numbers"
            };
            return arrayFlagKeys[key2];
          }).filter(Boolean).pop();
          if (assignment) {
            flags[assignment][key] = true;
          }
          flags.arrays[key] = true;
          flags.keys.push(key);
        });
        [].concat(opts.boolean || []).filter(Boolean).forEach(function(key) {
          flags.bools[key] = true;
          flags.keys.push(key);
        });
        [].concat(opts.string || []).filter(Boolean).forEach(function(key) {
          flags.strings[key] = true;
          flags.keys.push(key);
        });
        [].concat(opts.number || []).filter(Boolean).forEach(function(key) {
          flags.numbers[key] = true;
          flags.keys.push(key);
        });
        [].concat(opts.count || []).filter(Boolean).forEach(function(key) {
          flags.counts[key] = true;
          flags.keys.push(key);
        });
        [].concat(opts.normalize || []).filter(Boolean).forEach(function(key) {
          flags.normalize[key] = true;
          flags.keys.push(key);
        });
        if (typeof opts.narg === "object") {
          Object.entries(opts.narg).forEach(([key, value]) => {
            if (typeof value === "number") {
              flags.nargs[key] = value;
              flags.keys.push(key);
            }
          });
        }
        if (typeof opts.coerce === "object") {
          Object.entries(opts.coerce).forEach(([key, value]) => {
            if (typeof value === "function") {
              flags.coercions[key] = value;
              flags.keys.push(key);
            }
          });
        }
        if (typeof opts.config !== "undefined") {
          if (Array.isArray(opts.config) || typeof opts.config === "string") {
            [].concat(opts.config).filter(Boolean).forEach(function(key) {
              flags.configs[key] = true;
            });
          } else if (typeof opts.config === "object") {
            Object.entries(opts.config).forEach(([key, value]) => {
              if (typeof value === "boolean" || typeof value === "function") {
                flags.configs[key] = value;
              }
            });
          }
        }
        extendAliases(opts.key, aliases, opts.default, flags.arrays);
        Object.keys(defaults).forEach(function(key) {
          (flags.aliases[key] || []).forEach(function(alias) {
            defaults[alias] = defaults[key];
          });
        });
        let error = null;
        checkConfiguration();
        let notFlags = [];
        const argv2 = Object.assign(/* @__PURE__ */ Object.create(null), { _: [] });
        const argvReturn = {};
        for (let i = 0; i < args.length; i++) {
          const arg = args[i];
          const truncatedArg = arg.replace(/^-{3,}/, "---");
          let broken;
          let key;
          let letters;
          let m;
          let next;
          let value;
          if (arg !== "--" && isUnknownOptionAsArg(arg)) {
            pushPositional(arg);
          } else if (truncatedArg.match(/---+(=|$)/)) {
            pushPositional(arg);
            continue;
          } else if (arg.match(/^--.+=/) || !configuration["short-option-groups"] && arg.match(/^-.+=/)) {
            m = arg.match(/^--?([^=]+)=([\s\S]*)$/);
            if (m !== null && Array.isArray(m) && m.length >= 3) {
              if (checkAllAliases(m[1], flags.arrays)) {
                i = eatArray(i, m[1], args, m[2]);
              } else if (checkAllAliases(m[1], flags.nargs) !== false) {
                i = eatNargs(i, m[1], args, m[2]);
              } else {
                setArg(m[1], m[2], true);
              }
            }
          } else if (arg.match(negatedBoolean) && configuration["boolean-negation"]) {
            m = arg.match(negatedBoolean);
            if (m !== null && Array.isArray(m) && m.length >= 2) {
              key = m[1];
              setArg(key, checkAllAliases(key, flags.arrays) ? [false] : false);
            }
          } else if (arg.match(/^--.+/) || !configuration["short-option-groups"] && arg.match(/^-[^-]+/)) {
            m = arg.match(/^--?(.+)/);
            if (m !== null && Array.isArray(m) && m.length >= 2) {
              key = m[1];
              if (checkAllAliases(key, flags.arrays)) {
                i = eatArray(i, key, args);
              } else if (checkAllAliases(key, flags.nargs) !== false) {
                i = eatNargs(i, key, args);
              } else {
                next = args[i + 1];
                if (next !== void 0 && (!next.match(/^-/) || next.match(negative)) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
                  setArg(key, next);
                  i++;
                } else if (/^(true|false)$/.test(next)) {
                  setArg(key, next);
                  i++;
                } else {
                  setArg(key, defaultValue(key));
                }
              }
            }
          } else if (arg.match(/^-.\..+=/)) {
            m = arg.match(/^-([^=]+)=([\s\S]*)$/);
            if (m !== null && Array.isArray(m) && m.length >= 3) {
              setArg(m[1], m[2]);
            }
          } else if (arg.match(/^-.\..+/) && !arg.match(negative)) {
            next = args[i + 1];
            m = arg.match(/^-(.\..+)/);
            if (m !== null && Array.isArray(m) && m.length >= 2) {
              key = m[1];
              if (next !== void 0 && !next.match(/^-/) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
                setArg(key, next);
                i++;
              } else {
                setArg(key, defaultValue(key));
              }
            }
          } else if (arg.match(/^-[^-]+/) && !arg.match(negative)) {
            letters = arg.slice(1, -1).split("");
            broken = false;
            for (let j = 0; j < letters.length; j++) {
              next = arg.slice(j + 2);
              if (letters[j + 1] && letters[j + 1] === "=") {
                value = arg.slice(j + 3);
                key = letters[j];
                if (checkAllAliases(key, flags.arrays)) {
                  i = eatArray(i, key, args, value);
                } else if (checkAllAliases(key, flags.nargs) !== false) {
                  i = eatNargs(i, key, args, value);
                } else {
                  setArg(key, value);
                }
                broken = true;
                break;
              }
              if (next === "-") {
                setArg(letters[j], next);
                continue;
              }
              if (/[A-Za-z]/.test(letters[j]) && /^-?\d+(\.\d*)?(e-?\d+)?$/.test(next) && checkAllAliases(next, flags.bools) === false) {
                setArg(letters[j], next);
                broken = true;
                break;
              }
              if (letters[j + 1] && letters[j + 1].match(/\W/)) {
                setArg(letters[j], next);
                broken = true;
                break;
              } else {
                setArg(letters[j], defaultValue(letters[j]));
              }
            }
            key = arg.slice(-1)[0];
            if (!broken && key !== "-") {
              if (checkAllAliases(key, flags.arrays)) {
                i = eatArray(i, key, args);
              } else if (checkAllAliases(key, flags.nargs) !== false) {
                i = eatNargs(i, key, args);
              } else {
                next = args[i + 1];
                if (next !== void 0 && (!/^(-|--)[^-]/.test(next) || next.match(negative)) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
                  setArg(key, next);
                  i++;
                } else if (/^(true|false)$/.test(next)) {
                  setArg(key, next);
                  i++;
                } else {
                  setArg(key, defaultValue(key));
                }
              }
            }
          } else if (arg.match(/^-[0-9]$/) && arg.match(negative) && checkAllAliases(arg.slice(1), flags.bools)) {
            key = arg.slice(1);
            setArg(key, defaultValue(key));
          } else if (arg === "--") {
            notFlags = args.slice(i + 1);
            break;
          } else if (configuration["halt-at-non-option"]) {
            notFlags = args.slice(i);
            break;
          } else {
            pushPositional(arg);
          }
        }
        applyEnvVars(argv2, true);
        applyEnvVars(argv2, false);
        setConfig(argv2);
        setConfigObjects();
        applyDefaultsAndAliases(argv2, flags.aliases, defaults, true);
        applyCoercions(argv2);
        if (configuration["set-placeholder-key"])
          setPlaceholderKeys(argv2);
        Object.keys(flags.counts).forEach(function(key) {
          if (!hasKey(argv2, key.split(".")))
            setArg(key, 0);
        });
        if (notFlagsOption && notFlags.length)
          argv2[notFlagsArgv] = [];
        notFlags.forEach(function(key) {
          argv2[notFlagsArgv].push(key);
        });
        if (configuration["camel-case-expansion"] && configuration["strip-dashed"]) {
          Object.keys(argv2).filter((key) => key !== "--" && key.includes("-")).forEach((key) => {
            delete argv2[key];
          });
        }
        if (configuration["strip-aliased"]) {
          [].concat(...Object.keys(aliases).map((k) => aliases[k])).forEach((alias) => {
            if (configuration["camel-case-expansion"] && alias.includes("-")) {
              delete argv2[alias.split(".").map((prop) => camelCase2(prop)).join(".")];
            }
            delete argv2[alias];
          });
        }
        function pushPositional(arg) {
          const maybeCoercedNumber = maybeCoerceNumber("_", arg);
          if (typeof maybeCoercedNumber === "string" || typeof maybeCoercedNumber === "number") {
            argv2._.push(maybeCoercedNumber);
          }
        }
        function eatNargs(i, key, args2, argAfterEqualSign) {
          let ii;
          let toEat = checkAllAliases(key, flags.nargs);
          toEat = typeof toEat !== "number" || isNaN(toEat) ? 1 : toEat;
          if (toEat === 0) {
            if (!isUndefined(argAfterEqualSign)) {
              error = Error(__("Argument unexpected for: %s", key));
            }
            setArg(key, defaultValue(key));
            return i;
          }
          let available = isUndefined(argAfterEqualSign) ? 0 : 1;
          if (configuration["nargs-eats-options"]) {
            if (args2.length - (i + 1) + available < toEat) {
              error = Error(__("Not enough arguments following: %s", key));
            }
            available = toEat;
          } else {
            for (ii = i + 1; ii < args2.length; ii++) {
              if (!args2[ii].match(/^-[^0-9]/) || args2[ii].match(negative) || isUnknownOptionAsArg(args2[ii]))
                available++;
              else
                break;
            }
            if (available < toEat)
              error = Error(__("Not enough arguments following: %s", key));
          }
          let consumed = Math.min(available, toEat);
          if (!isUndefined(argAfterEqualSign) && consumed > 0) {
            setArg(key, argAfterEqualSign);
            consumed--;
          }
          for (ii = i + 1; ii < consumed + i + 1; ii++) {
            setArg(key, args2[ii]);
          }
          return i + consumed;
        }
        function eatArray(i, key, args2, argAfterEqualSign) {
          let argsToSet = [];
          let next = argAfterEqualSign || args2[i + 1];
          const nargsCount = checkAllAliases(key, flags.nargs);
          if (checkAllAliases(key, flags.bools) && !/^(true|false)$/.test(next)) {
            argsToSet.push(true);
          } else if (isUndefined(next) || isUndefined(argAfterEqualSign) && /^-/.test(next) && !negative.test(next) && !isUnknownOptionAsArg(next)) {
            if (defaults[key] !== void 0) {
              const defVal = defaults[key];
              argsToSet = Array.isArray(defVal) ? defVal : [defVal];
            }
          } else {
            if (!isUndefined(argAfterEqualSign)) {
              argsToSet.push(processValue(key, argAfterEqualSign, true));
            }
            for (let ii = i + 1; ii < args2.length; ii++) {
              if (!configuration["greedy-arrays"] && argsToSet.length > 0 || nargsCount && typeof nargsCount === "number" && argsToSet.length >= nargsCount)
                break;
              next = args2[ii];
              if (/^-/.test(next) && !negative.test(next) && !isUnknownOptionAsArg(next))
                break;
              i = ii;
              argsToSet.push(processValue(key, next, inputIsString));
            }
          }
          if (typeof nargsCount === "number" && (nargsCount && argsToSet.length < nargsCount || isNaN(nargsCount) && argsToSet.length === 0)) {
            error = Error(__("Not enough arguments following: %s", key));
          }
          setArg(key, argsToSet);
          return i;
        }
        function setArg(key, val, shouldStripQuotes = inputIsString) {
          if (/-/.test(key) && configuration["camel-case-expansion"]) {
            const alias = key.split(".").map(function(prop) {
              return camelCase2(prop);
            }).join(".");
            addNewAlias(key, alias);
          }
          const value = processValue(key, val, shouldStripQuotes);
          const splitKey = key.split(".");
          setKey(argv2, splitKey, value);
          if (flags.aliases[key]) {
            flags.aliases[key].forEach(function(x) {
              const keyProperties = x.split(".");
              setKey(argv2, keyProperties, value);
            });
          }
          if (splitKey.length > 1 && configuration["dot-notation"]) {
            (flags.aliases[splitKey[0]] || []).forEach(function(x) {
              let keyProperties = x.split(".");
              const a = [].concat(splitKey);
              a.shift();
              keyProperties = keyProperties.concat(a);
              if (!(flags.aliases[key] || []).includes(keyProperties.join("."))) {
                setKey(argv2, keyProperties, value);
              }
            });
          }
          if (checkAllAliases(key, flags.normalize) && !checkAllAliases(key, flags.arrays)) {
            const keys = [key].concat(flags.aliases[key] || []);
            keys.forEach(function(key2) {
              Object.defineProperty(argvReturn, key2, {
                enumerable: true,
                get() {
                  return val;
                },
                set(value2) {
                  val = typeof value2 === "string" ? mixin3.normalize(value2) : value2;
                }
              });
            });
          }
        }
        function addNewAlias(key, alias) {
          if (!(flags.aliases[key] && flags.aliases[key].length)) {
            flags.aliases[key] = [alias];
            newAliases[alias] = true;
          }
          if (!(flags.aliases[alias] && flags.aliases[alias].length)) {
            addNewAlias(alias, key);
          }
        }
        function processValue(key, val, shouldStripQuotes) {
          if (shouldStripQuotes) {
            val = stripQuotes2(val);
          }
          if (checkAllAliases(key, flags.bools) || checkAllAliases(key, flags.counts)) {
            if (typeof val === "string")
              val = val === "true";
          }
          let value = Array.isArray(val) ? val.map(function(v) {
            return maybeCoerceNumber(key, v);
          }) : maybeCoerceNumber(key, val);
          if (checkAllAliases(key, flags.counts) && (isUndefined(value) || typeof value === "boolean")) {
            value = increment2();
          }
          if (checkAllAliases(key, flags.normalize) && checkAllAliases(key, flags.arrays)) {
            if (Array.isArray(val))
              value = val.map((val2) => {
                return mixin3.normalize(val2);
              });
            else
              value = mixin3.normalize(val);
          }
          return value;
        }
        function maybeCoerceNumber(key, value) {
          if (!configuration["parse-positional-numbers"] && key === "_")
            return value;
          if (!checkAllAliases(key, flags.strings) && !checkAllAliases(key, flags.bools) && !Array.isArray(value)) {
            const shouldCoerceNumber = looksLikeNumber2(value) && configuration["parse-numbers"] && Number.isSafeInteger(Math.floor(parseFloat(`${value}`)));
            if (shouldCoerceNumber || !isUndefined(value) && checkAllAliases(key, flags.numbers)) {
              value = Number(value);
            }
          }
          return value;
        }
        function setConfig(argv3) {
          const configLookup = /* @__PURE__ */ Object.create(null);
          applyDefaultsAndAliases(configLookup, flags.aliases, defaults);
          Object.keys(flags.configs).forEach(function(configKey) {
            const configPath = argv3[configKey] || configLookup[configKey];
            if (configPath) {
              try {
                let config = null;
                const resolvedConfigPath = mixin3.resolve(mixin3.cwd(), configPath);
                const resolveConfig = flags.configs[configKey];
                if (typeof resolveConfig === "function") {
                  try {
                    config = resolveConfig(resolvedConfigPath);
                  } catch (e) {
                    config = e;
                  }
                  if (config instanceof Error) {
                    error = config;
                    return;
                  }
                } else {
                  config = mixin3.require(resolvedConfigPath);
                }
                setConfigObject(config);
              } catch (ex) {
                if (ex.name === "PermissionDenied")
                  error = ex;
                else if (argv3[configKey])
                  error = Error(__("Invalid JSON config file: %s", configPath));
              }
            }
          });
        }
        function setConfigObject(config, prev) {
          Object.keys(config).forEach(function(key) {
            const value = config[key];
            const fullKey = prev ? prev + "." + key : key;
            if (typeof value === "object" && value !== null && !Array.isArray(value) && configuration["dot-notation"]) {
              setConfigObject(value, fullKey);
            } else {
              if (!hasKey(argv2, fullKey.split(".")) || checkAllAliases(fullKey, flags.arrays) && configuration["combine-arrays"]) {
                setArg(fullKey, value);
              }
            }
          });
        }
        function setConfigObjects() {
          if (typeof configObjects !== "undefined") {
            configObjects.forEach(function(configObject) {
              setConfigObject(configObject);
            });
          }
        }
        function applyEnvVars(argv3, configOnly) {
          if (typeof envPrefix === "undefined")
            return;
          const prefix = typeof envPrefix === "string" ? envPrefix : "";
          const env4 = mixin3.env();
          Object.keys(env4).forEach(function(envVar) {
            if (prefix === "" || envVar.lastIndexOf(prefix, 0) === 0) {
              const keys = envVar.split("__").map(function(key, i) {
                if (i === 0) {
                  key = key.substring(prefix.length);
                }
                return camelCase2(key);
              });
              if ((configOnly && flags.configs[keys.join(".")] || !configOnly) && !hasKey(argv3, keys)) {
                setArg(keys.join("."), env4[envVar]);
              }
            }
          });
        }
        function applyCoercions(argv3) {
          let coerce;
          const applied = /* @__PURE__ */ new Set();
          Object.keys(argv3).forEach(function(key) {
            if (!applied.has(key)) {
              coerce = checkAllAliases(key, flags.coercions);
              if (typeof coerce === "function") {
                try {
                  const value = maybeCoerceNumber(key, coerce(argv3[key]));
                  [].concat(flags.aliases[key] || [], key).forEach((ali) => {
                    applied.add(ali);
                    argv3[ali] = value;
                  });
                } catch (err) {
                  error = err;
                }
              }
            }
          });
        }
        function setPlaceholderKeys(argv3) {
          flags.keys.forEach((key) => {
            if (~key.indexOf("."))
              return;
            if (typeof argv3[key] === "undefined")
              argv3[key] = void 0;
          });
          return argv3;
        }
        function applyDefaultsAndAliases(obj, aliases2, defaults2, canLog = false) {
          Object.keys(defaults2).forEach(function(key) {
            if (!hasKey(obj, key.split("."))) {
              setKey(obj, key.split("."), defaults2[key]);
              if (canLog)
                defaulted[key] = true;
              (aliases2[key] || []).forEach(function(x) {
                if (hasKey(obj, x.split(".")))
                  return;
                setKey(obj, x.split("."), defaults2[key]);
              });
            }
          });
        }
        function hasKey(obj, keys) {
          let o = obj;
          if (!configuration["dot-notation"])
            keys = [keys.join(".")];
          keys.slice(0, -1).forEach(function(key2) {
            o = o[key2] || {};
          });
          const key = keys[keys.length - 1];
          if (typeof o !== "object")
            return false;
          else
            return key in o;
        }
        function setKey(obj, keys, value) {
          let o = obj;
          if (!configuration["dot-notation"])
            keys = [keys.join(".")];
          keys.slice(0, -1).forEach(function(key2) {
            key2 = sanitizeKey2(key2);
            if (typeof o === "object" && o[key2] === void 0) {
              o[key2] = {};
            }
            if (typeof o[key2] !== "object" || Array.isArray(o[key2])) {
              if (Array.isArray(o[key2])) {
                o[key2].push({});
              } else {
                o[key2] = [o[key2], {}];
              }
              o = o[key2][o[key2].length - 1];
            } else {
              o = o[key2];
            }
          });
          const key = sanitizeKey2(keys[keys.length - 1]);
          const isTypeArray = checkAllAliases(keys.join("."), flags.arrays);
          const isValueArray = Array.isArray(value);
          let duplicate = configuration["duplicate-arguments-array"];
          if (!duplicate && checkAllAliases(key, flags.nargs)) {
            duplicate = true;
            if (!isUndefined(o[key]) && flags.nargs[key] === 1 || Array.isArray(o[key]) && o[key].length === flags.nargs[key]) {
              o[key] = void 0;
            }
          }
          if (value === increment2()) {
            o[key] = increment2(o[key]);
          } else if (Array.isArray(o[key])) {
            if (duplicate && isTypeArray && isValueArray) {
              o[key] = configuration["flatten-duplicate-arrays"] ? o[key].concat(value) : (Array.isArray(o[key][0]) ? o[key] : [o[key]]).concat([value]);
            } else if (!duplicate && Boolean(isTypeArray) === Boolean(isValueArray)) {
              o[key] = value;
            } else {
              o[key] = o[key].concat([value]);
            }
          } else if (o[key] === void 0 && isTypeArray) {
            o[key] = isValueArray ? value : [value];
          } else if (duplicate && !(o[key] === void 0 || checkAllAliases(key, flags.counts) || checkAllAliases(key, flags.bools))) {
            o[key] = [o[key], value];
          } else {
            o[key] = value;
          }
        }
        function extendAliases(...args2) {
          args2.forEach(function(obj) {
            Object.keys(obj || {}).forEach(function(key) {
              if (flags.aliases[key])
                return;
              flags.aliases[key] = [].concat(aliases[key] || []);
              flags.aliases[key].concat(key).forEach(function(x) {
                if (/-/.test(x) && configuration["camel-case-expansion"]) {
                  const c = camelCase2(x);
                  if (c !== key && flags.aliases[key].indexOf(c) === -1) {
                    flags.aliases[key].push(c);
                    newAliases[c] = true;
                  }
                }
              });
              flags.aliases[key].concat(key).forEach(function(x) {
                if (x.length > 1 && /[A-Z]/.test(x) && configuration["camel-case-expansion"]) {
                  const c = decamelize2(x, "-");
                  if (c !== key && flags.aliases[key].indexOf(c) === -1) {
                    flags.aliases[key].push(c);
                    newAliases[c] = true;
                  }
                }
              });
              flags.aliases[key].forEach(function(x) {
                flags.aliases[x] = [key].concat(flags.aliases[key].filter(function(y) {
                  return x !== y;
                }));
              });
            });
          });
        }
        function checkAllAliases(key, flag) {
          const toCheck = [].concat(flags.aliases[key] || [], key);
          const keys = Object.keys(flag);
          const setAlias = toCheck.find((key2) => keys.includes(key2));
          return setAlias ? flag[setAlias] : false;
        }
        function hasAnyFlag(key) {
          const flagsKeys = Object.keys(flags);
          const toCheck = [].concat(flagsKeys.map((k) => flags[k]));
          return toCheck.some(function(flag) {
            return Array.isArray(flag) ? flag.includes(key) : flag[key];
          });
        }
        function hasFlagsMatching(arg, ...patterns) {
          const toCheck = [].concat(...patterns);
          return toCheck.some(function(pattern) {
            const match = arg.match(pattern);
            return match && hasAnyFlag(match[1]);
          });
        }
        function hasAllShortFlags(arg) {
          if (arg.match(negative) || !arg.match(/^-[^-]+/)) {
            return false;
          }
          let hasAllFlags = true;
          let next;
          const letters = arg.slice(1).split("");
          for (let j = 0; j < letters.length; j++) {
            next = arg.slice(j + 2);
            if (!hasAnyFlag(letters[j])) {
              hasAllFlags = false;
              break;
            }
            if (letters[j + 1] && letters[j + 1] === "=" || next === "-" || /[A-Za-z]/.test(letters[j]) && /^-?\d+(\.\d*)?(e-?\d+)?$/.test(next) || letters[j + 1] && letters[j + 1].match(/\W/)) {
              break;
            }
          }
          return hasAllFlags;
        }
        function isUnknownOptionAsArg(arg) {
          return configuration["unknown-options-as-args"] && isUnknownOption(arg);
        }
        function isUnknownOption(arg) {
          arg = arg.replace(/^-{3,}/, "--");
          if (arg.match(negative)) {
            return false;
          }
          if (hasAllShortFlags(arg)) {
            return false;
          }
          const flagWithEquals = /^-+([^=]+?)=[\s\S]*$/;
          const normalFlag = /^-+([^=]+?)$/;
          const flagEndingInHyphen = /^-+([^=]+?)-$/;
          const flagEndingInDigits = /^-+([^=]+?\d+)$/;
          const flagEndingInNonWordCharacters = /^-+([^=]+?)\W+.*$/;
          return !hasFlagsMatching(arg, flagWithEquals, negatedBoolean, normalFlag, flagEndingInHyphen, flagEndingInDigits, flagEndingInNonWordCharacters);
        }
        function defaultValue(key) {
          if (!checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts) && `${key}` in defaults) {
            return defaults[key];
          } else {
            return defaultForType(guessType(key));
          }
        }
        function defaultForType(type) {
          const def = {
            [DefaultValuesForTypeKey2.BOOLEAN]: true,
            [DefaultValuesForTypeKey2.STRING]: "",
            [DefaultValuesForTypeKey2.NUMBER]: void 0,
            [DefaultValuesForTypeKey2.ARRAY]: []
          };
          return def[type];
        }
        function guessType(key) {
          let type = DefaultValuesForTypeKey2.BOOLEAN;
          if (checkAllAliases(key, flags.strings))
            type = DefaultValuesForTypeKey2.STRING;
          else if (checkAllAliases(key, flags.numbers))
            type = DefaultValuesForTypeKey2.NUMBER;
          else if (checkAllAliases(key, flags.bools))
            type = DefaultValuesForTypeKey2.BOOLEAN;
          else if (checkAllAliases(key, flags.arrays))
            type = DefaultValuesForTypeKey2.ARRAY;
          return type;
        }
        function isUndefined(num) {
          return num === void 0;
        }
        function checkConfiguration() {
          Object.keys(flags.counts).find((key) => {
            if (checkAllAliases(key, flags.arrays)) {
              error = Error(__("Invalid configuration: %s, opts.count excludes opts.array.", key));
              return true;
            } else if (checkAllAliases(key, flags.nargs)) {
              error = Error(__("Invalid configuration: %s, opts.count excludes opts.narg.", key));
              return true;
            }
            return false;
          });
        }
        return {
          aliases: Object.assign({}, flags.aliases),
          argv: Object.assign(argvReturn, argv2),
          configuration,
          defaulted: Object.assign({}, defaulted),
          error,
          newAliases: Object.assign({}, newAliases)
        };
      }
    };
    function combineAliases2(aliases) {
      const aliasArrays = [];
      const combined = /* @__PURE__ */ Object.create(null);
      let change = true;
      Object.keys(aliases).forEach(function(key) {
        aliasArrays.push([].concat(aliases[key], key));
      });
      while (change) {
        change = false;
        for (let i = 0; i < aliasArrays.length; i++) {
          for (let ii = i + 1; ii < aliasArrays.length; ii++) {
            const intersect = aliasArrays[i].filter(function(v) {
              return aliasArrays[ii].indexOf(v) !== -1;
            });
            if (intersect.length) {
              aliasArrays[i] = aliasArrays[i].concat(aliasArrays[ii]);
              aliasArrays.splice(ii, 1);
              change = true;
              break;
            }
          }
        }
      }
      aliasArrays.forEach(function(aliasArray) {
        aliasArray = aliasArray.filter(function(v, i, self) {
          return self.indexOf(v) === i;
        });
        const lastAlias = aliasArray.pop();
        if (lastAlias !== void 0 && typeof lastAlias === "string") {
          combined[lastAlias] = aliasArray;
        }
      });
      return combined;
    }
    function increment2(orig) {
      return orig !== void 0 ? orig + 1 : 1;
    }
    function sanitizeKey2(key) {
      if (key === "__proto__")
        return "___proto___";
      return key;
    }
    function stripQuotes2(val) {
      return typeof val === "string" && (val[0] === "'" || val[0] === '"') && val[val.length - 1] === val[0] ? val.substring(1, val.length - 1) : val;
    }
    var minNodeVersion2 = process && process.env && process.env.YARGS_MIN_NODE_VERSION ? Number(process.env.YARGS_MIN_NODE_VERSION) : 12;
    if (process && process.version) {
      const major = Number(process.version.match(/v([^.]+)/)[1]);
      if (major < minNodeVersion2) {
        throw Error(`yargs parser supports a minimum Node.js version of ${minNodeVersion2}. Read our version support policy: https://github.com/yargs/yargs-parser#supported-nodejs-versions`);
      }
    }
    var env3 = process ? process.env : {};
    var parser2 = new YargsParser2({
      cwd: process.cwd,
      env: () => {
        return env3;
      },
      format: util.format,
      normalize: path.normalize,
      resolve: path.resolve,
      require: (path2) => {
        if (typeof require !== "undefined") {
          return require(path2);
        } else if (path2.match(/\.json$/)) {
          return JSON.parse(fs3.readFileSync(path2, "utf8"));
        } else {
          throw Error("only .json config files are supported in ESM");
        }
      }
    });
    var yargsParser2 = function Parser3(args, opts) {
      const result = parser2.parse(args.slice(), opts);
      return result.argv;
    };
    yargsParser2.detailed = function(args, opts) {
      return parser2.parse(args.slice(), opts);
    };
    yargsParser2.camelCase = camelCase2;
    yargsParser2.decamelize = decamelize2;
    yargsParser2.looksLikeNumber = looksLikeNumber2;
    module2.exports = yargsParser2;
  }
});

// node_modules/ansi-regex/index.js
var require_ansi_regex = __commonJS({
  "node_modules/ansi-regex/index.js"(exports, module2) {
    "use strict";
    module2.exports = ({ onlyFirst = false } = {}) => {
      const pattern = [
        "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)",
        "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))"
      ].join("|");
      return new RegExp(pattern, onlyFirst ? void 0 : "g");
    };
  }
});

// node_modules/strip-ansi/index.js
var require_strip_ansi = __commonJS({
  "node_modules/strip-ansi/index.js"(exports, module2) {
    "use strict";
    var ansiRegex = require_ansi_regex();
    module2.exports = (string) => typeof string === "string" ? string.replace(ansiRegex(), "") : string;
  }
});

// node_modules/is-fullwidth-code-point/index.js
var require_is_fullwidth_code_point = __commonJS({
  "node_modules/is-fullwidth-code-point/index.js"(exports, module2) {
    "use strict";
    var isFullwidthCodePoint = (codePoint) => {
      if (Number.isNaN(codePoint)) {
        return false;
      }
      if (codePoint >= 4352 && (codePoint <= 4447 || codePoint === 9001 || codePoint === 9002 || 11904 <= codePoint && codePoint <= 12871 && codePoint !== 12351 || 12880 <= codePoint && codePoint <= 19903 || 19968 <= codePoint && codePoint <= 42182 || 43360 <= codePoint && codePoint <= 43388 || 44032 <= codePoint && codePoint <= 55203 || 63744 <= codePoint && codePoint <= 64255 || 65040 <= codePoint && codePoint <= 65049 || 65072 <= codePoint && codePoint <= 65131 || 65281 <= codePoint && codePoint <= 65376 || 65504 <= codePoint && codePoint <= 65510 || 110592 <= codePoint && codePoint <= 110593 || 127488 <= codePoint && codePoint <= 127569 || 131072 <= codePoint && codePoint <= 262141)) {
        return true;
      }
      return false;
    };
    module2.exports = isFullwidthCodePoint;
    module2.exports.default = isFullwidthCodePoint;
  }
});

// node_modules/emoji-regex/index.js
var require_emoji_regex = __commonJS({
  "node_modules/emoji-regex/index.js"(exports, module2) {
    "use strict";
    module2.exports = function() {
      return /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F|\uD83D\uDC68(?:\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68\uD83C\uDFFB|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|[\u2695\u2696\u2708]\uFE0F|\uD83D[\uDC66\uDC67]|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708])\uFE0F|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C[\uDFFB-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)\uD83C\uDFFB|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB\uDFFC])|\uD83D\uDC69(?:\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB-\uDFFD])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83C\uDFF4\u200D\u2620)\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDF6\uD83C\uDDE6|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDBB\uDDD2-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5\uDEEB\uDEEC\uDEF4-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
    };
  }
});

// node_modules/string-width/index.js
var require_string_width = __commonJS({
  "node_modules/string-width/index.js"(exports, module2) {
    "use strict";
    var stripAnsi2 = require_strip_ansi();
    var isFullwidthCodePoint = require_is_fullwidth_code_point();
    var emojiRegex = require_emoji_regex();
    var stringWidth = (string) => {
      if (typeof string !== "string" || string.length === 0) {
        return 0;
      }
      string = stripAnsi2(string);
      if (string.length === 0) {
        return 0;
      }
      string = string.replace(emojiRegex(), "  ");
      let width = 0;
      for (let i = 0; i < string.length; i++) {
        const code = string.codePointAt(i);
        if (code <= 31 || code >= 127 && code <= 159) {
          continue;
        }
        if (code >= 768 && code <= 879) {
          continue;
        }
        if (code > 65535) {
          i++;
        }
        width += isFullwidthCodePoint(code) ? 2 : 1;
      }
      return width;
    };
    module2.exports = stringWidth;
    module2.exports.default = stringWidth;
  }
});

// node_modules/color-name/index.js
var require_color_name = __commonJS({
  "node_modules/color-name/index.js"(exports, module2) {
    "use strict";
    module2.exports = {
      "aliceblue": [240, 248, 255],
      "antiquewhite": [250, 235, 215],
      "aqua": [0, 255, 255],
      "aquamarine": [127, 255, 212],
      "azure": [240, 255, 255],
      "beige": [245, 245, 220],
      "bisque": [255, 228, 196],
      "black": [0, 0, 0],
      "blanchedalmond": [255, 235, 205],
      "blue": [0, 0, 255],
      "blueviolet": [138, 43, 226],
      "brown": [165, 42, 42],
      "burlywood": [222, 184, 135],
      "cadetblue": [95, 158, 160],
      "chartreuse": [127, 255, 0],
      "chocolate": [210, 105, 30],
      "coral": [255, 127, 80],
      "cornflowerblue": [100, 149, 237],
      "cornsilk": [255, 248, 220],
      "crimson": [220, 20, 60],
      "cyan": [0, 255, 255],
      "darkblue": [0, 0, 139],
      "darkcyan": [0, 139, 139],
      "darkgoldenrod": [184, 134, 11],
      "darkgray": [169, 169, 169],
      "darkgreen": [0, 100, 0],
      "darkgrey": [169, 169, 169],
      "darkkhaki": [189, 183, 107],
      "darkmagenta": [139, 0, 139],
      "darkolivegreen": [85, 107, 47],
      "darkorange": [255, 140, 0],
      "darkorchid": [153, 50, 204],
      "darkred": [139, 0, 0],
      "darksalmon": [233, 150, 122],
      "darkseagreen": [143, 188, 143],
      "darkslateblue": [72, 61, 139],
      "darkslategray": [47, 79, 79],
      "darkslategrey": [47, 79, 79],
      "darkturquoise": [0, 206, 209],
      "darkviolet": [148, 0, 211],
      "deeppink": [255, 20, 147],
      "deepskyblue": [0, 191, 255],
      "dimgray": [105, 105, 105],
      "dimgrey": [105, 105, 105],
      "dodgerblue": [30, 144, 255],
      "firebrick": [178, 34, 34],
      "floralwhite": [255, 250, 240],
      "forestgreen": [34, 139, 34],
      "fuchsia": [255, 0, 255],
      "gainsboro": [220, 220, 220],
      "ghostwhite": [248, 248, 255],
      "gold": [255, 215, 0],
      "goldenrod": [218, 165, 32],
      "gray": [128, 128, 128],
      "green": [0, 128, 0],
      "greenyellow": [173, 255, 47],
      "grey": [128, 128, 128],
      "honeydew": [240, 255, 240],
      "hotpink": [255, 105, 180],
      "indianred": [205, 92, 92],
      "indigo": [75, 0, 130],
      "ivory": [255, 255, 240],
      "khaki": [240, 230, 140],
      "lavender": [230, 230, 250],
      "lavenderblush": [255, 240, 245],
      "lawngreen": [124, 252, 0],
      "lemonchiffon": [255, 250, 205],
      "lightblue": [173, 216, 230],
      "lightcoral": [240, 128, 128],
      "lightcyan": [224, 255, 255],
      "lightgoldenrodyellow": [250, 250, 210],
      "lightgray": [211, 211, 211],
      "lightgreen": [144, 238, 144],
      "lightgrey": [211, 211, 211],
      "lightpink": [255, 182, 193],
      "lightsalmon": [255, 160, 122],
      "lightseagreen": [32, 178, 170],
      "lightskyblue": [135, 206, 250],
      "lightslategray": [119, 136, 153],
      "lightslategrey": [119, 136, 153],
      "lightsteelblue": [176, 196, 222],
      "lightyellow": [255, 255, 224],
      "lime": [0, 255, 0],
      "limegreen": [50, 205, 50],
      "linen": [250, 240, 230],
      "magenta": [255, 0, 255],
      "maroon": [128, 0, 0],
      "mediumaquamarine": [102, 205, 170],
      "mediumblue": [0, 0, 205],
      "mediumorchid": [186, 85, 211],
      "mediumpurple": [147, 112, 219],
      "mediumseagreen": [60, 179, 113],
      "mediumslateblue": [123, 104, 238],
      "mediumspringgreen": [0, 250, 154],
      "mediumturquoise": [72, 209, 204],
      "mediumvioletred": [199, 21, 133],
      "midnightblue": [25, 25, 112],
      "mintcream": [245, 255, 250],
      "mistyrose": [255, 228, 225],
      "moccasin": [255, 228, 181],
      "navajowhite": [255, 222, 173],
      "navy": [0, 0, 128],
      "oldlace": [253, 245, 230],
      "olive": [128, 128, 0],
      "olivedrab": [107, 142, 35],
      "orange": [255, 165, 0],
      "orangered": [255, 69, 0],
      "orchid": [218, 112, 214],
      "palegoldenrod": [238, 232, 170],
      "palegreen": [152, 251, 152],
      "paleturquoise": [175, 238, 238],
      "palevioletred": [219, 112, 147],
      "papayawhip": [255, 239, 213],
      "peachpuff": [255, 218, 185],
      "peru": [205, 133, 63],
      "pink": [255, 192, 203],
      "plum": [221, 160, 221],
      "powderblue": [176, 224, 230],
      "purple": [128, 0, 128],
      "rebeccapurple": [102, 51, 153],
      "red": [255, 0, 0],
      "rosybrown": [188, 143, 143],
      "royalblue": [65, 105, 225],
      "saddlebrown": [139, 69, 19],
      "salmon": [250, 128, 114],
      "sandybrown": [244, 164, 96],
      "seagreen": [46, 139, 87],
      "seashell": [255, 245, 238],
      "sienna": [160, 82, 45],
      "silver": [192, 192, 192],
      "skyblue": [135, 206, 235],
      "slateblue": [106, 90, 205],
      "slategray": [112, 128, 144],
      "slategrey": [112, 128, 144],
      "snow": [255, 250, 250],
      "springgreen": [0, 255, 127],
      "steelblue": [70, 130, 180],
      "tan": [210, 180, 140],
      "teal": [0, 128, 128],
      "thistle": [216, 191, 216],
      "tomato": [255, 99, 71],
      "turquoise": [64, 224, 208],
      "violet": [238, 130, 238],
      "wheat": [245, 222, 179],
      "white": [255, 255, 255],
      "whitesmoke": [245, 245, 245],
      "yellow": [255, 255, 0],
      "yellowgreen": [154, 205, 50]
    };
  }
});

// node_modules/color-convert/conversions.js
var require_conversions = __commonJS({
  "node_modules/color-convert/conversions.js"(exports, module2) {
    var cssKeywords = require_color_name();
    var reverseKeywords = {};
    for (const key of Object.keys(cssKeywords)) {
      reverseKeywords[cssKeywords[key]] = key;
    }
    var convert = {
      rgb: { channels: 3, labels: "rgb" },
      hsl: { channels: 3, labels: "hsl" },
      hsv: { channels: 3, labels: "hsv" },
      hwb: { channels: 3, labels: "hwb" },
      cmyk: { channels: 4, labels: "cmyk" },
      xyz: { channels: 3, labels: "xyz" },
      lab: { channels: 3, labels: "lab" },
      lch: { channels: 3, labels: "lch" },
      hex: { channels: 1, labels: ["hex"] },
      keyword: { channels: 1, labels: ["keyword"] },
      ansi16: { channels: 1, labels: ["ansi16"] },
      ansi256: { channels: 1, labels: ["ansi256"] },
      hcg: { channels: 3, labels: ["h", "c", "g"] },
      apple: { channels: 3, labels: ["r16", "g16", "b16"] },
      gray: { channels: 1, labels: ["gray"] }
    };
    module2.exports = convert;
    for (const model of Object.keys(convert)) {
      if (!("channels" in convert[model])) {
        throw new Error("missing channels property: " + model);
      }
      if (!("labels" in convert[model])) {
        throw new Error("missing channel labels property: " + model);
      }
      if (convert[model].labels.length !== convert[model].channels) {
        throw new Error("channel and label counts mismatch: " + model);
      }
      const { channels, labels } = convert[model];
      delete convert[model].channels;
      delete convert[model].labels;
      Object.defineProperty(convert[model], "channels", { value: channels });
      Object.defineProperty(convert[model], "labels", { value: labels });
    }
    convert.rgb.hsl = function(rgb) {
      const r = rgb[0] / 255;
      const g = rgb[1] / 255;
      const b = rgb[2] / 255;
      const min = Math.min(r, g, b);
      const max = Math.max(r, g, b);
      const delta = max - min;
      let h;
      let s;
      if (max === min) {
        h = 0;
      } else if (r === max) {
        h = (g - b) / delta;
      } else if (g === max) {
        h = 2 + (b - r) / delta;
      } else if (b === max) {
        h = 4 + (r - g) / delta;
      }
      h = Math.min(h * 60, 360);
      if (h < 0) {
        h += 360;
      }
      const l = (min + max) / 2;
      if (max === min) {
        s = 0;
      } else if (l <= 0.5) {
        s = delta / (max + min);
      } else {
        s = delta / (2 - max - min);
      }
      return [h, s * 100, l * 100];
    };
    convert.rgb.hsv = function(rgb) {
      let rdif;
      let gdif;
      let bdif;
      let h;
      let s;
      const r = rgb[0] / 255;
      const g = rgb[1] / 255;
      const b = rgb[2] / 255;
      const v = Math.max(r, g, b);
      const diff = v - Math.min(r, g, b);
      const diffc = function(c) {
        return (v - c) / 6 / diff + 1 / 2;
      };
      if (diff === 0) {
        h = 0;
        s = 0;
      } else {
        s = diff / v;
        rdif = diffc(r);
        gdif = diffc(g);
        bdif = diffc(b);
        if (r === v) {
          h = bdif - gdif;
        } else if (g === v) {
          h = 1 / 3 + rdif - bdif;
        } else if (b === v) {
          h = 2 / 3 + gdif - rdif;
        }
        if (h < 0) {
          h += 1;
        } else if (h > 1) {
          h -= 1;
        }
      }
      return [
        h * 360,
        s * 100,
        v * 100
      ];
    };
    convert.rgb.hwb = function(rgb) {
      const r = rgb[0];
      const g = rgb[1];
      let b = rgb[2];
      const h = convert.rgb.hsl(rgb)[0];
      const w = 1 / 255 * Math.min(r, Math.min(g, b));
      b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));
      return [h, w * 100, b * 100];
    };
    convert.rgb.cmyk = function(rgb) {
      const r = rgb[0] / 255;
      const g = rgb[1] / 255;
      const b = rgb[2] / 255;
      const k = Math.min(1 - r, 1 - g, 1 - b);
      const c = (1 - r - k) / (1 - k) || 0;
      const m = (1 - g - k) / (1 - k) || 0;
      const y = (1 - b - k) / (1 - k) || 0;
      return [c * 100, m * 100, y * 100, k * 100];
    };
    function comparativeDistance(x, y) {
      return (x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2 + (x[2] - y[2]) ** 2;
    }
    convert.rgb.keyword = function(rgb) {
      const reversed = reverseKeywords[rgb];
      if (reversed) {
        return reversed;
      }
      let currentClosestDistance = Infinity;
      let currentClosestKeyword;
      for (const keyword of Object.keys(cssKeywords)) {
        const value = cssKeywords[keyword];
        const distance = comparativeDistance(rgb, value);
        if (distance < currentClosestDistance) {
          currentClosestDistance = distance;
          currentClosestKeyword = keyword;
        }
      }
      return currentClosestKeyword;
    };
    convert.keyword.rgb = function(keyword) {
      return cssKeywords[keyword];
    };
    convert.rgb.xyz = function(rgb) {
      let r = rgb[0] / 255;
      let g = rgb[1] / 255;
      let b = rgb[2] / 255;
      r = r > 0.04045 ? ((r + 0.055) / 1.055) ** 2.4 : r / 12.92;
      g = g > 0.04045 ? ((g + 0.055) / 1.055) ** 2.4 : g / 12.92;
      b = b > 0.04045 ? ((b + 0.055) / 1.055) ** 2.4 : b / 12.92;
      const x = r * 0.4124 + g * 0.3576 + b * 0.1805;
      const y = r * 0.2126 + g * 0.7152 + b * 0.0722;
      const z = r * 0.0193 + g * 0.1192 + b * 0.9505;
      return [x * 100, y * 100, z * 100];
    };
    convert.rgb.lab = function(rgb) {
      const xyz = convert.rgb.xyz(rgb);
      let x = xyz[0];
      let y = xyz[1];
      let z = xyz[2];
      x /= 95.047;
      y /= 100;
      z /= 108.883;
      x = x > 8856e-6 ? x ** (1 / 3) : 7.787 * x + 16 / 116;
      y = y > 8856e-6 ? y ** (1 / 3) : 7.787 * y + 16 / 116;
      z = z > 8856e-6 ? z ** (1 / 3) : 7.787 * z + 16 / 116;
      const l = 116 * y - 16;
      const a = 500 * (x - y);
      const b = 200 * (y - z);
      return [l, a, b];
    };
    convert.hsl.rgb = function(hsl) {
      const h = hsl[0] / 360;
      const s = hsl[1] / 100;
      const l = hsl[2] / 100;
      let t2;
      let t3;
      let val;
      if (s === 0) {
        val = l * 255;
        return [val, val, val];
      }
      if (l < 0.5) {
        t2 = l * (1 + s);
      } else {
        t2 = l + s - l * s;
      }
      const t1 = 2 * l - t2;
      const rgb = [0, 0, 0];
      for (let i = 0; i < 3; i++) {
        t3 = h + 1 / 3 * -(i - 1);
        if (t3 < 0) {
          t3++;
        }
        if (t3 > 1) {
          t3--;
        }
        if (6 * t3 < 1) {
          val = t1 + (t2 - t1) * 6 * t3;
        } else if (2 * t3 < 1) {
          val = t2;
        } else if (3 * t3 < 2) {
          val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
        } else {
          val = t1;
        }
        rgb[i] = val * 255;
      }
      return rgb;
    };
    convert.hsl.hsv = function(hsl) {
      const h = hsl[0];
      let s = hsl[1] / 100;
      let l = hsl[2] / 100;
      let smin = s;
      const lmin = Math.max(l, 0.01);
      l *= 2;
      s *= l <= 1 ? l : 2 - l;
      smin *= lmin <= 1 ? lmin : 2 - lmin;
      const v = (l + s) / 2;
      const sv = l === 0 ? 2 * smin / (lmin + smin) : 2 * s / (l + s);
      return [h, sv * 100, v * 100];
    };
    convert.hsv.rgb = function(hsv) {
      const h = hsv[0] / 60;
      const s = hsv[1] / 100;
      let v = hsv[2] / 100;
      const hi = Math.floor(h) % 6;
      const f = h - Math.floor(h);
      const p = 255 * v * (1 - s);
      const q = 255 * v * (1 - s * f);
      const t = 255 * v * (1 - s * (1 - f));
      v *= 255;
      switch (hi) {
        case 0:
          return [v, t, p];
        case 1:
          return [q, v, p];
        case 2:
          return [p, v, t];
        case 3:
          return [p, q, v];
        case 4:
          return [t, p, v];
        case 5:
          return [v, p, q];
      }
    };
    convert.hsv.hsl = function(hsv) {
      const h = hsv[0];
      const s = hsv[1] / 100;
      const v = hsv[2] / 100;
      const vmin = Math.max(v, 0.01);
      let sl;
      let l;
      l = (2 - s) * v;
      const lmin = (2 - s) * vmin;
      sl = s * vmin;
      sl /= lmin <= 1 ? lmin : 2 - lmin;
      sl = sl || 0;
      l /= 2;
      return [h, sl * 100, l * 100];
    };
    convert.hwb.rgb = function(hwb) {
      const h = hwb[0] / 360;
      let wh = hwb[1] / 100;
      let bl = hwb[2] / 100;
      const ratio = wh + bl;
      let f;
      if (ratio > 1) {
        wh /= ratio;
        bl /= ratio;
      }
      const i = Math.floor(6 * h);
      const v = 1 - bl;
      f = 6 * h - i;
      if ((i & 1) !== 0) {
        f = 1 - f;
      }
      const n = wh + f * (v - wh);
      let r;
      let g;
      let b;
      switch (i) {
        default:
        case 6:
        case 0:
          r = v;
          g = n;
          b = wh;
          break;
        case 1:
          r = n;
          g = v;
          b = wh;
          break;
        case 2:
          r = wh;
          g = v;
          b = n;
          break;
        case 3:
          r = wh;
          g = n;
          b = v;
          break;
        case 4:
          r = n;
          g = wh;
          b = v;
          break;
        case 5:
          r = v;
          g = wh;
          b = n;
          break;
      }
      return [r * 255, g * 255, b * 255];
    };
    convert.cmyk.rgb = function(cmyk) {
      const c = cmyk[0] / 100;
      const m = cmyk[1] / 100;
      const y = cmyk[2] / 100;
      const k = cmyk[3] / 100;
      const r = 1 - Math.min(1, c * (1 - k) + k);
      const g = 1 - Math.min(1, m * (1 - k) + k);
      const b = 1 - Math.min(1, y * (1 - k) + k);
      return [r * 255, g * 255, b * 255];
    };
    convert.xyz.rgb = function(xyz) {
      const x = xyz[0] / 100;
      const y = xyz[1] / 100;
      const z = xyz[2] / 100;
      let r;
      let g;
      let b;
      r = x * 3.2406 + y * -1.5372 + z * -0.4986;
      g = x * -0.9689 + y * 1.8758 + z * 0.0415;
      b = x * 0.0557 + y * -0.204 + z * 1.057;
      r = r > 31308e-7 ? 1.055 * r ** (1 / 2.4) - 0.055 : r * 12.92;
      g = g > 31308e-7 ? 1.055 * g ** (1 / 2.4) - 0.055 : g * 12.92;
      b = b > 31308e-7 ? 1.055 * b ** (1 / 2.4) - 0.055 : b * 12.92;
      r = Math.min(Math.max(0, r), 1);
      g = Math.min(Math.max(0, g), 1);
      b = Math.min(Math.max(0, b), 1);
      return [r * 255, g * 255, b * 255];
    };
    convert.xyz.lab = function(xyz) {
      let x = xyz[0];
      let y = xyz[1];
      let z = xyz[2];
      x /= 95.047;
      y /= 100;
      z /= 108.883;
      x = x > 8856e-6 ? x ** (1 / 3) : 7.787 * x + 16 / 116;
      y = y > 8856e-6 ? y ** (1 / 3) : 7.787 * y + 16 / 116;
      z = z > 8856e-6 ? z ** (1 / 3) : 7.787 * z + 16 / 116;
      const l = 116 * y - 16;
      const a = 500 * (x - y);
      const b = 200 * (y - z);
      return [l, a, b];
    };
    convert.lab.xyz = function(lab) {
      const l = lab[0];
      const a = lab[1];
      const b = lab[2];
      let x;
      let y;
      let z;
      y = (l + 16) / 116;
      x = a / 500 + y;
      z = y - b / 200;
      const y2 = y ** 3;
      const x2 = x ** 3;
      const z2 = z ** 3;
      y = y2 > 8856e-6 ? y2 : (y - 16 / 116) / 7.787;
      x = x2 > 8856e-6 ? x2 : (x - 16 / 116) / 7.787;
      z = z2 > 8856e-6 ? z2 : (z - 16 / 116) / 7.787;
      x *= 95.047;
      y *= 100;
      z *= 108.883;
      return [x, y, z];
    };
    convert.lab.lch = function(lab) {
      const l = lab[0];
      const a = lab[1];
      const b = lab[2];
      let h;
      const hr = Math.atan2(b, a);
      h = hr * 360 / 2 / Math.PI;
      if (h < 0) {
        h += 360;
      }
      const c = Math.sqrt(a * a + b * b);
      return [l, c, h];
    };
    convert.lch.lab = function(lch) {
      const l = lch[0];
      const c = lch[1];
      const h = lch[2];
      const hr = h / 360 * 2 * Math.PI;
      const a = c * Math.cos(hr);
      const b = c * Math.sin(hr);
      return [l, a, b];
    };
    convert.rgb.ansi16 = function(args, saturation = null) {
      const [r, g, b] = args;
      let value = saturation === null ? convert.rgb.hsv(args)[2] : saturation;
      value = Math.round(value / 50);
      if (value === 0) {
        return 30;
      }
      let ansi2 = 30 + (Math.round(b / 255) << 2 | Math.round(g / 255) << 1 | Math.round(r / 255));
      if (value === 2) {
        ansi2 += 60;
      }
      return ansi2;
    };
    convert.hsv.ansi16 = function(args) {
      return convert.rgb.ansi16(convert.hsv.rgb(args), args[2]);
    };
    convert.rgb.ansi256 = function(args) {
      const r = args[0];
      const g = args[1];
      const b = args[2];
      if (r === g && g === b) {
        if (r < 8) {
          return 16;
        }
        if (r > 248) {
          return 231;
        }
        return Math.round((r - 8) / 247 * 24) + 232;
      }
      const ansi2 = 16 + 36 * Math.round(r / 255 * 5) + 6 * Math.round(g / 255 * 5) + Math.round(b / 255 * 5);
      return ansi2;
    };
    convert.ansi16.rgb = function(args) {
      let color = args % 10;
      if (color === 0 || color === 7) {
        if (args > 50) {
          color += 3.5;
        }
        color = color / 10.5 * 255;
        return [color, color, color];
      }
      const mult = (~~(args > 50) + 1) * 0.5;
      const r = (color & 1) * mult * 255;
      const g = (color >> 1 & 1) * mult * 255;
      const b = (color >> 2 & 1) * mult * 255;
      return [r, g, b];
    };
    convert.ansi256.rgb = function(args) {
      if (args >= 232) {
        const c = (args - 232) * 10 + 8;
        return [c, c, c];
      }
      args -= 16;
      let rem;
      const r = Math.floor(args / 36) / 5 * 255;
      const g = Math.floor((rem = args % 36) / 6) / 5 * 255;
      const b = rem % 6 / 5 * 255;
      return [r, g, b];
    };
    convert.rgb.hex = function(args) {
      const integer = ((Math.round(args[0]) & 255) << 16) + ((Math.round(args[1]) & 255) << 8) + (Math.round(args[2]) & 255);
      const string = integer.toString(16).toUpperCase();
      return "000000".substring(string.length) + string;
    };
    convert.hex.rgb = function(args) {
      const match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
      if (!match) {
        return [0, 0, 0];
      }
      let colorString = match[0];
      if (match[0].length === 3) {
        colorString = colorString.split("").map((char) => {
          return char + char;
        }).join("");
      }
      const integer = parseInt(colorString, 16);
      const r = integer >> 16 & 255;
      const g = integer >> 8 & 255;
      const b = integer & 255;
      return [r, g, b];
    };
    convert.rgb.hcg = function(rgb) {
      const r = rgb[0] / 255;
      const g = rgb[1] / 255;
      const b = rgb[2] / 255;
      const max = Math.max(Math.max(r, g), b);
      const min = Math.min(Math.min(r, g), b);
      const chroma = max - min;
      let grayscale;
      let hue;
      if (chroma < 1) {
        grayscale = min / (1 - chroma);
      } else {
        grayscale = 0;
      }
      if (chroma <= 0) {
        hue = 0;
      } else if (max === r) {
        hue = (g - b) / chroma % 6;
      } else if (max === g) {
        hue = 2 + (b - r) / chroma;
      } else {
        hue = 4 + (r - g) / chroma;
      }
      hue /= 6;
      hue %= 1;
      return [hue * 360, chroma * 100, grayscale * 100];
    };
    convert.hsl.hcg = function(hsl) {
      const s = hsl[1] / 100;
      const l = hsl[2] / 100;
      const c = l < 0.5 ? 2 * s * l : 2 * s * (1 - l);
      let f = 0;
      if (c < 1) {
        f = (l - 0.5 * c) / (1 - c);
      }
      return [hsl[0], c * 100, f * 100];
    };
    convert.hsv.hcg = function(hsv) {
      const s = hsv[1] / 100;
      const v = hsv[2] / 100;
      const c = s * v;
      let f = 0;
      if (c < 1) {
        f = (v - c) / (1 - c);
      }
      return [hsv[0], c * 100, f * 100];
    };
    convert.hcg.rgb = function(hcg) {
      const h = hcg[0] / 360;
      const c = hcg[1] / 100;
      const g = hcg[2] / 100;
      if (c === 0) {
        return [g * 255, g * 255, g * 255];
      }
      const pure = [0, 0, 0];
      const hi = h % 1 * 6;
      const v = hi % 1;
      const w = 1 - v;
      let mg = 0;
      switch (Math.floor(hi)) {
        case 0:
          pure[0] = 1;
          pure[1] = v;
          pure[2] = 0;
          break;
        case 1:
          pure[0] = w;
          pure[1] = 1;
          pure[2] = 0;
          break;
        case 2:
          pure[0] = 0;
          pure[1] = 1;
          pure[2] = v;
          break;
        case 3:
          pure[0] = 0;
          pure[1] = w;
          pure[2] = 1;
          break;
        case 4:
          pure[0] = v;
          pure[1] = 0;
          pure[2] = 1;
          break;
        default:
          pure[0] = 1;
          pure[1] = 0;
          pure[2] = w;
      }
      mg = (1 - c) * g;
      return [
        (c * pure[0] + mg) * 255,
        (c * pure[1] + mg) * 255,
        (c * pure[2] + mg) * 255
      ];
    };
    convert.hcg.hsv = function(hcg) {
      const c = hcg[1] / 100;
      const g = hcg[2] / 100;
      const v = c + g * (1 - c);
      let f = 0;
      if (v > 0) {
        f = c / v;
      }
      return [hcg[0], f * 100, v * 100];
    };
    convert.hcg.hsl = function(hcg) {
      const c = hcg[1] / 100;
      const g = hcg[2] / 100;
      const l = g * (1 - c) + 0.5 * c;
      let s = 0;
      if (l > 0 && l < 0.5) {
        s = c / (2 * l);
      } else if (l >= 0.5 && l < 1) {
        s = c / (2 * (1 - l));
      }
      return [hcg[0], s * 100, l * 100];
    };
    convert.hcg.hwb = function(hcg) {
      const c = hcg[1] / 100;
      const g = hcg[2] / 100;
      const v = c + g * (1 - c);
      return [hcg[0], (v - c) * 100, (1 - v) * 100];
    };
    convert.hwb.hcg = function(hwb) {
      const w = hwb[1] / 100;
      const b = hwb[2] / 100;
      const v = 1 - b;
      const c = v - w;
      let g = 0;
      if (c < 1) {
        g = (v - c) / (1 - c);
      }
      return [hwb[0], c * 100, g * 100];
    };
    convert.apple.rgb = function(apple) {
      return [apple[0] / 65535 * 255, apple[1] / 65535 * 255, apple[2] / 65535 * 255];
    };
    convert.rgb.apple = function(rgb) {
      return [rgb[0] / 255 * 65535, rgb[1] / 255 * 65535, rgb[2] / 255 * 65535];
    };
    convert.gray.rgb = function(args) {
      return [args[0] / 100 * 255, args[0] / 100 * 255, args[0] / 100 * 255];
    };
    convert.gray.hsl = function(args) {
      return [0, 0, args[0]];
    };
    convert.gray.hsv = convert.gray.hsl;
    convert.gray.hwb = function(gray) {
      return [0, 100, gray[0]];
    };
    convert.gray.cmyk = function(gray) {
      return [0, 0, 0, gray[0]];
    };
    convert.gray.lab = function(gray) {
      return [gray[0], 0, 0];
    };
    convert.gray.hex = function(gray) {
      const val = Math.round(gray[0] / 100 * 255) & 255;
      const integer = (val << 16) + (val << 8) + val;
      const string = integer.toString(16).toUpperCase();
      return "000000".substring(string.length) + string;
    };
    convert.rgb.gray = function(rgb) {
      const val = (rgb[0] + rgb[1] + rgb[2]) / 3;
      return [val / 255 * 100];
    };
  }
});

// node_modules/color-convert/route.js
var require_route = __commonJS({
  "node_modules/color-convert/route.js"(exports, module2) {
    var conversions = require_conversions();
    function buildGraph() {
      const graph = {};
      const models = Object.keys(conversions);
      for (let len = models.length, i = 0; i < len; i++) {
        graph[models[i]] = {
          distance: -1,
          parent: null
        };
      }
      return graph;
    }
    function deriveBFS(fromModel) {
      const graph = buildGraph();
      const queue = [fromModel];
      graph[fromModel].distance = 0;
      while (queue.length) {
        const current = queue.pop();
        const adjacents = Object.keys(conversions[current]);
        for (let len = adjacents.length, i = 0; i < len; i++) {
          const adjacent = adjacents[i];
          const node = graph[adjacent];
          if (node.distance === -1) {
            node.distance = graph[current].distance + 1;
            node.parent = current;
            queue.unshift(adjacent);
          }
        }
      }
      return graph;
    }
    function link(from, to) {
      return function(args) {
        return to(from(args));
      };
    }
    function wrapConversion(toModel, graph) {
      const path = [graph[toModel].parent, toModel];
      let fn = conversions[graph[toModel].parent][toModel];
      let cur = graph[toModel].parent;
      while (graph[cur].parent) {
        path.unshift(graph[cur].parent);
        fn = link(conversions[graph[cur].parent][cur], fn);
        cur = graph[cur].parent;
      }
      fn.conversion = path;
      return fn;
    }
    module2.exports = function(fromModel) {
      const graph = deriveBFS(fromModel);
      const conversion = {};
      const models = Object.keys(graph);
      for (let len = models.length, i = 0; i < len; i++) {
        const toModel = models[i];
        const node = graph[toModel];
        if (node.parent === null) {
          continue;
        }
        conversion[toModel] = wrapConversion(toModel, graph);
      }
      return conversion;
    };
  }
});

// node_modules/color-convert/index.js
var require_color_convert = __commonJS({
  "node_modules/color-convert/index.js"(exports, module2) {
    var conversions = require_conversions();
    var route = require_route();
    var convert = {};
    var models = Object.keys(conversions);
    function wrapRaw(fn) {
      const wrappedFn = function(...args) {
        const arg0 = args[0];
        if (arg0 === void 0 || arg0 === null) {
          return arg0;
        }
        if (arg0.length > 1) {
          args = arg0;
        }
        return fn(args);
      };
      if ("conversion" in fn) {
        wrappedFn.conversion = fn.conversion;
      }
      return wrappedFn;
    }
    function wrapRounded(fn) {
      const wrappedFn = function(...args) {
        const arg0 = args[0];
        if (arg0 === void 0 || arg0 === null) {
          return arg0;
        }
        if (arg0.length > 1) {
          args = arg0;
        }
        const result = fn(args);
        if (typeof result === "object") {
          for (let len = result.length, i = 0; i < len; i++) {
            result[i] = Math.round(result[i]);
          }
        }
        return result;
      };
      if ("conversion" in fn) {
        wrappedFn.conversion = fn.conversion;
      }
      return wrappedFn;
    }
    models.forEach((fromModel) => {
      convert[fromModel] = {};
      Object.defineProperty(convert[fromModel], "channels", { value: conversions[fromModel].channels });
      Object.defineProperty(convert[fromModel], "labels", { value: conversions[fromModel].labels });
      const routes = route(fromModel);
      const routeModels = Object.keys(routes);
      routeModels.forEach((toModel) => {
        const fn = routes[toModel];
        convert[fromModel][toModel] = wrapRounded(fn);
        convert[fromModel][toModel].raw = wrapRaw(fn);
      });
    });
    module2.exports = convert;
  }
});

// node_modules/ansi-styles/index.js
var require_ansi_styles = __commonJS({
  "node_modules/ansi-styles/index.js"(exports, module2) {
    "use strict";
    var wrapAnsi16 = (fn, offset) => (...args) => {
      const code = fn(...args);
      return `\x1B[${code + offset}m`;
    };
    var wrapAnsi256 = (fn, offset) => (...args) => {
      const code = fn(...args);
      return `\x1B[${38 + offset};5;${code}m`;
    };
    var wrapAnsi16m = (fn, offset) => (...args) => {
      const rgb = fn(...args);
      return `\x1B[${38 + offset};2;${rgb[0]};${rgb[1]};${rgb[2]}m`;
    };
    var ansi2ansi = (n) => n;
    var rgb2rgb = (r, g, b) => [r, g, b];
    var setLazyProperty = (object, property, get) => {
      Object.defineProperty(object, property, {
        get: () => {
          const value = get();
          Object.defineProperty(object, property, {
            value,
            enumerable: true,
            configurable: true
          });
          return value;
        },
        enumerable: true,
        configurable: true
      });
    };
    var colorConvert;
    var makeDynamicStyles = (wrap2, targetSpace, identity, isBackground) => {
      if (colorConvert === void 0) {
        colorConvert = require_color_convert();
      }
      const offset = isBackground ? 10 : 0;
      const styles = {};
      for (const [sourceSpace, suite] of Object.entries(colorConvert)) {
        const name = sourceSpace === "ansi16" ? "ansi" : sourceSpace;
        if (sourceSpace === targetSpace) {
          styles[name] = wrap2(identity, offset);
        } else if (typeof suite === "object") {
          styles[name] = wrap2(suite[targetSpace], offset);
        }
      }
      return styles;
    };
    function assembleStyles() {
      const codes = /* @__PURE__ */ new Map();
      const styles = {
        modifier: {
          reset: [0, 0],
          bold: [1, 22],
          dim: [2, 22],
          italic: [3, 23],
          underline: [4, 24],
          inverse: [7, 27],
          hidden: [8, 28],
          strikethrough: [9, 29]
        },
        color: {
          black: [30, 39],
          red: [31, 39],
          green: [32, 39],
          yellow: [33, 39],
          blue: [34, 39],
          magenta: [35, 39],
          cyan: [36, 39],
          white: [37, 39],
          blackBright: [90, 39],
          redBright: [91, 39],
          greenBright: [92, 39],
          yellowBright: [93, 39],
          blueBright: [94, 39],
          magentaBright: [95, 39],
          cyanBright: [96, 39],
          whiteBright: [97, 39]
        },
        bgColor: {
          bgBlack: [40, 49],
          bgRed: [41, 49],
          bgGreen: [42, 49],
          bgYellow: [43, 49],
          bgBlue: [44, 49],
          bgMagenta: [45, 49],
          bgCyan: [46, 49],
          bgWhite: [47, 49],
          bgBlackBright: [100, 49],
          bgRedBright: [101, 49],
          bgGreenBright: [102, 49],
          bgYellowBright: [103, 49],
          bgBlueBright: [104, 49],
          bgMagentaBright: [105, 49],
          bgCyanBright: [106, 49],
          bgWhiteBright: [107, 49]
        }
      };
      styles.color.gray = styles.color.blackBright;
      styles.bgColor.bgGray = styles.bgColor.bgBlackBright;
      styles.color.grey = styles.color.blackBright;
      styles.bgColor.bgGrey = styles.bgColor.bgBlackBright;
      for (const [groupName, group] of Object.entries(styles)) {
        for (const [styleName, style] of Object.entries(group)) {
          styles[styleName] = {
            open: `\x1B[${style[0]}m`,
            close: `\x1B[${style[1]}m`
          };
          group[styleName] = styles[styleName];
          codes.set(style[0], style[1]);
        }
        Object.defineProperty(styles, groupName, {
          value: group,
          enumerable: false
        });
      }
      Object.defineProperty(styles, "codes", {
        value: codes,
        enumerable: false
      });
      styles.color.close = "\x1B[39m";
      styles.bgColor.close = "\x1B[49m";
      setLazyProperty(styles.color, "ansi", () => makeDynamicStyles(wrapAnsi16, "ansi16", ansi2ansi, false));
      setLazyProperty(styles.color, "ansi256", () => makeDynamicStyles(wrapAnsi256, "ansi256", ansi2ansi, false));
      setLazyProperty(styles.color, "ansi16m", () => makeDynamicStyles(wrapAnsi16m, "rgb", rgb2rgb, false));
      setLazyProperty(styles.bgColor, "ansi", () => makeDynamicStyles(wrapAnsi16, "ansi16", ansi2ansi, true));
      setLazyProperty(styles.bgColor, "ansi256", () => makeDynamicStyles(wrapAnsi256, "ansi256", ansi2ansi, true));
      setLazyProperty(styles.bgColor, "ansi16m", () => makeDynamicStyles(wrapAnsi16m, "rgb", rgb2rgb, true));
      return styles;
    }
    Object.defineProperty(module2, "exports", {
      enumerable: true,
      get: assembleStyles
    });
  }
});

// node_modules/wrap-ansi/index.js
var require_wrap_ansi = __commonJS({
  "node_modules/wrap-ansi/index.js"(exports, module2) {
    "use strict";
    var stringWidth = require_string_width();
    var stripAnsi2 = require_strip_ansi();
    var ansiStyles = require_ansi_styles();
    var ESCAPES = /* @__PURE__ */ new Set([
      "\x1B",
      "\x9B"
    ]);
    var END_CODE = 39;
    var ANSI_ESCAPE_BELL = "\x07";
    var ANSI_CSI = "[";
    var ANSI_OSC = "]";
    var ANSI_SGR_TERMINATOR = "m";
    var ANSI_ESCAPE_LINK = `${ANSI_OSC}8;;`;
    var wrapAnsi = (code) => `${ESCAPES.values().next().value}${ANSI_CSI}${code}${ANSI_SGR_TERMINATOR}`;
    var wrapAnsiHyperlink = (uri) => `${ESCAPES.values().next().value}${ANSI_ESCAPE_LINK}${uri}${ANSI_ESCAPE_BELL}`;
    var wordLengths = (string) => string.split(" ").map((character) => stringWidth(character));
    var wrapWord = (rows, word, columns) => {
      const characters = [...word];
      let isInsideEscape = false;
      let isInsideLinkEscape = false;
      let visible = stringWidth(stripAnsi2(rows[rows.length - 1]));
      for (const [index, character] of characters.entries()) {
        const characterLength = stringWidth(character);
        if (visible + characterLength <= columns) {
          rows[rows.length - 1] += character;
        } else {
          rows.push(character);
          visible = 0;
        }
        if (ESCAPES.has(character)) {
          isInsideEscape = true;
          isInsideLinkEscape = characters.slice(index + 1).join("").startsWith(ANSI_ESCAPE_LINK);
        }
        if (isInsideEscape) {
          if (isInsideLinkEscape) {
            if (character === ANSI_ESCAPE_BELL) {
              isInsideEscape = false;
              isInsideLinkEscape = false;
            }
          } else if (character === ANSI_SGR_TERMINATOR) {
            isInsideEscape = false;
          }
          continue;
        }
        visible += characterLength;
        if (visible === columns && index < characters.length - 1) {
          rows.push("");
          visible = 0;
        }
      }
      if (!visible && rows[rows.length - 1].length > 0 && rows.length > 1) {
        rows[rows.length - 2] += rows.pop();
      }
    };
    var stringVisibleTrimSpacesRight = (string) => {
      const words = string.split(" ");
      let last = words.length;
      while (last > 0) {
        if (stringWidth(words[last - 1]) > 0) {
          break;
        }
        last--;
      }
      if (last === words.length) {
        return string;
      }
      return words.slice(0, last).join(" ") + words.slice(last).join("");
    };
    var exec = (string, columns, options = {}) => {
      if (options.trim !== false && string.trim() === "") {
        return "";
      }
      let returnValue = "";
      let escapeCode;
      let escapeUrl;
      const lengths = wordLengths(string);
      let rows = [""];
      for (const [index, word] of string.split(" ").entries()) {
        if (options.trim !== false) {
          rows[rows.length - 1] = rows[rows.length - 1].trimStart();
        }
        let rowLength = stringWidth(rows[rows.length - 1]);
        if (index !== 0) {
          if (rowLength >= columns && (options.wordWrap === false || options.trim === false)) {
            rows.push("");
            rowLength = 0;
          }
          if (rowLength > 0 || options.trim === false) {
            rows[rows.length - 1] += " ";
            rowLength++;
          }
        }
        if (options.hard && lengths[index] > columns) {
          const remainingColumns = columns - rowLength;
          const breaksStartingThisLine = 1 + Math.floor((lengths[index] - remainingColumns - 1) / columns);
          const breaksStartingNextLine = Math.floor((lengths[index] - 1) / columns);
          if (breaksStartingNextLine < breaksStartingThisLine) {
            rows.push("");
          }
          wrapWord(rows, word, columns);
          continue;
        }
        if (rowLength + lengths[index] > columns && rowLength > 0 && lengths[index] > 0) {
          if (options.wordWrap === false && rowLength < columns) {
            wrapWord(rows, word, columns);
            continue;
          }
          rows.push("");
        }
        if (rowLength + lengths[index] > columns && options.wordWrap === false) {
          wrapWord(rows, word, columns);
          continue;
        }
        rows[rows.length - 1] += word;
      }
      if (options.trim !== false) {
        rows = rows.map(stringVisibleTrimSpacesRight);
      }
      const pre = [...rows.join("\n")];
      for (const [index, character] of pre.entries()) {
        returnValue += character;
        if (ESCAPES.has(character)) {
          const { groups } = new RegExp(`(?:\\${ANSI_CSI}(?<code>\\d+)m|\\${ANSI_ESCAPE_LINK}(?<uri>.*)${ANSI_ESCAPE_BELL})`).exec(pre.slice(index).join("")) || { groups: {} };
          if (groups.code !== void 0) {
            const code2 = Number.parseFloat(groups.code);
            escapeCode = code2 === END_CODE ? void 0 : code2;
          } else if (groups.uri !== void 0) {
            escapeUrl = groups.uri.length === 0 ? void 0 : groups.uri;
          }
        }
        const code = ansiStyles.codes.get(Number(escapeCode));
        if (pre[index + 1] === "\n") {
          if (escapeUrl) {
            returnValue += wrapAnsiHyperlink("");
          }
          if (escapeCode && code) {
            returnValue += wrapAnsi(code);
          }
        } else if (character === "\n") {
          if (escapeCode && code) {
            returnValue += wrapAnsi(escapeCode);
          }
          if (escapeUrl) {
            returnValue += wrapAnsiHyperlink(escapeUrl);
          }
        }
      }
      return returnValue;
    };
    module2.exports = (string, columns, options) => {
      return String(string).normalize().replace(/\r\n/g, "\n").split("\n").map((line) => exec(line, columns, options)).join("\n");
    };
  }
});

// node_modules/cliui/build/index.cjs
var require_build3 = __commonJS({
  "node_modules/cliui/build/index.cjs"(exports, module2) {
    "use strict";
    var align2 = {
      right: alignRight2,
      center: alignCenter2
    };
    var top2 = 0;
    var right2 = 1;
    var bottom2 = 2;
    var left2 = 3;
    var UI2 = class {
      constructor(opts) {
        var _a;
        this.width = opts.width;
        this.wrap = (_a = opts.wrap) !== null && _a !== void 0 ? _a : true;
        this.rows = [];
      }
      span(...args) {
        const cols = this.div(...args);
        cols.span = true;
      }
      resetOutput() {
        this.rows = [];
      }
      div(...args) {
        if (args.length === 0) {
          this.div("");
        }
        if (this.wrap && this.shouldApplyLayoutDSL(...args) && typeof args[0] === "string") {
          return this.applyLayoutDSL(args[0]);
        }
        const cols = args.map((arg) => {
          if (typeof arg === "string") {
            return this.colFromString(arg);
          }
          return arg;
        });
        this.rows.push(cols);
        return cols;
      }
      shouldApplyLayoutDSL(...args) {
        return args.length === 1 && typeof args[0] === "string" && /[\t\n]/.test(args[0]);
      }
      applyLayoutDSL(str2) {
        const rows = str2.split("\n").map((row) => row.split("	"));
        let leftColumnWidth = 0;
        rows.forEach((columns) => {
          if (columns.length > 1 && mixin3.stringWidth(columns[0]) > leftColumnWidth) {
            leftColumnWidth = Math.min(Math.floor(this.width * 0.5), mixin3.stringWidth(columns[0]));
          }
        });
        rows.forEach((columns) => {
          this.div(...columns.map((r, i) => {
            return {
              text: r.trim(),
              padding: this.measurePadding(r),
              width: i === 0 && columns.length > 1 ? leftColumnWidth : void 0
            };
          }));
        });
        return this.rows[this.rows.length - 1];
      }
      colFromString(text2) {
        return {
          text: text2,
          padding: this.measurePadding(text2)
        };
      }
      measurePadding(str2) {
        const noAnsi = mixin3.stripAnsi(str2);
        return [0, noAnsi.match(/\s*$/)[0].length, 0, noAnsi.match(/^\s*/)[0].length];
      }
      toString() {
        const lines = [];
        this.rows.forEach((row) => {
          this.rowToString(row, lines);
        });
        return lines.filter((line) => !line.hidden).map((line) => line.text).join("\n");
      }
      rowToString(row, lines) {
        this.rasterize(row).forEach((rrow, r) => {
          let str2 = "";
          rrow.forEach((col, c) => {
            const { width } = row[c];
            const wrapWidth = this.negatePadding(row[c]);
            let ts = col;
            if (wrapWidth > mixin3.stringWidth(col)) {
              ts += " ".repeat(wrapWidth - mixin3.stringWidth(col));
            }
            if (row[c].align && row[c].align !== "left" && this.wrap) {
              const fn = align2[row[c].align];
              ts = fn(ts, wrapWidth);
              if (mixin3.stringWidth(ts) < wrapWidth) {
                ts += " ".repeat((width || 0) - mixin3.stringWidth(ts) - 1);
              }
            }
            const padding = row[c].padding || [0, 0, 0, 0];
            if (padding[left2]) {
              str2 += " ".repeat(padding[left2]);
            }
            str2 += addBorder2(row[c], ts, "| ");
            str2 += ts;
            str2 += addBorder2(row[c], ts, " |");
            if (padding[right2]) {
              str2 += " ".repeat(padding[right2]);
            }
            if (r === 0 && lines.length > 0) {
              str2 = this.renderInline(str2, lines[lines.length - 1]);
            }
          });
          lines.push({
            text: str2.replace(/ +$/, ""),
            span: row.span
          });
        });
        return lines;
      }
      renderInline(source, previousLine) {
        const match = source.match(/^ */);
        const leadingWhitespace = match ? match[0].length : 0;
        const target = previousLine.text;
        const targetTextWidth = mixin3.stringWidth(target.trimRight());
        if (!previousLine.span) {
          return source;
        }
        if (!this.wrap) {
          previousLine.hidden = true;
          return target + source;
        }
        if (leadingWhitespace < targetTextWidth) {
          return source;
        }
        previousLine.hidden = true;
        return target.trimRight() + " ".repeat(leadingWhitespace - targetTextWidth) + source.trimLeft();
      }
      rasterize(row) {
        const rrows = [];
        const widths = this.columnWidths(row);
        let wrapped;
        row.forEach((col, c) => {
          col.width = widths[c];
          if (this.wrap) {
            wrapped = mixin3.wrap(col.text, this.negatePadding(col), { hard: true }).split("\n");
          } else {
            wrapped = col.text.split("\n");
          }
          if (col.border) {
            wrapped.unshift("." + "-".repeat(this.negatePadding(col) + 2) + ".");
            wrapped.push("'" + "-".repeat(this.negatePadding(col) + 2) + "'");
          }
          if (col.padding) {
            wrapped.unshift(...new Array(col.padding[top2] || 0).fill(""));
            wrapped.push(...new Array(col.padding[bottom2] || 0).fill(""));
          }
          wrapped.forEach((str2, r) => {
            if (!rrows[r]) {
              rrows.push([]);
            }
            const rrow = rrows[r];
            for (let i = 0; i < c; i++) {
              if (rrow[i] === void 0) {
                rrow.push("");
              }
            }
            rrow.push(str2);
          });
        });
        return rrows;
      }
      negatePadding(col) {
        let wrapWidth = col.width || 0;
        if (col.padding) {
          wrapWidth -= (col.padding[left2] || 0) + (col.padding[right2] || 0);
        }
        if (col.border) {
          wrapWidth -= 4;
        }
        return wrapWidth;
      }
      columnWidths(row) {
        if (!this.wrap) {
          return row.map((col) => {
            return col.width || mixin3.stringWidth(col.text);
          });
        }
        let unset = row.length;
        let remainingWidth = this.width;
        const widths = row.map((col) => {
          if (col.width) {
            unset--;
            remainingWidth -= col.width;
            return col.width;
          }
          return void 0;
        });
        const unsetWidth = unset ? Math.floor(remainingWidth / unset) : 0;
        return widths.map((w, i) => {
          if (w === void 0) {
            return Math.max(unsetWidth, _minWidth2(row[i]));
          }
          return w;
        });
      }
    };
    function addBorder2(col, ts, style) {
      if (col.border) {
        if (/[.']-+[.']/.test(ts)) {
          return "";
        }
        if (ts.trim().length !== 0) {
          return style;
        }
        return "  ";
      }
      return "";
    }
    function _minWidth2(col) {
      const padding = col.padding || [];
      const minWidth = 1 + (padding[left2] || 0) + (padding[right2] || 0);
      if (col.border) {
        return minWidth + 4;
      }
      return minWidth;
    }
    function getWindowWidth2() {
      if (typeof process === "object" && process.stdout && process.stdout.columns) {
        return process.stdout.columns;
      }
      return 80;
    }
    function alignRight2(str2, width) {
      str2 = str2.trim();
      const strWidth = mixin3.stringWidth(str2);
      if (strWidth < width) {
        return " ".repeat(width - strWidth) + str2;
      }
      return str2;
    }
    function alignCenter2(str2, width) {
      str2 = str2.trim();
      const strWidth = mixin3.stringWidth(str2);
      if (strWidth >= width) {
        return str2;
      }
      return " ".repeat(width - strWidth >> 1) + str2;
    }
    var mixin3;
    function cliui2(opts, _mixin) {
      mixin3 = _mixin;
      return new UI2({
        width: (opts === null || opts === void 0 ? void 0 : opts.width) || getWindowWidth2(),
        wrap: opts === null || opts === void 0 ? void 0 : opts.wrap
      });
    }
    var stringWidth = require_string_width();
    var stripAnsi2 = require_strip_ansi();
    var wrap2 = require_wrap_ansi();
    function ui2(opts) {
      return cliui2(opts, {
        stringWidth,
        stripAnsi: stripAnsi2,
        wrap: wrap2
      });
    }
    module2.exports = ui2;
  }
});

// node_modules/escalade/sync/index.js
var require_sync = __commonJS({
  "node_modules/escalade/sync/index.js"(exports, module2) {
    var { dirname: dirname3, resolve: resolve5 } = require("path");
    var { readdirSync: readdirSync3, statSync: statSync4 } = require("fs");
    module2.exports = function(start, callback) {
      let dir = resolve5(".", start);
      let tmp, stats = statSync4(dir);
      if (!stats.isDirectory()) {
        dir = dirname3(dir);
      }
      while (true) {
        tmp = callback(dir, readdirSync3(dir));
        if (tmp)
          return resolve5(dir, tmp);
        dir = dirname3(tmp = dir);
        if (tmp === dir)
          break;
      }
    };
  }
});

// node_modules/get-caller-file/index.js
var require_get_caller_file = __commonJS({
  "node_modules/get-caller-file/index.js"(exports, module2) {
    "use strict";
    module2.exports = function getCallerFile(position) {
      if (position === void 0) {
        position = 2;
      }
      if (position >= Error.stackTraceLimit) {
        throw new TypeError("getCallerFile(position) requires position be less then Error.stackTraceLimit but position was: `" + position + "` and Error.stackTraceLimit was: `" + Error.stackTraceLimit + "`");
      }
      var oldPrepareStackTrace = Error.prepareStackTrace;
      Error.prepareStackTrace = function(_, stack2) {
        return stack2;
      };
      var stack = new Error().stack;
      Error.prepareStackTrace = oldPrepareStackTrace;
      if (stack !== null && typeof stack === "object") {
        return stack[position] ? stack[position].getFileName() : void 0;
      }
    };
  }
});

// node_modules/require-directory/index.js
var require_require_directory = __commonJS({
  "node_modules/require-directory/index.js"(exports, module2) {
    "use strict";
    var fs3 = require("fs");
    var join = require("path").join;
    var resolve5 = require("path").resolve;
    var dirname3 = require("path").dirname;
    var defaultOptions = {
      extensions: ["js", "json", "coffee"],
      recurse: true,
      rename: function(name) {
        return name;
      },
      visit: function(obj) {
        return obj;
      }
    };
    function checkFileInclusion(path, filename, options) {
      return new RegExp("\\.(" + options.extensions.join("|") + ")$", "i").test(filename) && !(options.include && options.include instanceof RegExp && !options.include.test(path)) && !(options.include && typeof options.include === "function" && !options.include(path, filename)) && !(options.exclude && options.exclude instanceof RegExp && options.exclude.test(path)) && !(options.exclude && typeof options.exclude === "function" && options.exclude(path, filename));
    }
    function requireDirectory(m, path, options) {
      var retval = {};
      if (path && !options && typeof path !== "string") {
        options = path;
        path = null;
      }
      options = options || {};
      for (var prop in defaultOptions) {
        if (typeof options[prop] === "undefined") {
          options[prop] = defaultOptions[prop];
        }
      }
      path = !path ? dirname3(m.filename) : resolve5(dirname3(m.filename), path);
      fs3.readdirSync(path).forEach(function(filename) {
        var joined = join(path, filename), files, key, obj;
        if (fs3.statSync(joined).isDirectory() && options.recurse) {
          files = requireDirectory(m, joined, options);
          if (Object.keys(files).length) {
            retval[options.rename(filename, joined, filename)] = files;
          }
        } else {
          if (joined !== m.filename && checkFileInclusion(joined, filename, options)) {
            key = filename.substring(0, filename.lastIndexOf("."));
            obj = m.require(joined);
            retval[options.rename(key, joined, filename)] = options.visit(obj, joined, filename) || obj;
          }
        }
      });
      return retval;
    }
    module2.exports = requireDirectory;
    module2.exports.defaults = defaultOptions;
  }
});

// node_modules/yargs/build/index.cjs
var require_build4 = __commonJS({
  "node_modules/yargs/build/index.cjs"(exports, module2) {
    "use strict";
    var t = require("assert");
    var e = class extends Error {
      constructor(t2) {
        super(t2 || "yargs error"), this.name = "YError", Error.captureStackTrace && Error.captureStackTrace(this, e);
      }
    };
    var s;
    var i = [];
    function n(t2, o2, a2, h2) {
      s = h2;
      let l2 = {};
      if (Object.prototype.hasOwnProperty.call(t2, "extends")) {
        if ("string" != typeof t2.extends)
          return l2;
        const r2 = /\.json|\..*rc$/.test(t2.extends);
        let h3 = null;
        if (r2)
          h3 = function(t3, e2) {
            return s.path.resolve(t3, e2);
          }(o2, t2.extends);
        else
          try {
            h3 = require.resolve(t2.extends);
          } catch (e2) {
            return t2;
          }
        !function(t3) {
          if (i.indexOf(t3) > -1)
            throw new e(`Circular extended configurations: '${t3}'.`);
        }(h3), i.push(h3), l2 = r2 ? JSON.parse(s.readFileSync(h3, "utf8")) : require(t2.extends), delete t2.extends, l2 = n(l2, s.path.dirname(h3), a2, s);
      }
      return i = [], a2 ? r(l2, t2) : Object.assign({}, l2, t2);
    }
    function r(t2, e2) {
      const s2 = {};
      function i2(t3) {
        return t3 && "object" == typeof t3 && !Array.isArray(t3);
      }
      Object.assign(s2, t2);
      for (const n2 of Object.keys(e2))
        i2(e2[n2]) && i2(s2[n2]) ? s2[n2] = r(t2[n2], e2[n2]) : s2[n2] = e2[n2];
      return s2;
    }
    function o(t2) {
      const e2 = t2.replace(/\s{2,}/g, " ").split(/\s+(?![^[]*]|[^<]*>)/), s2 = /\.*[\][<>]/g, i2 = e2.shift();
      if (!i2)
        throw new Error(`No command found in: ${t2}`);
      const n2 = { cmd: i2.replace(s2, ""), demanded: [], optional: [] };
      return e2.forEach((t3, i3) => {
        let r2 = false;
        t3 = t3.replace(/\s/g, ""), /\.+[\]>]/.test(t3) && i3 === e2.length - 1 && (r2 = true), /^\[/.test(t3) ? n2.optional.push({ cmd: t3.replace(s2, "").split("|"), variadic: r2 }) : n2.demanded.push({ cmd: t3.replace(s2, "").split("|"), variadic: r2 });
      }), n2;
    }
    var a = ["first", "second", "third", "fourth", "fifth", "sixth"];
    function h(t2, s2, i2) {
      try {
        let n2 = 0;
        const [r2, a2, h2] = "object" == typeof t2 ? [{ demanded: [], optional: [] }, t2, s2] : [o(`cmd ${t2}`), s2, i2], f2 = [].slice.call(a2);
        for (; f2.length && void 0 === f2[f2.length - 1]; )
          f2.pop();
        const d2 = h2 || f2.length;
        if (d2 < r2.demanded.length)
          throw new e(`Not enough arguments provided. Expected ${r2.demanded.length} but received ${f2.length}.`);
        const u2 = r2.demanded.length + r2.optional.length;
        if (d2 > u2)
          throw new e(`Too many arguments provided. Expected max ${u2} but received ${d2}.`);
        r2.demanded.forEach((t3) => {
          const e2 = l(f2.shift());
          0 === t3.cmd.filter((t4) => t4 === e2 || "*" === t4).length && c(e2, t3.cmd, n2), n2 += 1;
        }), r2.optional.forEach((t3) => {
          if (0 === f2.length)
            return;
          const e2 = l(f2.shift());
          0 === t3.cmd.filter((t4) => t4 === e2 || "*" === t4).length && c(e2, t3.cmd, n2), n2 += 1;
        });
      } catch (t3) {
        console.warn(t3.stack);
      }
    }
    function l(t2) {
      return Array.isArray(t2) ? "array" : null === t2 ? "null" : typeof t2;
    }
    function c(t2, s2, i2) {
      throw new e(`Invalid ${a[i2] || "manyith"} argument. Expected ${s2.join(" or ")} but received ${t2}.`);
    }
    function f(t2) {
      return !!t2 && !!t2.then && "function" == typeof t2.then;
    }
    function d(t2, e2, s2, i2) {
      s2.assert.notStrictEqual(t2, e2, i2);
    }
    function u(t2, e2) {
      e2.assert.strictEqual(typeof t2, "string");
    }
    function p(t2) {
      return Object.keys(t2);
    }
    function g(t2 = {}, e2 = () => true) {
      const s2 = {};
      return p(t2).forEach((i2) => {
        e2(i2, t2[i2]) && (s2[i2] = t2[i2]);
      }), s2;
    }
    function m() {
      return process.versions.electron && !process.defaultApp ? 0 : 1;
    }
    function y() {
      return process.argv[m()];
    }
    var b = Object.freeze({ __proto__: null, hideBin: function(t2) {
      return t2.slice(m() + 1);
    }, getProcessArgvBin: y });
    function v(t2, e2, s2, i2) {
      if ("a" === s2 && !i2)
        throw new TypeError("Private accessor was defined without a getter");
      if ("function" == typeof e2 ? t2 !== e2 || !i2 : !e2.has(t2))
        throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return "m" === s2 ? i2 : "a" === s2 ? i2.call(t2) : i2 ? i2.value : e2.get(t2);
    }
    function O(t2, e2, s2, i2, n2) {
      if ("m" === i2)
        throw new TypeError("Private method is not writable");
      if ("a" === i2 && !n2)
        throw new TypeError("Private accessor was defined without a setter");
      if ("function" == typeof e2 ? t2 !== e2 || !n2 : !e2.has(t2))
        throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return "a" === i2 ? n2.call(t2, s2) : n2 ? n2.value = s2 : e2.set(t2, s2), s2;
    }
    var w = class {
      constructor(t2) {
        this.globalMiddleware = [], this.frozens = [], this.yargs = t2;
      }
      addMiddleware(t2, e2, s2 = true, i2 = false) {
        if (h("<array|function> [boolean] [boolean] [boolean]", [t2, e2, s2], arguments.length), Array.isArray(t2)) {
          for (let i3 = 0; i3 < t2.length; i3++) {
            if ("function" != typeof t2[i3])
              throw Error("middleware must be a function");
            const n2 = t2[i3];
            n2.applyBeforeValidation = e2, n2.global = s2;
          }
          Array.prototype.push.apply(this.globalMiddleware, t2);
        } else if ("function" == typeof t2) {
          const n2 = t2;
          n2.applyBeforeValidation = e2, n2.global = s2, n2.mutates = i2, this.globalMiddleware.push(t2);
        }
        return this.yargs;
      }
      addCoerceMiddleware(t2, e2) {
        const s2 = this.yargs.getAliases();
        return this.globalMiddleware = this.globalMiddleware.filter((t3) => {
          const i2 = [...s2[e2] || [], e2];
          return !t3.option || !i2.includes(t3.option);
        }), t2.option = e2, this.addMiddleware(t2, true, true, true);
      }
      getMiddleware() {
        return this.globalMiddleware;
      }
      freeze() {
        this.frozens.push([...this.globalMiddleware]);
      }
      unfreeze() {
        const t2 = this.frozens.pop();
        void 0 !== t2 && (this.globalMiddleware = t2);
      }
      reset() {
        this.globalMiddleware = this.globalMiddleware.filter((t2) => t2.global);
      }
    };
    function C(t2, e2, s2, i2) {
      return s2.reduce((t3, s3) => {
        if (s3.applyBeforeValidation !== i2)
          return t3;
        if (s3.mutates) {
          if (s3.applied)
            return t3;
          s3.applied = true;
        }
        if (f(t3))
          return t3.then((t4) => Promise.all([t4, s3(t4, e2)])).then(([t4, e3]) => Object.assign(t4, e3));
        {
          const i3 = s3(t3, e2);
          return f(i3) ? i3.then((e3) => Object.assign(t3, e3)) : Object.assign(t3, i3);
        }
      }, t2);
    }
    function j(t2, e2, s2 = (t3) => {
      throw t3;
    }) {
      try {
        const s3 = "function" == typeof t2 ? t2() : t2;
        return f(s3) ? s3.then((t3) => e2(t3)) : e2(s3);
      } catch (t3) {
        return s2(t3);
      }
    }
    var _ = /(^\*)|(^\$0)/;
    var M = class {
      constructor(t2, e2, s2, i2) {
        this.requireCache = /* @__PURE__ */ new Set(), this.handlers = {}, this.aliasMap = {}, this.frozens = [], this.shim = i2, this.usage = t2, this.globalMiddleware = s2, this.validation = e2;
      }
      addDirectory(t2, e2, s2, i2) {
        "boolean" != typeof (i2 = i2 || {}).recurse && (i2.recurse = false), Array.isArray(i2.extensions) || (i2.extensions = ["js"]);
        const n2 = "function" == typeof i2.visit ? i2.visit : (t3) => t3;
        i2.visit = (t3, e3, s3) => {
          const i3 = n2(t3, e3, s3);
          if (i3) {
            if (this.requireCache.has(e3))
              return i3;
            this.requireCache.add(e3), this.addHandler(i3);
          }
          return i3;
        }, this.shim.requireDirectory({ require: e2, filename: s2 }, t2, i2);
      }
      addHandler(t2, e2, s2, i2, n2, r2) {
        let a2 = [];
        const h2 = function(t3) {
          return t3 ? t3.map((t4) => (t4.applyBeforeValidation = false, t4)) : [];
        }(n2);
        if (i2 = i2 || (() => {
        }), Array.isArray(t2))
          if (function(t3) {
            return t3.every((t4) => "string" == typeof t4);
          }(t2))
            [t2, ...a2] = t2;
          else
            for (const e3 of t2)
              this.addHandler(e3);
        else {
          if (function(t3) {
            return "object" == typeof t3 && !Array.isArray(t3);
          }(t2)) {
            let e3 = Array.isArray(t2.command) || "string" == typeof t2.command ? t2.command : this.moduleName(t2);
            return t2.aliases && (e3 = [].concat(e3).concat(t2.aliases)), void this.addHandler(e3, this.extractDesc(t2), t2.builder, t2.handler, t2.middlewares, t2.deprecated);
          }
          if (k(s2))
            return void this.addHandler([t2].concat(a2), e2, s2.builder, s2.handler, s2.middlewares, s2.deprecated);
        }
        if ("string" == typeof t2) {
          const n3 = o(t2);
          a2 = a2.map((t3) => o(t3).cmd);
          let l2 = false;
          const c2 = [n3.cmd].concat(a2).filter((t3) => !_.test(t3) || (l2 = true, false));
          0 === c2.length && l2 && c2.push("$0"), l2 && (n3.cmd = c2[0], a2 = c2.slice(1), t2 = t2.replace(_, n3.cmd)), a2.forEach((t3) => {
            this.aliasMap[t3] = n3.cmd;
          }), false !== e2 && this.usage.command(t2, e2, l2, a2, r2), this.handlers[n3.cmd] = { original: t2, description: e2, handler: i2, builder: s2 || {}, middlewares: h2, deprecated: r2, demanded: n3.demanded, optional: n3.optional }, l2 && (this.defaultCommand = this.handlers[n3.cmd]);
        }
      }
      getCommandHandlers() {
        return this.handlers;
      }
      getCommands() {
        return Object.keys(this.handlers).concat(Object.keys(this.aliasMap));
      }
      hasDefaultCommand() {
        return !!this.defaultCommand;
      }
      runCommand(t2, e2, s2, i2, n2, r2) {
        const o2 = this.handlers[t2] || this.handlers[this.aliasMap[t2]] || this.defaultCommand, a2 = e2.getInternalMethods().getContext(), h2 = a2.commands.slice(), l2 = !t2;
        t2 && (a2.commands.push(t2), a2.fullCommands.push(o2.original));
        const c2 = this.applyBuilderUpdateUsageAndParse(l2, o2, e2, s2.aliases, h2, i2, n2, r2);
        return f(c2) ? c2.then((t3) => this.applyMiddlewareAndGetResult(l2, o2, t3.innerArgv, a2, n2, t3.aliases, e2)) : this.applyMiddlewareAndGetResult(l2, o2, c2.innerArgv, a2, n2, c2.aliases, e2);
      }
      applyBuilderUpdateUsageAndParse(t2, e2, s2, i2, n2, r2, o2, a2) {
        const h2 = e2.builder;
        let l2 = s2;
        if (x(h2)) {
          const c2 = h2(s2.getInternalMethods().reset(i2), a2);
          if (f(c2))
            return c2.then((i3) => {
              var a3;
              return l2 = (a3 = i3) && "function" == typeof a3.getInternalMethods ? i3 : s2, this.parseAndUpdateUsage(t2, e2, l2, n2, r2, o2);
            });
        } else
          (function(t3) {
            return "object" == typeof t3;
          })(h2) && (l2 = s2.getInternalMethods().reset(i2), Object.keys(e2.builder).forEach((t3) => {
            l2.option(t3, h2[t3]);
          }));
        return this.parseAndUpdateUsage(t2, e2, l2, n2, r2, o2);
      }
      parseAndUpdateUsage(t2, e2, s2, i2, n2, r2) {
        t2 && s2.getInternalMethods().getUsageInstance().unfreeze(true), this.shouldUpdateUsage(s2) && s2.getInternalMethods().getUsageInstance().usage(this.usageFromParentCommandsCommandHandler(i2, e2), e2.description);
        const o2 = s2.getInternalMethods().runYargsParserAndExecuteCommands(null, void 0, true, n2, r2);
        return f(o2) ? o2.then((t3) => ({ aliases: s2.parsed.aliases, innerArgv: t3 })) : { aliases: s2.parsed.aliases, innerArgv: o2 };
      }
      shouldUpdateUsage(t2) {
        return !t2.getInternalMethods().getUsageInstance().getUsageDisabled() && 0 === t2.getInternalMethods().getUsageInstance().getUsage().length;
      }
      usageFromParentCommandsCommandHandler(t2, e2) {
        const s2 = _.test(e2.original) ? e2.original.replace(_, "").trim() : e2.original, i2 = t2.filter((t3) => !_.test(t3));
        return i2.push(s2), `$0 ${i2.join(" ")}`;
      }
      handleValidationAndGetResult(t2, e2, s2, i2, n2, r2, o2, a2) {
        if (!r2.getInternalMethods().getHasOutput()) {
          const e3 = r2.getInternalMethods().runValidation(n2, a2, r2.parsed.error, t2);
          s2 = j(s2, (t3) => (e3(t3), t3));
        }
        if (e2.handler && !r2.getInternalMethods().getHasOutput()) {
          r2.getInternalMethods().setHasOutput();
          const i3 = !!r2.getOptions().configuration["populate--"];
          r2.getInternalMethods().postProcess(s2, i3, false, false), s2 = j(s2 = C(s2, r2, o2, false), (t3) => {
            const s3 = e2.handler(t3);
            return f(s3) ? s3.then(() => t3) : t3;
          }), t2 || r2.getInternalMethods().getUsageInstance().cacheHelpMessage(), f(s2) && !r2.getInternalMethods().hasParseCallback() && s2.catch((t3) => {
            try {
              r2.getInternalMethods().getUsageInstance().fail(null, t3);
            } catch (t4) {
            }
          });
        }
        return t2 || (i2.commands.pop(), i2.fullCommands.pop()), s2;
      }
      applyMiddlewareAndGetResult(t2, e2, s2, i2, n2, r2, o2) {
        let a2 = {};
        if (n2)
          return s2;
        o2.getInternalMethods().getHasOutput() || (a2 = this.populatePositionals(e2, s2, i2, o2));
        const h2 = this.globalMiddleware.getMiddleware().slice(0).concat(e2.middlewares), l2 = C(s2, o2, h2, true);
        return f(l2) ? l2.then((s3) => this.handleValidationAndGetResult(t2, e2, s3, i2, r2, o2, h2, a2)) : this.handleValidationAndGetResult(t2, e2, l2, i2, r2, o2, h2, a2);
      }
      populatePositionals(t2, e2, s2, i2) {
        e2._ = e2._.slice(s2.commands.length);
        const n2 = t2.demanded.slice(0), r2 = t2.optional.slice(0), o2 = {};
        for (this.validation.positionalCount(n2.length, e2._.length); n2.length; ) {
          const t3 = n2.shift();
          this.populatePositional(t3, e2, o2);
        }
        for (; r2.length; ) {
          const t3 = r2.shift();
          this.populatePositional(t3, e2, o2);
        }
        return e2._ = s2.commands.concat(e2._.map((t3) => "" + t3)), this.postProcessPositionals(e2, o2, this.cmdToParseOptions(t2.original), i2), o2;
      }
      populatePositional(t2, e2, s2) {
        const i2 = t2.cmd[0];
        t2.variadic ? s2[i2] = e2._.splice(0).map(String) : e2._.length && (s2[i2] = [String(e2._.shift())]);
      }
      cmdToParseOptions(t2) {
        const e2 = { array: [], default: {}, alias: {}, demand: {} }, s2 = o(t2);
        return s2.demanded.forEach((t3) => {
          const [s3, ...i2] = t3.cmd;
          t3.variadic && (e2.array.push(s3), e2.default[s3] = []), e2.alias[s3] = i2, e2.demand[s3] = true;
        }), s2.optional.forEach((t3) => {
          const [s3, ...i2] = t3.cmd;
          t3.variadic && (e2.array.push(s3), e2.default[s3] = []), e2.alias[s3] = i2;
        }), e2;
      }
      postProcessPositionals(t2, e2, s2, i2) {
        const n2 = Object.assign({}, i2.getOptions());
        n2.default = Object.assign(s2.default, n2.default);
        for (const t3 of Object.keys(s2.alias))
          n2.alias[t3] = (n2.alias[t3] || []).concat(s2.alias[t3]);
        n2.array = n2.array.concat(s2.array), n2.config = {};
        const r2 = [];
        if (Object.keys(e2).forEach((t3) => {
          e2[t3].map((e3) => {
            n2.configuration["unknown-options-as-args"] && (n2.key[t3] = true), r2.push(`--${t3}`), r2.push(e3);
          });
        }), !r2.length)
          return;
        const o2 = Object.assign({}, n2.configuration, { "populate--": false }), a2 = this.shim.Parser.detailed(r2, Object.assign({}, n2, { configuration: o2 }));
        if (a2.error)
          i2.getInternalMethods().getUsageInstance().fail(a2.error.message, a2.error);
        else {
          const s3 = Object.keys(e2);
          Object.keys(e2).forEach((t3) => {
            s3.push(...a2.aliases[t3]);
          }), Object.keys(a2.argv).forEach((n3) => {
            s3.includes(n3) && (e2[n3] || (e2[n3] = a2.argv[n3]), !this.isInConfigs(i2, n3) && !this.isDefaulted(i2, n3) && Object.prototype.hasOwnProperty.call(t2, n3) && Object.prototype.hasOwnProperty.call(a2.argv, n3) && (Array.isArray(t2[n3]) || Array.isArray(a2.argv[n3])) ? t2[n3] = [].concat(t2[n3], a2.argv[n3]) : t2[n3] = a2.argv[n3]);
          });
        }
      }
      isDefaulted(t2, e2) {
        const { default: s2 } = t2.getOptions();
        return Object.prototype.hasOwnProperty.call(s2, e2) || Object.prototype.hasOwnProperty.call(s2, this.shim.Parser.camelCase(e2));
      }
      isInConfigs(t2, e2) {
        const { configObjects: s2 } = t2.getOptions();
        return s2.some((t3) => Object.prototype.hasOwnProperty.call(t3, e2)) || s2.some((t3) => Object.prototype.hasOwnProperty.call(t3, this.shim.Parser.camelCase(e2)));
      }
      runDefaultBuilderOn(t2) {
        if (!this.defaultCommand)
          return;
        if (this.shouldUpdateUsage(t2)) {
          const e3 = _.test(this.defaultCommand.original) ? this.defaultCommand.original : this.defaultCommand.original.replace(/^[^[\]<>]*/, "$0 ");
          t2.getInternalMethods().getUsageInstance().usage(e3, this.defaultCommand.description);
        }
        const e2 = this.defaultCommand.builder;
        if (x(e2))
          return e2(t2, true);
        k(e2) || Object.keys(e2).forEach((s2) => {
          t2.option(s2, e2[s2]);
        });
      }
      moduleName(t2) {
        const e2 = function(t3) {
          if ("undefined" == typeof require)
            return null;
          for (let e3, s2 = 0, i2 = Object.keys(require.cache); s2 < i2.length; s2++)
            if (e3 = require.cache[i2[s2]], e3.exports === t3)
              return e3;
          return null;
        }(t2);
        if (!e2)
          throw new Error(`No command name given for module: ${this.shim.inspect(t2)}`);
        return this.commandFromFilename(e2.filename);
      }
      commandFromFilename(t2) {
        return this.shim.path.basename(t2, this.shim.path.extname(t2));
      }
      extractDesc({ describe: t2, description: e2, desc: s2 }) {
        for (const i2 of [t2, e2, s2]) {
          if ("string" == typeof i2 || false === i2)
            return i2;
          d(i2, true, this.shim);
        }
        return false;
      }
      freeze() {
        this.frozens.push({ handlers: this.handlers, aliasMap: this.aliasMap, defaultCommand: this.defaultCommand });
      }
      unfreeze() {
        const t2 = this.frozens.pop();
        d(t2, void 0, this.shim), { handlers: this.handlers, aliasMap: this.aliasMap, defaultCommand: this.defaultCommand } = t2;
      }
      reset() {
        return this.handlers = {}, this.aliasMap = {}, this.defaultCommand = void 0, this.requireCache = /* @__PURE__ */ new Set(), this;
      }
    };
    function k(t2) {
      return "object" == typeof t2 && !!t2.builder && "function" == typeof t2.handler;
    }
    function x(t2) {
      return "function" == typeof t2;
    }
    function E(t2) {
      "undefined" != typeof process && [process.stdout, process.stderr].forEach((e2) => {
        const s2 = e2;
        s2._handle && s2.isTTY && "function" == typeof s2._handle.setBlocking && s2._handle.setBlocking(t2);
      });
    }
    function A(t2) {
      return "boolean" == typeof t2;
    }
    function P(t2, s2) {
      const i2 = s2.y18n.__, n2 = {}, r2 = [];
      n2.failFn = function(t3) {
        r2.push(t3);
      };
      let o2 = null, a2 = null, h2 = true;
      n2.showHelpOnFail = function(e2 = true, s3) {
        const [i3, r3] = "string" == typeof e2 ? [true, e2] : [e2, s3];
        return t2.getInternalMethods().isGlobalContext() && (a2 = r3), o2 = r3, h2 = i3, n2;
      };
      let l2 = false;
      n2.fail = function(s3, i3) {
        const c3 = t2.getInternalMethods().getLoggerInstance();
        if (!r2.length) {
          if (t2.getExitProcess() && E(true), !l2) {
            l2 = true, h2 && (t2.showHelp("error"), c3.error()), (s3 || i3) && c3.error(s3 || i3);
            const e2 = o2 || a2;
            e2 && ((s3 || i3) && c3.error(""), c3.error(e2));
          }
          if (i3 = i3 || new e(s3), t2.getExitProcess())
            return t2.exit(1);
          if (t2.getInternalMethods().hasParseCallback())
            return t2.exit(1, i3);
          throw i3;
        }
        for (let t3 = r2.length - 1; t3 >= 0; --t3) {
          const e2 = r2[t3];
          if (A(e2)) {
            if (i3)
              throw i3;
            if (s3)
              throw Error(s3);
          } else
            e2(s3, i3, n2);
        }
      };
      let c2 = [], f2 = false;
      n2.usage = (t3, e2) => null === t3 ? (f2 = true, c2 = [], n2) : (f2 = false, c2.push([t3, e2 || ""]), n2), n2.getUsage = () => c2, n2.getUsageDisabled = () => f2, n2.getPositionalGroupName = () => i2("Positionals:");
      let d2 = [];
      n2.example = (t3, e2) => {
        d2.push([t3, e2 || ""]);
      };
      let u2 = [];
      n2.command = function(t3, e2, s3, i3, n3 = false) {
        s3 && (u2 = u2.map((t4) => (t4[2] = false, t4))), u2.push([t3, e2 || "", s3, i3, n3]);
      }, n2.getCommands = () => u2;
      let p2 = {};
      n2.describe = function(t3, e2) {
        Array.isArray(t3) ? t3.forEach((t4) => {
          n2.describe(t4, e2);
        }) : "object" == typeof t3 ? Object.keys(t3).forEach((e3) => {
          n2.describe(e3, t3[e3]);
        }) : p2[t3] = e2;
      }, n2.getDescriptions = () => p2;
      let m2 = [];
      n2.epilog = (t3) => {
        m2.push(t3);
      };
      let y2, b2 = false;
      function v2() {
        return b2 || (y2 = function() {
          const t3 = 80;
          return s2.process.stdColumns ? Math.min(t3, s2.process.stdColumns) : t3;
        }(), b2 = true), y2;
      }
      n2.wrap = (t3) => {
        b2 = true, y2 = t3;
      };
      const O2 = "__yargsString__:";
      function w2(t3, e2, i3) {
        let n3 = 0;
        return Array.isArray(t3) || (t3 = Object.values(t3).map((t4) => [t4])), t3.forEach((t4) => {
          n3 = Math.max(s2.stringWidth(i3 ? `${i3} ${I(t4[0])}` : I(t4[0])) + $(t4[0]), n3);
        }), e2 && (n3 = Math.min(n3, parseInt((0.5 * e2).toString(), 10))), n3;
      }
      let C2;
      function j2(e2) {
        return t2.getOptions().hiddenOptions.indexOf(e2) < 0 || t2.parsed.argv[t2.getOptions().showHiddenOpt];
      }
      function _2(t3, e2) {
        let s3 = `[${i2("default:")} `;
        if (void 0 === t3 && !e2)
          return null;
        if (e2)
          s3 += e2;
        else
          switch (typeof t3) {
            case "string":
              s3 += `"${t3}"`;
              break;
            case "object":
              s3 += JSON.stringify(t3);
              break;
            default:
              s3 += t3;
          }
        return `${s3}]`;
      }
      n2.deferY18nLookup = (t3) => O2 + t3, n2.help = function() {
        if (C2)
          return C2;
        !function() {
          const e3 = t2.getDemandedOptions(), s3 = t2.getOptions();
          (Object.keys(s3.alias) || []).forEach((i3) => {
            s3.alias[i3].forEach((r4) => {
              p2[r4] && n2.describe(i3, p2[r4]), r4 in e3 && t2.demandOption(i3, e3[r4]), s3.boolean.includes(r4) && t2.boolean(i3), s3.count.includes(r4) && t2.count(i3), s3.string.includes(r4) && t2.string(i3), s3.normalize.includes(r4) && t2.normalize(i3), s3.array.includes(r4) && t2.array(i3), s3.number.includes(r4) && t2.number(i3);
            });
          });
        }();
        const e2 = t2.customScriptName ? t2.$0 : s2.path.basename(t2.$0), r3 = t2.getDemandedOptions(), o3 = t2.getDemandedCommands(), a3 = t2.getDeprecatedOptions(), h3 = t2.getGroups(), l3 = t2.getOptions();
        let g2 = [];
        g2 = g2.concat(Object.keys(p2)), g2 = g2.concat(Object.keys(r3)), g2 = g2.concat(Object.keys(o3)), g2 = g2.concat(Object.keys(l3.default)), g2 = g2.filter(j2), g2 = Object.keys(g2.reduce((t3, e3) => ("_" !== e3 && (t3[e3] = true), t3), {}));
        const y3 = v2(), b3 = s2.cliui({ width: y3, wrap: !!y3 });
        if (!f2) {
          if (c2.length)
            c2.forEach((t3) => {
              b3.div({ text: `${t3[0].replace(/\$0/g, e2)}` }), t3[1] && b3.div({ text: `${t3[1]}`, padding: [1, 0, 0, 0] });
            }), b3.div();
          else if (u2.length) {
            let t3 = null;
            t3 = o3._ ? `${e2} <${i2("command")}>
` : `${e2} [${i2("command")}]
`, b3.div(`${t3}`);
          }
        }
        if (u2.length > 1 || 1 === u2.length && !u2[0][2]) {
          b3.div(i2("Commands:"));
          const s3 = t2.getInternalMethods().getContext(), n3 = s3.commands.length ? `${s3.commands.join(" ")} ` : "";
          true === t2.getInternalMethods().getParserConfiguration()["sort-commands"] && (u2 = u2.sort((t3, e3) => t3[0].localeCompare(e3[0])));
          const r4 = e2 ? `${e2} ` : "";
          u2.forEach((t3) => {
            const s4 = `${r4}${n3}${t3[0].replace(/^\$0 ?/, "")}`;
            b3.span({ text: s4, padding: [0, 2, 0, 2], width: w2(u2, y3, `${e2}${n3}`) + 4 }, { text: t3[1] });
            const o4 = [];
            t3[2] && o4.push(`[${i2("default")}]`), t3[3] && t3[3].length && o4.push(`[${i2("aliases:")} ${t3[3].join(", ")}]`), t3[4] && ("string" == typeof t3[4] ? o4.push(`[${i2("deprecated: %s", t3[4])}]`) : o4.push(`[${i2("deprecated")}]`)), o4.length ? b3.div({ text: o4.join(" "), padding: [0, 0, 0, 2], align: "right" }) : b3.div();
          }), b3.div();
        }
        const M3 = (Object.keys(l3.alias) || []).concat(Object.keys(t2.parsed.newAliases) || []);
        g2 = g2.filter((e3) => !t2.parsed.newAliases[e3] && M3.every((t3) => -1 === (l3.alias[t3] || []).indexOf(e3)));
        const k3 = i2("Options:");
        h3[k3] || (h3[k3] = []), function(t3, e3, s3, i3) {
          let n3 = [], r4 = null;
          Object.keys(s3).forEach((t4) => {
            n3 = n3.concat(s3[t4]);
          }), t3.forEach((t4) => {
            r4 = [t4].concat(e3[t4]), r4.some((t5) => -1 !== n3.indexOf(t5)) || s3[i3].push(t4);
          });
        }(g2, l3.alias, h3, k3);
        const x2 = (t3) => /^--/.test(I(t3)), E2 = Object.keys(h3).filter((t3) => h3[t3].length > 0).map((t3) => ({ groupName: t3, normalizedKeys: h3[t3].filter(j2).map((t4) => {
          if (M3.includes(t4))
            return t4;
          for (let e3, s3 = 0; void 0 !== (e3 = M3[s3]); s3++)
            if ((l3.alias[e3] || []).includes(t4))
              return e3;
          return t4;
        }) })).filter(({ normalizedKeys: t3 }) => t3.length > 0).map(({ groupName: t3, normalizedKeys: e3 }) => {
          const s3 = e3.reduce((e4, s4) => (e4[s4] = [s4].concat(l3.alias[s4] || []).map((e5) => t3 === n2.getPositionalGroupName() ? e5 : (/^[0-9]$/.test(e5) ? l3.boolean.includes(s4) ? "-" : "--" : e5.length > 1 ? "--" : "-") + e5).sort((t4, e5) => x2(t4) === x2(e5) ? 0 : x2(t4) ? 1 : -1).join(", "), e4), {});
          return { groupName: t3, normalizedKeys: e3, switches: s3 };
        });
        if (E2.filter(({ groupName: t3 }) => t3 !== n2.getPositionalGroupName()).some(({ normalizedKeys: t3, switches: e3 }) => !t3.every((t4) => x2(e3[t4]))) && E2.filter(({ groupName: t3 }) => t3 !== n2.getPositionalGroupName()).forEach(({ normalizedKeys: t3, switches: e3 }) => {
          t3.forEach((t4) => {
            var s3, i3;
            x2(e3[t4]) && (e3[t4] = (s3 = e3[t4], i3 = "-x, ".length, S(s3) ? { text: s3.text, indentation: s3.indentation + i3 } : { text: s3, indentation: i3 }));
          });
        }), E2.forEach(({ groupName: t3, normalizedKeys: e3, switches: s3 }) => {
          b3.div(t3), e3.forEach((t4) => {
            const e4 = s3[t4];
            let o4 = p2[t4] || "", h4 = null;
            o4.includes(O2) && (o4 = i2(o4.substring(O2.length))), l3.boolean.includes(t4) && (h4 = `[${i2("boolean")}]`), l3.count.includes(t4) && (h4 = `[${i2("count")}]`), l3.string.includes(t4) && (h4 = `[${i2("string")}]`), l3.normalize.includes(t4) && (h4 = `[${i2("string")}]`), l3.array.includes(t4) && (h4 = `[${i2("array")}]`), l3.number.includes(t4) && (h4 = `[${i2("number")}]`);
            const c3 = [t4 in a3 ? (f3 = a3[t4], "string" == typeof f3 ? `[${i2("deprecated: %s", f3)}]` : `[${i2("deprecated")}]`) : null, h4, t4 in r3 ? `[${i2("required")}]` : null, l3.choices && l3.choices[t4] ? `[${i2("choices:")} ${n2.stringifiedValues(l3.choices[t4])}]` : null, _2(l3.default[t4], l3.defaultDescription[t4])].filter(Boolean).join(" ");
            var f3;
            b3.span({ text: I(e4), padding: [0, 2, 0, 2 + $(e4)], width: w2(s3, y3) + 4 }, o4), c3 ? b3.div({ text: c3, padding: [0, 0, 0, 2], align: "right" }) : b3.div();
          }), b3.div();
        }), d2.length && (b3.div(i2("Examples:")), d2.forEach((t3) => {
          t3[0] = t3[0].replace(/\$0/g, e2);
        }), d2.forEach((t3) => {
          "" === t3[1] ? b3.div({ text: t3[0], padding: [0, 2, 0, 2] }) : b3.div({ text: t3[0], padding: [0, 2, 0, 2], width: w2(d2, y3) + 4 }, { text: t3[1] });
        }), b3.div()), m2.length > 0) {
          const t3 = m2.map((t4) => t4.replace(/\$0/g, e2)).join("\n");
          b3.div(`${t3}
`);
        }
        return b3.toString().replace(/\s*$/, "");
      }, n2.cacheHelpMessage = function() {
        C2 = this.help();
      }, n2.clearCachedHelpMessage = function() {
        C2 = void 0;
      }, n2.hasCachedHelpMessage = function() {
        return !!C2;
      }, n2.showHelp = (e2) => {
        const s3 = t2.getInternalMethods().getLoggerInstance();
        e2 || (e2 = "error");
        ("function" == typeof e2 ? e2 : s3[e2])(n2.help());
      }, n2.functionDescription = (t3) => ["(", t3.name ? s2.Parser.decamelize(t3.name, "-") : i2("generated-value"), ")"].join(""), n2.stringifiedValues = function(t3, e2) {
        let s3 = "";
        const i3 = e2 || ", ", n3 = [].concat(t3);
        return t3 && n3.length ? (n3.forEach((t4) => {
          s3.length && (s3 += i3), s3 += JSON.stringify(t4);
        }), s3) : s3;
      };
      let M2 = null;
      n2.version = (t3) => {
        M2 = t3;
      }, n2.showVersion = (e2) => {
        const s3 = t2.getInternalMethods().getLoggerInstance();
        e2 || (e2 = "error");
        ("function" == typeof e2 ? e2 : s3[e2])(M2);
      }, n2.reset = function(t3) {
        return o2 = null, l2 = false, c2 = [], f2 = false, m2 = [], d2 = [], u2 = [], p2 = g(p2, (e2) => !t3[e2]), n2;
      };
      const k2 = [];
      return n2.freeze = function() {
        k2.push({ failMessage: o2, failureOutput: l2, usages: c2, usageDisabled: f2, epilogs: m2, examples: d2, commands: u2, descriptions: p2 });
      }, n2.unfreeze = function(t3 = false) {
        const e2 = k2.pop();
        e2 && (t3 ? (p2 = { ...e2.descriptions, ...p2 }, u2 = [...e2.commands, ...u2], c2 = [...e2.usages, ...c2], d2 = [...e2.examples, ...d2], m2 = [...e2.epilogs, ...m2]) : { failMessage: o2, failureOutput: l2, usages: c2, usageDisabled: f2, epilogs: m2, examples: d2, commands: u2, descriptions: p2 } = e2);
      }, n2;
    }
    function S(t2) {
      return "object" == typeof t2;
    }
    function $(t2) {
      return S(t2) ? t2.indentation : 0;
    }
    function I(t2) {
      return S(t2) ? t2.text : t2;
    }
    var D = class {
      constructor(t2, e2, s2, i2) {
        var n2, r2, o2;
        this.yargs = t2, this.usage = e2, this.command = s2, this.shim = i2, this.completionKey = "get-yargs-completions", this.aliases = null, this.customCompletionFunction = null, this.indexAfterLastReset = 0, this.zshShell = null !== (o2 = (null === (n2 = this.shim.getEnv("SHELL")) || void 0 === n2 ? void 0 : n2.includes("zsh")) || (null === (r2 = this.shim.getEnv("ZSH_NAME")) || void 0 === r2 ? void 0 : r2.includes("zsh"))) && void 0 !== o2 && o2;
      }
      defaultCompletion(t2, e2, s2, i2) {
        const n2 = this.command.getCommandHandlers();
        for (let e3 = 0, s3 = t2.length; e3 < s3; ++e3)
          if (n2[t2[e3]] && n2[t2[e3]].builder) {
            const s4 = n2[t2[e3]].builder;
            if (x(s4)) {
              this.indexAfterLastReset = e3 + 1;
              const t3 = this.yargs.getInternalMethods().reset();
              return s4(t3, true), t3.argv;
            }
          }
        const r2 = [];
        this.commandCompletions(r2, t2, s2), this.optionCompletions(r2, t2, e2, s2), this.choicesFromOptionsCompletions(r2, t2, e2, s2), this.choicesFromPositionalsCompletions(r2, t2, e2, s2), i2(null, r2);
      }
      commandCompletions(t2, e2, s2) {
        const i2 = this.yargs.getInternalMethods().getContext().commands;
        s2.match(/^-/) || i2[i2.length - 1] === s2 || this.previousArgHasChoices(e2) || this.usage.getCommands().forEach((s3) => {
          const i3 = o(s3[0]).cmd;
          if (-1 === e2.indexOf(i3))
            if (this.zshShell) {
              const e3 = s3[1] || "";
              t2.push(i3.replace(/:/g, "\\:") + ":" + e3);
            } else
              t2.push(i3);
        });
      }
      optionCompletions(t2, e2, s2, i2) {
        if ((i2.match(/^-/) || "" === i2 && 0 === t2.length) && !this.previousArgHasChoices(e2)) {
          const s3 = this.yargs.getOptions(), n2 = this.yargs.getGroups()[this.usage.getPositionalGroupName()] || [];
          Object.keys(s3.key).forEach((r2) => {
            const o2 = !!s3.configuration["boolean-negation"] && s3.boolean.includes(r2);
            n2.includes(r2) || s3.hiddenOptions.includes(r2) || this.argsContainKey(e2, r2, o2) || (this.completeOptionKey(r2, t2, i2), o2 && s3.default[r2] && this.completeOptionKey(`no-${r2}`, t2, i2));
          });
        }
      }
      choicesFromOptionsCompletions(t2, e2, s2, i2) {
        if (this.previousArgHasChoices(e2)) {
          const s3 = this.getPreviousArgChoices(e2);
          s3 && s3.length > 0 && t2.push(...s3.map((t3) => t3.replace(/:/g, "\\:")));
        }
      }
      choicesFromPositionalsCompletions(t2, e2, s2, i2) {
        if ("" === i2 && t2.length > 0 && this.previousArgHasChoices(e2))
          return;
        const n2 = this.yargs.getGroups()[this.usage.getPositionalGroupName()] || [], r2 = Math.max(this.indexAfterLastReset, this.yargs.getInternalMethods().getContext().commands.length + 1), o2 = n2[s2._.length - r2 - 1];
        if (!o2)
          return;
        const a2 = this.yargs.getOptions().choices[o2] || [];
        for (const e3 of a2)
          e3.startsWith(i2) && t2.push(e3.replace(/:/g, "\\:"));
      }
      getPreviousArgChoices(t2) {
        if (t2.length < 1)
          return;
        let e2 = t2[t2.length - 1], s2 = "";
        if (!e2.startsWith("-") && t2.length > 1 && (s2 = e2, e2 = t2[t2.length - 2]), !e2.startsWith("-"))
          return;
        const i2 = e2.replace(/^-+/, ""), n2 = this.yargs.getOptions(), r2 = [i2, ...this.yargs.getAliases()[i2] || []];
        let o2;
        for (const t3 of r2)
          if (Object.prototype.hasOwnProperty.call(n2.key, t3) && Array.isArray(n2.choices[t3])) {
            o2 = n2.choices[t3];
            break;
          }
        return o2 ? o2.filter((t3) => !s2 || t3.startsWith(s2)) : void 0;
      }
      previousArgHasChoices(t2) {
        const e2 = this.getPreviousArgChoices(t2);
        return void 0 !== e2 && e2.length > 0;
      }
      argsContainKey(t2, e2, s2) {
        const i2 = (e3) => -1 !== t2.indexOf((/^[^0-9]$/.test(e3) ? "-" : "--") + e3);
        if (i2(e2))
          return true;
        if (s2 && i2(`no-${e2}`))
          return true;
        if (this.aliases) {
          for (const t3 of this.aliases[e2])
            if (i2(t3))
              return true;
        }
        return false;
      }
      completeOptionKey(t2, e2, s2) {
        const i2 = this.usage.getDescriptions(), n2 = !/^--/.test(s2) && ((t3) => /^[^0-9]$/.test(t3))(t2) ? "-" : "--";
        if (this.zshShell) {
          const s3 = i2[t2] || "";
          e2.push(n2 + `${t2.replace(/:/g, "\\:")}:${s3.replace("__yargsString__:", "")}`);
        } else
          e2.push(n2 + t2);
      }
      customCompletion(t2, e2, s2, i2) {
        if (d(this.customCompletionFunction, null, this.shim), this.customCompletionFunction.length < 3) {
          const t3 = this.customCompletionFunction(s2, e2);
          return f(t3) ? t3.then((t4) => {
            this.shim.process.nextTick(() => {
              i2(null, t4);
            });
          }).catch((t4) => {
            this.shim.process.nextTick(() => {
              i2(t4, void 0);
            });
          }) : i2(null, t3);
        }
        return function(t3) {
          return t3.length > 3;
        }(this.customCompletionFunction) ? this.customCompletionFunction(s2, e2, (n2 = i2) => this.defaultCompletion(t2, e2, s2, n2), (t3) => {
          i2(null, t3);
        }) : this.customCompletionFunction(s2, e2, (t3) => {
          i2(null, t3);
        });
      }
      getCompletion(t2, e2) {
        const s2 = t2.length ? t2[t2.length - 1] : "", i2 = this.yargs.parse(t2, true), n2 = this.customCompletionFunction ? (i3) => this.customCompletion(t2, i3, s2, e2) : (i3) => this.defaultCompletion(t2, i3, s2, e2);
        return f(i2) ? i2.then(n2) : n2(i2);
      }
      generateCompletionScript(t2, e2) {
        let s2 = this.zshShell ? `#compdef {{app_name}}
###-begin-{{app_name}}-completions-###
#
# yargs command completion script
#
# Installation: {{app_path}} {{completion_command}} >> ~/.zshrc
#    or {{app_path}} {{completion_command}} >> ~/.zprofile on OSX.
#
_{{app_name}}_yargs_completions()
{
  local reply
  local si=$IFS
  IFS=$'
' reply=($(COMP_CWORD="$((CURRENT-1))" COMP_LINE="$BUFFER" COMP_POINT="$CURSOR" {{app_path}} --get-yargs-completions "\${words[@]}"))
  IFS=$si
  _describe 'values' reply
}
compdef _{{app_name}}_yargs_completions {{app_name}}
###-end-{{app_name}}-completions-###
` : '###-begin-{{app_name}}-completions-###\n#\n# yargs command completion script\n#\n# Installation: {{app_path}} {{completion_command}} >> ~/.bashrc\n#    or {{app_path}} {{completion_command}} >> ~/.bash_profile on OSX.\n#\n_{{app_name}}_yargs_completions()\n{\n    local cur_word args type_list\n\n    cur_word="${COMP_WORDS[COMP_CWORD]}"\n    args=("${COMP_WORDS[@]}")\n\n    # ask yargs to generate completions.\n    type_list=$({{app_path}} --get-yargs-completions "${args[@]}")\n\n    COMPREPLY=( $(compgen -W "${type_list}" -- ${cur_word}) )\n\n    # if no match was found, fall back to filename completion\n    if [ ${#COMPREPLY[@]} -eq 0 ]; then\n      COMPREPLY=()\n    fi\n\n    return 0\n}\ncomplete -o bashdefault -o default -F _{{app_name}}_yargs_completions {{app_name}}\n###-end-{{app_name}}-completions-###\n';
        const i2 = this.shim.path.basename(t2);
        return t2.match(/\.js$/) && (t2 = `./${t2}`), s2 = s2.replace(/{{app_name}}/g, i2), s2 = s2.replace(/{{completion_command}}/g, e2), s2.replace(/{{app_path}}/g, t2);
      }
      registerFunction(t2) {
        this.customCompletionFunction = t2;
      }
      setParsed(t2) {
        this.aliases = t2.aliases;
      }
    };
    function N(t2, e2) {
      if (0 === t2.length)
        return e2.length;
      if (0 === e2.length)
        return t2.length;
      const s2 = [];
      let i2, n2;
      for (i2 = 0; i2 <= e2.length; i2++)
        s2[i2] = [i2];
      for (n2 = 0; n2 <= t2.length; n2++)
        s2[0][n2] = n2;
      for (i2 = 1; i2 <= e2.length; i2++)
        for (n2 = 1; n2 <= t2.length; n2++)
          e2.charAt(i2 - 1) === t2.charAt(n2 - 1) ? s2[i2][n2] = s2[i2 - 1][n2 - 1] : i2 > 1 && n2 > 1 && e2.charAt(i2 - 2) === t2.charAt(n2 - 1) && e2.charAt(i2 - 1) === t2.charAt(n2 - 2) ? s2[i2][n2] = s2[i2 - 2][n2 - 2] + 1 : s2[i2][n2] = Math.min(s2[i2 - 1][n2 - 1] + 1, Math.min(s2[i2][n2 - 1] + 1, s2[i2 - 1][n2] + 1));
      return s2[e2.length][t2.length];
    }
    var H = ["$0", "--", "_"];
    var z;
    var q;
    var W;
    var F;
    var U;
    var L;
    var V;
    var G;
    var R;
    var T;
    var K;
    var B;
    var Y;
    var J;
    var Z;
    var X;
    var Q;
    var tt;
    var et;
    var st;
    var it;
    var nt;
    var rt;
    var ot;
    var at;
    var ht;
    var lt;
    var ct;
    var ft;
    var dt;
    var ut;
    var pt;
    var gt;
    var mt;
    var yt = Symbol("copyDoubleDash");
    var bt = Symbol("copyDoubleDash");
    var vt = Symbol("deleteFromParserHintObject");
    var Ot = Symbol("emitWarning");
    var wt = Symbol("freeze");
    var Ct = Symbol("getDollarZero");
    var jt = Symbol("getParserConfiguration");
    var _t = Symbol("guessLocale");
    var Mt = Symbol("guessVersion");
    var kt = Symbol("parsePositionalNumbers");
    var xt = Symbol("pkgUp");
    var Et = Symbol("populateParserHintArray");
    var At = Symbol("populateParserHintSingleValueDictionary");
    var Pt = Symbol("populateParserHintArrayDictionary");
    var St = Symbol("populateParserHintDictionary");
    var $t = Symbol("sanitizeKey");
    var It = Symbol("setKey");
    var Dt = Symbol("unfreeze");
    var Nt = Symbol("validateAsync");
    var Ht = Symbol("getCommandInstance");
    var zt = Symbol("getContext");
    var qt = Symbol("getHasOutput");
    var Wt = Symbol("getLoggerInstance");
    var Ft = Symbol("getParseContext");
    var Ut = Symbol("getUsageInstance");
    var Lt = Symbol("getValidationInstance");
    var Vt = Symbol("hasParseCallback");
    var Gt = Symbol("isGlobalContext");
    var Rt = Symbol("postProcess");
    var Tt = Symbol("rebase");
    var Kt = Symbol("reset");
    var Bt = Symbol("runYargsParserAndExecuteCommands");
    var Yt = Symbol("runValidation");
    var Jt = Symbol("setHasOutput");
    var Zt = Symbol("kTrackManuallySetKeys");
    var Xt = class {
      constructor(t2 = [], e2, s2, i2) {
        this.customScriptName = false, this.parsed = false, z.set(this, void 0), q.set(this, void 0), W.set(this, { commands: [], fullCommands: [] }), F.set(this, null), U.set(this, null), L.set(this, "show-hidden"), V.set(this, null), G.set(this, true), R.set(this, {}), T.set(this, true), K.set(this, []), B.set(this, void 0), Y.set(this, {}), J.set(this, false), Z.set(this, null), X.set(this, true), Q.set(this, void 0), tt.set(this, ""), et.set(this, void 0), st.set(this, void 0), it.set(this, {}), nt.set(this, null), rt.set(this, null), ot.set(this, {}), at.set(this, {}), ht.set(this, void 0), lt.set(this, false), ct.set(this, void 0), ft.set(this, false), dt.set(this, false), ut.set(this, false), pt.set(this, void 0), gt.set(this, null), mt.set(this, void 0), O(this, ct, i2, "f"), O(this, ht, t2, "f"), O(this, q, e2, "f"), O(this, st, s2, "f"), O(this, B, new w(this), "f"), this.$0 = this[Ct](), this[Kt](), O(this, z, v(this, z, "f"), "f"), O(this, pt, v(this, pt, "f"), "f"), O(this, mt, v(this, mt, "f"), "f"), O(this, et, v(this, et, "f"), "f"), v(this, et, "f").showHiddenOpt = v(this, L, "f"), O(this, Q, this[bt](), "f");
      }
      addHelpOpt(t2, e2) {
        return h("[string|boolean] [string]", [t2, e2], arguments.length), v(this, Z, "f") && (this[vt](v(this, Z, "f")), O(this, Z, null, "f")), false === t2 && void 0 === e2 || (O(this, Z, "string" == typeof t2 ? t2 : "help", "f"), this.boolean(v(this, Z, "f")), this.describe(v(this, Z, "f"), e2 || v(this, pt, "f").deferY18nLookup("Show help"))), this;
      }
      help(t2, e2) {
        return this.addHelpOpt(t2, e2);
      }
      addShowHiddenOpt(t2, e2) {
        if (h("[string|boolean] [string]", [t2, e2], arguments.length), false === t2 && void 0 === e2)
          return this;
        const s2 = "string" == typeof t2 ? t2 : v(this, L, "f");
        return this.boolean(s2), this.describe(s2, e2 || v(this, pt, "f").deferY18nLookup("Show hidden options")), v(this, et, "f").showHiddenOpt = s2, this;
      }
      showHidden(t2, e2) {
        return this.addShowHiddenOpt(t2, e2);
      }
      alias(t2, e2) {
        return h("<object|string|array> [string|array]", [t2, e2], arguments.length), this[Pt](this.alias.bind(this), "alias", t2, e2), this;
      }
      array(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("array", t2), this[Zt](t2), this;
      }
      boolean(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("boolean", t2), this[Zt](t2), this;
      }
      check(t2, e2) {
        return h("<function> [boolean]", [t2, e2], arguments.length), this.middleware((e3, s2) => j(() => t2(e3, s2.getOptions()), (s3) => (s3 ? ("string" == typeof s3 || s3 instanceof Error) && v(this, pt, "f").fail(s3.toString(), s3) : v(this, pt, "f").fail(v(this, ct, "f").y18n.__("Argument check failed: %s", t2.toString())), e3), (t3) => (v(this, pt, "f").fail(t3.message ? t3.message : t3.toString(), t3), e3)), false, e2), this;
      }
      choices(t2, e2) {
        return h("<object|string|array> [string|array]", [t2, e2], arguments.length), this[Pt](this.choices.bind(this), "choices", t2, e2), this;
      }
      coerce(t2, s2) {
        if (h("<object|string|array> [function]", [t2, s2], arguments.length), Array.isArray(t2)) {
          if (!s2)
            throw new e("coerce callback must be provided");
          for (const e2 of t2)
            this.coerce(e2, s2);
          return this;
        }
        if ("object" == typeof t2) {
          for (const e2 of Object.keys(t2))
            this.coerce(e2, t2[e2]);
          return this;
        }
        if (!s2)
          throw new e("coerce callback must be provided");
        return v(this, et, "f").key[t2] = true, v(this, B, "f").addCoerceMiddleware((i2, n2) => {
          let r2;
          return Object.prototype.hasOwnProperty.call(i2, t2) ? j(() => (r2 = n2.getAliases(), s2(i2[t2])), (e2) => {
            i2[t2] = e2;
            const s3 = n2.getInternalMethods().getParserConfiguration()["strip-aliased"];
            if (r2[t2] && true !== s3)
              for (const s4 of r2[t2])
                i2[s4] = e2;
            return i2;
          }, (t3) => {
            throw new e(t3.message);
          }) : i2;
        }, t2), this;
      }
      conflicts(t2, e2) {
        return h("<string|object> [string|array]", [t2, e2], arguments.length), v(this, mt, "f").conflicts(t2, e2), this;
      }
      config(t2 = "config", e2, s2) {
        return h("[object|string] [string|function] [function]", [t2, e2, s2], arguments.length), "object" != typeof t2 || Array.isArray(t2) ? ("function" == typeof e2 && (s2 = e2, e2 = void 0), this.describe(t2, e2 || v(this, pt, "f").deferY18nLookup("Path to JSON config file")), (Array.isArray(t2) ? t2 : [t2]).forEach((t3) => {
          v(this, et, "f").config[t3] = s2 || true;
        }), this) : (t2 = n(t2, v(this, q, "f"), this[jt]()["deep-merge-config"] || false, v(this, ct, "f")), v(this, et, "f").configObjects = (v(this, et, "f").configObjects || []).concat(t2), this);
      }
      completion(t2, e2, s2) {
        return h("[string] [string|boolean|function] [function]", [t2, e2, s2], arguments.length), "function" == typeof e2 && (s2 = e2, e2 = void 0), O(this, U, t2 || v(this, U, "f") || "completion", "f"), e2 || false === e2 || (e2 = "generate completion script"), this.command(v(this, U, "f"), e2), s2 && v(this, F, "f").registerFunction(s2), this;
      }
      command(t2, e2, s2, i2, n2, r2) {
        return h("<string|array|object> [string|boolean] [function|object] [function] [array] [boolean|string]", [t2, e2, s2, i2, n2, r2], arguments.length), v(this, z, "f").addHandler(t2, e2, s2, i2, n2, r2), this;
      }
      commands(t2, e2, s2, i2, n2, r2) {
        return this.command(t2, e2, s2, i2, n2, r2);
      }
      commandDir(t2, e2) {
        h("<string> [object]", [t2, e2], arguments.length);
        const s2 = v(this, st, "f") || v(this, ct, "f").require;
        return v(this, z, "f").addDirectory(t2, s2, v(this, ct, "f").getCallerFile(), e2), this;
      }
      count(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("count", t2), this[Zt](t2), this;
      }
      default(t2, e2, s2) {
        return h("<object|string|array> [*] [string]", [t2, e2, s2], arguments.length), s2 && (u(t2, v(this, ct, "f")), v(this, et, "f").defaultDescription[t2] = s2), "function" == typeof e2 && (u(t2, v(this, ct, "f")), v(this, et, "f").defaultDescription[t2] || (v(this, et, "f").defaultDescription[t2] = v(this, pt, "f").functionDescription(e2)), e2 = e2.call()), this[At](this.default.bind(this), "default", t2, e2), this;
      }
      defaults(t2, e2, s2) {
        return this.default(t2, e2, s2);
      }
      demandCommand(t2 = 1, e2, s2, i2) {
        return h("[number] [number|string] [string|null|undefined] [string|null|undefined]", [t2, e2, s2, i2], arguments.length), "number" != typeof e2 && (s2 = e2, e2 = 1 / 0), this.global("_", false), v(this, et, "f").demandedCommands._ = { min: t2, max: e2, minMsg: s2, maxMsg: i2 }, this;
      }
      demand(t2, e2, s2) {
        return Array.isArray(e2) ? (e2.forEach((t3) => {
          d(s2, true, v(this, ct, "f")), this.demandOption(t3, s2);
        }), e2 = 1 / 0) : "number" != typeof e2 && (s2 = e2, e2 = 1 / 0), "number" == typeof t2 ? (d(s2, true, v(this, ct, "f")), this.demandCommand(t2, e2, s2, s2)) : Array.isArray(t2) ? t2.forEach((t3) => {
          d(s2, true, v(this, ct, "f")), this.demandOption(t3, s2);
        }) : "string" == typeof s2 ? this.demandOption(t2, s2) : true !== s2 && void 0 !== s2 || this.demandOption(t2), this;
      }
      demandOption(t2, e2) {
        return h("<object|string|array> [string]", [t2, e2], arguments.length), this[At](this.demandOption.bind(this), "demandedOptions", t2, e2), this;
      }
      deprecateOption(t2, e2) {
        return h("<string> [string|boolean]", [t2, e2], arguments.length), v(this, et, "f").deprecatedOptions[t2] = e2, this;
      }
      describe(t2, e2) {
        return h("<object|string|array> [string]", [t2, e2], arguments.length), this[It](t2, true), v(this, pt, "f").describe(t2, e2), this;
      }
      detectLocale(t2) {
        return h("<boolean>", [t2], arguments.length), O(this, G, t2, "f"), this;
      }
      env(t2) {
        return h("[string|boolean]", [t2], arguments.length), false === t2 ? delete v(this, et, "f").envPrefix : v(this, et, "f").envPrefix = t2 || "", this;
      }
      epilogue(t2) {
        return h("<string>", [t2], arguments.length), v(this, pt, "f").epilog(t2), this;
      }
      epilog(t2) {
        return this.epilogue(t2);
      }
      example(t2, e2) {
        return h("<string|array> [string]", [t2, e2], arguments.length), Array.isArray(t2) ? t2.forEach((t3) => this.example(...t3)) : v(this, pt, "f").example(t2, e2), this;
      }
      exit(t2, e2) {
        O(this, J, true, "f"), O(this, V, e2, "f"), v(this, T, "f") && v(this, ct, "f").process.exit(t2);
      }
      exitProcess(t2 = true) {
        return h("[boolean]", [t2], arguments.length), O(this, T, t2, "f"), this;
      }
      fail(t2) {
        if (h("<function|boolean>", [t2], arguments.length), "boolean" == typeof t2 && false !== t2)
          throw new e("Invalid first argument. Expected function or boolean 'false'");
        return v(this, pt, "f").failFn(t2), this;
      }
      getAliases() {
        return this.parsed ? this.parsed.aliases : {};
      }
      async getCompletion(t2, e2) {
        return h("<array> [function]", [t2, e2], arguments.length), e2 ? v(this, F, "f").getCompletion(t2, e2) : new Promise((e3, s2) => {
          v(this, F, "f").getCompletion(t2, (t3, i2) => {
            t3 ? s2(t3) : e3(i2);
          });
        });
      }
      getDemandedOptions() {
        return h([], 0), v(this, et, "f").demandedOptions;
      }
      getDemandedCommands() {
        return h([], 0), v(this, et, "f").demandedCommands;
      }
      getDeprecatedOptions() {
        return h([], 0), v(this, et, "f").deprecatedOptions;
      }
      getDetectLocale() {
        return v(this, G, "f");
      }
      getExitProcess() {
        return v(this, T, "f");
      }
      getGroups() {
        return Object.assign({}, v(this, Y, "f"), v(this, at, "f"));
      }
      getHelp() {
        if (O(this, J, true, "f"), !v(this, pt, "f").hasCachedHelpMessage()) {
          if (!this.parsed) {
            const t3 = this[Bt](v(this, ht, "f"), void 0, void 0, 0, true);
            if (f(t3))
              return t3.then(() => v(this, pt, "f").help());
          }
          const t2 = v(this, z, "f").runDefaultBuilderOn(this);
          if (f(t2))
            return t2.then(() => v(this, pt, "f").help());
        }
        return Promise.resolve(v(this, pt, "f").help());
      }
      getOptions() {
        return v(this, et, "f");
      }
      getStrict() {
        return v(this, ft, "f");
      }
      getStrictCommands() {
        return v(this, dt, "f");
      }
      getStrictOptions() {
        return v(this, ut, "f");
      }
      global(t2, e2) {
        return h("<string|array> [boolean]", [t2, e2], arguments.length), t2 = [].concat(t2), false !== e2 ? v(this, et, "f").local = v(this, et, "f").local.filter((e3) => -1 === t2.indexOf(e3)) : t2.forEach((t3) => {
          v(this, et, "f").local.includes(t3) || v(this, et, "f").local.push(t3);
        }), this;
      }
      group(t2, e2) {
        h("<string|array> <string>", [t2, e2], arguments.length);
        const s2 = v(this, at, "f")[e2] || v(this, Y, "f")[e2];
        v(this, at, "f")[e2] && delete v(this, at, "f")[e2];
        const i2 = {};
        return v(this, Y, "f")[e2] = (s2 || []).concat(t2).filter((t3) => !i2[t3] && (i2[t3] = true)), this;
      }
      hide(t2) {
        return h("<string>", [t2], arguments.length), v(this, et, "f").hiddenOptions.push(t2), this;
      }
      implies(t2, e2) {
        return h("<string|object> [number|string|array]", [t2, e2], arguments.length), v(this, mt, "f").implies(t2, e2), this;
      }
      locale(t2) {
        return h("[string]", [t2], arguments.length), void 0 === t2 ? (this[_t](), v(this, ct, "f").y18n.getLocale()) : (O(this, G, false, "f"), v(this, ct, "f").y18n.setLocale(t2), this);
      }
      middleware(t2, e2, s2) {
        return v(this, B, "f").addMiddleware(t2, !!e2, s2);
      }
      nargs(t2, e2) {
        return h("<string|object|array> [number]", [t2, e2], arguments.length), this[At](this.nargs.bind(this), "narg", t2, e2), this;
      }
      normalize(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("normalize", t2), this;
      }
      number(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("number", t2), this[Zt](t2), this;
      }
      option(t2, e2) {
        if (h("<string|object> [object]", [t2, e2], arguments.length), "object" == typeof t2)
          Object.keys(t2).forEach((e3) => {
            this.options(e3, t2[e3]);
          });
        else {
          "object" != typeof e2 && (e2 = {}), this[Zt](t2), !v(this, gt, "f") || "version" !== t2 && "version" !== (null == e2 ? void 0 : e2.alias) || this[Ot](['"version" is a reserved word.', "Please do one of the following:", '- Disable version with `yargs.version(false)` if using "version" as an option', "- Use the built-in `yargs.version` method instead (if applicable)", "- Use a different option key", "https://yargs.js.org/docs/#api-reference-version"].join("\n"), void 0, "versionWarning"), v(this, et, "f").key[t2] = true, e2.alias && this.alias(t2, e2.alias);
          const s2 = e2.deprecate || e2.deprecated;
          s2 && this.deprecateOption(t2, s2);
          const i2 = e2.demand || e2.required || e2.require;
          i2 && this.demand(t2, i2), e2.demandOption && this.demandOption(t2, "string" == typeof e2.demandOption ? e2.demandOption : void 0), e2.conflicts && this.conflicts(t2, e2.conflicts), "default" in e2 && this.default(t2, e2.default), void 0 !== e2.implies && this.implies(t2, e2.implies), void 0 !== e2.nargs && this.nargs(t2, e2.nargs), e2.config && this.config(t2, e2.configParser), e2.normalize && this.normalize(t2), e2.choices && this.choices(t2, e2.choices), e2.coerce && this.coerce(t2, e2.coerce), e2.group && this.group(t2, e2.group), (e2.boolean || "boolean" === e2.type) && (this.boolean(t2), e2.alias && this.boolean(e2.alias)), (e2.array || "array" === e2.type) && (this.array(t2), e2.alias && this.array(e2.alias)), (e2.number || "number" === e2.type) && (this.number(t2), e2.alias && this.number(e2.alias)), (e2.string || "string" === e2.type) && (this.string(t2), e2.alias && this.string(e2.alias)), (e2.count || "count" === e2.type) && this.count(t2), "boolean" == typeof e2.global && this.global(t2, e2.global), e2.defaultDescription && (v(this, et, "f").defaultDescription[t2] = e2.defaultDescription), e2.skipValidation && this.skipValidation(t2);
          const n2 = e2.describe || e2.description || e2.desc;
          this.describe(t2, n2), e2.hidden && this.hide(t2), e2.requiresArg && this.requiresArg(t2);
        }
        return this;
      }
      options(t2, e2) {
        return this.option(t2, e2);
      }
      parse(t2, e2, s2) {
        h("[string|array] [function|boolean|object] [function]", [t2, e2, s2], arguments.length), this[wt](), void 0 === t2 && (t2 = v(this, ht, "f")), "object" == typeof e2 && (O(this, rt, e2, "f"), e2 = s2), "function" == typeof e2 && (O(this, nt, e2, "f"), e2 = false), e2 || O(this, ht, t2, "f"), v(this, nt, "f") && O(this, T, false, "f");
        const i2 = this[Bt](t2, !!e2), n2 = this.parsed;
        return v(this, F, "f").setParsed(this.parsed), f(i2) ? i2.then((t3) => (v(this, nt, "f") && v(this, nt, "f").call(this, v(this, V, "f"), t3, v(this, tt, "f")), t3)).catch((t3) => {
          throw v(this, nt, "f") && v(this, nt, "f")(t3, this.parsed.argv, v(this, tt, "f")), t3;
        }).finally(() => {
          this[Dt](), this.parsed = n2;
        }) : (v(this, nt, "f") && v(this, nt, "f").call(this, v(this, V, "f"), i2, v(this, tt, "f")), this[Dt](), this.parsed = n2, i2);
      }
      parseAsync(t2, e2, s2) {
        const i2 = this.parse(t2, e2, s2);
        return f(i2) ? i2 : Promise.resolve(i2);
      }
      parseSync(t2, s2, i2) {
        const n2 = this.parse(t2, s2, i2);
        if (f(n2))
          throw new e(".parseSync() must not be used with asynchronous builders, handlers, or middleware");
        return n2;
      }
      parserConfiguration(t2) {
        return h("<object>", [t2], arguments.length), O(this, it, t2, "f"), this;
      }
      pkgConf(t2, e2) {
        h("<string> [string]", [t2, e2], arguments.length);
        let s2 = null;
        const i2 = this[xt](e2 || v(this, q, "f"));
        return i2[t2] && "object" == typeof i2[t2] && (s2 = n(i2[t2], e2 || v(this, q, "f"), this[jt]()["deep-merge-config"] || false, v(this, ct, "f")), v(this, et, "f").configObjects = (v(this, et, "f").configObjects || []).concat(s2)), this;
      }
      positional(t2, e2) {
        h("<string> <object>", [t2, e2], arguments.length);
        const s2 = ["default", "defaultDescription", "implies", "normalize", "choices", "conflicts", "coerce", "type", "describe", "desc", "description", "alias"];
        e2 = g(e2, (t3, e3) => !("type" === t3 && !["string", "number", "boolean"].includes(e3)) && s2.includes(t3));
        const i2 = v(this, W, "f").fullCommands[v(this, W, "f").fullCommands.length - 1], n2 = i2 ? v(this, z, "f").cmdToParseOptions(i2) : { array: [], alias: {}, default: {}, demand: {} };
        return p(n2).forEach((s3) => {
          const i3 = n2[s3];
          Array.isArray(i3) ? -1 !== i3.indexOf(t2) && (e2[s3] = true) : i3[t2] && !(s3 in e2) && (e2[s3] = i3[t2]);
        }), this.group(t2, v(this, pt, "f").getPositionalGroupName()), this.option(t2, e2);
      }
      recommendCommands(t2 = true) {
        return h("[boolean]", [t2], arguments.length), O(this, lt, t2, "f"), this;
      }
      required(t2, e2, s2) {
        return this.demand(t2, e2, s2);
      }
      require(t2, e2, s2) {
        return this.demand(t2, e2, s2);
      }
      requiresArg(t2) {
        return h("<array|string|object> [number]", [t2], arguments.length), "string" == typeof t2 && v(this, et, "f").narg[t2] || this[At](this.requiresArg.bind(this), "narg", t2, NaN), this;
      }
      showCompletionScript(t2, e2) {
        return h("[string] [string]", [t2, e2], arguments.length), t2 = t2 || this.$0, v(this, Q, "f").log(v(this, F, "f").generateCompletionScript(t2, e2 || v(this, U, "f") || "completion")), this;
      }
      showHelp(t2) {
        if (h("[string|function]", [t2], arguments.length), O(this, J, true, "f"), !v(this, pt, "f").hasCachedHelpMessage()) {
          if (!this.parsed) {
            const e3 = this[Bt](v(this, ht, "f"), void 0, void 0, 0, true);
            if (f(e3))
              return e3.then(() => {
                v(this, pt, "f").showHelp(t2);
              }), this;
          }
          const e2 = v(this, z, "f").runDefaultBuilderOn(this);
          if (f(e2))
            return e2.then(() => {
              v(this, pt, "f").showHelp(t2);
            }), this;
        }
        return v(this, pt, "f").showHelp(t2), this;
      }
      scriptName(t2) {
        return this.customScriptName = true, this.$0 = t2, this;
      }
      showHelpOnFail(t2, e2) {
        return h("[boolean|string] [string]", [t2, e2], arguments.length), v(this, pt, "f").showHelpOnFail(t2, e2), this;
      }
      showVersion(t2) {
        return h("[string|function]", [t2], arguments.length), v(this, pt, "f").showVersion(t2), this;
      }
      skipValidation(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("skipValidation", t2), this;
      }
      strict(t2) {
        return h("[boolean]", [t2], arguments.length), O(this, ft, false !== t2, "f"), this;
      }
      strictCommands(t2) {
        return h("[boolean]", [t2], arguments.length), O(this, dt, false !== t2, "f"), this;
      }
      strictOptions(t2) {
        return h("[boolean]", [t2], arguments.length), O(this, ut, false !== t2, "f"), this;
      }
      string(t2) {
        return h("<array|string>", [t2], arguments.length), this[Et]("string", t2), this[Zt](t2), this;
      }
      terminalWidth() {
        return h([], 0), v(this, ct, "f").process.stdColumns;
      }
      updateLocale(t2) {
        return this.updateStrings(t2);
      }
      updateStrings(t2) {
        return h("<object>", [t2], arguments.length), O(this, G, false, "f"), v(this, ct, "f").y18n.updateLocale(t2), this;
      }
      usage(t2, s2, i2, n2) {
        if (h("<string|null|undefined> [string|boolean] [function|object] [function]", [t2, s2, i2, n2], arguments.length), void 0 !== s2) {
          if (d(t2, null, v(this, ct, "f")), (t2 || "").match(/^\$0( |$)/))
            return this.command(t2, s2, i2, n2);
          throw new e(".usage() description must start with $0 if being used as alias for .command()");
        }
        return v(this, pt, "f").usage(t2), this;
      }
      version(t2, e2, s2) {
        const i2 = "version";
        if (h("[boolean|string] [string] [string]", [t2, e2, s2], arguments.length), v(this, gt, "f") && (this[vt](v(this, gt, "f")), v(this, pt, "f").version(void 0), O(this, gt, null, "f")), 0 === arguments.length)
          s2 = this[Mt](), t2 = i2;
        else if (1 === arguments.length) {
          if (false === t2)
            return this;
          s2 = t2, t2 = i2;
        } else
          2 === arguments.length && (s2 = e2, e2 = void 0);
        return O(this, gt, "string" == typeof t2 ? t2 : i2, "f"), e2 = e2 || v(this, pt, "f").deferY18nLookup("Show version number"), v(this, pt, "f").version(s2 || void 0), this.boolean(v(this, gt, "f")), this.describe(v(this, gt, "f"), e2), this;
      }
      wrap(t2) {
        return h("<number|null|undefined>", [t2], arguments.length), v(this, pt, "f").wrap(t2), this;
      }
      [(z = /* @__PURE__ */ new WeakMap(), q = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap(), F = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), V = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), R = /* @__PURE__ */ new WeakMap(), T = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), B = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakMap(), Z = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap(), tt = /* @__PURE__ */ new WeakMap(), et = /* @__PURE__ */ new WeakMap(), st = /* @__PURE__ */ new WeakMap(), it = /* @__PURE__ */ new WeakMap(), nt = /* @__PURE__ */ new WeakMap(), rt = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new WeakMap(), at = /* @__PURE__ */ new WeakMap(), ht = /* @__PURE__ */ new WeakMap(), lt = /* @__PURE__ */ new WeakMap(), ct = /* @__PURE__ */ new WeakMap(), ft = /* @__PURE__ */ new WeakMap(), dt = /* @__PURE__ */ new WeakMap(), ut = /* @__PURE__ */ new WeakMap(), pt = /* @__PURE__ */ new WeakMap(), gt = /* @__PURE__ */ new WeakMap(), mt = /* @__PURE__ */ new WeakMap(), yt)](t2) {
        if (!t2._ || !t2["--"])
          return t2;
        t2._.push.apply(t2._, t2["--"]);
        try {
          delete t2["--"];
        } catch (t3) {
        }
        return t2;
      }
      [bt]() {
        return { log: (...t2) => {
          this[Vt]() || console.log(...t2), O(this, J, true, "f"), v(this, tt, "f").length && O(this, tt, v(this, tt, "f") + "\n", "f"), O(this, tt, v(this, tt, "f") + t2.join(" "), "f");
        }, error: (...t2) => {
          this[Vt]() || console.error(...t2), O(this, J, true, "f"), v(this, tt, "f").length && O(this, tt, v(this, tt, "f") + "\n", "f"), O(this, tt, v(this, tt, "f") + t2.join(" "), "f");
        } };
      }
      [vt](t2) {
        p(v(this, et, "f")).forEach((e2) => {
          if ("configObjects" === e2)
            return;
          const s2 = v(this, et, "f")[e2];
          Array.isArray(s2) ? s2.includes(t2) && s2.splice(s2.indexOf(t2), 1) : "object" == typeof s2 && delete s2[t2];
        }), delete v(this, pt, "f").getDescriptions()[t2];
      }
      [Ot](t2, e2, s2) {
        v(this, R, "f")[s2] || (v(this, ct, "f").process.emitWarning(t2, e2), v(this, R, "f")[s2] = true);
      }
      [wt]() {
        v(this, K, "f").push({ options: v(this, et, "f"), configObjects: v(this, et, "f").configObjects.slice(0), exitProcess: v(this, T, "f"), groups: v(this, Y, "f"), strict: v(this, ft, "f"), strictCommands: v(this, dt, "f"), strictOptions: v(this, ut, "f"), completionCommand: v(this, U, "f"), output: v(this, tt, "f"), exitError: v(this, V, "f"), hasOutput: v(this, J, "f"), parsed: this.parsed, parseFn: v(this, nt, "f"), parseContext: v(this, rt, "f") }), v(this, pt, "f").freeze(), v(this, mt, "f").freeze(), v(this, z, "f").freeze(), v(this, B, "f").freeze();
      }
      [Ct]() {
        let t2, e2 = "";
        return t2 = /\b(node|iojs|electron)(\.exe)?$/.test(v(this, ct, "f").process.argv()[0]) ? v(this, ct, "f").process.argv().slice(1, 2) : v(this, ct, "f").process.argv().slice(0, 1), e2 = t2.map((t3) => {
          const e3 = this[Tt](v(this, q, "f"), t3);
          return t3.match(/^(\/|([a-zA-Z]:)?\\)/) && e3.length < t3.length ? e3 : t3;
        }).join(" ").trim(), v(this, ct, "f").getEnv("_") && v(this, ct, "f").getProcessArgvBin() === v(this, ct, "f").getEnv("_") && (e2 = v(this, ct, "f").getEnv("_").replace(`${v(this, ct, "f").path.dirname(v(this, ct, "f").process.execPath())}/`, "")), e2;
      }
      [jt]() {
        return v(this, it, "f");
      }
      [_t]() {
        if (!v(this, G, "f"))
          return;
        const t2 = v(this, ct, "f").getEnv("LC_ALL") || v(this, ct, "f").getEnv("LC_MESSAGES") || v(this, ct, "f").getEnv("LANG") || v(this, ct, "f").getEnv("LANGUAGE") || "en_US";
        this.locale(t2.replace(/[.:].*/, ""));
      }
      [Mt]() {
        return this[xt]().version || "unknown";
      }
      [kt](t2) {
        const e2 = t2["--"] ? t2["--"] : t2._;
        for (let t3, s2 = 0; void 0 !== (t3 = e2[s2]); s2++)
          v(this, ct, "f").Parser.looksLikeNumber(t3) && Number.isSafeInteger(Math.floor(parseFloat(`${t3}`))) && (e2[s2] = Number(t3));
        return t2;
      }
      [xt](t2) {
        const e2 = t2 || "*";
        if (v(this, ot, "f")[e2])
          return v(this, ot, "f")[e2];
        let s2 = {};
        try {
          let e3 = t2 || v(this, ct, "f").mainFilename;
          !t2 && v(this, ct, "f").path.extname(e3) && (e3 = v(this, ct, "f").path.dirname(e3));
          const i2 = v(this, ct, "f").findUp(e3, (t3, e4) => e4.includes("package.json") ? "package.json" : void 0);
          d(i2, void 0, v(this, ct, "f")), s2 = JSON.parse(v(this, ct, "f").readFileSync(i2, "utf8"));
        } catch (t3) {
        }
        return v(this, ot, "f")[e2] = s2 || {}, v(this, ot, "f")[e2];
      }
      [Et](t2, e2) {
        (e2 = [].concat(e2)).forEach((e3) => {
          e3 = this[$t](e3), v(this, et, "f")[t2].push(e3);
        });
      }
      [At](t2, e2, s2, i2) {
        this[St](t2, e2, s2, i2, (t3, e3, s3) => {
          v(this, et, "f")[t3][e3] = s3;
        });
      }
      [Pt](t2, e2, s2, i2) {
        this[St](t2, e2, s2, i2, (t3, e3, s3) => {
          v(this, et, "f")[t3][e3] = (v(this, et, "f")[t3][e3] || []).concat(s3);
        });
      }
      [St](t2, e2, s2, i2, n2) {
        if (Array.isArray(s2))
          s2.forEach((e3) => {
            t2(e3, i2);
          });
        else if (((t3) => "object" == typeof t3)(s2))
          for (const e3 of p(s2))
            t2(e3, s2[e3]);
        else
          n2(e2, this[$t](s2), i2);
      }
      [$t](t2) {
        return "__proto__" === t2 ? "___proto___" : t2;
      }
      [It](t2, e2) {
        return this[At](this[It].bind(this), "key", t2, e2), this;
      }
      [Dt]() {
        var t2, e2, s2, i2, n2, r2, o2, a2, h2, l2, c2, f2;
        const u2 = v(this, K, "f").pop();
        let p2;
        d(u2, void 0, v(this, ct, "f")), t2 = this, e2 = this, s2 = this, i2 = this, n2 = this, r2 = this, o2 = this, a2 = this, h2 = this, l2 = this, c2 = this, f2 = this, { options: { set value(e3) {
          O(t2, et, e3, "f");
        } }.value, configObjects: p2, exitProcess: { set value(t3) {
          O(e2, T, t3, "f");
        } }.value, groups: { set value(t3) {
          O(s2, Y, t3, "f");
        } }.value, output: { set value(t3) {
          O(i2, tt, t3, "f");
        } }.value, exitError: { set value(t3) {
          O(n2, V, t3, "f");
        } }.value, hasOutput: { set value(t3) {
          O(r2, J, t3, "f");
        } }.value, parsed: this.parsed, strict: { set value(t3) {
          O(o2, ft, t3, "f");
        } }.value, strictCommands: { set value(t3) {
          O(a2, dt, t3, "f");
        } }.value, strictOptions: { set value(t3) {
          O(h2, ut, t3, "f");
        } }.value, completionCommand: { set value(t3) {
          O(l2, U, t3, "f");
        } }.value, parseFn: { set value(t3) {
          O(c2, nt, t3, "f");
        } }.value, parseContext: { set value(t3) {
          O(f2, rt, t3, "f");
        } }.value } = u2, v(this, et, "f").configObjects = p2, v(this, pt, "f").unfreeze(), v(this, mt, "f").unfreeze(), v(this, z, "f").unfreeze(), v(this, B, "f").unfreeze();
      }
      [Nt](t2, e2) {
        return j(e2, (e3) => (t2(e3), e3));
      }
      getInternalMethods() {
        return { getCommandInstance: this[Ht].bind(this), getContext: this[zt].bind(this), getHasOutput: this[qt].bind(this), getLoggerInstance: this[Wt].bind(this), getParseContext: this[Ft].bind(this), getParserConfiguration: this[jt].bind(this), getUsageInstance: this[Ut].bind(this), getValidationInstance: this[Lt].bind(this), hasParseCallback: this[Vt].bind(this), isGlobalContext: this[Gt].bind(this), postProcess: this[Rt].bind(this), reset: this[Kt].bind(this), runValidation: this[Yt].bind(this), runYargsParserAndExecuteCommands: this[Bt].bind(this), setHasOutput: this[Jt].bind(this) };
      }
      [Ht]() {
        return v(this, z, "f");
      }
      [zt]() {
        return v(this, W, "f");
      }
      [qt]() {
        return v(this, J, "f");
      }
      [Wt]() {
        return v(this, Q, "f");
      }
      [Ft]() {
        return v(this, rt, "f") || {};
      }
      [Ut]() {
        return v(this, pt, "f");
      }
      [Lt]() {
        return v(this, mt, "f");
      }
      [Vt]() {
        return !!v(this, nt, "f");
      }
      [Gt]() {
        return v(this, X, "f");
      }
      [Rt](t2, e2, s2, i2) {
        if (s2)
          return t2;
        if (f(t2))
          return t2;
        e2 || (t2 = this[yt](t2));
        return (this[jt]()["parse-positional-numbers"] || void 0 === this[jt]()["parse-positional-numbers"]) && (t2 = this[kt](t2)), i2 && (t2 = C(t2, this, v(this, B, "f").getMiddleware(), false)), t2;
      }
      [Kt](t2 = {}) {
        O(this, et, v(this, et, "f") || {}, "f");
        const e2 = {};
        e2.local = v(this, et, "f").local || [], e2.configObjects = v(this, et, "f").configObjects || [];
        const s2 = {};
        e2.local.forEach((e3) => {
          s2[e3] = true, (t2[e3] || []).forEach((t3) => {
            s2[t3] = true;
          });
        }), Object.assign(v(this, at, "f"), Object.keys(v(this, Y, "f")).reduce((t3, e3) => {
          const i2 = v(this, Y, "f")[e3].filter((t4) => !(t4 in s2));
          return i2.length > 0 && (t3[e3] = i2), t3;
        }, {})), O(this, Y, {}, "f");
        return ["array", "boolean", "string", "skipValidation", "count", "normalize", "number", "hiddenOptions"].forEach((t3) => {
          e2[t3] = (v(this, et, "f")[t3] || []).filter((t4) => !s2[t4]);
        }), ["narg", "key", "alias", "default", "defaultDescription", "config", "choices", "demandedOptions", "demandedCommands", "deprecatedOptions"].forEach((t3) => {
          e2[t3] = g(v(this, et, "f")[t3], (t4) => !s2[t4]);
        }), e2.envPrefix = v(this, et, "f").envPrefix, O(this, et, e2, "f"), O(this, pt, v(this, pt, "f") ? v(this, pt, "f").reset(s2) : P(this, v(this, ct, "f")), "f"), O(this, mt, v(this, mt, "f") ? v(this, mt, "f").reset(s2) : function(t3, e3, s3) {
          const i2 = s3.y18n.__, n2 = s3.y18n.__n, r2 = { nonOptionCount: function(s4) {
            const i3 = t3.getDemandedCommands(), r3 = s4._.length + (s4["--"] ? s4["--"].length : 0) - t3.getInternalMethods().getContext().commands.length;
            i3._ && (r3 < i3._.min || r3 > i3._.max) && (r3 < i3._.min ? void 0 !== i3._.minMsg ? e3.fail(i3._.minMsg ? i3._.minMsg.replace(/\$0/g, r3.toString()).replace(/\$1/, i3._.min.toString()) : null) : e3.fail(n2("Not enough non-option arguments: got %s, need at least %s", "Not enough non-option arguments: got %s, need at least %s", r3, r3.toString(), i3._.min.toString())) : r3 > i3._.max && (void 0 !== i3._.maxMsg ? e3.fail(i3._.maxMsg ? i3._.maxMsg.replace(/\$0/g, r3.toString()).replace(/\$1/, i3._.max.toString()) : null) : e3.fail(n2("Too many non-option arguments: got %s, maximum of %s", "Too many non-option arguments: got %s, maximum of %s", r3, r3.toString(), i3._.max.toString()))));
          }, positionalCount: function(t4, s4) {
            s4 < t4 && e3.fail(n2("Not enough non-option arguments: got %s, need at least %s", "Not enough non-option arguments: got %s, need at least %s", s4, s4 + "", t4 + ""));
          }, requiredArguments: function(t4, s4) {
            let i3 = null;
            for (const e4 of Object.keys(s4))
              Object.prototype.hasOwnProperty.call(t4, e4) && void 0 !== t4[e4] || (i3 = i3 || {}, i3[e4] = s4[e4]);
            if (i3) {
              const t5 = [];
              for (const e4 of Object.keys(i3)) {
                const s6 = i3[e4];
                s6 && t5.indexOf(s6) < 0 && t5.push(s6);
              }
              const s5 = t5.length ? `
${t5.join("\n")}` : "";
              e3.fail(n2("Missing required argument: %s", "Missing required arguments: %s", Object.keys(i3).length, Object.keys(i3).join(", ") + s5));
            }
          }, unknownArguments: function(s4, i3, o3, a3, h2 = true) {
            var l3;
            const c3 = t3.getInternalMethods().getCommandInstance().getCommands(), f2 = [], d2 = t3.getInternalMethods().getContext();
            if (Object.keys(s4).forEach((e4) => {
              H.includes(e4) || Object.prototype.hasOwnProperty.call(o3, e4) || Object.prototype.hasOwnProperty.call(t3.getInternalMethods().getParseContext(), e4) || r2.isValidAndSomeAliasIsNotNew(e4, i3) || f2.push(e4);
            }), h2 && (d2.commands.length > 0 || c3.length > 0 || a3) && s4._.slice(d2.commands.length).forEach((t4) => {
              c3.includes("" + t4) || f2.push("" + t4);
            }), h2) {
              const e4 = (null === (l3 = t3.getDemandedCommands()._) || void 0 === l3 ? void 0 : l3.max) || 0, i4 = d2.commands.length + e4;
              i4 < s4._.length && s4._.slice(i4).forEach((t4) => {
                t4 = String(t4), d2.commands.includes(t4) || f2.includes(t4) || f2.push(t4);
              });
            }
            f2.length && e3.fail(n2("Unknown argument: %s", "Unknown arguments: %s", f2.length, f2.map((t4) => t4.trim() ? t4 : `"${t4}"`).join(", ")));
          }, unknownCommands: function(s4) {
            const i3 = t3.getInternalMethods().getCommandInstance().getCommands(), r3 = [], o3 = t3.getInternalMethods().getContext();
            return (o3.commands.length > 0 || i3.length > 0) && s4._.slice(o3.commands.length).forEach((t4) => {
              i3.includes("" + t4) || r3.push("" + t4);
            }), r3.length > 0 && (e3.fail(n2("Unknown command: %s", "Unknown commands: %s", r3.length, r3.join(", "))), true);
          }, isValidAndSomeAliasIsNotNew: function(e4, s4) {
            if (!Object.prototype.hasOwnProperty.call(s4, e4))
              return false;
            const i3 = t3.parsed.newAliases;
            return [e4, ...s4[e4]].some((t4) => !Object.prototype.hasOwnProperty.call(i3, t4) || !i3[e4]);
          }, limitedChoices: function(s4) {
            const n3 = t3.getOptions(), r3 = {};
            if (!Object.keys(n3.choices).length)
              return;
            Object.keys(s4).forEach((t4) => {
              -1 === H.indexOf(t4) && Object.prototype.hasOwnProperty.call(n3.choices, t4) && [].concat(s4[t4]).forEach((e4) => {
                -1 === n3.choices[t4].indexOf(e4) && void 0 !== e4 && (r3[t4] = (r3[t4] || []).concat(e4));
              });
            });
            const o3 = Object.keys(r3);
            if (!o3.length)
              return;
            let a3 = i2("Invalid values:");
            o3.forEach((t4) => {
              a3 += `
  ${i2("Argument: %s, Given: %s, Choices: %s", t4, e3.stringifiedValues(r3[t4]), e3.stringifiedValues(n3.choices[t4]))}`;
            }), e3.fail(a3);
          } };
          let o2 = {};
          function a2(t4, e4) {
            const s4 = Number(e4);
            return "number" == typeof (e4 = isNaN(s4) ? e4 : s4) ? e4 = t4._.length >= e4 : e4.match(/^--no-.+/) ? (e4 = e4.match(/^--no-(.+)/)[1], e4 = !Object.prototype.hasOwnProperty.call(t4, e4)) : e4 = Object.prototype.hasOwnProperty.call(t4, e4), e4;
          }
          r2.implies = function(e4, i3) {
            h("<string|object> [array|number|string]", [e4, i3], arguments.length), "object" == typeof e4 ? Object.keys(e4).forEach((t4) => {
              r2.implies(t4, e4[t4]);
            }) : (t3.global(e4), o2[e4] || (o2[e4] = []), Array.isArray(i3) ? i3.forEach((t4) => r2.implies(e4, t4)) : (d(i3, void 0, s3), o2[e4].push(i3)));
          }, r2.getImplied = function() {
            return o2;
          }, r2.implications = function(t4) {
            const s4 = [];
            if (Object.keys(o2).forEach((e4) => {
              const i3 = e4;
              (o2[e4] || []).forEach((e5) => {
                let n3 = i3;
                const r3 = e5;
                n3 = a2(t4, n3), e5 = a2(t4, e5), n3 && !e5 && s4.push(` ${i3} -> ${r3}`);
              });
            }), s4.length) {
              let t5 = `${i2("Implications failed:")}
`;
              s4.forEach((e4) => {
                t5 += e4;
              }), e3.fail(t5);
            }
          };
          let l2 = {};
          r2.conflicts = function(e4, s4) {
            h("<string|object> [array|string]", [e4, s4], arguments.length), "object" == typeof e4 ? Object.keys(e4).forEach((t4) => {
              r2.conflicts(t4, e4[t4]);
            }) : (t3.global(e4), l2[e4] || (l2[e4] = []), Array.isArray(s4) ? s4.forEach((t4) => r2.conflicts(e4, t4)) : l2[e4].push(s4));
          }, r2.getConflicting = () => l2, r2.conflicting = function(n3) {
            Object.keys(n3).forEach((t4) => {
              l2[t4] && l2[t4].forEach((s4) => {
                s4 && void 0 !== n3[t4] && void 0 !== n3[s4] && e3.fail(i2("Arguments %s and %s are mutually exclusive", t4, s4));
              });
            }), t3.getInternalMethods().getParserConfiguration()["strip-dashed"] && Object.keys(l2).forEach((t4) => {
              l2[t4].forEach((r3) => {
                r3 && void 0 !== n3[s3.Parser.camelCase(t4)] && void 0 !== n3[s3.Parser.camelCase(r3)] && e3.fail(i2("Arguments %s and %s are mutually exclusive", t4, r3));
              });
            });
          }, r2.recommendCommands = function(t4, s4) {
            s4 = s4.sort((t5, e4) => e4.length - t5.length);
            let n3 = null, r3 = 1 / 0;
            for (let e4, i3 = 0; void 0 !== (e4 = s4[i3]); i3++) {
              const s5 = N(t4, e4);
              s5 <= 3 && s5 < r3 && (r3 = s5, n3 = e4);
            }
            n3 && e3.fail(i2("Did you mean %s?", n3));
          }, r2.reset = function(t4) {
            return o2 = g(o2, (e4) => !t4[e4]), l2 = g(l2, (e4) => !t4[e4]), r2;
          };
          const c2 = [];
          return r2.freeze = function() {
            c2.push({ implied: o2, conflicting: l2 });
          }, r2.unfreeze = function() {
            const t4 = c2.pop();
            d(t4, void 0, s3), { implied: o2, conflicting: l2 } = t4;
          }, r2;
        }(this, v(this, pt, "f"), v(this, ct, "f")), "f"), O(this, z, v(this, z, "f") ? v(this, z, "f").reset() : function(t3, e3, s3, i2) {
          return new M(t3, e3, s3, i2);
        }(v(this, pt, "f"), v(this, mt, "f"), v(this, B, "f"), v(this, ct, "f")), "f"), v(this, F, "f") || O(this, F, function(t3, e3, s3, i2) {
          return new D(t3, e3, s3, i2);
        }(this, v(this, pt, "f"), v(this, z, "f"), v(this, ct, "f")), "f"), v(this, B, "f").reset(), O(this, U, null, "f"), O(this, tt, "", "f"), O(this, V, null, "f"), O(this, J, false, "f"), this.parsed = false, this;
      }
      [Tt](t2, e2) {
        return v(this, ct, "f").path.relative(t2, e2);
      }
      [Bt](t2, s2, i2, n2 = 0, r2 = false) {
        let o2 = !!i2 || r2;
        t2 = t2 || v(this, ht, "f"), v(this, et, "f").__ = v(this, ct, "f").y18n.__, v(this, et, "f").configuration = this[jt]();
        const a2 = !!v(this, et, "f").configuration["populate--"], h2 = Object.assign({}, v(this, et, "f").configuration, { "populate--": true }), l2 = v(this, ct, "f").Parser.detailed(t2, Object.assign({}, v(this, et, "f"), { configuration: { "parse-positional-numbers": false, ...h2 } })), c2 = Object.assign(l2.argv, v(this, rt, "f"));
        let d2;
        const u2 = l2.aliases;
        let p2 = false, g2 = false;
        Object.keys(c2).forEach((t3) => {
          t3 === v(this, Z, "f") && c2[t3] ? p2 = true : t3 === v(this, gt, "f") && c2[t3] && (g2 = true);
        }), c2.$0 = this.$0, this.parsed = l2, 0 === n2 && v(this, pt, "f").clearCachedHelpMessage();
        try {
          if (this[_t](), s2)
            return this[Rt](c2, a2, !!i2, false);
          if (v(this, Z, "f")) {
            [v(this, Z, "f")].concat(u2[v(this, Z, "f")] || []).filter((t3) => t3.length > 1).includes("" + c2._[c2._.length - 1]) && (c2._.pop(), p2 = true);
          }
          O(this, X, false, "f");
          const h3 = v(this, z, "f").getCommands(), m2 = v(this, F, "f").completionKey in c2, y2 = p2 || m2 || r2;
          if (c2._.length) {
            if (h3.length) {
              let t3;
              for (let e2, s3 = n2 || 0; void 0 !== c2._[s3]; s3++) {
                if (e2 = String(c2._[s3]), h3.includes(e2) && e2 !== v(this, U, "f")) {
                  const t4 = v(this, z, "f").runCommand(e2, this, l2, s3 + 1, r2, p2 || g2 || r2);
                  return this[Rt](t4, a2, !!i2, false);
                }
                if (!t3 && e2 !== v(this, U, "f")) {
                  t3 = e2;
                  break;
                }
              }
              !v(this, z, "f").hasDefaultCommand() && v(this, lt, "f") && t3 && !y2 && v(this, mt, "f").recommendCommands(t3, h3);
            }
            v(this, U, "f") && c2._.includes(v(this, U, "f")) && !m2 && (v(this, T, "f") && E(true), this.showCompletionScript(), this.exit(0));
          }
          if (v(this, z, "f").hasDefaultCommand() && !y2) {
            const t3 = v(this, z, "f").runCommand(null, this, l2, 0, r2, p2 || g2 || r2);
            return this[Rt](t3, a2, !!i2, false);
          }
          if (m2) {
            v(this, T, "f") && E(true);
            const s3 = (t2 = [].concat(t2)).slice(t2.indexOf(`--${v(this, F, "f").completionKey}`) + 1);
            return v(this, F, "f").getCompletion(s3, (t3, s4) => {
              if (t3)
                throw new e(t3.message);
              (s4 || []).forEach((t4) => {
                v(this, Q, "f").log(t4);
              }), this.exit(0);
            }), this[Rt](c2, !a2, !!i2, false);
          }
          if (v(this, J, "f") || (p2 ? (v(this, T, "f") && E(true), o2 = true, this.showHelp("log"), this.exit(0)) : g2 && (v(this, T, "f") && E(true), o2 = true, v(this, pt, "f").showVersion("log"), this.exit(0))), !o2 && v(this, et, "f").skipValidation.length > 0 && (o2 = Object.keys(c2).some((t3) => v(this, et, "f").skipValidation.indexOf(t3) >= 0 && true === c2[t3])), !o2) {
            if (l2.error)
              throw new e(l2.error.message);
            if (!m2) {
              const t3 = this[Yt](u2, {}, l2.error);
              i2 || (d2 = C(c2, this, v(this, B, "f").getMiddleware(), true)), d2 = this[Nt](t3, null != d2 ? d2 : c2), f(d2) && !i2 && (d2 = d2.then(() => C(c2, this, v(this, B, "f").getMiddleware(), false)));
            }
          }
        } catch (t3) {
          if (!(t3 instanceof e))
            throw t3;
          v(this, pt, "f").fail(t3.message, t3);
        }
        return this[Rt](null != d2 ? d2 : c2, a2, !!i2, true);
      }
      [Yt](t2, s2, i2, n2) {
        const r2 = { ...this.getDemandedOptions() };
        return (o2) => {
          if (i2)
            throw new e(i2.message);
          v(this, mt, "f").nonOptionCount(o2), v(this, mt, "f").requiredArguments(o2, r2);
          let a2 = false;
          v(this, dt, "f") && (a2 = v(this, mt, "f").unknownCommands(o2)), v(this, ft, "f") && !a2 ? v(this, mt, "f").unknownArguments(o2, t2, s2, !!n2) : v(this, ut, "f") && v(this, mt, "f").unknownArguments(o2, t2, {}, false, false), v(this, mt, "f").limitedChoices(o2), v(this, mt, "f").implications(o2), v(this, mt, "f").conflicting(o2);
        };
      }
      [Jt]() {
        O(this, J, true, "f");
      }
      [Zt](t2) {
        if ("string" == typeof t2)
          v(this, et, "f").key[t2] = true;
        else
          for (const e2 of t2)
            v(this, et, "f").key[e2] = true;
      }
    };
    var Qt;
    var te;
    var { readFileSync: ee } = require("fs");
    var { inspect: se } = require("util");
    var { resolve: ie } = require("path");
    var ne = require_build();
    var re = require_build2();
    var oe;
    var ae = { assert: { notStrictEqual: t.notStrictEqual, strictEqual: t.strictEqual }, cliui: require_build3(), findUp: require_sync(), getEnv: (t2) => process.env[t2], getCallerFile: require_get_caller_file(), getProcessArgvBin: y, inspect: se, mainFilename: null !== (te = null === (Qt = null === require || void 0 === require ? void 0 : require.main) || void 0 === Qt ? void 0 : Qt.filename) && void 0 !== te ? te : process.cwd(), Parser: re, path: require("path"), process: { argv: () => process.argv, cwd: process.cwd, emitWarning: (t2, e2) => process.emitWarning(t2, e2), execPath: () => process.execPath, exit: (t2) => {
      process.exit(t2);
    }, nextTick: process.nextTick, stdColumns: void 0 !== process.stdout.columns ? process.stdout.columns : null }, readFileSync: ee, require, requireDirectory: require_require_directory(), stringWidth: require_string_width(), y18n: ne({ directory: ie(__dirname, "../locales"), updateFiles: false }) };
    var he = (null === (oe = null === process || void 0 === process ? void 0 : process.env) || void 0 === oe ? void 0 : oe.YARGS_MIN_NODE_VERSION) ? Number(process.env.YARGS_MIN_NODE_VERSION) : 12;
    if (process && process.version) {
      if (Number(process.version.match(/v([^.]+)/)[1]) < he)
        throw Error(`yargs supports a minimum Node.js version of ${he}. Read our version support policy: https://github.com/yargs/yargs#supported-nodejs-versions`);
    }
    var le = require_build2();
    var ce;
    var fe = { applyExtends: n, cjsPlatformShim: ae, Yargs: (ce = ae, (t2 = [], e2 = ce.process.cwd(), s2) => {
      const i2 = new Xt(t2, e2, s2, ce);
      return Object.defineProperty(i2, "argv", { get: () => i2.parse(), enumerable: true }), i2.help(), i2.version(), i2;
    }), argsert: h, isPromise: f, objFilter: g, parseCommand: o, Parser: le, processArgv: b, YError: e };
    module2.exports = fe;
  }
});

// node_modules/path-normalize/lib/index.js
var require_lib = __commonJS({
  "node_modules/path-normalize/lib/index.js"(exports, module2) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports["default"] = void 0;
    function _typeof(obj) {
      "@babel/helpers - typeof";
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
        return typeof obj2;
      } : function(obj2) {
        return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
      }, _typeof(obj);
    }
    var SLASH = 47;
    var DOT = 46;
    var assertPath = function assertPath2(path) {
      var t = _typeof(path);
      if (t !== "string") {
        throw new TypeError("Expected a string, got a ".concat(t));
      }
    };
    var posixNormalize = function posixNormalize2(path, allowAboveRoot) {
      var res = "";
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code;
      for (var i = 0; i <= path.length; ++i) {
        if (i < path.length) {
          code = path.charCodeAt(i);
        } else if (code === SLASH) {
          break;
        } else {
          code = SLASH;
        }
        if (code === SLASH) {
          if (lastSlash === i - 1 || dots === 1) {
          } else if (lastSlash !== i - 1 && dots === 2) {
            if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== DOT || res.charCodeAt(res.length - 2) !== DOT) {
              if (res.length > 2) {
                var lastSlashIndex = res.lastIndexOf("/");
                if (lastSlashIndex !== res.length - 1) {
                  if (lastSlashIndex === -1) {
                    res = "";
                    lastSegmentLength = 0;
                  } else {
                    res = res.slice(0, lastSlashIndex);
                    lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
                  }
                  lastSlash = i;
                  dots = 0;
                  continue;
                }
              } else if (res.length === 2 || res.length === 1) {
                res = "";
                lastSegmentLength = 0;
                lastSlash = i;
                dots = 0;
                continue;
              }
            }
            if (allowAboveRoot) {
              if (res.length > 0) {
                res += "/..";
              } else {
                res = "..";
              }
              lastSegmentLength = 2;
            }
          } else {
            if (res.length > 0) {
              res += "/" + path.slice(lastSlash + 1, i);
            } else {
              res = path.slice(lastSlash + 1, i);
            }
            lastSegmentLength = i - lastSlash - 1;
          }
          lastSlash = i;
          dots = 0;
        } else if (code === DOT && dots !== -1) {
          ++dots;
        } else {
          dots = -1;
        }
      }
      return res;
    };
    var decode = function decode2(s) {
      try {
        return decodeURIComponent(s);
      } catch (_unused) {
        return s;
      }
    };
    var normalize2 = function normalize3(p) {
      assertPath(p);
      var path = p;
      if (path.length === 0) {
        return ".";
      }
      var isAbsolute = path.charCodeAt(0) === SLASH;
      var trailingSeparator = path.charCodeAt(path.length - 1) === SLASH;
      path = decode(path);
      path = posixNormalize(path, !isAbsolute);
      if (path.length === 0 && !isAbsolute) {
        path = ".";
      }
      if (path.length > 0 && trailingSeparator) {
        path += "/";
      }
      if (isAbsolute) {
        return "/" + path;
      }
      return path;
    };
    var _default = normalize2;
    exports["default"] = _default;
    module2.exports = exports.default;
  }
});

// node_modules/restructure/src/DecodeStream.js
var require_DecodeStream = __commonJS({
  "node_modules/restructure/src/DecodeStream.js"(exports, module2) {
    var iconv;
    try {
      iconv = require("iconv-lite");
    } catch (error) {
    }
    var DecodeStream = class {
      constructor(buffer) {
        this.buffer = buffer;
        this.pos = 0;
        this.length = this.buffer.length;
      }
      readString(length, encoding = "ascii") {
        switch (encoding) {
          case "utf16le":
          case "ucs2":
          case "utf8":
          case "ascii":
            return this.buffer.toString(encoding, this.pos, this.pos += length);
          case "utf16be":
            var buf = Buffer.from(this.readBuffer(length));
            for (let i = 0, end = buf.length - 1; i < end; i += 2) {
              const byte = buf[i];
              buf[i] = buf[i + 1];
              buf[i + 1] = byte;
            }
            return buf.toString("utf16le");
          default:
            buf = this.readBuffer(length);
            if (iconv) {
              try {
                return iconv.decode(buf, encoding);
              } catch (error1) {
              }
            }
            return buf;
        }
      }
      readBuffer(length) {
        return this.buffer.slice(this.pos, this.pos += length);
      }
      readUInt24BE() {
        return (this.readUInt16BE() << 8) + this.readUInt8();
      }
      readUInt24LE() {
        return this.readUInt16LE() + (this.readUInt8() << 16);
      }
      readInt24BE() {
        return (this.readInt16BE() << 8) + this.readUInt8();
      }
      readInt24LE() {
        return this.readUInt16LE() + (this.readInt8() << 16);
      }
    };
    DecodeStream.TYPES = {
      UInt8: 1,
      UInt16: 2,
      UInt24: 3,
      UInt32: 4,
      Int8: 1,
      Int16: 2,
      Int24: 3,
      Int32: 4,
      Float: 4,
      Double: 8
    };
    for (let key in Buffer.prototype) {
      if (key.slice(0, 4) === "read") {
        const bytes = DecodeStream.TYPES[key.replace(/read|[BL]E/g, "")];
        DecodeStream.prototype[key] = function() {
          const ret = this.buffer[key](this.pos);
          this.pos += bytes;
          return ret;
        };
      }
    }
    module2.exports = DecodeStream;
  }
});

// node_modules/restructure/src/EncodeStream.js
var require_EncodeStream = __commonJS({
  "node_modules/restructure/src/EncodeStream.js"(exports, module2) {
    var iconv;
    var stream = require("stream");
    var DecodeStream = require_DecodeStream();
    try {
      iconv = require("iconv-lite");
    } catch (error) {
    }
    var EncodeStream = class extends stream.Readable {
      constructor(bufferSize = 65536) {
        super(...arguments);
        this.buffer = Buffer.alloc(bufferSize);
        this.bufferOffset = 0;
        this.pos = 0;
      }
      _read() {
      }
      ensure(bytes) {
        if (this.bufferOffset + bytes > this.buffer.length) {
          return this.flush();
        }
      }
      flush() {
        if (this.bufferOffset > 0) {
          this.push(Buffer.from(this.buffer.slice(0, this.bufferOffset)));
          return this.bufferOffset = 0;
        }
      }
      writeBuffer(buffer) {
        this.flush();
        this.push(buffer);
        return this.pos += buffer.length;
      }
      writeString(string, encoding = "ascii") {
        switch (encoding) {
          case "utf16le":
          case "ucs2":
          case "utf8":
          case "ascii":
            return this.writeBuffer(Buffer.from(string, encoding));
          case "utf16be":
            var buf = Buffer.from(string, "utf16le");
            for (let i = 0, end = buf.length - 1; i < end; i += 2) {
              const byte = buf[i];
              buf[i] = buf[i + 1];
              buf[i + 1] = byte;
            }
            return this.writeBuffer(buf);
          default:
            if (iconv) {
              return this.writeBuffer(iconv.encode(string, encoding));
            } else {
              throw new Error("Install iconv-lite to enable additional string encodings.");
            }
        }
      }
      writeUInt24BE(val) {
        this.ensure(3);
        this.buffer[this.bufferOffset++] = val >>> 16 & 255;
        this.buffer[this.bufferOffset++] = val >>> 8 & 255;
        this.buffer[this.bufferOffset++] = val & 255;
        return this.pos += 3;
      }
      writeUInt24LE(val) {
        this.ensure(3);
        this.buffer[this.bufferOffset++] = val & 255;
        this.buffer[this.bufferOffset++] = val >>> 8 & 255;
        this.buffer[this.bufferOffset++] = val >>> 16 & 255;
        return this.pos += 3;
      }
      writeInt24BE(val) {
        if (val >= 0) {
          return this.writeUInt24BE(val);
        } else {
          return this.writeUInt24BE(val + 16777215 + 1);
        }
      }
      writeInt24LE(val) {
        if (val >= 0) {
          return this.writeUInt24LE(val);
        } else {
          return this.writeUInt24LE(val + 16777215 + 1);
        }
      }
      fill(val, length) {
        if (length < this.buffer.length) {
          this.ensure(length);
          this.buffer.fill(val, this.bufferOffset, this.bufferOffset + length);
          this.bufferOffset += length;
          return this.pos += length;
        } else {
          const buf = Buffer.alloc(length);
          buf.fill(val);
          return this.writeBuffer(buf);
        }
      }
      end() {
        this.flush();
        return this.push(null);
      }
    };
    for (let key in Buffer.prototype) {
      if (key.slice(0, 5) === "write") {
        const bytes = +DecodeStream.TYPES[key.replace(/write|[BL]E/g, "")];
        EncodeStream.prototype[key] = function(value) {
          this.ensure(bytes);
          this.buffer[key](value, this.bufferOffset);
          this.bufferOffset += bytes;
          return this.pos += bytes;
        };
      }
    }
    module2.exports = EncodeStream;
  }
});

// node_modules/restructure/src/Number.js
var require_Number = __commonJS({
  "node_modules/restructure/src/Number.js"(exports) {
    var DecodeStream = require_DecodeStream();
    var NumberT = class {
      constructor(type, endian = "BE") {
        this.type = type;
        this.endian = endian;
        this.fn = this.type;
        if (this.type[this.type.length - 1] !== "8") {
          this.fn += this.endian;
        }
      }
      size() {
        return DecodeStream.TYPES[this.type];
      }
      decode(stream) {
        return stream[`read${this.fn}`]();
      }
      encode(stream, val) {
        return stream[`write${this.fn}`](val);
      }
    };
    exports.Number = NumberT;
    exports.uint8 = new NumberT("UInt8");
    exports.uint16be = exports.uint16 = new NumberT("UInt16", "BE");
    exports.uint16le = new NumberT("UInt16", "LE");
    exports.uint24be = exports.uint24 = new NumberT("UInt24", "BE");
    exports.uint24le = new NumberT("UInt24", "LE");
    exports.uint32be = exports.uint32 = new NumberT("UInt32", "BE");
    exports.uint32le = new NumberT("UInt32", "LE");
    exports.int8 = new NumberT("Int8");
    exports.int16be = exports.int16 = new NumberT("Int16", "BE");
    exports.int16le = new NumberT("Int16", "LE");
    exports.int24be = exports.int24 = new NumberT("Int24", "BE");
    exports.int24le = new NumberT("Int24", "LE");
    exports.int32be = exports.int32 = new NumberT("Int32", "BE");
    exports.int32le = new NumberT("Int32", "LE");
    exports.floatbe = exports.float = new NumberT("Float", "BE");
    exports.floatle = new NumberT("Float", "LE");
    exports.doublebe = exports.double = new NumberT("Double", "BE");
    exports.doublele = new NumberT("Double", "LE");
    var Fixed = class extends NumberT {
      constructor(size, endian, fracBits = size >> 1) {
        super(`Int${size}`, endian);
        this._point = 1 << fracBits;
      }
      decode(stream) {
        return super.decode(stream) / this._point;
      }
      encode(stream, val) {
        return super.encode(stream, val * this._point | 0);
      }
    };
    exports.Fixed = Fixed;
    exports.fixed16be = exports.fixed16 = new Fixed(16, "BE");
    exports.fixed16le = new Fixed(16, "LE");
    exports.fixed32be = exports.fixed32 = new Fixed(32, "BE");
    exports.fixed32le = new Fixed(32, "LE");
  }
});

// node_modules/restructure/src/utils.js
var require_utils = __commonJS({
  "node_modules/restructure/src/utils.js"(exports) {
    var { Number: NumberT } = require_Number();
    exports.resolveLength = function(length, stream, parent) {
      let res;
      if (typeof length === "number") {
        res = length;
      } else if (typeof length === "function") {
        res = length.call(parent, parent);
      } else if (parent && typeof length === "string") {
        res = parent[length];
      } else if (stream && length instanceof NumberT) {
        res = length.decode(stream);
      }
      if (isNaN(res)) {
        throw new Error("Not a fixed size");
      }
      return res;
    };
    var PropertyDescriptor = class {
      constructor(opts = {}) {
        this.enumerable = true;
        this.configurable = true;
        for (let key in opts) {
          const val = opts[key];
          this[key] = val;
        }
      }
    };
    exports.PropertyDescriptor = PropertyDescriptor;
  }
});

// node_modules/restructure/src/Array.js
var require_Array = __commonJS({
  "node_modules/restructure/src/Array.js"(exports, module2) {
    var { Number: NumberT } = require_Number();
    var utils = require_utils();
    var ArrayT = class {
      constructor(type, length, lengthType = "count") {
        this.type = type;
        this.length = length;
        this.lengthType = lengthType;
      }
      decode(stream, parent) {
        let length;
        const { pos } = stream;
        const res = [];
        let ctx = parent;
        if (this.length != null) {
          length = utils.resolveLength(this.length, stream, parent);
        }
        if (this.length instanceof NumberT) {
          Object.defineProperties(res, {
            parent: { value: parent },
            _startOffset: { value: pos },
            _currentOffset: { value: 0, writable: true },
            _length: { value: length }
          });
          ctx = res;
        }
        if (length == null || this.lengthType === "bytes") {
          const target = length != null ? stream.pos + length : (parent != null ? parent._length : void 0) ? parent._startOffset + parent._length : stream.length;
          while (stream.pos < target) {
            res.push(this.type.decode(stream, ctx));
          }
        } else {
          for (let i = 0, end = length; i < end; i++) {
            res.push(this.type.decode(stream, ctx));
          }
        }
        return res;
      }
      size(array, ctx) {
        if (!array) {
          return this.type.size(null, ctx) * utils.resolveLength(this.length, null, ctx);
        }
        let size = 0;
        if (this.length instanceof NumberT) {
          size += this.length.size();
          ctx = { parent: ctx };
        }
        for (let item of array) {
          size += this.type.size(item, ctx);
        }
        return size;
      }
      encode(stream, array, parent) {
        let ctx = parent;
        if (this.length instanceof NumberT) {
          ctx = {
            pointers: [],
            startOffset: stream.pos,
            parent
          };
          ctx.pointerOffset = stream.pos + this.size(array, ctx);
          this.length.encode(stream, array.length);
        }
        for (let item of array) {
          this.type.encode(stream, item, ctx);
        }
        if (this.length instanceof NumberT) {
          let i = 0;
          while (i < ctx.pointers.length) {
            const ptr = ctx.pointers[i++];
            ptr.type.encode(stream, ptr.val);
          }
        }
      }
    };
    module2.exports = ArrayT;
  }
});

// node_modules/restructure/src/LazyArray.js
var require_LazyArray = __commonJS({
  "node_modules/restructure/src/LazyArray.js"(exports, module2) {
    var ArrayT = require_Array();
    var { Number: NumberT } = require_Number();
    var utils = require_utils();
    var { inspect: inspect2 } = require("util");
    var LazyArrayT = class extends ArrayT {
      decode(stream, parent) {
        const { pos } = stream;
        const length = utils.resolveLength(this.length, stream, parent);
        if (this.length instanceof NumberT) {
          parent = {
            parent,
            _startOffset: pos,
            _currentOffset: 0,
            _length: length
          };
        }
        const res = new LazyArray(this.type, length, stream, parent);
        stream.pos += length * this.type.size(null, parent);
        return res;
      }
      size(val, ctx) {
        if (val instanceof LazyArray) {
          val = val.toArray();
        }
        return super.size(val, ctx);
      }
      encode(stream, val, ctx) {
        if (val instanceof LazyArray) {
          val = val.toArray();
        }
        return super.encode(stream, val, ctx);
      }
    };
    var LazyArray = class {
      constructor(type, length, stream, ctx) {
        this.type = type;
        this.length = length;
        this.stream = stream;
        this.ctx = ctx;
        this.base = this.stream.pos;
        this.items = [];
      }
      get(index) {
        if (index < 0 || index >= this.length) {
          return void 0;
        }
        if (this.items[index] == null) {
          const { pos } = this.stream;
          this.stream.pos = this.base + this.type.size(null, this.ctx) * index;
          this.items[index] = this.type.decode(this.stream, this.ctx);
          this.stream.pos = pos;
        }
        return this.items[index];
      }
      toArray() {
        const result = [];
        for (let i = 0, end = this.length; i < end; i++) {
          result.push(this.get(i));
        }
        return result;
      }
      inspect() {
        return inspect2(this.toArray());
      }
    };
    module2.exports = LazyArrayT;
  }
});

// node_modules/restructure/src/Bitfield.js
var require_Bitfield = __commonJS({
  "node_modules/restructure/src/Bitfield.js"(exports, module2) {
    var Bitfield = class {
      constructor(type, flags = []) {
        this.type = type;
        this.flags = flags;
      }
      decode(stream) {
        const val = this.type.decode(stream);
        const res = {};
        for (let i = 0; i < this.flags.length; i++) {
          const flag = this.flags[i];
          if (flag != null) {
            res[flag] = !!(val & 1 << i);
          }
        }
        return res;
      }
      size() {
        return this.type.size();
      }
      encode(stream, keys) {
        let val = 0;
        for (let i = 0; i < this.flags.length; i++) {
          const flag = this.flags[i];
          if (flag != null) {
            if (keys[flag]) {
              val |= 1 << i;
            }
          }
        }
        return this.type.encode(stream, val);
      }
    };
    module2.exports = Bitfield;
  }
});

// node_modules/restructure/src/Boolean.js
var require_Boolean = __commonJS({
  "node_modules/restructure/src/Boolean.js"(exports, module2) {
    var BooleanT = class {
      constructor(type) {
        this.type = type;
      }
      decode(stream, parent) {
        return !!this.type.decode(stream, parent);
      }
      size(val, parent) {
        return this.type.size(val, parent);
      }
      encode(stream, val, parent) {
        return this.type.encode(stream, +val, parent);
      }
    };
    module2.exports = BooleanT;
  }
});

// node_modules/restructure/src/Buffer.js
var require_Buffer = __commonJS({
  "node_modules/restructure/src/Buffer.js"(exports, module2) {
    var utils = require_utils();
    var { Number: NumberT } = require_Number();
    var BufferT = class {
      constructor(length) {
        this.length = length;
      }
      decode(stream, parent) {
        const length = utils.resolveLength(this.length, stream, parent);
        return stream.readBuffer(length);
      }
      size(val, parent) {
        if (!val) {
          return utils.resolveLength(this.length, null, parent);
        }
        return val.length;
      }
      encode(stream, buf, parent) {
        if (this.length instanceof NumberT) {
          this.length.encode(stream, buf.length);
        }
        return stream.writeBuffer(buf);
      }
    };
    module2.exports = BufferT;
  }
});

// node_modules/restructure/src/Enum.js
var require_Enum = __commonJS({
  "node_modules/restructure/src/Enum.js"(exports, module2) {
    var Enum = class {
      constructor(type, options = []) {
        this.type = type;
        this.options = options;
      }
      decode(stream) {
        const index = this.type.decode(stream);
        return this.options[index] || index;
      }
      size() {
        return this.type.size();
      }
      encode(stream, val) {
        const index = this.options.indexOf(val);
        if (index === -1) {
          throw new Error(`Unknown option in enum: ${val}`);
        }
        return this.type.encode(stream, index);
      }
    };
    module2.exports = Enum;
  }
});

// node_modules/restructure/src/Optional.js
var require_Optional = __commonJS({
  "node_modules/restructure/src/Optional.js"(exports, module2) {
    var Optional = class {
      constructor(type, condition = true) {
        this.type = type;
        this.condition = condition;
      }
      decode(stream, parent) {
        let { condition } = this;
        if (typeof condition === "function") {
          condition = condition.call(parent, parent);
        }
        if (condition) {
          return this.type.decode(stream, parent);
        }
      }
      size(val, parent) {
        let { condition } = this;
        if (typeof condition === "function") {
          condition = condition.call(parent, parent);
        }
        if (condition) {
          return this.type.size(val, parent);
        } else {
          return 0;
        }
      }
      encode(stream, val, parent) {
        let { condition } = this;
        if (typeof condition === "function") {
          condition = condition.call(parent, parent);
        }
        if (condition) {
          return this.type.encode(stream, val, parent);
        }
      }
    };
    module2.exports = Optional;
  }
});

// node_modules/restructure/src/Reserved.js
var require_Reserved = __commonJS({
  "node_modules/restructure/src/Reserved.js"(exports, module2) {
    var utils = require_utils();
    var Reserved = class {
      constructor(type, count = 1) {
        this.type = type;
        this.count = count;
      }
      decode(stream, parent) {
        stream.pos += this.size(null, parent);
        return void 0;
      }
      size(data, parent) {
        const count = utils.resolveLength(this.count, null, parent);
        return this.type.size() * count;
      }
      encode(stream, val, parent) {
        return stream.fill(0, this.size(val, parent));
      }
    };
    module2.exports = Reserved;
  }
});

// node_modules/restructure/src/String.js
var require_String = __commonJS({
  "node_modules/restructure/src/String.js"(exports, module2) {
    var { Number: NumberT } = require_Number();
    var utils = require_utils();
    var StringT = class {
      constructor(length, encoding = "ascii") {
        this.length = length;
        this.encoding = encoding;
      }
      decode(stream, parent) {
        let length, pos;
        if (this.length != null) {
          length = utils.resolveLength(this.length, stream, parent);
        } else {
          let buffer;
          ({ buffer, length, pos } = stream);
          while (pos < length && buffer[pos] !== 0) {
            ++pos;
          }
          length = pos - stream.pos;
        }
        let { encoding } = this;
        if (typeof encoding === "function") {
          encoding = encoding.call(parent, parent) || "ascii";
        }
        const string = stream.readString(length, encoding);
        if (this.length == null && stream.pos < stream.length) {
          stream.pos++;
        }
        return string;
      }
      size(val, parent) {
        if (!val) {
          return utils.resolveLength(this.length, null, parent);
        }
        let { encoding } = this;
        if (typeof encoding === "function") {
          encoding = encoding.call(parent != null ? parent.val : void 0, parent != null ? parent.val : void 0) || "ascii";
        }
        if (encoding === "utf16be") {
          encoding = "utf16le";
        }
        let size = Buffer.byteLength(val, encoding);
        if (this.length instanceof NumberT) {
          size += this.length.size();
        }
        if (this.length == null) {
          size++;
        }
        return size;
      }
      encode(stream, val, parent) {
        let { encoding } = this;
        if (typeof encoding === "function") {
          encoding = encoding.call(parent != null ? parent.val : void 0, parent != null ? parent.val : void 0) || "ascii";
        }
        if (this.length instanceof NumberT) {
          this.length.encode(stream, Buffer.byteLength(val, encoding));
        }
        stream.writeString(val, encoding);
        if (this.length == null) {
          return stream.writeUInt8(0);
        }
      }
    };
    module2.exports = StringT;
  }
});

// node_modules/restructure/src/Struct.js
var require_Struct = __commonJS({
  "node_modules/restructure/src/Struct.js"(exports, module2) {
    var utils = require_utils();
    var Struct = class {
      constructor(fields = {}) {
        this.fields = fields;
      }
      decode(stream, parent, length = 0) {
        const res = this._setup(stream, parent, length);
        this._parseFields(stream, res, this.fields);
        if (this.process != null) {
          this.process.call(res, stream);
        }
        return res;
      }
      _setup(stream, parent, length) {
        const res = {};
        Object.defineProperties(res, {
          parent: { value: parent },
          _startOffset: { value: stream.pos },
          _currentOffset: { value: 0, writable: true },
          _length: { value: length }
        });
        return res;
      }
      _parseFields(stream, res, fields) {
        for (let key in fields) {
          var val;
          const type = fields[key];
          if (typeof type === "function") {
            val = type.call(res, res);
          } else {
            val = type.decode(stream, res);
          }
          if (val !== void 0) {
            if (val instanceof utils.PropertyDescriptor) {
              Object.defineProperty(res, key, val);
            } else {
              res[key] = val;
            }
          }
          res._currentOffset = stream.pos - res._startOffset;
        }
      }
      size(val, parent, includePointers) {
        if (val == null) {
          val = {};
        }
        if (includePointers == null) {
          includePointers = true;
        }
        const ctx = {
          parent,
          val,
          pointerSize: 0
        };
        let size = 0;
        for (let key in this.fields) {
          const type = this.fields[key];
          if (type.size != null) {
            size += type.size(val[key], ctx);
          }
        }
        if (includePointers) {
          size += ctx.pointerSize;
        }
        return size;
      }
      encode(stream, val, parent) {
        let type;
        if (this.preEncode != null) {
          this.preEncode.call(val, stream);
        }
        const ctx = {
          pointers: [],
          startOffset: stream.pos,
          parent,
          val,
          pointerSize: 0
        };
        ctx.pointerOffset = stream.pos + this.size(val, ctx, false);
        for (let key in this.fields) {
          type = this.fields[key];
          if (type.encode != null) {
            type.encode(stream, val[key], ctx);
          }
        }
        let i = 0;
        while (i < ctx.pointers.length) {
          const ptr = ctx.pointers[i++];
          ptr.type.encode(stream, ptr.val, ptr.parent);
        }
      }
    };
    module2.exports = Struct;
  }
});

// node_modules/restructure/src/VersionedStruct.js
var require_VersionedStruct = __commonJS({
  "node_modules/restructure/src/VersionedStruct.js"(exports, module2) {
    var Struct = require_Struct();
    var getPath = (object, pathArray) => {
      return pathArray.reduce((prevObj, key) => prevObj && prevObj[key], object);
    };
    var VersionedStruct = class extends Struct {
      constructor(type, versions = {}) {
        super();
        this.type = type;
        this.versions = versions;
        if (typeof type === "string") {
          this.versionPath = type.split(".");
        }
      }
      decode(stream, parent, length = 0) {
        const res = this._setup(stream, parent, length);
        if (typeof this.type === "string") {
          res.version = getPath(parent, this.versionPath);
        } else {
          res.version = this.type.decode(stream);
        }
        if (this.versions.header) {
          this._parseFields(stream, res, this.versions.header);
        }
        const fields = this.versions[res.version];
        if (fields == null) {
          throw new Error(`Unknown version ${res.version}`);
        }
        if (fields instanceof VersionedStruct) {
          return fields.decode(stream, parent);
        }
        this._parseFields(stream, res, fields);
        if (this.process != null) {
          this.process.call(res, stream);
        }
        return res;
      }
      size(val, parent, includePointers = true) {
        let key, type;
        if (!val) {
          throw new Error("Not a fixed size");
        }
        const ctx = {
          parent,
          val,
          pointerSize: 0
        };
        let size = 0;
        if (typeof this.type !== "string") {
          size += this.type.size(val.version, ctx);
        }
        if (this.versions.header) {
          for (key in this.versions.header) {
            type = this.versions.header[key];
            if (type.size != null) {
              size += type.size(val[key], ctx);
            }
          }
        }
        const fields = this.versions[val.version];
        if (fields == null) {
          throw new Error(`Unknown version ${val.version}`);
        }
        for (key in fields) {
          type = fields[key];
          if (type.size != null) {
            size += type.size(val[key], ctx);
          }
        }
        if (includePointers) {
          size += ctx.pointerSize;
        }
        return size;
      }
      encode(stream, val, parent) {
        let key, type;
        if (this.preEncode != null) {
          this.preEncode.call(val, stream);
        }
        const ctx = {
          pointers: [],
          startOffset: stream.pos,
          parent,
          val,
          pointerSize: 0
        };
        ctx.pointerOffset = stream.pos + this.size(val, ctx, false);
        if (typeof this.type !== "string") {
          this.type.encode(stream, val.version);
        }
        if (this.versions.header) {
          for (key in this.versions.header) {
            type = this.versions.header[key];
            if (type.encode != null) {
              type.encode(stream, val[key], ctx);
            }
          }
        }
        const fields = this.versions[val.version];
        for (key in fields) {
          type = fields[key];
          if (type.encode != null) {
            type.encode(stream, val[key], ctx);
          }
        }
        let i = 0;
        while (i < ctx.pointers.length) {
          const ptr = ctx.pointers[i++];
          ptr.type.encode(stream, ptr.val, ptr.parent);
        }
      }
    };
    module2.exports = VersionedStruct;
  }
});

// node_modules/restructure/src/Pointer.js
var require_Pointer = __commonJS({
  "node_modules/restructure/src/Pointer.js"(exports) {
    var utils = require_utils();
    var Pointer = class {
      constructor(offsetType, type, options = {}) {
        this.offsetType = offsetType;
        this.type = type;
        this.options = options;
        if (this.type === "void") {
          this.type = null;
        }
        if (this.options.type == null) {
          this.options.type = "local";
        }
        if (this.options.allowNull == null) {
          this.options.allowNull = true;
        }
        if (this.options.nullValue == null) {
          this.options.nullValue = 0;
        }
        if (this.options.lazy == null) {
          this.options.lazy = false;
        }
        if (this.options.relativeTo) {
          if (typeof this.options.relativeTo !== "function") {
            throw new Error("relativeTo option must be a function");
          }
          this.relativeToGetter = options.relativeTo;
        }
      }
      decode(stream, ctx) {
        const offset = this.offsetType.decode(stream, ctx);
        if (offset === this.options.nullValue && this.options.allowNull) {
          return null;
        }
        let relative2;
        switch (this.options.type) {
          case "local":
            relative2 = ctx._startOffset;
            break;
          case "immediate":
            relative2 = stream.pos - this.offsetType.size();
            break;
          case "parent":
            relative2 = ctx.parent._startOffset;
            break;
          default:
            var c = ctx;
            while (c.parent) {
              c = c.parent;
            }
            relative2 = c._startOffset || 0;
        }
        if (this.options.relativeTo) {
          relative2 += this.relativeToGetter(ctx);
        }
        const ptr = offset + relative2;
        if (this.type != null) {
          let val = null;
          const decodeValue = () => {
            if (val != null) {
              return val;
            }
            const { pos } = stream;
            stream.pos = ptr;
            val = this.type.decode(stream, ctx);
            stream.pos = pos;
            return val;
          };
          if (this.options.lazy) {
            return new utils.PropertyDescriptor({
              get: decodeValue
            });
          }
          return decodeValue();
        } else {
          return ptr;
        }
      }
      size(val, ctx) {
        const parent = ctx;
        switch (this.options.type) {
          case "local":
          case "immediate":
            break;
          case "parent":
            ctx = ctx.parent;
            break;
          default:
            while (ctx.parent) {
              ctx = ctx.parent;
            }
        }
        let { type } = this;
        if (type == null) {
          if (!(val instanceof VoidPointer)) {
            throw new Error("Must be a VoidPointer");
          }
          ({ type } = val);
          val = val.value;
        }
        if (val && ctx) {
          ctx.pointerSize += type.size(val, parent);
        }
        return this.offsetType.size();
      }
      encode(stream, val, ctx) {
        let relative2;
        const parent = ctx;
        if (val == null) {
          this.offsetType.encode(stream, this.options.nullValue);
          return;
        }
        switch (this.options.type) {
          case "local":
            relative2 = ctx.startOffset;
            break;
          case "immediate":
            relative2 = stream.pos + this.offsetType.size(val, parent);
            break;
          case "parent":
            ctx = ctx.parent;
            relative2 = ctx.startOffset;
            break;
          default:
            relative2 = 0;
            while (ctx.parent) {
              ctx = ctx.parent;
            }
        }
        if (this.options.relativeTo) {
          relative2 += this.relativeToGetter(parent.val);
        }
        this.offsetType.encode(stream, ctx.pointerOffset - relative2);
        let { type } = this;
        if (type == null) {
          if (!(val instanceof VoidPointer)) {
            throw new Error("Must be a VoidPointer");
          }
          ({ type } = val);
          val = val.value;
        }
        ctx.pointers.push({
          type,
          val,
          parent
        });
        return ctx.pointerOffset += type.size(val, parent);
      }
    };
    var VoidPointer = class {
      constructor(type, value) {
        this.type = type;
        this.value = value;
      }
    };
    exports.Pointer = Pointer;
    exports.VoidPointer = VoidPointer;
  }
});

// node_modules/restructure/index.js
var require_restructure = __commonJS({
  "node_modules/restructure/index.js"(exports) {
    exports.EncodeStream = require_EncodeStream();
    exports.DecodeStream = require_DecodeStream();
    exports.Array = require_Array();
    exports.LazyArray = require_LazyArray();
    exports.Bitfield = require_Bitfield();
    exports.Boolean = require_Boolean();
    exports.Buffer = require_Buffer();
    exports.Enum = require_Enum();
    exports.Optional = require_Optional();
    exports.Reserved = require_Reserved();
    exports.String = require_String();
    exports.Struct = require_Struct();
    exports.VersionedStruct = require_VersionedStruct();
    var utils = require_utils();
    var NumberT = require_Number();
    var Pointer = require_Pointer();
    Object.assign(exports, utils, NumberT, Pointer);
  }
});

// node_modules/tga/src/struct.js
var require_struct = __commonJS({
  "node_modules/tga/src/struct.js"(exports) {
    var r = require_restructure();
    exports.headerStruct = new r.Struct({
      idLength: r.uint8,
      colorMapType: r.uint8,
      dataType: r.uint8,
      colorMapOrigin: r.uint16le,
      colorMapLength: r.uint16le,
      colorMapDepth: r.uint8,
      xOrigin: r.uint16le,
      yOrigin: r.uint16le,
      width: r.uint16le,
      height: r.uint16le,
      bitsPerPixel: r.uint8,
      flags: r.uint8,
      id: new r.String("idLength", "ascii")
    });
    exports.footerStruct = new r.Struct({
      extensionAreaOffset: r.uint32le,
      developerDirectoryOffset: r.uint32,
      signature: new r.String(18)
    });
    exports.extensionStruct = new r.Struct({
      extensionSize: r.uint16le,
      authorName: new r.String(41),
      authorComments: new r.String(324),
      saveTime: new r.Array(r.uint16le, 6),
      jobName: new r.String(41),
      jobTime: new r.Array(r.uint16le, 3),
      software: new r.String(41),
      softwareVersion: r.uint16le,
      softwareVersionTag: new r.String(1),
      keyColor: new r.Array(r.uint8, 4),
      pixelAspectRatio: new r.Array(r.uint16le, 2),
      gamma: new r.Array(r.uint16le, 2),
      colorCorrectionOffset: r.uint32le,
      postageStampOffset: r.uint32le,
      scanLineOffset: r.uint32le,
      attributesType: r.uint8
    });
  }
});

// node_modules/tga/node_modules/ms/index.js
var require_ms = __commonJS({
  "node_modules/tga/node_modules/ms/index.js"(exports, module2) {
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var y = d * 365.25;
    module2.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse(val);
      } else if (type === "number" && isNaN(val) === false) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(val));
    };
    function parse(str2) {
      str2 = String(str2);
      if (str2.length > 100) {
        return;
      }
      var match = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(str2);
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    function fmtShort(ms) {
      if (ms >= d) {
        return Math.round(ms / d) + "d";
      }
      if (ms >= h) {
        return Math.round(ms / h) + "h";
      }
      if (ms >= m) {
        return Math.round(ms / m) + "m";
      }
      if (ms >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    function fmtLong(ms) {
      return plural(ms, d, "day") || plural(ms, h, "hour") || plural(ms, m, "minute") || plural(ms, s, "second") || ms + " ms";
    }
    function plural(ms, n, name) {
      if (ms < n) {
        return;
      }
      if (ms < n * 1.5) {
        return Math.floor(ms / n) + " " + name;
      }
      return Math.ceil(ms / n) + " " + name + "s";
    }
  }
});

// node_modules/tga/node_modules/debug/src/debug.js
var require_debug = __commonJS({
  "node_modules/tga/node_modules/debug/src/debug.js"(exports, module2) {
    exports = module2.exports = createDebug.debug = createDebug["default"] = createDebug;
    exports.coerce = coerce;
    exports.disable = disable;
    exports.enable = enable;
    exports.enabled = enabled;
    exports.humanize = require_ms();
    exports.names = [];
    exports.skips = [];
    exports.formatters = {};
    var prevTime;
    function selectColor(namespace) {
      var hash = 0, i;
      for (i in namespace) {
        hash = (hash << 5) - hash + namespace.charCodeAt(i);
        hash |= 0;
      }
      return exports.colors[Math.abs(hash) % exports.colors.length];
    }
    function createDebug(namespace) {
      function debug() {
        if (!debug.enabled)
          return;
        var self = debug;
        var curr = +new Date();
        var ms = curr - (prevTime || curr);
        self.diff = ms;
        self.prev = prevTime;
        self.curr = curr;
        prevTime = curr;
        var args = new Array(arguments.length);
        for (var i = 0; i < args.length; i++) {
          args[i] = arguments[i];
        }
        args[0] = exports.coerce(args[0]);
        if ("string" !== typeof args[0]) {
          args.unshift("%O");
        }
        var index = 0;
        args[0] = args[0].replace(/%([a-zA-Z%])/g, function(match, format3) {
          if (match === "%%")
            return match;
          index++;
          var formatter = exports.formatters[format3];
          if ("function" === typeof formatter) {
            var val = args[index];
            match = formatter.call(self, val);
            args.splice(index, 1);
            index--;
          }
          return match;
        });
        exports.formatArgs.call(self, args);
        var logFn = debug.log || exports.log || console.log.bind(console);
        logFn.apply(self, args);
      }
      debug.namespace = namespace;
      debug.enabled = exports.enabled(namespace);
      debug.useColors = exports.useColors();
      debug.color = selectColor(namespace);
      if ("function" === typeof exports.init) {
        exports.init(debug);
      }
      return debug;
    }
    function enable(namespaces) {
      exports.save(namespaces);
      exports.names = [];
      exports.skips = [];
      var split = (typeof namespaces === "string" ? namespaces : "").split(/[\s,]+/);
      var len = split.length;
      for (var i = 0; i < len; i++) {
        if (!split[i])
          continue;
        namespaces = split[i].replace(/\*/g, ".*?");
        if (namespaces[0] === "-") {
          exports.skips.push(new RegExp("^" + namespaces.substr(1) + "$"));
        } else {
          exports.names.push(new RegExp("^" + namespaces + "$"));
        }
      }
    }
    function disable() {
      exports.enable("");
    }
    function enabled(name) {
      var i, len;
      for (i = 0, len = exports.skips.length; i < len; i++) {
        if (exports.skips[i].test(name)) {
          return false;
        }
      }
      for (i = 0, len = exports.names.length; i < len; i++) {
        if (exports.names[i].test(name)) {
          return true;
        }
      }
      return false;
    }
    function coerce(val) {
      if (val instanceof Error)
        return val.stack || val.message;
      return val;
    }
  }
});

// node_modules/tga/node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "node_modules/tga/node_modules/debug/src/browser.js"(exports, module2) {
    exports = module2.exports = require_debug();
    exports.log = log;
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.storage = "undefined" != typeof chrome && "undefined" != typeof chrome.storage ? chrome.storage.local : localstorage();
    exports.colors = [
      "lightseagreen",
      "forestgreen",
      "goldenrod",
      "dodgerblue",
      "darkorchid",
      "crimson"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && window.process.type === "renderer") {
        return true;
      }
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    exports.formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (err) {
        return "[UnexpectedJSONParseError]: " + err.message;
      }
    };
    function formatArgs(args) {
      var useColors2 = this.useColors;
      args[0] = (useColors2 ? "%c" : "") + this.namespace + (useColors2 ? " %c" : " ") + args[0] + (useColors2 ? "%c " : " ") + "+" + exports.humanize(this.diff);
      if (!useColors2)
        return;
      var c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      var index = 0;
      var lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, function(match) {
        if ("%%" === match)
          return;
        index++;
        if ("%c" === match) {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    function log() {
      return "object" === typeof console && console.log && Function.prototype.apply.call(console.log, console, arguments);
    }
    function save(namespaces) {
      try {
        if (null == namespaces) {
          exports.storage.removeItem("debug");
        } else {
          exports.storage.debug = namespaces;
        }
      } catch (e) {
      }
    }
    function load() {
      var r;
      try {
        r = exports.storage.debug;
      } catch (e) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    exports.enable(load());
    function localstorage() {
      try {
        return window.localStorage;
      } catch (e) {
      }
    }
  }
});

// node_modules/tga/node_modules/debug/src/node.js
var require_node = __commonJS({
  "node_modules/tga/node_modules/debug/src/node.js"(exports, module2) {
    var tty = require("tty");
    var util = require("util");
    exports = module2.exports = require_debug();
    exports.init = init;
    exports.log = log;
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.colors = [6, 2, 3, 4, 5, 1];
    exports.inspectOpts = Object.keys(process.env).filter(function(key) {
      return /^debug_/i.test(key);
    }).reduce(function(obj, key) {
      var prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, function(_, k) {
        return k.toUpperCase();
      });
      var val = process.env[key];
      if (/^(yes|on|true|enabled)$/i.test(val))
        val = true;
      else if (/^(no|off|false|disabled)$/i.test(val))
        val = false;
      else if (val === "null")
        val = null;
      else
        val = Number(val);
      obj[prop] = val;
      return obj;
    }, {});
    var fd = parseInt(process.env.DEBUG_FD, 10) || 2;
    if (1 !== fd && 2 !== fd) {
      util.deprecate(function() {
      }, "except for stderr(2) and stdout(1), any other usage of DEBUG_FD is deprecated. Override debug.log if you want to use a different log function (https://git.io/debug_fd)")();
    }
    var stream = 1 === fd ? process.stdout : 2 === fd ? process.stderr : createWritableStdioStream(fd);
    function useColors() {
      return "colors" in exports.inspectOpts ? Boolean(exports.inspectOpts.colors) : tty.isatty(fd);
    }
    exports.formatters.o = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts).split("\n").map(function(str2) {
        return str2.trim();
      }).join(" ");
    };
    exports.formatters.O = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts);
    };
    function formatArgs(args) {
      var name = this.namespace;
      var useColors2 = this.useColors;
      if (useColors2) {
        var c = this.color;
        var prefix = "  \x1B[3" + c + ";1m" + name + " \x1B[0m";
        args[0] = prefix + args[0].split("\n").join("\n" + prefix);
        args.push("\x1B[3" + c + "m+" + exports.humanize(this.diff) + "\x1B[0m");
      } else {
        args[0] = new Date().toUTCString() + " " + name + " " + args[0];
      }
    }
    function log() {
      return stream.write(util.format.apply(util, arguments) + "\n");
    }
    function save(namespaces) {
      if (null == namespaces) {
        delete process.env.DEBUG;
      } else {
        process.env.DEBUG = namespaces;
      }
    }
    function load() {
      return process.env.DEBUG;
    }
    function createWritableStdioStream(fd2) {
      var stream2;
      var tty_wrap = process.binding("tty_wrap");
      switch (tty_wrap.guessHandleType(fd2)) {
        case "TTY":
          stream2 = new tty.WriteStream(fd2);
          stream2._type = "tty";
          if (stream2._handle && stream2._handle.unref) {
            stream2._handle.unref();
          }
          break;
        case "FILE":
          var fs3 = require("fs");
          stream2 = new fs3.SyncWriteStream(fd2, { autoClose: false });
          stream2._type = "fs";
          break;
        case "PIPE":
        case "TCP":
          var net = require("net");
          stream2 = new net.Socket({
            fd: fd2,
            readable: false,
            writable: true
          });
          stream2.readable = false;
          stream2.read = null;
          stream2._type = "pipe";
          if (stream2._handle && stream2._handle.unref) {
            stream2._handle.unref();
          }
          break;
        default:
          throw new Error("Implement me. Unknown stream file type!");
      }
      stream2.fd = fd2;
      stream2._isStdio = true;
      return stream2;
    }
    function init(debug) {
      debug.inspectOpts = {};
      var keys = Object.keys(exports.inspectOpts);
      for (var i = 0; i < keys.length; i++) {
        debug.inspectOpts[keys[i]] = exports.inspectOpts[keys[i]];
      }
    }
    exports.enable(load());
  }
});

// node_modules/tga/node_modules/debug/src/index.js
var require_src = __commonJS({
  "node_modules/tga/node_modules/debug/src/index.js"(exports, module2) {
    if (typeof process !== "undefined" && process.type === "renderer") {
      module2.exports = require_browser();
    } else {
      module2.exports = require_node();
    }
  }
});

// node_modules/tga/src/index.js
var require_src2 = __commonJS({
  "node_modules/tga/src/index.js"(exports, module2) {
    var r = require_restructure();
    var { headerStruct, footerStruct, extensionStruct } = require_struct();
    var debug = require_src()("TGA");
    var tempColor = new Uint8Array(4);
    var TGA2 = class {
      constructor(buf, opt = { dontFixAlpha: false }) {
        this.dontFixAlpha = !!opt.dontFixAlpha;
        this._buf = buf;
        this.data = new Uint8Array(buf);
        this.currentOffset = 0;
        this.parse();
      }
      static createTgaBuffer(width, height, pixels, dontFlipY) {
        debug("createTgaBuffer");
        const buffer = Buffer.alloc(18 + pixels.length);
        buffer.writeInt8(0, 0);
        buffer.writeInt8(0, 1);
        buffer.writeInt8(2, 2);
        buffer.writeInt16LE(0, 3);
        buffer.writeInt16LE(0, 5);
        buffer.writeInt8(0, 7);
        buffer.writeInt16LE(0, 8);
        buffer.writeInt16LE(0, 10);
        buffer.writeInt16LE(width, 12);
        buffer.writeInt16LE(height, 14);
        buffer.writeInt8(32, 16);
        buffer.writeInt8(dontFlipY ? 32 : 0, 17);
        let offset = 18;
        for (let i = 0; i < height; i++) {
          for (let j = 0; j < width; j++) {
            const idx = ((dontFlipY ? i : height - i - 1) * width + j) * 4;
            buffer.writeUInt8(pixels[idx + 2], offset++);
            buffer.writeUInt8(pixels[idx + 1], offset++);
            buffer.writeUInt8(pixels[idx], offset++);
            buffer.writeUInt8(pixels[idx + 3], offset++);
          }
        }
        return buffer;
      }
      parseHeader() {
        const stream = new r.DecodeStream(this._buf);
        const header = headerStruct.decode(stream);
        debug("tga header", header);
        this.header = header;
        this.width = header.width;
        this.height = header.height;
        this.isUsingColorMap = [1, 9].includes(header.dataType);
        this.isUsingRLE = [9, 10, 11].includes(header.dataType);
        this.isGray = [3, 11].includes(header.dataType);
        this.hasAlpha = header.flags & 15 || header.bitsPerPixel === 32 || this.isUsingColorMap && header.colorMapDepth === 32 || this.isGray && header.bitsPerPixel === 16;
        debug("tga info isUsingColorMap=%s isUsingRLE=%s isGray=%s hasAlpha=%s", this.isUsingColorMap, this.isUsingRLE, this.isGray, this.hasAlpha);
        this.isFlipX = header.flags & 16;
        this.isFlipY = !(header.flags & 32);
        this.currentOffset = 18 + header.idLength;
        debug("tag info isFlipX=%s isFlipY=%s", this.isFlipX, this.isFlipY);
      }
      parseFooter() {
        const stream = new r.DecodeStream(this._buf.subarray(-26));
        const footer = footerStruct.decode(stream);
        if (footer.signature.trim() === "TRUEVISION-XFILE.\0") {
          debug("footer", footer);
          if (footer.extensionAreaOffset) {
            this.parseExtension(footer.extensionAreaOffset);
          }
        }
      }
      parseExtension(extensionAreaOffset) {
        const stream = new r.DecodeStream(this._buf.subarray(extensionAreaOffset));
        const extension = extensionStruct.decode(stream);
        debug("extension", extension);
        if (extension.attributesType === 3) {
          this.hasAlpha = true;
        } else if (extension.attributesType === 4) {
          this.hasAlpha = true;
        } else {
          this.hasAlpha = false;
        }
      }
      readColor(offset, bytesPerPixel) {
        const arr = this.data;
        if (bytesPerPixel === 3 || bytesPerPixel === 4) {
          tempColor[0] = arr[offset + 2];
          tempColor[1] = arr[offset + 1];
          tempColor[2] = arr[offset];
          tempColor[3] = this.hasAlpha && bytesPerPixel === 4 ? arr[offset + 3] : 255;
        } else if (bytesPerPixel === 2) {
          if (this.isGray) {
            tempColor[0] = tempColor[1] = tempColor[2] = arr[offset];
            tempColor[1] = this.hasAlpha ? arr[offset + 1] : 255;
          } else {
            tempColor[0] = (arr[offset + 1] & 124) << 1;
            tempColor[1] = (arr[offset + 1] & 3) << 6 | (arr[offset] & 224) >> 2;
            tempColor[2] = (arr[offset] & 31) << 3;
            tempColor[3] = this.hasAlpha ? arr[offset + 1] & 128 : 255;
          }
        } else if (bytesPerPixel === 1) {
          tempColor[0] = tempColor[1] = tempColor[2] = arr[offset];
          tempColor[3] = 255;
        } else {
          console.error("Can't read color with bytesPerPixel=%s", bytesPerPixel);
        }
        return tempColor;
      }
      readColorWithColorMap(offset) {
        let index = this.data[offset];
        return this.colorMap.subarray(index * 4, index * 4 + 4);
      }
      readColorAuto(offset, bytesPerPixel, isUsingColorMap) {
        return isUsingColorMap ? this.readColorWithColorMap(offset) : this.readColor(offset, bytesPerPixel);
      }
      parseColorMap() {
        const len = this.header.colorMapLength;
        const bytesPerPixel = this.header.colorMapDepth / 8;
        const colorMap = new Uint8Array(len * 4);
        for (let i = 0; i < len; i++) {
          const color = this.readColor(this.currentOffset, bytesPerPixel);
          this.currentOffset += bytesPerPixel;
          colorMap.set(color, i * 4);
        }
        this.colorMap = colorMap;
      }
      setPixel(pixels, idx, color) {
        const { width, height } = this.header;
        if (this.isFlipX || this.isFlipY) {
          let x = idx % width;
          let y = Math.floor(idx / width);
          if (this.isFlipX) {
            x = width - 1 - x;
          }
          if (this.isFlipY) {
            y = height - 1 - y;
          }
          idx = y * width + x;
        }
        pixels.set(color, idx * 4);
      }
      parsePixels() {
        const header = this.header;
        const pixelCount = header.width * header.height;
        const pixels = new Uint8Array(pixelCount * 4);
        const bytesPerPixel = header.bitsPerPixel / 8;
        let offset = this.currentOffset;
        for (let i = 0; i < pixelCount; i++) {
          if (this.isUsingRLE) {
            const flag = this.data[offset++];
            const count = flag & 127;
            const isRLEChunk = flag & 128;
            let color = this.readColorAuto(offset, bytesPerPixel, this.isUsingColorMap);
            offset += bytesPerPixel;
            this.setPixel(pixels, i, color);
            for (let j = 0; j < count; j++) {
              if (!isRLEChunk) {
                color = this.readColorAuto(offset, bytesPerPixel, this.isUsingColorMap);
                offset += bytesPerPixel;
              }
              this.setPixel(pixels, ++i, color);
            }
          } else {
            const color = this.readColorAuto(offset, bytesPerPixel, this.isUsingColorMap);
            offset += bytesPerPixel;
            this.setPixel(pixels, i, color);
          }
        }
        this.currentOffset = offset;
        this.pixels = pixels;
        debug("pixels", this.pixels);
      }
      parse() {
        this.parseHeader();
        this.parseFooter();
        if (this.header.colorMapType === 1) {
          this.parseColorMap();
        }
        this.parsePixels();
        if (!this.dontFixAlpha) {
          this.fixForAlpha();
        }
      }
      fixForAlpha() {
        debug("fixForAlpha");
        let alpha0Count = 0;
        for (let i = this.pixels.length - 1; i > 0; i -= 4) {
          if (!this.pixels[i]) {
            alpha0Count++;
          }
        }
        if (alpha0Count === this.pixels.length / 4) {
          for (let i = this.pixels.length - 1; i > 0; i -= 4) {
            if (!this.pixels[i]) {
              this.pixels[i] = 255;
            }
          }
        }
      }
    };
    module2.exports = TGA2;
  }
});

// node_modules/gif-encoder-2/src/LZWEncoder.js
var require_LZWEncoder = __commonJS({
  "node_modules/gif-encoder-2/src/LZWEncoder.js"(exports, module2) {
    var EOF = -1;
    var BITS = 12;
    var HSIZE = 5003;
    var masks = [
      0,
      1,
      3,
      7,
      15,
      31,
      63,
      127,
      255,
      511,
      1023,
      2047,
      4095,
      8191,
      16383,
      32767,
      65535
    ];
    function LZWEncoder(width, height, pixels, colorDepth) {
      var initCodeSize = Math.max(2, colorDepth);
      var accum = new Uint8Array(256);
      var htab = new Int32Array(HSIZE);
      var codetab = new Int32Array(HSIZE);
      var cur_accum, cur_bits = 0;
      var a_count;
      var free_ent = 0;
      var maxcode;
      var clear_flg = false;
      var g_init_bits, ClearCode, EOFCode;
      function char_out(c, outs) {
        accum[a_count++] = c;
        if (a_count >= 254)
          flush_char(outs);
      }
      function cl_block(outs) {
        cl_hash(HSIZE);
        free_ent = ClearCode + 2;
        clear_flg = true;
        output(ClearCode, outs);
      }
      function cl_hash(hsize) {
        for (var i = 0; i < hsize; ++i)
          htab[i] = -1;
      }
      function compress(init_bits, outs) {
        var fcode, c, i, ent, disp, hsize_reg, hshift;
        g_init_bits = init_bits;
        clear_flg = false;
        n_bits = g_init_bits;
        maxcode = MAXCODE(n_bits);
        ClearCode = 1 << init_bits - 1;
        EOFCode = ClearCode + 1;
        free_ent = ClearCode + 2;
        a_count = 0;
        ent = nextPixel();
        hshift = 0;
        for (fcode = HSIZE; fcode < 65536; fcode *= 2)
          ++hshift;
        hshift = 8 - hshift;
        hsize_reg = HSIZE;
        cl_hash(hsize_reg);
        output(ClearCode, outs);
        outer_loop:
          while ((c = nextPixel()) != EOF) {
            fcode = (c << BITS) + ent;
            i = c << hshift ^ ent;
            if (htab[i] === fcode) {
              ent = codetab[i];
              continue;
            } else if (htab[i] >= 0) {
              disp = hsize_reg - i;
              if (i === 0)
                disp = 1;
              do {
                if ((i -= disp) < 0)
                  i += hsize_reg;
                if (htab[i] === fcode) {
                  ent = codetab[i];
                  continue outer_loop;
                }
              } while (htab[i] >= 0);
            }
            output(ent, outs);
            ent = c;
            if (free_ent < 1 << BITS) {
              codetab[i] = free_ent++;
              htab[i] = fcode;
            } else {
              cl_block(outs);
            }
          }
        output(ent, outs);
        output(EOFCode, outs);
      }
      function encode(outs) {
        outs.writeByte(initCodeSize);
        remaining = width * height;
        curPixel = 0;
        compress(initCodeSize + 1, outs);
        outs.writeByte(0);
      }
      function flush_char(outs) {
        if (a_count > 0) {
          outs.writeByte(a_count);
          outs.writeBytes(accum, 0, a_count);
          a_count = 0;
        }
      }
      function MAXCODE(n_bits2) {
        return (1 << n_bits2) - 1;
      }
      function nextPixel() {
        if (remaining === 0)
          return EOF;
        --remaining;
        var pix = pixels[curPixel++];
        return pix & 255;
      }
      function output(code, outs) {
        cur_accum &= masks[cur_bits];
        if (cur_bits > 0)
          cur_accum |= code << cur_bits;
        else
          cur_accum = code;
        cur_bits += n_bits;
        while (cur_bits >= 8) {
          char_out(cur_accum & 255, outs);
          cur_accum >>= 8;
          cur_bits -= 8;
        }
        if (free_ent > maxcode || clear_flg) {
          if (clear_flg) {
            maxcode = MAXCODE(n_bits = g_init_bits);
            clear_flg = false;
          } else {
            ++n_bits;
            if (n_bits == BITS)
              maxcode = 1 << BITS;
            else
              maxcode = MAXCODE(n_bits);
          }
        }
        if (code == EOFCode) {
          while (cur_bits > 0) {
            char_out(cur_accum & 255, outs);
            cur_accum >>= 8;
            cur_bits -= 8;
          }
          flush_char(outs);
        }
      }
      this.encode = encode;
    }
    module2.exports = LZWEncoder;
  }
});

// node_modules/gif-encoder-2/src/TypedNeuQuant.js
var require_TypedNeuQuant = __commonJS({
  "node_modules/gif-encoder-2/src/TypedNeuQuant.js"(exports, module2) {
    var ncycles = 100;
    var netsize = 256;
    var maxnetpos = netsize - 1;
    var netbiasshift = 4;
    var intbiasshift = 16;
    var intbias = 1 << intbiasshift;
    var gammashift = 10;
    var gamma = 1 << gammashift;
    var betashift = 10;
    var beta = intbias >> betashift;
    var betagamma = intbias << gammashift - betashift;
    var initrad = netsize >> 3;
    var radiusbiasshift = 6;
    var radiusbias = 1 << radiusbiasshift;
    var initradius = initrad * radiusbias;
    var radiusdec = 30;
    var alphabiasshift = 10;
    var initalpha = 1 << alphabiasshift;
    var radbiasshift = 8;
    var radbias = 1 << radbiasshift;
    var alpharadbshift = alphabiasshift + radbiasshift;
    var alpharadbias = 1 << alpharadbshift;
    var prime1 = 499;
    var prime2 = 491;
    var prime3 = 487;
    var prime4 = 503;
    var minpicturebytes = 3 * prime4;
    function NeuQuant(pixels, samplefac) {
      var network;
      var netindex;
      var bias;
      var freq;
      var radpower;
      function init() {
        network = [];
        netindex = new Int32Array(256);
        bias = new Int32Array(netsize);
        freq = new Int32Array(netsize);
        radpower = new Int32Array(netsize >> 3);
        var i, v;
        for (i = 0; i < netsize; i++) {
          v = (i << netbiasshift + 8) / netsize;
          network[i] = new Float64Array([v, v, v, 0]);
          freq[i] = intbias / netsize;
          bias[i] = 0;
        }
      }
      function unbiasnet() {
        for (var i = 0; i < netsize; i++) {
          network[i][0] >>= netbiasshift;
          network[i][1] >>= netbiasshift;
          network[i][2] >>= netbiasshift;
          network[i][3] = i;
        }
      }
      function altersingle(alpha, i, b, g, r) {
        network[i][0] -= alpha * (network[i][0] - b) / initalpha;
        network[i][1] -= alpha * (network[i][1] - g) / initalpha;
        network[i][2] -= alpha * (network[i][2] - r) / initalpha;
      }
      function alterneigh(radius, i, b, g, r) {
        var lo = Math.abs(i - radius);
        var hi = Math.min(i + radius, netsize);
        var j = i + 1;
        var k = i - 1;
        var m = 1;
        var p, a;
        while (j < hi || k > lo) {
          a = radpower[m++];
          if (j < hi) {
            p = network[j++];
            p[0] -= a * (p[0] - b) / alpharadbias;
            p[1] -= a * (p[1] - g) / alpharadbias;
            p[2] -= a * (p[2] - r) / alpharadbias;
          }
          if (k > lo) {
            p = network[k--];
            p[0] -= a * (p[0] - b) / alpharadbias;
            p[1] -= a * (p[1] - g) / alpharadbias;
            p[2] -= a * (p[2] - r) / alpharadbias;
          }
        }
      }
      function contest(b, g, r) {
        var bestd = ~(1 << 31);
        var bestbiasd = bestd;
        var bestpos = -1;
        var bestbiaspos = bestpos;
        var i, n, dist, biasdist, betafreq;
        for (i = 0; i < netsize; i++) {
          n = network[i];
          dist = Math.abs(n[0] - b) + Math.abs(n[1] - g) + Math.abs(n[2] - r);
          if (dist < bestd) {
            bestd = dist;
            bestpos = i;
          }
          biasdist = dist - (bias[i] >> intbiasshift - netbiasshift);
          if (biasdist < bestbiasd) {
            bestbiasd = biasdist;
            bestbiaspos = i;
          }
          betafreq = freq[i] >> betashift;
          freq[i] -= betafreq;
          bias[i] += betafreq << gammashift;
        }
        freq[bestpos] += beta;
        bias[bestpos] -= betagamma;
        return bestbiaspos;
      }
      function inxbuild() {
        var i, j, p, q, smallpos, smallval, previouscol = 0, startpos = 0;
        for (i = 0; i < netsize; i++) {
          p = network[i];
          smallpos = i;
          smallval = p[1];
          for (j = i + 1; j < netsize; j++) {
            q = network[j];
            if (q[1] < smallval) {
              smallpos = j;
              smallval = q[1];
            }
          }
          q = network[smallpos];
          if (i != smallpos) {
            j = q[0];
            q[0] = p[0];
            p[0] = j;
            j = q[1];
            q[1] = p[1];
            p[1] = j;
            j = q[2];
            q[2] = p[2];
            p[2] = j;
            j = q[3];
            q[3] = p[3];
            p[3] = j;
          }
          if (smallval != previouscol) {
            netindex[previouscol] = startpos + i >> 1;
            for (j = previouscol + 1; j < smallval; j++)
              netindex[j] = i;
            previouscol = smallval;
            startpos = i;
          }
        }
        netindex[previouscol] = startpos + maxnetpos >> 1;
        for (j = previouscol + 1; j < 256; j++)
          netindex[j] = maxnetpos;
      }
      function inxsearch(b, g, r) {
        var a, p, dist;
        var bestd = 1e3;
        var best = -1;
        var i = netindex[g];
        var j = i - 1;
        while (i < netsize || j >= 0) {
          if (i < netsize) {
            p = network[i];
            dist = p[1] - g;
            if (dist >= bestd)
              i = netsize;
            else {
              i++;
              if (dist < 0)
                dist = -dist;
              a = p[0] - b;
              if (a < 0)
                a = -a;
              dist += a;
              if (dist < bestd) {
                a = p[2] - r;
                if (a < 0)
                  a = -a;
                dist += a;
                if (dist < bestd) {
                  bestd = dist;
                  best = p[3];
                }
              }
            }
          }
          if (j >= 0) {
            p = network[j];
            dist = g - p[1];
            if (dist >= bestd)
              j = -1;
            else {
              j--;
              if (dist < 0)
                dist = -dist;
              a = p[0] - b;
              if (a < 0)
                a = -a;
              dist += a;
              if (dist < bestd) {
                a = p[2] - r;
                if (a < 0)
                  a = -a;
                dist += a;
                if (dist < bestd) {
                  bestd = dist;
                  best = p[3];
                }
              }
            }
          }
        }
        return best;
      }
      function learn() {
        var i;
        var lengthcount = pixels.length;
        var alphadec2 = 30 + (samplefac - 1) / 3;
        var samplepixels = lengthcount / (3 * samplefac);
        var delta = ~~(samplepixels / ncycles);
        var alpha = initalpha;
        var radius = initradius;
        var rad = radius >> radiusbiasshift;
        if (rad <= 1)
          rad = 0;
        for (i = 0; i < rad; i++)
          radpower[i] = alpha * ((rad * rad - i * i) * radbias / (rad * rad));
        var step;
        if (lengthcount < minpicturebytes) {
          samplefac = 1;
          step = 3;
        } else if (lengthcount % prime1 !== 0) {
          step = 3 * prime1;
        } else if (lengthcount % prime2 !== 0) {
          step = 3 * prime2;
        } else if (lengthcount % prime3 !== 0) {
          step = 3 * prime3;
        } else {
          step = 3 * prime4;
        }
        var b, g, r, j;
        var pix = 0;
        i = 0;
        while (i < samplepixels) {
          b = (pixels[pix] & 255) << netbiasshift;
          g = (pixels[pix + 1] & 255) << netbiasshift;
          r = (pixels[pix + 2] & 255) << netbiasshift;
          j = contest(b, g, r);
          altersingle(alpha, j, b, g, r);
          if (rad !== 0)
            alterneigh(rad, j, b, g, r);
          pix += step;
          if (pix >= lengthcount)
            pix -= lengthcount;
          i++;
          if (delta === 0)
            delta = 1;
          if (i % delta === 0) {
            alpha -= alpha / alphadec2;
            radius -= radius / radiusdec;
            rad = radius >> radiusbiasshift;
            if (rad <= 1)
              rad = 0;
            for (j = 0; j < rad; j++)
              radpower[j] = alpha * ((rad * rad - j * j) * radbias / (rad * rad));
          }
        }
      }
      function buildColormap() {
        init();
        learn();
        unbiasnet();
        inxbuild();
      }
      this.buildColormap = buildColormap;
      function getColormap() {
        var map = [];
        var index = [];
        for (var i = 0; i < netsize; i++)
          index[network[i][3]] = i;
        var k = 0;
        for (var l = 0; l < netsize; l++) {
          var j = index[l];
          map[k++] = network[j][0];
          map[k++] = network[j][1];
          map[k++] = network[j][2];
        }
        return map;
      }
      this.getColormap = getColormap;
      this.lookupRGB = inxsearch;
    }
    module2.exports = NeuQuant;
  }
});

// node_modules/gif-encoder-2/src/OctreeQuant.js
var require_OctreeQuant = __commonJS({
  "node_modules/gif-encoder-2/src/OctreeQuant.js"(exports, module2) {
    var MAX_DEPTH = 8;
    var OctreeQuant = class {
      constructor() {
        this.levels = Array.from({ length: MAX_DEPTH }, () => []);
        this.root = new Node(0, this);
      }
      addColor(color) {
        this.root.addColor(color, 0, this);
      }
      makePalette(colorCount) {
        let palette = [];
        let paletteIndex = 0;
        let leafCount = this.leafNodes.length;
        for (let level = MAX_DEPTH - 1; level > -1; level -= 1) {
          if (this.levels[level]) {
            for (let node of this.levels[level]) {
              leafCount -= node.removeLeaves();
              if (leafCount <= colorCount)
                break;
            }
            if (leafCount <= colorCount)
              break;
            this.levels[level] = [];
          }
        }
        for (let node of this.leafNodes) {
          if (paletteIndex >= colorCount)
            break;
          if (node.isLeaf)
            palette.push(node.color);
          node.paletteIndex = paletteIndex;
          paletteIndex++;
        }
        return palette;
      }
      *makePaletteIncremental(colorCount) {
        let palette = [];
        let paletteIndex = 0;
        let leafCount = this.leafNodes.length;
        for (let level = MAX_DEPTH - 1; level > -1; level -= 1) {
          if (this.levels[level]) {
            for (let node of this.levels[level]) {
              leafCount -= node.removeLeaves();
              if (leafCount <= colorCount)
                break;
            }
            if (leafCount <= colorCount)
              break;
            this.levels[level] = [];
          }
          yield;
        }
        for (let node of this.leafNodes) {
          if (paletteIndex >= colorCount)
            break;
          if (node.isLeaf)
            palette.push(node.color);
          node.paletteIndex = paletteIndex;
          paletteIndex++;
        }
        yield;
        return palette;
      }
      get leafNodes() {
        return this.root.leafNodes;
      }
      addLevelNode(level, node) {
        this.levels[level].push(node);
      }
      getPaletteIndex(color) {
        return this.root.getPaletteIndex(color, 0);
      }
    };
    var Node = class {
      constructor(level, parent) {
        this._color = new Color(0, 0, 0);
        this.pixelCount = 0;
        this.paletteIndex = 0;
        this.children = [];
        this._debugColor;
        if (level < MAX_DEPTH - 1)
          parent.addLevelNode(level, this);
      }
      get isLeaf() {
        return this.pixelCount > 0;
      }
      get leafNodes() {
        let leafNodes = [];
        for (let node of this.children) {
          if (!node)
            continue;
          if (node.isLeaf) {
            leafNodes.push(node);
          } else {
            leafNodes.push(...node.leafNodes);
          }
        }
        return leafNodes;
      }
      addColor(color, level, parent) {
        if (level >= MAX_DEPTH) {
          this._color.add(color);
          this.pixelCount++;
          return;
        }
        let index = getColorIndex(color, level);
        if (!this.children[index]) {
          this.children[index] = new Node(level, parent);
        }
        this.children[index].addColor(color, level + 1, parent);
      }
      getPaletteIndex(color, level) {
        if (this.isLeaf) {
          return this.paletteIndex;
        }
        let index = getColorIndex(color, level);
        if (this.children[index]) {
          return this.children[index].getPaletteIndex(color, level + 1);
        } else {
          for (let node of this.children) {
            if (node) {
              return node.getPaletteIndex(color, level + 1);
            }
          }
        }
      }
      removeLeaves() {
        let result = 0;
        for (let node of this.children) {
          if (!node)
            continue;
          this._color.add(node._color);
          this.pixelCount += node.pixelCount;
          result++;
        }
        this.children = [];
        return result - 1;
      }
      get debugColor() {
        if (this._debugColor)
          return this._debugColor;
        if (this.isLeaf)
          return this.color;
        let c = new Color();
        let count = 0;
        function traverse(node) {
          for (let child of node.children) {
            if (child.isLeaf) {
              c.add(child._color);
              count++;
            } else {
              traverse(child);
            }
          }
        }
        traverse(this);
        return c.normalized(count);
      }
      get color() {
        return this._color.normalized(this.pixelCount);
      }
    };
    var Color = class {
      constructor(red = 0, green = 0, blue = 0) {
        this.red = red;
        this.green = green;
        this.blue = blue;
      }
      clone() {
        return new Color(this.red, this.green, this.blue);
      }
      get array() {
        return [this.red, this.green, this.blue, this.red + this.green + this.blue];
      }
      toString() {
        return [this.red, this.green, this.blue].join(",");
      }
      toCSS() {
        return `rgb(${[this.red, this.green, this.blue].map((n) => Math.floor(n)).join(",")})`;
      }
      normalized(pixelCount) {
        return new Color(this.red / pixelCount, this.green / pixelCount, this.blue / pixelCount);
      }
      add(color) {
        this.red += color.red;
        this.green += color.green;
        this.blue += color.blue;
      }
    };
    function getColorIndex(color, level) {
      let index = 0;
      let mask = 128 >> level;
      if (color.red & mask)
        index |= 4;
      if (color.green & mask)
        index |= 2;
      if (color.blue & mask)
        index |= 1;
      return index;
    }
    module2.exports = { OctreeQuant, Node, Color };
  }
});

// node_modules/gif-encoder-2/src/GIFEncoder.js
var require_GIFEncoder = __commonJS({
  "node_modules/gif-encoder-2/src/GIFEncoder.js"(exports, module2) {
    var stream = require("stream");
    var EventEmitter = require("events");
    var LZWEncoder = require_LZWEncoder();
    var NeuQuant = require_TypedNeuQuant();
    var { OctreeQuant, Color } = require_OctreeQuant();
    var ByteArray = class {
      constructor() {
        this.data = [];
      }
      getData() {
        return Buffer.from(this.data);
      }
      writeByte(val) {
        this.data.push(val);
      }
      writeUTFBytes(str2) {
        for (var len = str2.length, i = 0; i < len; i++) {
          this.writeByte(str2.charCodeAt(i));
        }
      }
      writeBytes(array, offset, length) {
        for (var len = length || array.length, i = offset || 0; i < len; i++) {
          this.writeByte(array[i]);
        }
      }
    };
    var GIFEncoder2 = class extends EventEmitter {
      constructor(width, height, algorithm = "neuquant", useOptimizer = false, totalFrames = 0) {
        super();
        this.width = ~~width;
        this.height = ~~height;
        this.algorithm = algorithm;
        this.useOptimizer = useOptimizer;
        this.totalFrames = totalFrames;
        this.frames = 1;
        this.threshold = 90;
        this.indexedPixels = null;
        this.palSizeNeu = 7;
        this.palSizeOct = 7;
        this.sample = 10;
        this.colorTab = null;
        this.reuseTab = null;
        this.colorDepth = null;
        this.usedEntry = new Array();
        this.firstFrame = true;
        this.started = false;
        this.image = null;
        this.prevImage = null;
        this.dispose = -1;
        this.repeat = 0;
        this.delay = 0;
        this.transparent = null;
        this.transIndex = 0;
        this.readStreams = [];
        this.out = new ByteArray();
      }
      createReadStream(rs) {
        if (!rs) {
          rs = new stream.Readable();
          rs._read = function() {
          };
        }
        this.readStreams.push(rs);
        return rs;
      }
      emitData() {
        if (this.readStreams.length === 0) {
          return;
        }
        if (this.out.data.length) {
          this.readStreams.forEach((rs) => {
            rs.push(Buffer.from(this.out.data));
          });
          this.out.data = [];
        }
      }
      start() {
        this.out.writeUTFBytes("GIF89a");
        this.started = true;
        this.emitData();
      }
      end() {
        if (this.readStreams.length === null) {
          return;
        }
        this.emitData();
        this.readStreams.forEach((rs) => rs.push(null));
        this.readStreams = [];
      }
      addFrame(input) {
        if (input && input.getImageData) {
          this.image = input.getImageData(0, 0, this.width, this.height).data;
        } else {
          this.image = input;
        }
        this.analyzePixels();
        if (this.firstFrame) {
          this.writeLSD();
          this.writePalette();
          if (this.repeat >= 0) {
            this.writeNetscapeExt();
          }
        }
        this.writeGraphicCtrlExt();
        this.writeImageDesc();
        if (!this.firstFrame) {
          this.writePalette();
        }
        this.writePixels();
        this.firstFrame = false;
        this.emitData();
        if (this.totalFrames) {
          this.emit("progress", Math.floor(this.frames++ / this.totalFrames * 100));
        }
      }
      analyzePixels() {
        const w = this.width;
        const h = this.height;
        var data = this.image;
        if (this.useOptimizer && this.prevImage) {
          var delta = 0;
          for (var len = data.length, i = 0; i < len; i += 4) {
            if (data[i] !== this.prevImage[i] || data[i + 1] !== this.prevImage[i + 1] || data[i + 2] !== this.prevImage[i + 2]) {
              delta++;
            }
          }
          const match = 100 - Math.ceil(delta / (data.length / 4) * 100);
          this.reuseTab = match >= this.threshold;
        }
        this.prevImage = data;
        if (this.algorithm === "neuquant") {
          var count = 0;
          this.pixels = new Uint8Array(w * h * 3);
          for (var i = 0; i < h; i++) {
            for (var j = 0; j < w; j++) {
              var b = i * w * 4 + j * 4;
              this.pixels[count++] = data[b];
              this.pixels[count++] = data[b + 1];
              this.pixels[count++] = data[b + 2];
            }
          }
          var nPix = this.pixels.length / 3;
          this.indexedPixels = new Uint8Array(nPix);
          if (!this.reuseTab) {
            this.quantizer = new NeuQuant(this.pixels, this.sample);
            this.quantizer.buildColormap();
            this.colorTab = this.quantizer.getColormap();
          }
          var k = 0;
          for (var j = 0; j < nPix; j++) {
            var index = this.quantizer.lookupRGB(this.pixels[k++] & 255, this.pixels[k++] & 255, this.pixels[k++] & 255);
            this.usedEntry[index] = true;
            this.indexedPixels[j] = index;
          }
          this.colorDepth = 8;
          this.palSizeNeu = 7;
          this.pixels = null;
        } else if (this.algorithm === "octree") {
          this.colors = [];
          if (!this.reuseTab) {
            this.quantizer = new OctreeQuant();
          }
          for (var i = 0; i < h; i++) {
            for (var j = 0; j < w; j++) {
              var b = i * w * 4 + j * 4;
              const color = new Color(data[b], data[b + 1], data[b + 2]);
              this.colors.push(color);
              if (!this.reuseTab) {
                this.quantizer.addColor(color);
              }
            }
          }
          const nPix2 = this.colors.length;
          this.indexedPixels = new Uint8Array(nPix2);
          if (!this.reuseTab) {
            this.colorTab = [];
            const palette = this.quantizer.makePalette(Math.pow(2, this.palSizeOct + 1));
            for (const p of palette) {
              this.colorTab.push(p.red, p.green, p.blue);
            }
          }
          for (var i = 0; i < nPix2; i++) {
            this.indexedPixels[i] = this.quantizer.getPaletteIndex(this.colors[i]);
          }
          this.colorDepth = this.palSizeOct + 1;
        }
        if (this.transparent !== null) {
          this.transIndex = this.findClosest(this.transparent);
          for (var pixelIndex = 0; pixelIndex < nPix; pixelIndex++) {
            if (this.image[pixelIndex * 4 + 3] == 0) {
              this.indexedPixels[pixelIndex] = this.transIndex;
            }
          }
        }
      }
      findClosest(c) {
        if (this.colorTab === null) {
          return -1;
        }
        var r = (c & 16711680) >> 16;
        var g = (c & 65280) >> 8;
        var b = c & 255;
        var minpos = 0;
        var dmin = 256 * 256 * 256;
        var len = this.colorTab.length;
        for (var i = 0; i < len; ) {
          var index = i / 3;
          var dr = r - (this.colorTab[i++] & 255);
          var dg = g - (this.colorTab[i++] & 255);
          var db = b - (this.colorTab[i++] & 255);
          var d = dr * dr + dg * dg + db * db;
          if (this.usedEntry[index] && d < dmin) {
            dmin = d;
            minpos = index;
          }
        }
        return minpos;
      }
      setFrameRate(fps) {
        this.delay = Math.round(100 / fps);
      }
      setDelay(ms) {
        this.delay = Math.round(ms / 10);
      }
      setDispose(code) {
        if (code >= 0) {
          this.dispose = code;
        }
      }
      setRepeat(repeat) {
        this.repeat = repeat;
      }
      setTransparent(color) {
        this.transparent = color;
      }
      setQuality(quality) {
        if (quality < 1) {
          quality = 1;
        }
        this.quality = quality;
      }
      setThreshold(threshold) {
        if (threshold > 100) {
          threshold = 100;
        } else if (threshold < 0) {
          threshold = 0;
        }
        this.threshold = threshold;
      }
      setPaletteSize(size) {
        if (size > 7) {
          size = 7;
        } else if (size < 4) {
          size = 4;
        }
        this.palSizeOct = size;
      }
      writeLSD() {
        this.writeShort(this.width);
        this.writeShort(this.height);
        this.out.writeByte(128 | 112 | 0 | this.palSizeNeu);
        this.out.writeByte(0);
        this.out.writeByte(0);
      }
      writeGraphicCtrlExt() {
        this.out.writeByte(33);
        this.out.writeByte(249);
        this.out.writeByte(4);
        var transp, disp;
        if (this.transparent === null) {
          transp = 0;
          disp = 0;
        } else {
          transp = 1;
          disp = 2;
        }
        if (this.dispose >= 0) {
          disp = this.dispose & 7;
        }
        disp <<= 2;
        this.out.writeByte(0 | disp | 0 | transp);
        this.writeShort(this.delay);
        this.out.writeByte(this.transIndex);
        this.out.writeByte(0);
      }
      writeNetscapeExt() {
        this.out.writeByte(33);
        this.out.writeByte(255);
        this.out.writeByte(11);
        this.out.writeUTFBytes("NETSCAPE2.0");
        this.out.writeByte(3);
        this.out.writeByte(1);
        this.writeShort(this.repeat);
        this.out.writeByte(0);
      }
      writeImageDesc() {
        this.out.writeByte(44);
        this.writeShort(0);
        this.writeShort(0);
        this.writeShort(this.width);
        this.writeShort(this.height);
        if (this.firstFrame) {
          this.out.writeByte(0);
        } else {
          this.out.writeByte(128 | 0 | 0 | 0 | this.palSizeNeu);
        }
      }
      writePalette() {
        this.out.writeBytes(this.colorTab);
        var n = 3 * 256 - this.colorTab.length;
        for (var i = 0; i < n; i++) {
          this.out.writeByte(0);
        }
      }
      writeShort(pValue) {
        this.out.writeByte(pValue & 255);
        this.out.writeByte(pValue >> 8 & 255);
      }
      writePixels() {
        var enc = new LZWEncoder(this.width, this.height, this.indexedPixels, this.colorDepth);
        enc.encode(this.out);
      }
      finish() {
        this.out.writeByte(59);
        this.end();
      }
    };
    module2.exports = GIFEncoder2;
  }
});

// node_modules/gif-encoder-2/index.js
var require_gif_encoder_2 = __commonJS({
  "node_modules/gif-encoder-2/index.js"(exports, module2) {
    module2.exports = require_GIFEncoder();
  }
});

// node_modules/yargs/yargs.mjs
var import_build = __toESM(require_build4(), 1);
var { applyExtends, cjsPlatformShim, Parser, processArgv, Yargs } = import_build.default;
Yargs.applyExtends = (config, cwd, mergeExtends) => {
  return applyExtends(config, cwd, mergeExtends, cjsPlatformShim);
};
Yargs.hideBin = processArgv.hideBin;
Yargs.Parser = Parser;
var yargs_default = Yargs;

// node_modules/yargs/build/lib/yerror.js
var YError = class extends Error {
  constructor(msg) {
    super(msg || "yargs error");
    this.name = "YError";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, YError);
    }
  }
};

// node_modules/yargs/build/lib/utils/process-argv.js
function getProcessArgvBinIndex() {
  if (isBundledElectronApp())
    return 0;
  return 1;
}
function isBundledElectronApp() {
  return isElectronApp() && !process.defaultApp;
}
function isElectronApp() {
  return !!process.versions.electron;
}
function hideBin(argv2) {
  return argv2.slice(getProcessArgvBinIndex() + 1);
}
function getProcessArgvBin() {
  return process.argv[getProcessArgvBinIndex()];
}

// node_modules/yargs-parser/build/lib/index.js
var import_util = require("util");
var import_path = require("path");

// node_modules/yargs-parser/build/lib/string-utils.js
function camelCase(str2) {
  const isCamelCase = str2 !== str2.toLowerCase() && str2 !== str2.toUpperCase();
  if (!isCamelCase) {
    str2 = str2.toLowerCase();
  }
  if (str2.indexOf("-") === -1 && str2.indexOf("_") === -1) {
    return str2;
  } else {
    let camelcase = "";
    let nextChrUpper = false;
    const leadingHyphens = str2.match(/^-+/);
    for (let i = leadingHyphens ? leadingHyphens[0].length : 0; i < str2.length; i++) {
      let chr = str2.charAt(i);
      if (nextChrUpper) {
        nextChrUpper = false;
        chr = chr.toUpperCase();
      }
      if (i !== 0 && (chr === "-" || chr === "_")) {
        nextChrUpper = true;
      } else if (chr !== "-" && chr !== "_") {
        camelcase += chr;
      }
    }
    return camelcase;
  }
}
function decamelize(str2, joinString) {
  const lowercase = str2.toLowerCase();
  joinString = joinString || "-";
  let notCamelcase = "";
  for (let i = 0; i < str2.length; i++) {
    const chrLower = lowercase.charAt(i);
    const chrString = str2.charAt(i);
    if (chrLower !== chrString && i > 0) {
      notCamelcase += `${joinString}${lowercase.charAt(i)}`;
    } else {
      notCamelcase += chrString;
    }
  }
  return notCamelcase;
}
function looksLikeNumber(x) {
  if (x === null || x === void 0)
    return false;
  if (typeof x === "number")
    return true;
  if (/^0x[0-9a-f]+$/i.test(x))
    return true;
  if (/^0[^.]/.test(x))
    return false;
  return /^[-]?(?:\d+(?:\.\d*)?|\.\d+)(e[-+]?\d+)?$/.test(x);
}

// node_modules/yargs-parser/build/lib/tokenize-arg-string.js
function tokenizeArgString(argString) {
  if (Array.isArray(argString)) {
    return argString.map((e) => typeof e !== "string" ? e + "" : e);
  }
  argString = argString.trim();
  let i = 0;
  let prevC = null;
  let c = null;
  let opening = null;
  const args = [];
  for (let ii = 0; ii < argString.length; ii++) {
    prevC = c;
    c = argString.charAt(ii);
    if (c === " " && !opening) {
      if (!(prevC === " ")) {
        i++;
      }
      continue;
    }
    if (c === opening) {
      opening = null;
    } else if ((c === "'" || c === '"') && !opening) {
      opening = c;
    }
    if (!args[i])
      args[i] = "";
    args[i] += c;
  }
  return args;
}

// node_modules/yargs-parser/build/lib/yargs-parser-types.js
var DefaultValuesForTypeKey;
(function(DefaultValuesForTypeKey2) {
  DefaultValuesForTypeKey2["BOOLEAN"] = "boolean";
  DefaultValuesForTypeKey2["STRING"] = "string";
  DefaultValuesForTypeKey2["NUMBER"] = "number";
  DefaultValuesForTypeKey2["ARRAY"] = "array";
})(DefaultValuesForTypeKey || (DefaultValuesForTypeKey = {}));

// node_modules/yargs-parser/build/lib/yargs-parser.js
var mixin;
var YargsParser = class {
  constructor(_mixin) {
    mixin = _mixin;
  }
  parse(argsInput, options) {
    const opts = Object.assign({
      alias: void 0,
      array: void 0,
      boolean: void 0,
      config: void 0,
      configObjects: void 0,
      configuration: void 0,
      coerce: void 0,
      count: void 0,
      default: void 0,
      envPrefix: void 0,
      narg: void 0,
      normalize: void 0,
      string: void 0,
      number: void 0,
      __: void 0,
      key: void 0
    }, options);
    const args = tokenizeArgString(argsInput);
    const inputIsString = typeof argsInput === "string";
    const aliases = combineAliases(Object.assign(/* @__PURE__ */ Object.create(null), opts.alias));
    const configuration = Object.assign({
      "boolean-negation": true,
      "camel-case-expansion": true,
      "combine-arrays": false,
      "dot-notation": true,
      "duplicate-arguments-array": true,
      "flatten-duplicate-arrays": true,
      "greedy-arrays": true,
      "halt-at-non-option": false,
      "nargs-eats-options": false,
      "negation-prefix": "no-",
      "parse-numbers": true,
      "parse-positional-numbers": true,
      "populate--": false,
      "set-placeholder-key": false,
      "short-option-groups": true,
      "strip-aliased": false,
      "strip-dashed": false,
      "unknown-options-as-args": false
    }, opts.configuration);
    const defaults = Object.assign(/* @__PURE__ */ Object.create(null), opts.default);
    const configObjects = opts.configObjects || [];
    const envPrefix = opts.envPrefix;
    const notFlagsOption = configuration["populate--"];
    const notFlagsArgv = notFlagsOption ? "--" : "_";
    const newAliases = /* @__PURE__ */ Object.create(null);
    const defaulted = /* @__PURE__ */ Object.create(null);
    const __ = opts.__ || mixin.format;
    const flags = {
      aliases: /* @__PURE__ */ Object.create(null),
      arrays: /* @__PURE__ */ Object.create(null),
      bools: /* @__PURE__ */ Object.create(null),
      strings: /* @__PURE__ */ Object.create(null),
      numbers: /* @__PURE__ */ Object.create(null),
      counts: /* @__PURE__ */ Object.create(null),
      normalize: /* @__PURE__ */ Object.create(null),
      configs: /* @__PURE__ */ Object.create(null),
      nargs: /* @__PURE__ */ Object.create(null),
      coercions: /* @__PURE__ */ Object.create(null),
      keys: []
    };
    const negative = /^-([0-9]+(\.[0-9]+)?|\.[0-9]+)$/;
    const negatedBoolean = new RegExp("^--" + configuration["negation-prefix"] + "(.+)");
    [].concat(opts.array || []).filter(Boolean).forEach(function(opt) {
      const key = typeof opt === "object" ? opt.key : opt;
      const assignment = Object.keys(opt).map(function(key2) {
        const arrayFlagKeys = {
          boolean: "bools",
          string: "strings",
          number: "numbers"
        };
        return arrayFlagKeys[key2];
      }).filter(Boolean).pop();
      if (assignment) {
        flags[assignment][key] = true;
      }
      flags.arrays[key] = true;
      flags.keys.push(key);
    });
    [].concat(opts.boolean || []).filter(Boolean).forEach(function(key) {
      flags.bools[key] = true;
      flags.keys.push(key);
    });
    [].concat(opts.string || []).filter(Boolean).forEach(function(key) {
      flags.strings[key] = true;
      flags.keys.push(key);
    });
    [].concat(opts.number || []).filter(Boolean).forEach(function(key) {
      flags.numbers[key] = true;
      flags.keys.push(key);
    });
    [].concat(opts.count || []).filter(Boolean).forEach(function(key) {
      flags.counts[key] = true;
      flags.keys.push(key);
    });
    [].concat(opts.normalize || []).filter(Boolean).forEach(function(key) {
      flags.normalize[key] = true;
      flags.keys.push(key);
    });
    if (typeof opts.narg === "object") {
      Object.entries(opts.narg).forEach(([key, value]) => {
        if (typeof value === "number") {
          flags.nargs[key] = value;
          flags.keys.push(key);
        }
      });
    }
    if (typeof opts.coerce === "object") {
      Object.entries(opts.coerce).forEach(([key, value]) => {
        if (typeof value === "function") {
          flags.coercions[key] = value;
          flags.keys.push(key);
        }
      });
    }
    if (typeof opts.config !== "undefined") {
      if (Array.isArray(opts.config) || typeof opts.config === "string") {
        ;
        [].concat(opts.config).filter(Boolean).forEach(function(key) {
          flags.configs[key] = true;
        });
      } else if (typeof opts.config === "object") {
        Object.entries(opts.config).forEach(([key, value]) => {
          if (typeof value === "boolean" || typeof value === "function") {
            flags.configs[key] = value;
          }
        });
      }
    }
    extendAliases(opts.key, aliases, opts.default, flags.arrays);
    Object.keys(defaults).forEach(function(key) {
      (flags.aliases[key] || []).forEach(function(alias) {
        defaults[alias] = defaults[key];
      });
    });
    let error = null;
    checkConfiguration();
    let notFlags = [];
    const argv2 = Object.assign(/* @__PURE__ */ Object.create(null), { _: [] });
    const argvReturn = {};
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      const truncatedArg = arg.replace(/^-{3,}/, "---");
      let broken;
      let key;
      let letters;
      let m;
      let next;
      let value;
      if (arg !== "--" && isUnknownOptionAsArg(arg)) {
        pushPositional(arg);
      } else if (truncatedArg.match(/---+(=|$)/)) {
        pushPositional(arg);
        continue;
      } else if (arg.match(/^--.+=/) || !configuration["short-option-groups"] && arg.match(/^-.+=/)) {
        m = arg.match(/^--?([^=]+)=([\s\S]*)$/);
        if (m !== null && Array.isArray(m) && m.length >= 3) {
          if (checkAllAliases(m[1], flags.arrays)) {
            i = eatArray(i, m[1], args, m[2]);
          } else if (checkAllAliases(m[1], flags.nargs) !== false) {
            i = eatNargs(i, m[1], args, m[2]);
          } else {
            setArg(m[1], m[2], true);
          }
        }
      } else if (arg.match(negatedBoolean) && configuration["boolean-negation"]) {
        m = arg.match(negatedBoolean);
        if (m !== null && Array.isArray(m) && m.length >= 2) {
          key = m[1];
          setArg(key, checkAllAliases(key, flags.arrays) ? [false] : false);
        }
      } else if (arg.match(/^--.+/) || !configuration["short-option-groups"] && arg.match(/^-[^-]+/)) {
        m = arg.match(/^--?(.+)/);
        if (m !== null && Array.isArray(m) && m.length >= 2) {
          key = m[1];
          if (checkAllAliases(key, flags.arrays)) {
            i = eatArray(i, key, args);
          } else if (checkAllAliases(key, flags.nargs) !== false) {
            i = eatNargs(i, key, args);
          } else {
            next = args[i + 1];
            if (next !== void 0 && (!next.match(/^-/) || next.match(negative)) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
              setArg(key, next);
              i++;
            } else if (/^(true|false)$/.test(next)) {
              setArg(key, next);
              i++;
            } else {
              setArg(key, defaultValue(key));
            }
          }
        }
      } else if (arg.match(/^-.\..+=/)) {
        m = arg.match(/^-([^=]+)=([\s\S]*)$/);
        if (m !== null && Array.isArray(m) && m.length >= 3) {
          setArg(m[1], m[2]);
        }
      } else if (arg.match(/^-.\..+/) && !arg.match(negative)) {
        next = args[i + 1];
        m = arg.match(/^-(.\..+)/);
        if (m !== null && Array.isArray(m) && m.length >= 2) {
          key = m[1];
          if (next !== void 0 && !next.match(/^-/) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
            setArg(key, next);
            i++;
          } else {
            setArg(key, defaultValue(key));
          }
        }
      } else if (arg.match(/^-[^-]+/) && !arg.match(negative)) {
        letters = arg.slice(1, -1).split("");
        broken = false;
        for (let j = 0; j < letters.length; j++) {
          next = arg.slice(j + 2);
          if (letters[j + 1] && letters[j + 1] === "=") {
            value = arg.slice(j + 3);
            key = letters[j];
            if (checkAllAliases(key, flags.arrays)) {
              i = eatArray(i, key, args, value);
            } else if (checkAllAliases(key, flags.nargs) !== false) {
              i = eatNargs(i, key, args, value);
            } else {
              setArg(key, value);
            }
            broken = true;
            break;
          }
          if (next === "-") {
            setArg(letters[j], next);
            continue;
          }
          if (/[A-Za-z]/.test(letters[j]) && /^-?\d+(\.\d*)?(e-?\d+)?$/.test(next) && checkAllAliases(next, flags.bools) === false) {
            setArg(letters[j], next);
            broken = true;
            break;
          }
          if (letters[j + 1] && letters[j + 1].match(/\W/)) {
            setArg(letters[j], next);
            broken = true;
            break;
          } else {
            setArg(letters[j], defaultValue(letters[j]));
          }
        }
        key = arg.slice(-1)[0];
        if (!broken && key !== "-") {
          if (checkAllAliases(key, flags.arrays)) {
            i = eatArray(i, key, args);
          } else if (checkAllAliases(key, flags.nargs) !== false) {
            i = eatNargs(i, key, args);
          } else {
            next = args[i + 1];
            if (next !== void 0 && (!/^(-|--)[^-]/.test(next) || next.match(negative)) && !checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts)) {
              setArg(key, next);
              i++;
            } else if (/^(true|false)$/.test(next)) {
              setArg(key, next);
              i++;
            } else {
              setArg(key, defaultValue(key));
            }
          }
        }
      } else if (arg.match(/^-[0-9]$/) && arg.match(negative) && checkAllAliases(arg.slice(1), flags.bools)) {
        key = arg.slice(1);
        setArg(key, defaultValue(key));
      } else if (arg === "--") {
        notFlags = args.slice(i + 1);
        break;
      } else if (configuration["halt-at-non-option"]) {
        notFlags = args.slice(i);
        break;
      } else {
        pushPositional(arg);
      }
    }
    applyEnvVars(argv2, true);
    applyEnvVars(argv2, false);
    setConfig(argv2);
    setConfigObjects();
    applyDefaultsAndAliases(argv2, flags.aliases, defaults, true);
    applyCoercions(argv2);
    if (configuration["set-placeholder-key"])
      setPlaceholderKeys(argv2);
    Object.keys(flags.counts).forEach(function(key) {
      if (!hasKey(argv2, key.split(".")))
        setArg(key, 0);
    });
    if (notFlagsOption && notFlags.length)
      argv2[notFlagsArgv] = [];
    notFlags.forEach(function(key) {
      argv2[notFlagsArgv].push(key);
    });
    if (configuration["camel-case-expansion"] && configuration["strip-dashed"]) {
      Object.keys(argv2).filter((key) => key !== "--" && key.includes("-")).forEach((key) => {
        delete argv2[key];
      });
    }
    if (configuration["strip-aliased"]) {
      ;
      [].concat(...Object.keys(aliases).map((k) => aliases[k])).forEach((alias) => {
        if (configuration["camel-case-expansion"] && alias.includes("-")) {
          delete argv2[alias.split(".").map((prop) => camelCase(prop)).join(".")];
        }
        delete argv2[alias];
      });
    }
    function pushPositional(arg) {
      const maybeCoercedNumber = maybeCoerceNumber("_", arg);
      if (typeof maybeCoercedNumber === "string" || typeof maybeCoercedNumber === "number") {
        argv2._.push(maybeCoercedNumber);
      }
    }
    function eatNargs(i, key, args2, argAfterEqualSign) {
      let ii;
      let toEat = checkAllAliases(key, flags.nargs);
      toEat = typeof toEat !== "number" || isNaN(toEat) ? 1 : toEat;
      if (toEat === 0) {
        if (!isUndefined(argAfterEqualSign)) {
          error = Error(__("Argument unexpected for: %s", key));
        }
        setArg(key, defaultValue(key));
        return i;
      }
      let available = isUndefined(argAfterEqualSign) ? 0 : 1;
      if (configuration["nargs-eats-options"]) {
        if (args2.length - (i + 1) + available < toEat) {
          error = Error(__("Not enough arguments following: %s", key));
        }
        available = toEat;
      } else {
        for (ii = i + 1; ii < args2.length; ii++) {
          if (!args2[ii].match(/^-[^0-9]/) || args2[ii].match(negative) || isUnknownOptionAsArg(args2[ii]))
            available++;
          else
            break;
        }
        if (available < toEat)
          error = Error(__("Not enough arguments following: %s", key));
      }
      let consumed = Math.min(available, toEat);
      if (!isUndefined(argAfterEqualSign) && consumed > 0) {
        setArg(key, argAfterEqualSign);
        consumed--;
      }
      for (ii = i + 1; ii < consumed + i + 1; ii++) {
        setArg(key, args2[ii]);
      }
      return i + consumed;
    }
    function eatArray(i, key, args2, argAfterEqualSign) {
      let argsToSet = [];
      let next = argAfterEqualSign || args2[i + 1];
      const nargsCount = checkAllAliases(key, flags.nargs);
      if (checkAllAliases(key, flags.bools) && !/^(true|false)$/.test(next)) {
        argsToSet.push(true);
      } else if (isUndefined(next) || isUndefined(argAfterEqualSign) && /^-/.test(next) && !negative.test(next) && !isUnknownOptionAsArg(next)) {
        if (defaults[key] !== void 0) {
          const defVal = defaults[key];
          argsToSet = Array.isArray(defVal) ? defVal : [defVal];
        }
      } else {
        if (!isUndefined(argAfterEqualSign)) {
          argsToSet.push(processValue(key, argAfterEqualSign, true));
        }
        for (let ii = i + 1; ii < args2.length; ii++) {
          if (!configuration["greedy-arrays"] && argsToSet.length > 0 || nargsCount && typeof nargsCount === "number" && argsToSet.length >= nargsCount)
            break;
          next = args2[ii];
          if (/^-/.test(next) && !negative.test(next) && !isUnknownOptionAsArg(next))
            break;
          i = ii;
          argsToSet.push(processValue(key, next, inputIsString));
        }
      }
      if (typeof nargsCount === "number" && (nargsCount && argsToSet.length < nargsCount || isNaN(nargsCount) && argsToSet.length === 0)) {
        error = Error(__("Not enough arguments following: %s", key));
      }
      setArg(key, argsToSet);
      return i;
    }
    function setArg(key, val, shouldStripQuotes = inputIsString) {
      if (/-/.test(key) && configuration["camel-case-expansion"]) {
        const alias = key.split(".").map(function(prop) {
          return camelCase(prop);
        }).join(".");
        addNewAlias(key, alias);
      }
      const value = processValue(key, val, shouldStripQuotes);
      const splitKey = key.split(".");
      setKey(argv2, splitKey, value);
      if (flags.aliases[key]) {
        flags.aliases[key].forEach(function(x) {
          const keyProperties = x.split(".");
          setKey(argv2, keyProperties, value);
        });
      }
      if (splitKey.length > 1 && configuration["dot-notation"]) {
        ;
        (flags.aliases[splitKey[0]] || []).forEach(function(x) {
          let keyProperties = x.split(".");
          const a = [].concat(splitKey);
          a.shift();
          keyProperties = keyProperties.concat(a);
          if (!(flags.aliases[key] || []).includes(keyProperties.join("."))) {
            setKey(argv2, keyProperties, value);
          }
        });
      }
      if (checkAllAliases(key, flags.normalize) && !checkAllAliases(key, flags.arrays)) {
        const keys = [key].concat(flags.aliases[key] || []);
        keys.forEach(function(key2) {
          Object.defineProperty(argvReturn, key2, {
            enumerable: true,
            get() {
              return val;
            },
            set(value2) {
              val = typeof value2 === "string" ? mixin.normalize(value2) : value2;
            }
          });
        });
      }
    }
    function addNewAlias(key, alias) {
      if (!(flags.aliases[key] && flags.aliases[key].length)) {
        flags.aliases[key] = [alias];
        newAliases[alias] = true;
      }
      if (!(flags.aliases[alias] && flags.aliases[alias].length)) {
        addNewAlias(alias, key);
      }
    }
    function processValue(key, val, shouldStripQuotes) {
      if (shouldStripQuotes) {
        val = stripQuotes(val);
      }
      if (checkAllAliases(key, flags.bools) || checkAllAliases(key, flags.counts)) {
        if (typeof val === "string")
          val = val === "true";
      }
      let value = Array.isArray(val) ? val.map(function(v) {
        return maybeCoerceNumber(key, v);
      }) : maybeCoerceNumber(key, val);
      if (checkAllAliases(key, flags.counts) && (isUndefined(value) || typeof value === "boolean")) {
        value = increment();
      }
      if (checkAllAliases(key, flags.normalize) && checkAllAliases(key, flags.arrays)) {
        if (Array.isArray(val))
          value = val.map((val2) => {
            return mixin.normalize(val2);
          });
        else
          value = mixin.normalize(val);
      }
      return value;
    }
    function maybeCoerceNumber(key, value) {
      if (!configuration["parse-positional-numbers"] && key === "_")
        return value;
      if (!checkAllAliases(key, flags.strings) && !checkAllAliases(key, flags.bools) && !Array.isArray(value)) {
        const shouldCoerceNumber = looksLikeNumber(value) && configuration["parse-numbers"] && Number.isSafeInteger(Math.floor(parseFloat(`${value}`)));
        if (shouldCoerceNumber || !isUndefined(value) && checkAllAliases(key, flags.numbers)) {
          value = Number(value);
        }
      }
      return value;
    }
    function setConfig(argv3) {
      const configLookup = /* @__PURE__ */ Object.create(null);
      applyDefaultsAndAliases(configLookup, flags.aliases, defaults);
      Object.keys(flags.configs).forEach(function(configKey) {
        const configPath = argv3[configKey] || configLookup[configKey];
        if (configPath) {
          try {
            let config = null;
            const resolvedConfigPath = mixin.resolve(mixin.cwd(), configPath);
            const resolveConfig = flags.configs[configKey];
            if (typeof resolveConfig === "function") {
              try {
                config = resolveConfig(resolvedConfigPath);
              } catch (e) {
                config = e;
              }
              if (config instanceof Error) {
                error = config;
                return;
              }
            } else {
              config = mixin.require(resolvedConfigPath);
            }
            setConfigObject(config);
          } catch (ex) {
            if (ex.name === "PermissionDenied")
              error = ex;
            else if (argv3[configKey])
              error = Error(__("Invalid JSON config file: %s", configPath));
          }
        }
      });
    }
    function setConfigObject(config, prev) {
      Object.keys(config).forEach(function(key) {
        const value = config[key];
        const fullKey = prev ? prev + "." + key : key;
        if (typeof value === "object" && value !== null && !Array.isArray(value) && configuration["dot-notation"]) {
          setConfigObject(value, fullKey);
        } else {
          if (!hasKey(argv2, fullKey.split(".")) || checkAllAliases(fullKey, flags.arrays) && configuration["combine-arrays"]) {
            setArg(fullKey, value);
          }
        }
      });
    }
    function setConfigObjects() {
      if (typeof configObjects !== "undefined") {
        configObjects.forEach(function(configObject) {
          setConfigObject(configObject);
        });
      }
    }
    function applyEnvVars(argv3, configOnly) {
      if (typeof envPrefix === "undefined")
        return;
      const prefix = typeof envPrefix === "string" ? envPrefix : "";
      const env3 = mixin.env();
      Object.keys(env3).forEach(function(envVar) {
        if (prefix === "" || envVar.lastIndexOf(prefix, 0) === 0) {
          const keys = envVar.split("__").map(function(key, i) {
            if (i === 0) {
              key = key.substring(prefix.length);
            }
            return camelCase(key);
          });
          if ((configOnly && flags.configs[keys.join(".")] || !configOnly) && !hasKey(argv3, keys)) {
            setArg(keys.join("."), env3[envVar]);
          }
        }
      });
    }
    function applyCoercions(argv3) {
      let coerce;
      const applied = /* @__PURE__ */ new Set();
      Object.keys(argv3).forEach(function(key) {
        if (!applied.has(key)) {
          coerce = checkAllAliases(key, flags.coercions);
          if (typeof coerce === "function") {
            try {
              const value = maybeCoerceNumber(key, coerce(argv3[key]));
              [].concat(flags.aliases[key] || [], key).forEach((ali) => {
                applied.add(ali);
                argv3[ali] = value;
              });
            } catch (err) {
              error = err;
            }
          }
        }
      });
    }
    function setPlaceholderKeys(argv3) {
      flags.keys.forEach((key) => {
        if (~key.indexOf("."))
          return;
        if (typeof argv3[key] === "undefined")
          argv3[key] = void 0;
      });
      return argv3;
    }
    function applyDefaultsAndAliases(obj, aliases2, defaults2, canLog = false) {
      Object.keys(defaults2).forEach(function(key) {
        if (!hasKey(obj, key.split("."))) {
          setKey(obj, key.split("."), defaults2[key]);
          if (canLog)
            defaulted[key] = true;
          (aliases2[key] || []).forEach(function(x) {
            if (hasKey(obj, x.split(".")))
              return;
            setKey(obj, x.split("."), defaults2[key]);
          });
        }
      });
    }
    function hasKey(obj, keys) {
      let o = obj;
      if (!configuration["dot-notation"])
        keys = [keys.join(".")];
      keys.slice(0, -1).forEach(function(key2) {
        o = o[key2] || {};
      });
      const key = keys[keys.length - 1];
      if (typeof o !== "object")
        return false;
      else
        return key in o;
    }
    function setKey(obj, keys, value) {
      let o = obj;
      if (!configuration["dot-notation"])
        keys = [keys.join(".")];
      keys.slice(0, -1).forEach(function(key2) {
        key2 = sanitizeKey(key2);
        if (typeof o === "object" && o[key2] === void 0) {
          o[key2] = {};
        }
        if (typeof o[key2] !== "object" || Array.isArray(o[key2])) {
          if (Array.isArray(o[key2])) {
            o[key2].push({});
          } else {
            o[key2] = [o[key2], {}];
          }
          o = o[key2][o[key2].length - 1];
        } else {
          o = o[key2];
        }
      });
      const key = sanitizeKey(keys[keys.length - 1]);
      const isTypeArray = checkAllAliases(keys.join("."), flags.arrays);
      const isValueArray = Array.isArray(value);
      let duplicate = configuration["duplicate-arguments-array"];
      if (!duplicate && checkAllAliases(key, flags.nargs)) {
        duplicate = true;
        if (!isUndefined(o[key]) && flags.nargs[key] === 1 || Array.isArray(o[key]) && o[key].length === flags.nargs[key]) {
          o[key] = void 0;
        }
      }
      if (value === increment()) {
        o[key] = increment(o[key]);
      } else if (Array.isArray(o[key])) {
        if (duplicate && isTypeArray && isValueArray) {
          o[key] = configuration["flatten-duplicate-arrays"] ? o[key].concat(value) : (Array.isArray(o[key][0]) ? o[key] : [o[key]]).concat([value]);
        } else if (!duplicate && Boolean(isTypeArray) === Boolean(isValueArray)) {
          o[key] = value;
        } else {
          o[key] = o[key].concat([value]);
        }
      } else if (o[key] === void 0 && isTypeArray) {
        o[key] = isValueArray ? value : [value];
      } else if (duplicate && !(o[key] === void 0 || checkAllAliases(key, flags.counts) || checkAllAliases(key, flags.bools))) {
        o[key] = [o[key], value];
      } else {
        o[key] = value;
      }
    }
    function extendAliases(...args2) {
      args2.forEach(function(obj) {
        Object.keys(obj || {}).forEach(function(key) {
          if (flags.aliases[key])
            return;
          flags.aliases[key] = [].concat(aliases[key] || []);
          flags.aliases[key].concat(key).forEach(function(x) {
            if (/-/.test(x) && configuration["camel-case-expansion"]) {
              const c = camelCase(x);
              if (c !== key && flags.aliases[key].indexOf(c) === -1) {
                flags.aliases[key].push(c);
                newAliases[c] = true;
              }
            }
          });
          flags.aliases[key].concat(key).forEach(function(x) {
            if (x.length > 1 && /[A-Z]/.test(x) && configuration["camel-case-expansion"]) {
              const c = decamelize(x, "-");
              if (c !== key && flags.aliases[key].indexOf(c) === -1) {
                flags.aliases[key].push(c);
                newAliases[c] = true;
              }
            }
          });
          flags.aliases[key].forEach(function(x) {
            flags.aliases[x] = [key].concat(flags.aliases[key].filter(function(y) {
              return x !== y;
            }));
          });
        });
      });
    }
    function checkAllAliases(key, flag) {
      const toCheck = [].concat(flags.aliases[key] || [], key);
      const keys = Object.keys(flag);
      const setAlias = toCheck.find((key2) => keys.includes(key2));
      return setAlias ? flag[setAlias] : false;
    }
    function hasAnyFlag(key) {
      const flagsKeys = Object.keys(flags);
      const toCheck = [].concat(flagsKeys.map((k) => flags[k]));
      return toCheck.some(function(flag) {
        return Array.isArray(flag) ? flag.includes(key) : flag[key];
      });
    }
    function hasFlagsMatching(arg, ...patterns) {
      const toCheck = [].concat(...patterns);
      return toCheck.some(function(pattern) {
        const match = arg.match(pattern);
        return match && hasAnyFlag(match[1]);
      });
    }
    function hasAllShortFlags(arg) {
      if (arg.match(negative) || !arg.match(/^-[^-]+/)) {
        return false;
      }
      let hasAllFlags = true;
      let next;
      const letters = arg.slice(1).split("");
      for (let j = 0; j < letters.length; j++) {
        next = arg.slice(j + 2);
        if (!hasAnyFlag(letters[j])) {
          hasAllFlags = false;
          break;
        }
        if (letters[j + 1] && letters[j + 1] === "=" || next === "-" || /[A-Za-z]/.test(letters[j]) && /^-?\d+(\.\d*)?(e-?\d+)?$/.test(next) || letters[j + 1] && letters[j + 1].match(/\W/)) {
          break;
        }
      }
      return hasAllFlags;
    }
    function isUnknownOptionAsArg(arg) {
      return configuration["unknown-options-as-args"] && isUnknownOption(arg);
    }
    function isUnknownOption(arg) {
      arg = arg.replace(/^-{3,}/, "--");
      if (arg.match(negative)) {
        return false;
      }
      if (hasAllShortFlags(arg)) {
        return false;
      }
      const flagWithEquals = /^-+([^=]+?)=[\s\S]*$/;
      const normalFlag = /^-+([^=]+?)$/;
      const flagEndingInHyphen = /^-+([^=]+?)-$/;
      const flagEndingInDigits = /^-+([^=]+?\d+)$/;
      const flagEndingInNonWordCharacters = /^-+([^=]+?)\W+.*$/;
      return !hasFlagsMatching(arg, flagWithEquals, negatedBoolean, normalFlag, flagEndingInHyphen, flagEndingInDigits, flagEndingInNonWordCharacters);
    }
    function defaultValue(key) {
      if (!checkAllAliases(key, flags.bools) && !checkAllAliases(key, flags.counts) && `${key}` in defaults) {
        return defaults[key];
      } else {
        return defaultForType(guessType(key));
      }
    }
    function defaultForType(type) {
      const def = {
        [DefaultValuesForTypeKey.BOOLEAN]: true,
        [DefaultValuesForTypeKey.STRING]: "",
        [DefaultValuesForTypeKey.NUMBER]: void 0,
        [DefaultValuesForTypeKey.ARRAY]: []
      };
      return def[type];
    }
    function guessType(key) {
      let type = DefaultValuesForTypeKey.BOOLEAN;
      if (checkAllAliases(key, flags.strings))
        type = DefaultValuesForTypeKey.STRING;
      else if (checkAllAliases(key, flags.numbers))
        type = DefaultValuesForTypeKey.NUMBER;
      else if (checkAllAliases(key, flags.bools))
        type = DefaultValuesForTypeKey.BOOLEAN;
      else if (checkAllAliases(key, flags.arrays))
        type = DefaultValuesForTypeKey.ARRAY;
      return type;
    }
    function isUndefined(num) {
      return num === void 0;
    }
    function checkConfiguration() {
      Object.keys(flags.counts).find((key) => {
        if (checkAllAliases(key, flags.arrays)) {
          error = Error(__("Invalid configuration: %s, opts.count excludes opts.array.", key));
          return true;
        } else if (checkAllAliases(key, flags.nargs)) {
          error = Error(__("Invalid configuration: %s, opts.count excludes opts.narg.", key));
          return true;
        }
        return false;
      });
    }
    return {
      aliases: Object.assign({}, flags.aliases),
      argv: Object.assign(argvReturn, argv2),
      configuration,
      defaulted: Object.assign({}, defaulted),
      error,
      newAliases: Object.assign({}, newAliases)
    };
  }
};
function combineAliases(aliases) {
  const aliasArrays = [];
  const combined = /* @__PURE__ */ Object.create(null);
  let change = true;
  Object.keys(aliases).forEach(function(key) {
    aliasArrays.push([].concat(aliases[key], key));
  });
  while (change) {
    change = false;
    for (let i = 0; i < aliasArrays.length; i++) {
      for (let ii = i + 1; ii < aliasArrays.length; ii++) {
        const intersect = aliasArrays[i].filter(function(v) {
          return aliasArrays[ii].indexOf(v) !== -1;
        });
        if (intersect.length) {
          aliasArrays[i] = aliasArrays[i].concat(aliasArrays[ii]);
          aliasArrays.splice(ii, 1);
          change = true;
          break;
        }
      }
    }
  }
  aliasArrays.forEach(function(aliasArray) {
    aliasArray = aliasArray.filter(function(v, i, self) {
      return self.indexOf(v) === i;
    });
    const lastAlias = aliasArray.pop();
    if (lastAlias !== void 0 && typeof lastAlias === "string") {
      combined[lastAlias] = aliasArray;
    }
  });
  return combined;
}
function increment(orig) {
  return orig !== void 0 ? orig + 1 : 1;
}
function sanitizeKey(key) {
  if (key === "__proto__")
    return "___proto___";
  return key;
}
function stripQuotes(val) {
  return typeof val === "string" && (val[0] === "'" || val[0] === '"') && val[val.length - 1] === val[0] ? val.substring(1, val.length - 1) : val;
}

// node_modules/yargs-parser/build/lib/index.js
var import_fs = require("fs");
var minNodeVersion = process && process.env && process.env.YARGS_MIN_NODE_VERSION ? Number(process.env.YARGS_MIN_NODE_VERSION) : 12;
if (process && process.version) {
  const major = Number(process.version.match(/v([^.]+)/)[1]);
  if (major < minNodeVersion) {
    throw Error(`yargs parser supports a minimum Node.js version of ${minNodeVersion}. Read our version support policy: https://github.com/yargs/yargs-parser#supported-nodejs-versions`);
  }
}
var env2 = process ? process.env : {};
var parser = new YargsParser({
  cwd: process.cwd,
  env: () => {
    return env2;
  },
  format: import_util.format,
  normalize: import_path.normalize,
  resolve: import_path.resolve,
  require: (path) => {
    if (typeof require !== "undefined") {
      return require(path);
    } else if (path.match(/\.json$/)) {
      return JSON.parse((0, import_fs.readFileSync)(path, "utf8"));
    } else {
      throw Error("only .json config files are supported in ESM");
    }
  }
});
var yargsParser = function Parser2(args, opts) {
  const result = parser.parse(args.slice(), opts);
  return result.argv;
};
yargsParser.detailed = function(args, opts) {
  return parser.parse(args.slice(), opts);
};
yargsParser.camelCase = camelCase;
yargsParser.decamelize = decamelize;
yargsParser.looksLikeNumber = looksLikeNumber;
var lib_default = yargsParser;

// node_modules/yargs/lib/platform-shims/esm.mjs
var import_assert = require("assert");

// node_modules/cliui/build/lib/index.js
var align = {
  right: alignRight,
  center: alignCenter
};
var top = 0;
var right = 1;
var bottom = 2;
var left = 3;
var UI = class {
  constructor(opts) {
    var _a;
    this.width = opts.width;
    this.wrap = (_a = opts.wrap) !== null && _a !== void 0 ? _a : true;
    this.rows = [];
  }
  span(...args) {
    const cols = this.div(...args);
    cols.span = true;
  }
  resetOutput() {
    this.rows = [];
  }
  div(...args) {
    if (args.length === 0) {
      this.div("");
    }
    if (this.wrap && this.shouldApplyLayoutDSL(...args) && typeof args[0] === "string") {
      return this.applyLayoutDSL(args[0]);
    }
    const cols = args.map((arg) => {
      if (typeof arg === "string") {
        return this.colFromString(arg);
      }
      return arg;
    });
    this.rows.push(cols);
    return cols;
  }
  shouldApplyLayoutDSL(...args) {
    return args.length === 1 && typeof args[0] === "string" && /[\t\n]/.test(args[0]);
  }
  applyLayoutDSL(str2) {
    const rows = str2.split("\n").map((row) => row.split("	"));
    let leftColumnWidth = 0;
    rows.forEach((columns) => {
      if (columns.length > 1 && mixin2.stringWidth(columns[0]) > leftColumnWidth) {
        leftColumnWidth = Math.min(Math.floor(this.width * 0.5), mixin2.stringWidth(columns[0]));
      }
    });
    rows.forEach((columns) => {
      this.div(...columns.map((r, i) => {
        return {
          text: r.trim(),
          padding: this.measurePadding(r),
          width: i === 0 && columns.length > 1 ? leftColumnWidth : void 0
        };
      }));
    });
    return this.rows[this.rows.length - 1];
  }
  colFromString(text2) {
    return {
      text: text2,
      padding: this.measurePadding(text2)
    };
  }
  measurePadding(str2) {
    const noAnsi = mixin2.stripAnsi(str2);
    return [0, noAnsi.match(/\s*$/)[0].length, 0, noAnsi.match(/^\s*/)[0].length];
  }
  toString() {
    const lines = [];
    this.rows.forEach((row) => {
      this.rowToString(row, lines);
    });
    return lines.filter((line) => !line.hidden).map((line) => line.text).join("\n");
  }
  rowToString(row, lines) {
    this.rasterize(row).forEach((rrow, r) => {
      let str2 = "";
      rrow.forEach((col, c) => {
        const { width } = row[c];
        const wrapWidth = this.negatePadding(row[c]);
        let ts = col;
        if (wrapWidth > mixin2.stringWidth(col)) {
          ts += " ".repeat(wrapWidth - mixin2.stringWidth(col));
        }
        if (row[c].align && row[c].align !== "left" && this.wrap) {
          const fn = align[row[c].align];
          ts = fn(ts, wrapWidth);
          if (mixin2.stringWidth(ts) < wrapWidth) {
            ts += " ".repeat((width || 0) - mixin2.stringWidth(ts) - 1);
          }
        }
        const padding = row[c].padding || [0, 0, 0, 0];
        if (padding[left]) {
          str2 += " ".repeat(padding[left]);
        }
        str2 += addBorder(row[c], ts, "| ");
        str2 += ts;
        str2 += addBorder(row[c], ts, " |");
        if (padding[right]) {
          str2 += " ".repeat(padding[right]);
        }
        if (r === 0 && lines.length > 0) {
          str2 = this.renderInline(str2, lines[lines.length - 1]);
        }
      });
      lines.push({
        text: str2.replace(/ +$/, ""),
        span: row.span
      });
    });
    return lines;
  }
  renderInline(source, previousLine) {
    const match = source.match(/^ */);
    const leadingWhitespace = match ? match[0].length : 0;
    const target = previousLine.text;
    const targetTextWidth = mixin2.stringWidth(target.trimRight());
    if (!previousLine.span) {
      return source;
    }
    if (!this.wrap) {
      previousLine.hidden = true;
      return target + source;
    }
    if (leadingWhitespace < targetTextWidth) {
      return source;
    }
    previousLine.hidden = true;
    return target.trimRight() + " ".repeat(leadingWhitespace - targetTextWidth) + source.trimLeft();
  }
  rasterize(row) {
    const rrows = [];
    const widths = this.columnWidths(row);
    let wrapped;
    row.forEach((col, c) => {
      col.width = widths[c];
      if (this.wrap) {
        wrapped = mixin2.wrap(col.text, this.negatePadding(col), { hard: true }).split("\n");
      } else {
        wrapped = col.text.split("\n");
      }
      if (col.border) {
        wrapped.unshift("." + "-".repeat(this.negatePadding(col) + 2) + ".");
        wrapped.push("'" + "-".repeat(this.negatePadding(col) + 2) + "'");
      }
      if (col.padding) {
        wrapped.unshift(...new Array(col.padding[top] || 0).fill(""));
        wrapped.push(...new Array(col.padding[bottom] || 0).fill(""));
      }
      wrapped.forEach((str2, r) => {
        if (!rrows[r]) {
          rrows.push([]);
        }
        const rrow = rrows[r];
        for (let i = 0; i < c; i++) {
          if (rrow[i] === void 0) {
            rrow.push("");
          }
        }
        rrow.push(str2);
      });
    });
    return rrows;
  }
  negatePadding(col) {
    let wrapWidth = col.width || 0;
    if (col.padding) {
      wrapWidth -= (col.padding[left] || 0) + (col.padding[right] || 0);
    }
    if (col.border) {
      wrapWidth -= 4;
    }
    return wrapWidth;
  }
  columnWidths(row) {
    if (!this.wrap) {
      return row.map((col) => {
        return col.width || mixin2.stringWidth(col.text);
      });
    }
    let unset = row.length;
    let remainingWidth = this.width;
    const widths = row.map((col) => {
      if (col.width) {
        unset--;
        remainingWidth -= col.width;
        return col.width;
      }
      return void 0;
    });
    const unsetWidth = unset ? Math.floor(remainingWidth / unset) : 0;
    return widths.map((w, i) => {
      if (w === void 0) {
        return Math.max(unsetWidth, _minWidth(row[i]));
      }
      return w;
    });
  }
};
function addBorder(col, ts, style) {
  if (col.border) {
    if (/[.']-+[.']/.test(ts)) {
      return "";
    }
    if (ts.trim().length !== 0) {
      return style;
    }
    return "  ";
  }
  return "";
}
function _minWidth(col) {
  const padding = col.padding || [];
  const minWidth = 1 + (padding[left] || 0) + (padding[right] || 0);
  if (col.border) {
    return minWidth + 4;
  }
  return minWidth;
}
function getWindowWidth() {
  if (typeof process === "object" && process.stdout && process.stdout.columns) {
    return process.stdout.columns;
  }
  return 80;
}
function alignRight(str2, width) {
  str2 = str2.trim();
  const strWidth = mixin2.stringWidth(str2);
  if (strWidth < width) {
    return " ".repeat(width - strWidth) + str2;
  }
  return str2;
}
function alignCenter(str2, width) {
  str2 = str2.trim();
  const strWidth = mixin2.stringWidth(str2);
  if (strWidth >= width) {
    return str2;
  }
  return " ".repeat(width - strWidth >> 1) + str2;
}
var mixin2;
function cliui(opts, _mixin) {
  mixin2 = _mixin;
  return new UI({
    width: (opts === null || opts === void 0 ? void 0 : opts.width) || getWindowWidth(),
    wrap: opts === null || opts === void 0 ? void 0 : opts.wrap
  });
}

// node_modules/cliui/build/lib/string-utils.js
var ansi = new RegExp("\x1B(?:\\[(?:\\d+[ABCDEFGJKSTm]|\\d+;\\d+[Hfm]|\\d+;\\d+;\\d+m|6n|s|u|\\?25[lh])|\\w)", "g");
function stripAnsi(str2) {
  return str2.replace(ansi, "");
}
function wrap(str2, width) {
  const [start, end] = str2.match(ansi) || ["", ""];
  str2 = stripAnsi(str2);
  let wrapped = "";
  for (let i = 0; i < str2.length; i++) {
    if (i !== 0 && i % width === 0) {
      wrapped += "\n";
    }
    wrapped += str2.charAt(i);
  }
  if (start && end) {
    wrapped = `${start}${wrapped}${end}`;
  }
  return wrapped;
}

// node_modules/cliui/index.mjs
function ui(opts) {
  return cliui(opts, {
    stringWidth: (str2) => {
      return [...str2].length;
    },
    stripAnsi,
    wrap
  });
}

// node_modules/escalade/sync/index.mjs
var import_path2 = require("path");
var import_fs2 = require("fs");
function sync_default(start, callback) {
  let dir = (0, import_path2.resolve)(".", start);
  let tmp, stats = (0, import_fs2.statSync)(dir);
  if (!stats.isDirectory()) {
    dir = (0, import_path2.dirname)(dir);
  }
  while (true) {
    tmp = callback(dir, (0, import_fs2.readdirSync)(dir));
    if (tmp)
      return (0, import_path2.resolve)(dir, tmp);
    dir = (0, import_path2.dirname)(tmp = dir);
    if (tmp === dir)
      break;
  }
}

// node_modules/yargs/lib/platform-shims/esm.mjs
var import_util3 = require("util");
var import_fs4 = require("fs");
var import_url = require("url");
var import_path4 = require("path");

// node_modules/y18n/build/lib/platform-shims/node.js
var import_fs3 = require("fs");
var import_util2 = require("util");
var import_path3 = require("path");
var node_default = {
  fs: {
    readFileSync: import_fs3.readFileSync,
    writeFile: import_fs3.writeFile
  },
  format: import_util2.format,
  resolve: import_path3.resolve,
  exists: (file) => {
    try {
      return (0, import_fs3.statSync)(file).isFile();
    } catch (err) {
      return false;
    }
  }
};

// node_modules/y18n/build/lib/index.js
var shim;
var Y18N = class {
  constructor(opts) {
    opts = opts || {};
    this.directory = opts.directory || "./locales";
    this.updateFiles = typeof opts.updateFiles === "boolean" ? opts.updateFiles : true;
    this.locale = opts.locale || "en";
    this.fallbackToLanguage = typeof opts.fallbackToLanguage === "boolean" ? opts.fallbackToLanguage : true;
    this.cache = /* @__PURE__ */ Object.create(null);
    this.writeQueue = [];
  }
  __(...args) {
    if (typeof arguments[0] !== "string") {
      return this._taggedLiteral(arguments[0], ...arguments);
    }
    const str2 = args.shift();
    let cb = function() {
    };
    if (typeof args[args.length - 1] === "function")
      cb = args.pop();
    cb = cb || function() {
    };
    if (!this.cache[this.locale])
      this._readLocaleFile();
    if (!this.cache[this.locale][str2] && this.updateFiles) {
      this.cache[this.locale][str2] = str2;
      this._enqueueWrite({
        directory: this.directory,
        locale: this.locale,
        cb
      });
    } else {
      cb();
    }
    return shim.format.apply(shim.format, [this.cache[this.locale][str2] || str2].concat(args));
  }
  __n() {
    const args = Array.prototype.slice.call(arguments);
    const singular = args.shift();
    const plural = args.shift();
    const quantity = args.shift();
    let cb = function() {
    };
    if (typeof args[args.length - 1] === "function")
      cb = args.pop();
    if (!this.cache[this.locale])
      this._readLocaleFile();
    let str2 = quantity === 1 ? singular : plural;
    if (this.cache[this.locale][singular]) {
      const entry = this.cache[this.locale][singular];
      str2 = entry[quantity === 1 ? "one" : "other"];
    }
    if (!this.cache[this.locale][singular] && this.updateFiles) {
      this.cache[this.locale][singular] = {
        one: singular,
        other: plural
      };
      this._enqueueWrite({
        directory: this.directory,
        locale: this.locale,
        cb
      });
    } else {
      cb();
    }
    const values = [str2];
    if (~str2.indexOf("%d"))
      values.push(quantity);
    return shim.format.apply(shim.format, values.concat(args));
  }
  setLocale(locale) {
    this.locale = locale;
  }
  getLocale() {
    return this.locale;
  }
  updateLocale(obj) {
    if (!this.cache[this.locale])
      this._readLocaleFile();
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        this.cache[this.locale][key] = obj[key];
      }
    }
  }
  _taggedLiteral(parts, ...args) {
    let str2 = "";
    parts.forEach(function(part, i) {
      const arg = args[i + 1];
      str2 += part;
      if (typeof arg !== "undefined") {
        str2 += "%s";
      }
    });
    return this.__.apply(this, [str2].concat([].slice.call(args, 1)));
  }
  _enqueueWrite(work) {
    this.writeQueue.push(work);
    if (this.writeQueue.length === 1)
      this._processWriteQueue();
  }
  _processWriteQueue() {
    const _this = this;
    const work = this.writeQueue[0];
    const directory = work.directory;
    const locale = work.locale;
    const cb = work.cb;
    const languageFile = this._resolveLocaleFile(directory, locale);
    const serializedLocale = JSON.stringify(this.cache[locale], null, 2);
    shim.fs.writeFile(languageFile, serializedLocale, "utf-8", function(err) {
      _this.writeQueue.shift();
      if (_this.writeQueue.length > 0)
        _this._processWriteQueue();
      cb(err);
    });
  }
  _readLocaleFile() {
    let localeLookup = {};
    const languageFile = this._resolveLocaleFile(this.directory, this.locale);
    try {
      if (shim.fs.readFileSync) {
        localeLookup = JSON.parse(shim.fs.readFileSync(languageFile, "utf-8"));
      }
    } catch (err) {
      if (err instanceof SyntaxError) {
        err.message = "syntax error in " + languageFile;
      }
      if (err.code === "ENOENT")
        localeLookup = {};
      else
        throw err;
    }
    this.cache[this.locale] = localeLookup;
  }
  _resolveLocaleFile(directory, locale) {
    let file = shim.resolve(directory, "./", locale + ".json");
    if (this.fallbackToLanguage && !this._fileExistsSync(file) && ~locale.lastIndexOf("_")) {
      const languageFile = shim.resolve(directory, "./", locale.split("_")[0] + ".json");
      if (this._fileExistsSync(languageFile))
        file = languageFile;
    }
    return file;
  }
  _fileExistsSync(file) {
    return shim.exists(file);
  }
};
function y18n(opts, _shim) {
  shim = _shim;
  const y18n3 = new Y18N(opts);
  return {
    __: y18n3.__.bind(y18n3),
    __n: y18n3.__n.bind(y18n3),
    setLocale: y18n3.setLocale.bind(y18n3),
    getLocale: y18n3.getLocale.bind(y18n3),
    updateLocale: y18n3.updateLocale.bind(y18n3),
    locale: y18n3.locale
  };
}

// node_modules/y18n/index.mjs
var y18n2 = (opts) => {
  return y18n(opts, node_default);
};
var y18n_default = y18n2;

// node_modules/yargs/lib/platform-shims/esm.mjs
var import_meta = {};
var REQUIRE_ERROR = "require is not supported by ESM";
var REQUIRE_DIRECTORY_ERROR = "loading a directory of commands is not supported yet for ESM";
var __dirname2;
try {
  __dirname2 = (0, import_url.fileURLToPath)(import_meta.url);
} catch (e) {
  __dirname2 = process.cwd();
}
var mainFilename = __dirname2.substring(0, __dirname2.lastIndexOf("node_modules"));
var esm_default = {
  assert: {
    notStrictEqual: import_assert.notStrictEqual,
    strictEqual: import_assert.strictEqual
  },
  cliui: ui,
  findUp: sync_default,
  getEnv: (key) => {
    return process.env[key];
  },
  inspect: import_util3.inspect,
  getCallerFile: () => {
    throw new YError(REQUIRE_DIRECTORY_ERROR);
  },
  getProcessArgvBin,
  mainFilename: mainFilename || process.cwd(),
  Parser: lib_default,
  path: {
    basename: import_path4.basename,
    dirname: import_path4.dirname,
    extname: import_path4.extname,
    relative: import_path4.relative,
    resolve: import_path4.resolve
  },
  process: {
    argv: () => process.argv,
    cwd: process.cwd,
    emitWarning: (warning, type) => process.emitWarning(warning, type),
    execPath: () => process.execPath,
    exit: process.exit,
    nextTick: process.nextTick,
    stdColumns: typeof process.stdout.columns !== "undefined" ? process.stdout.columns : null
  },
  readFileSync: import_fs4.readFileSync,
  require: () => {
    throw new YError(REQUIRE_ERROR);
  },
  requireDirectory: () => {
    throw new YError(REQUIRE_DIRECTORY_ERROR);
  },
  stringWidth: (str2) => {
    return [...str2].length;
  },
  y18n: y18n_default({
    directory: (0, import_path4.resolve)(__dirname2, "../../../locales"),
    updateFiles: false
  })
};

// src/zepp_player/NodeZeppPlayer.js
var import_canvas2 = require("canvas");

// src/zepp_player/DeviceStateObject.js
function createDeviceState() {
  const state = {
    HOUR: {
      value: 9,
      type: "number",
      groupIcon: "calendar_month",
      maxLength: 0,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 12,
      shift: (tick) => tick % 2 === 0 ? (state.HOUR.value + 1) % 24 : null
    },
    MINUTE: {
      value: 30,
      type: "number",
      maxLength: 0,
      groupIcon: "calendar_month",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 60,
      shift: () => (state.MINUTE.value + 5) % 60
    },
    SECOND: {
      value: 45,
      type: "number",
      maxLength: 0,
      groupIcon: "calendar_month",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 60,
      shift: () => (state.SECOND.value + 1) % 60
    },
    DAY: {
      value: 25,
      type: "number",
      maxLength: 2,
      groupIcon: "calendar_month",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value % 31 / 31,
      shift: () => state.DAY.value % 30 + 1
    },
    MONTH: {
      value: 7,
      type: "number",
      maxLength: 2,
      groupIcon: "calendar_month",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value % 12 / 12,
      shift: (tick) => tick % 2 === 0 ? state.MONTH.value % 12 + 1 : null
    },
    YEAR: {
      value: 22,
      type: "number",
      groupIcon: "calendar_month",
      maxLength: 2,
      getString: (t) => t.value.toString()
    },
    WEEKDAY: {
      value: 0,
      type: "number",
      groupIcon: "calendar_month",
      maxLength: 1,
      getString: (t) => t.value.toString(),
      getProgress: (t) => (t.value + 1) / 7,
      shift: (tick) => tick % 2 === 0 ? (state.WEEKDAY.value + 1) % 7 : null
    },
    AM_PM: {
      value: "hide",
      type: "select",
      options: ["hide", "am", "pm"],
      groupIcon: "calendar_month",
      info: "AM/PM state: hide - 24h mode, am/pm - 12h mode",
      maxLength: 4,
      getString: (t) => t.value,
      shift: () => {
        if (state.AM_PM === "hidden")
          return "am";
        if (state.AM_PM === "am")
          return "pm";
        return "hidden";
      }
    },
    OS_LANGUAGE: {
      value: "en-US",
      type: "string",
      groupIcon: "settings",
      maxLength: 5,
      getString: (t) => t.value
    },
    OVERLAY_COLOR: {
      value: "#FFFFFF",
      type: "string",
      groupIcon: "settings",
      maxLength: 7,
      getString: (t) => t.value
    },
    ALARM_CLOCK: {
      value: "09:30",
      type: "string",
      groupIcon: "settings",
      maxLength: 4,
      getBoolean: (v) => v.value !== "0",
      getString: (t) => t.value.replaceAll(":", "."),
      getProgress: (t) => {
        try {
          const v = t.value.split(":");
          const float = parseInt(v[0]) + parseInt(v[1]) / 100;
          return Math.min(1, float / 24);
        } catch (e) {
          return 0;
        }
      },
      shift: (tick, t) => {
        if (tick % 2 !== 0)
          return null;
        const vals = ["0", "06:00", "09:30", "11:00"];
        let index = vals.indexOf(t.value);
        if (index < 0)
          index = 0;
        return vals[(index + 1) % vals.length];
      }
    },
    BATTERY: {
      value: 60,
      type: "number",
      groupIcon: "settings",
      maxLength: 3,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: (_, t) => t.value % 100 + 10
    },
    WEAR_STATE: {
      value: 0,
      groupIcon: "settings",
      displayName: "Wear",
      info: "Wear state: 0 - Not worn, 1 - Wearing, 2 - In motion, 3 - not sure"
    },
    DISCONNECT: {
      value: true,
      type: "boolean",
      groupIcon: "settings",
      maxLength: 1,
      getBoolean: (v) => v.value,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value ? 1 : 0,
      shift: (tick, t) => tick % 3 === 1 ? !t.value : null
    },
    DISTURB: {
      value: true,
      type: "boolean",
      groupIcon: "settings",
      maxLength: 1,
      getBoolean: (v) => v.value,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value ? 1 : 0,
      shift: (tick, t) => tick % 3 === 2 ? !t.value : null
    },
    LOCK: {
      value: true,
      type: "boolean",
      groupIcon: "settings",
      maxLength: 1,
      getBoolean: (v) => v.value,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value ? 1 : 0,
      shift: (tick, t) => tick % 3 === 0 ? !t.value : null
    },
    STEP: {
      value: 4500,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 5,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / state.STEP_TARGET.value,
      shift: (_, t) => (t.value + 500) % state.STEP_TARGET.value
    },
    STEP_TARGET: {
      value: 9e3,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 5,
      getString: (t) => t.value.toString()
    },
    DISTANCE: {
      value: 1.5,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 4,
      getString: (t) => {
        return t.value.toFixed(2);
      },
      shift: () => (state.DISTANCE.value + 0.75) % 20
    },
    CAL: {
      value: 320,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 4,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / state.CAL_TARGET.value,
      shift: (_, t) => (t.value + 30) % state.CAL_TARGET.value
    },
    CAL_TARGET: {
      value: 500,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 4,
      getString: (t) => t.value.toString()
    },
    STAND: {
      value: 12,
      type: "number",
      maxLength: 2,
      groupIcon: "fitness_center",
      getString: (t) => {
        return t.value + "." + state.STAND_TARGET.value;
      },
      getProgress: (t) => t.value / state.STAND_TARGET.value,
      shift: (tick) => tick % 2 === 0 ? state.STAND.value % state.STAND_TARGET.value + 1 : null
    },
    STAND_TARGET: {
      value: 13,
      type: "number",
      groupIcon: "fitness_center",
      maxLength: 2,
      getString: (t) => t.value.toString()
    },
    HEART: {
      value: 99,
      type: "number",
      groupIcon: "monitor_heart",
      maxLength: 3,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 180,
      shift: () => (state.HEART.value + 15) % 180
    },
    SLEEP: {
      value: "9:0",
      type: "string",
      groupIcon: "monitor_heart",
      maxLength: 5,
      getBoolean: (v) => v.value !== "0",
      getString: (t) => t.value,
      getProgress: (t) => {
        try {
          const v = t.value.split(":");
          const float = parseInt(v[0]) + parseInt(v[1]) / 100;
          return Math.min(1, float / 24);
        } catch (e) {
          return 0;
        }
      },
      shift: (tick, t) => {
        if (tick % 2 !== 0)
          return null;
        const vals = ["0", "06:00", "09:30", "11:00"];
        let index = vals.indexOf(t.value);
        if (index < 0)
          index = 0;
        return vals[index + 1 % vals.length];
      }
    },
    SPO2: {
      value: 30,
      type: "number",
      maxLength: 3,
      groupIcon: "monitor_heart",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.SPO2.value + 2 % 100
    },
    PAI_WEEKLY: {
      value: 55,
      type: "number",
      maxLength: 3,
      groupIcon: "monitor_heart",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: (tick) => tick % 3 == 0 ? state.PAI_WEEKLY.value % 100 + 4 : null
    },
    PAI_DAILY: {
      value: 80,
      type: "number",
      maxLength: 3,
      groupIcon: "monitor_heart",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.PAI_DAILY.value % 100 + 4
    },
    STRESS: {
      value: 50,
      type: "number",
      maxLength: 3,
      groupIcon: "monitor_heart",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.STRESS.value % 100 + 5
    },
    WEATHER_CURRENT: {
      value: 12,
      type: "number",
      groupIcon: "sunny",
      displayName: "Current",
      maxLength: 2,
      getString: (t) => t.value.toString(),
      getProgress: () => state.WEATHER_CURRENT_ICON.value / 28,
      shift: (tick, t) => (Math.abs(t.value) + 2) % 30 * (tick % 4 < 2 ? -1 : 1)
    },
    WEATHER_HIGH: {
      value: 14,
      type: "number",
      groupIcon: "sunny",
      displayName: "High",
      maxLength: 2,
      getString: (t) => t.value.toString(),
      shift: (tick, t) => (Math.abs(t.value) + 2) % 30
    },
    WEATHER_LOW: {
      value: 14,
      type: "number",
      groupIcon: "sunny",
      displayName: "Low",
      maxLength: 2,
      getString: (t) => t.value.toString(),
      shift: (tick, t) => (Math.abs(t.value) + 2) % 15 * (tick % 4 < 2 ? -1 : 1)
    },
    WEATHER_CURRENT_ICON: {
      value: 0,
      maxLength: 2,
      groupIcon: "sunny",
      displayName: "Icon",
      shift: () => (state.WEATHER_CURRENT_ICON.value + 1) % 29
    },
    WEATHER_CITY: {
      value: "Barnaul",
      type: "string",
      maxLength: 15,
      groupIcon: "sunny",
      displayName: "City name",
      getString: (t) => t.value
    },
    WIND: {
      value: 2,
      type: "number",
      maxLength: 2,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.HUMIDITY.value % 16 + 1
    },
    AQI: {
      value: 20,
      type: "number",
      maxLength: 3,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.HUMIDITY.value % 100 + 5
    },
    HUMIDITY: {
      value: 10,
      type: "number",
      maxLength: 3,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.HUMIDITY.value % 92 + 8
    },
    ALTIMETER: {
      value: 0,
      type: "number",
      maxLength: 4,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100
    },
    WIND_DIRECTION: {
      value: 0,
      type: "number",
      maxLength: 3,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 7
    },
    UVI: {
      value: 10,
      type: "number",
      maxLength: 2,
      groupIcon: "sunny",
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / 100,
      shift: () => state.UVI.value % 100 + 5
    },
    MUSIC_IS_PLAYING: {
      value: true,
      type: "boolean",
      groupIcon: "music_note",
      maxLength: 1,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value ? 1 : 0,
      shift: (tick, t) => tick % 3 === 0 ? !t.value : null
    },
    MUSIC_ARTIST: {
      value: "Crusher-P",
      groupIcon: "music_note",
      type: "string",
      maxLength: 8
    },
    MUSIC_TITLE: {
      value: "ECHO",
      groupIcon: "music_note",
      type: "string",
      maxLength: 12
    },
    FAT_BURNING: {
      value: 0,
      type: "number",
      maxLength: 3,
      getString: (t) => t.value.toString(),
      getProgress: (t) => t.value / state.FAT_BURNING_TARGET.value,
      shift: () => (state.FAT_BURNING.value + 1) % state.FAT_BURNING_TARGET.value
    },
    FAT_BURNING_TARGET: {
      value: 20,
      type: "number",
      maxLength: 3
    },
    BODY_TEMP: {
      value: 36.5,
      type: "number",
      maxLength: 4,
      getString: (t) => {
        const km = Math.floor(t.value).toString(), dm = Math.round(t.value % 1 * 100).toString();
        return km.padStart(2, "0") + "." + dm.padStart(1, "0");
      },
      getProgress: (t) => t.value / 45
    },
    MOON: {
      value: 0,
      maxLength: 1,
      type: "number",
      getProgress: (t) => Math.max(0, t.value / 7)
    },
    SUN_CURRENT: {
      value: 0,
      notEditable: true,
      maxLength: 5,
      getString: () => {
        const current = state.HOUR.value + state.MINUTE.value / 100;
        if (current <= 6.3 || current >= 21.3) {
          return state.SUN_RISE.value;
        }
        return state.SUN_SET.value;
      }
    },
    SUN_SET: {
      value: "21.30",
      notEditable: true,
      maxLength: 5,
      getString: (t) => t.value
    },
    SUN_RISE: {
      value: "06.30",
      notEditable: true,
      maxLength: 5,
      getString: (t) => t.value
    }
  };
  return state;
}

// src/zepp_player/PersistentStorage.js
var PersistentStorage = class {
  static get(group, key) {
    let data = PersistentStorage._getStorage();
    if (!data[group])
      return null;
    return data[group][key];
  }
  static set(group, key, value) {
    let data = PersistentStorage._getStorage();
    if (!data[group])
      data[group] = {};
    data[group][key] = value;
    localStorage._zeppPlayer_storage = JSON.stringify(data);
  }
  static wipe() {
    localStorage._zeppPlayer_storage = "{}";
  }
  static del(group, key) {
    PersistentStorage.set(group, key, null);
  }
  static keys(group) {
    return Object.keys(PersistentStorage._getStorage()[group]);
  }
  static _getStorage() {
    try {
      return JSON.parse(localStorage._zeppPlayer_storage);
    } catch (e) {
      return {};
    }
  }
};

// src/zepp_player/ZeppPlayerConfig.js
var ZeppPlayerConfig = class {
  constructor() {
    __publicField(this, "refresh_required", true);
    __publicField(this, "_currentRenderLevel", 1);
    __publicField(this, "_renderEventZones", false);
    __publicField(this, "_renderWithoutTransparency", true);
    __publicField(this, "_renderAutoShift", false);
    __publicField(this, "_renderOverlay", true);
    __publicField(this, "_renderLanguage", "en");
    __publicField(this, "_renderScroll", 0);
    __publicField(this, "withScriptConsole", true);
  }
  get renderScroll() {
    return this._renderScroll;
  }
  set renderScroll(v) {
    this._renderScroll = Math.max(0, v);
    if (this.currentRuntime)
      this.currentRuntime.refresh_required = true;
  }
  get current_level() {
    return this._currentRenderLevel;
  }
  set current_level(_) {
    throw new Error("Can't set directly, use setRenderLevel()");
  }
  get render_overlay() {
    return this._renderOverlay;
  }
  set render_overlay(val) {
    this._renderOverlay = val;
    if (this.currentRuntime)
      this.currentRuntime.refresh_required = true;
  }
  get showEventZones() {
    return this._renderEventZones;
  }
  set showEventZones(val) {
    this._renderEventZones = val;
    if (this.currentRuntime)
      this.currentRuntime.refresh_required = true;
  }
  get withoutTransparency() {
    return this._renderWithoutTransparency;
  }
  set withoutTransparency(val) {
    this._renderWithoutTransparency = val;
    this.refresh_required = true;
  }
  get withShift() {
    return this._renderAutoShift;
  }
  set withShift(val) {
    this._renderAutoShift = val;
    if (this.currentRuntime)
      this.currentRuntime.refresh_required = true;
  }
};

// src/zepp_player/ui/Overlay.js
var Overlay = class {
  constructor(player2) {
    __publicField(this, "maskData", null);
    __publicField(this, "mask", null);
    this.player = player2;
  }
  async init() {
    if (!this.player.profileData.hasOverlay)
      return this;
    const maskFile = await this.player.loadFile(`/app/overlay/${this.player.profileName}.png`);
    const mask = await this.player._loadPNG(maskFile);
    const maskCanvas = this.player.newCanvas();
    maskCanvas.width = mask.width;
    maskCanvas.height = mask.height;
    const ctx = maskCanvas.getContext("2d");
    ctx.drawImage(mask, 0, 0);
    this.mask = maskCanvas;
    this.maskData = ctx.getImageData(0, 0, maskCanvas.width, maskCanvas.height).data;
    return this;
  }
  async drawEventZones(canvas, eventGroups) {
    const ctx = canvas.getContext("2d");
    ctx.strokeStyle = "rgba(0, 153, 255, 0.5)";
    ctx.lineWidth = 2;
    for (let group of eventGroups) {
      let hasNoNull = false;
      for (let i in group.events) {
        if (group.events[i] !== null) {
          hasNoNull = true;
          break;
        }
      }
      if (!hasNoNull)
        continue;
      const { x1, y1, x2, y2 } = group;
      ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    }
  }
  async drawDeviceFrame(canvas) {
    if (canvas.width !== this.mask.width || canvas.height !== this.mask.height)
      return;
    const ctx = canvas.getContext("2d");
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    for (let i = 3; i < imgData.data.length; i += 4) {
      imgData.data[i] = 255 - this.maskData[i];
    }
    ctx.putImageData(imgData, 0, 0);
  }
};

// src/zepp_player/Errors.js
var ZeppNotImplementedError = class extends TypeError {
  constructor(propertyName) {
    super(`Not implemented in ZeppPlayer: ${propertyName}. Please contact developer.`);
  }
};

// src/zepp_player/zepp_env/HuamiSensor.js
var HuamiSensorMock = class {
  constructor(runtime) {
    __publicField(this, "id", {
      TIME: TimeSensor,
      BATTERY: BatterySensor,
      STEP: StepSensor,
      CALORIE: CalorieSensor,
      HEART: HeartSensor,
      PAI: PaiSensor,
      DISTANCE: DistanceSensor,
      STAND: StandSensor,
      WEATHER: WeatherSensor,
      FAT_BURRING: FatBurningSensor,
      SPO2: SPO2Sensor,
      BODY_TEMP: BodyTempSensor,
      STRESS: StressSensor,
      VIBRATE: VibrateSensor,
      WEAR: WearSensor,
      WORLD_CLOCK: WorldClockSensor,
      SLEEP: SleepSensor,
      MUSIC: MusicSensor,
      ACTIVITY: ActivitySensor
    });
    __publicField(this, "event", {
      CHANGE: "CHANGE",
      CURRENT: "CURRENT",
      LAST: "LAST"
    });
    this._runtime = runtime;
  }
  createSensor(id) {
    if (id === void 0)
      throw new ZeppNotImplementedError(`hmSensor.id.?`);
    return new id(this._runtime);
  }
};
var TimeSensor = class {
  constructor(player2) {
    __publicField(this, "event", {
      MINUTEEND: "MINUTEEND",
      DAYCHANGE: "DAYCHANGE"
    });
    this.player = player2;
    this.lunar_day = this.day;
    this.lunar_month = this.month;
    this.lunar_solar_term = "ZeppPlayer";
    this.solar_festival = "New year";
  }
  addEventListener(name, callback) {
    if (name === "MINUTEEND") {
      this.player.addDeviceStateChangeEvent("HOUR", () => {
        callback();
      });
      this.player.addDeviceStateChangeEvent("MINUTE", () => {
        callback();
      });
    } else if (name === "DAYCHANGE") {
      this.player.addDeviceStateChangeEvent("DAY", () => {
        callback();
      });
      this.player.addDeviceStateChangeEvent("MONTH", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
  get utc() {
    return Date.now();
  }
  get week() {
    return this.player.getDeviceState("WEEKDAY") + 1;
  }
  get hour() {
    return this.player.getDeviceState("HOUR");
  }
  get minute() {
    return this.player.getDeviceState("MINUTE");
  }
  get second() {
    return this.player.getDeviceState("SECOND");
  }
  get day() {
    return this.player.getDeviceState("DAY");
  }
  get month() {
    return this.player.getDeviceState("MONTH");
  }
  get year() {
    return this.player.getDeviceState("YEAR") + 2e3;
  }
  get format_hour() {
    return this.player.getDeviceState("HOUR");
  }
  getLunarMonthCalendar() {
    return { lunar_days_array: [], day_count: 0 };
  }
  getShowFestival() {
    return this.solar_festival;
  }
};
var BatterySensor = class {
  get current() {
    return this.player.getDeviceState("BATTERY");
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("BATTERY", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var StepSensor = class {
  get target() {
    return this.player.getDeviceState("STEP_TARGET");
  }
  get current() {
    return this.player.getDeviceState("STEP");
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("STEP", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var CalorieSensor = class {
  get current() {
    return this.player.getDeviceState("CAL");
  }
  get target() {
    return this.player.getDeviceState("CAL_TARGET");
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("CAL", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var HeartSensor = class {
  constructor(player2) {
    __publicField(this, "event", {
      CURRENT: "CHANGE",
      LAST: "LAST"
    });
    this.player = player2;
    this.today = [];
    for (let i = 0; i < 3600; i++) {
      this.today[i] = Math.round(90 + 90 * (i % 120) / 120);
    }
  }
  get current() {
    return this.player.getDeviceState("HEART");
  }
  get last() {
    return this.player.getDeviceState("HEART");
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
  addEventListener(name, callback) {
    this.player.addDeviceStateChangeEvent("HEART", () => {
      callback();
    });
  }
};
var PaiSensor = class {
  constructor(player2) {
    this.player = player2;
  }
  get totalpai() {
    return this.player.getDeviceState("PAI_DAILY") * 4.5;
  }
  get dailypai() {
    return this.player.getDeviceState("PAI_DAILY");
  }
  get prepai0() {
    return this.player.getDeviceState("PAI_DAILY") * 0.2;
  }
  get prepai1() {
    return this.player.getDeviceState("PAI_DAILY") * 0.3;
  }
  get prepai2() {
    return this.player.getDeviceState("PAI_DAILY") * 0.4;
  }
  get prepai3() {
    return this.player.getDeviceState("PAI_DAILY") * 0.5;
  }
  get prepai4() {
    return this.player.getDeviceState("PAI_DAILY") * 0.6;
  }
  get prepai5() {
    return this.player.getDeviceState("PAI_DAILY") * 0.7;
  }
  get prepai6() {
    return this.player.getDeviceState("PAI_DAILY") * 0.8;
  }
  addEventListener(name, callback) {
  }
};
var DistanceSensor = class {
  get current() {
    return this.player.getDeviceState("DISTANCE") * 1e3;
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("DISTANCE", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var StandSensor = class {
  get target() {
    return this.player.getDeviceState("STAND_TARGET");
  }
  get current() {
    return this.player.getDeviceState("STAND");
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("STAND", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var WeatherSensor = class {
  constructor(player2) {
    this.player = player2;
  }
  getForecastWeather() {
    return {
      cityName: this.player.getDeviceState("WEATHER_CITY", "string"),
      forecastData: {
        data: [
          { high: 15, low: 12, index: 0 },
          { high: 10, low: 8, index: 1 },
          { high: 5, low: 2, index: 2 },
          { high: -1, low: -3, index: 3 }
        ],
        count: 4
      },
      tideData: {
        data: [
          {
            sunrise: { hour: 9, minute: 30 },
            sunset: { hour: 21, minute: 30 }
          },
          {
            sunrise: { hour: 9, minute: 30 },
            sunset: { hour: 21, minute: 30 }
          },
          {
            sunrise: { hour: 9, minute: 30 },
            sunset: { hour: 21, minute: 30 }
          },
          {
            sunrise: { hour: 9, minute: 30 },
            sunset: { hour: 21, minute: 30 }
          }
        ],
        count: 4
      }
    };
  }
};
var FatBurningSensor = class {
  get target() {
    return this.player.getDeviceState("FAT_BURNING_TARGET");
  }
  get current() {
    return this.player.getDeviceState("FAT_BURNING");
  }
  constructor(player2) {
    this.player = player2;
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("FAT_BURNING", () => {
        callback();
      });
    }
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var SPO2Sensor = class {
  get current() {
    return this.player.getDeviceState("SPO2");
  }
  constructor(player2) {
    this.player = player2;
    this.time = 0;
    this.hourAvgofDay = [];
    for (let i = 0; i < 24; i++) {
      this.hourAvgofDay.push(this.current);
    }
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("SPO2", () => {
        callback();
      });
    }
  }
  start() {
    console.log("[SPO2] start()");
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
};
var BodyTempSensor = class {
  constructor(player2) {
    this.current = player2.getDeviceState("BODY_TEMP");
    this.timeinterval = 10;
  }
};
var StressSensor = class {
  get current() {
    return this.player.getDeviceState("STRESS");
  }
  constructor(player2) {
    this.player = player2;
    this.time = Date.now();
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("STRESS", () => {
        callback();
      });
    }
  }
};
var VibrateSensor = class {
  constructor() {
    this.motortype = 0;
    this.motorenable = 0;
    this.crowneffecton = 0;
    this.scene = 0;
  }
  start() {
    console.log("[VIBRATE] start");
  }
  stop() {
    console.log("[VIBRATE] stop");
  }
};
var WearSensor = class {
  get current() {
    return this.player.getDeviceState("WEAR_STATE");
  }
  constructor(player2) {
    this.player = player2;
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("WEAR_STATE", () => {
        callback();
      });
    }
  }
};
var WorldClockSensor = class {
  constructor(player2) {
    this.player = player2;
  }
  init() {
    console.log("[WC] Init");
  }
  uninit() {
    console.log("[WC] unInit");
  }
  getWorldClockCount() {
    return 2;
  }
  getWorldClockInfo() {
    return {
      city: "Moscow",
      hour: this.player.getDeviceState("HOUR") - 4,
      minute: this.player.getDeviceState("MINUTE")
    };
  }
};
var SleepSensor = class {
  updateInfo() {
    console.log("[SLEEP] Fetching new info (really not)...");
  }
  getSleepStageData() {
    const out = [];
    for (let i = 0; i < 4; i++)
      out.push({
        model: i,
        start: i * 60 + 22 * 60,
        stop: i * 60 + 23 * 60
      });
    return out;
  }
  getSleepStageModel() {
    return {
      WAKE_STAGE: 0,
      REM_STAGE: 1,
      LIGHT_STAGE: 2,
      DEEP_STAGE: 3
    };
  }
};
var MusicSensor = class {
  get title() {
    return this.player.getDeviceState("MUSIC_TITLE");
  }
  get artist() {
    return this.player.getDeviceState("MUSIC_ARTIST");
  }
  get isPlaying() {
    return this.player.getDeviceState("MUSIC_IS_PLAYING");
  }
  constructor(player2) {
    this.player = player2;
  }
  audInit() {
  }
  audPlay() {
    this.isPlaying = !this.isPlaying;
    this.player.setDeviceState("MUSIC_IS_PLAYING", this.isPlaying);
  }
  audPause() {
    this.audPlay();
  }
  audPrev() {
    console.log("[MUSIC] prev track");
  }
  audNext() {
    console.log("[MUSIC] next track");
  }
  removeEventListener(_) {
    this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
  }
  addEventListener(name, callback) {
    if (name === "CHANGE") {
      this.player.addDeviceStateChangeEvent("MUSIC_TITLE", () => {
        callback();
      });
      this.player.addDeviceStateChangeEvent("MUSIC_ARTIST", () => {
        callback();
      });
      this.player.addDeviceStateChangeEvent("MUSIC_IS_PLAYING", () => {
        callback();
      });
    }
  }
};
var ActivitySensor = class {
  constructor(player2) {
    this.player = player2;
  }
  getActivityInfo() {
    return {
      displayMode: 1
    };
  }
};

// src/zepp_player/zepp_env/ConsoleCatch.js
var ConsoleMock = class {
  constructor(player2, console2) {
    this.console = console2;
    this.player = player2;
  }
  _parse(level, args) {
    try {
      this.player.onConsole(level, args);
      if (args[0] instanceof Error) {
        this.player.autoFixGlobalScopeError(args[0]);
      }
    } catch (e) {
    }
  }
  log() {
    this._parse("log", arguments);
  }
  info() {
    this._parse("info", arguments);
  }
  warn() {
    this._parse("warn", arguments);
  }
  error() {
    this._parse("error", arguments);
  }
};

// src/zepp_player/ui/BaseWidget.js
var BaseWidget = class {
  constructor(config) {
    __publicField(this, "setPropertyBanlist", []);
    this.config = config;
    this.runtime = config.__runtime;
    this.positionInfo = false;
    if (!this.config.visible)
      this.config.visible = true;
    this.events = {
      "onmousemove": null,
      "onmouseup": null,
      "onmousedown": null
    };
    this.init();
  }
  async render() {
  }
  init() {
  }
  playerWidgetIdentify() {
    let title = this.config.__widget;
    let subtitle = "", subtitleClass = "";
    if (this.config._name) {
      subtitle = this.config._name;
      subtitleClass = "userDefined";
    } else if (this.config.type) {
      subtitle = this.config.type;
    } else if (this.config.src) {
      subtitle = this.config.src;
    } else if (this.config.text) {
      subtitle = this.config.text;
    }
    return [title, subtitle, subtitleClass];
  }
  _isVisible() {
    if (!this.config.visible)
      return false;
    const show_level = this.config.show_level;
    return !((show_level & this.runtime.showLevel) === 0 && show_level);
  }
  _getPlainConfig() {
    const out = {};
    for (let i in this.config) {
      if (i[0] !== "_")
        out[i] = this.config[i];
    }
    return out;
  }
  setProperty(prop, val) {
    if (prop === void 0) {
      console.warn("This prop was missing in simulator. Please, debug me...");
    }
    if (prop === "more") {
      for (var a in val) {
        if (this.setPropertyBanlist.indexOf(a) > -1) {
          const info = `You can't set ${a} in ${this.constructor.name} via hmUI.prop.MORE. Player crashed.`;
          this.runtime.onConsole("SystemWarning", [info]);
          this.runtime.destroy();
          throw new Error(info);
        }
        this.config[a] = val[a];
      }
      this.runtime.refresh_required = "set_prop";
      return;
    }
    this.config[prop] = val;
    this.runtime.refresh_required = "set_prop";
  }
  getProperty(key, second) {
    if (!this._isVisible()) {
      console.warn("attempt to getprop on invisible", this, key);
      return void 0;
    }
    if (key === "more") {
      if (typeof second !== "object")
        this.player.onConsole("SystemWarning", [
          "When using getProperty with MORE, you must give empty object as second param."
        ]);
      return this.config;
    }
    return this.config[key];
  }
  addEventListener(event, fn) {
    this.events[event] = fn;
  }
  removeEventListener(event, fn) {
    for (let a in this.events) {
      if (this.events[a][0] === event && this.events[a][1] + "" === fn + "") {
        this.events.splice(a, 1);
        return;
      }
    }
  }
  dropEvents(player2, zone = null) {
    const config = this.config;
    if (zone == null)
      zone = [config.x, config.y, config.w, config.h];
    let [x1, y1, x2, y2] = zone;
    if (config.__eventOffsetX) {
      x1 += config.__eventOffsetX;
      x2 += config.__eventOffsetX;
    }
    if (config.__eventOffsetY) {
      y1 += config.__eventOffsetY;
      y2 += config.__eventOffsetY;
    }
    player2.dropEvents(this.events, x1, y1, x2, y2);
    this.positionInfo = [x1, y1, x2, y2];
  }
};

// src/zepp_player/Utils.js
function zeppColorToHex(i) {
  if (typeof i == "string") {
    if (i.startsWith("0x")) {
      i = parseInt(i);
    } else
      return i;
  }
  let s = i.toString(16);
  if (s.length > 6)
    s = s.substring(s.length - 6, s.length);
  s = "#" + s.padStart(6, "0");
  return s;
}

// src/zepp_player/ui/ImagingWidgets.js
var ImageWidget = class extends BaseWidget {
  static draw(img, canvas, player2, config) {
    let w = config.w, h = config.h;
    if (!config.w)
      w = img.width;
    if (!config.h)
      h = img.height;
    const cnv = player2.newCanvas();
    cnv.width = w;
    cnv.height = h;
    let centerX = config.center_x ? config.center_x : 0, centerY = config.center_y ? config.center_y : 0, posX = config.pos_x ? config.pos_x : 0, posY = config.pos_y ? config.pos_y : 0;
    const ctx = cnv.getContext("2d");
    if (config.angle === void 0 || config.angle === 0) {
      ctx.drawImage(img, posX, posY);
    } else {
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(config.angle * Math.PI / 180);
      ctx.drawImage(img, posX - centerX, posY - centerY);
      ctx.restore();
    }
    const x = config.x ? config.x : 0;
    const y = config.y ? config.y : 0;
    canvas.getContext("2d").drawImage(cnv, x, y);
    return [x, y, x + w, y + h];
  }
  async render(canvas, player2) {
    const item = this.config;
    let img, evZone;
    try {
      img = await player2.getAssetImage(item.src);
      if (player2.getImageFormat(item.src) === "TGA-RLP" && item.angle) {
        player2.onConsole("SystemWarning", [
          "WARN: MB7 can't rotate images in TGA-RLP format.",
          "Re-convert file",
          item.src,
          "to TGA-P format."
        ]);
        item.angle = 0;
      }
      evZone = ImageWidget.draw(img, canvas, player2, item);
    } catch (e) {
      evZone = [
        item.x,
        item.y,
        item.x + item.w,
        item.y + item.h
      ];
    }
    if (!item.angle) {
      super.dropEvents(player2, evZone);
    }
  }
};
var ClickableImageWidget = class extends ImageWidget {
  constructor(config) {
    super(config);
    this.addEventListener("onmousedown", () => {
      console.info("[IMG_CLICK] " + config.type);
      config.__runtime.onConsole("IMG_CLICK", ["clicked", config.type]);
    });
  }
};
var PointerWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    const img = await player2.getAssetImage(config.src);
    let angle = config.angle;
    if (config.type)
      angle = player2.getDeviceState(config.type, "progress") * 360;
    if (config.start_angle !== void 0 && config.end_angle !== void 0) {
      angle = angle / 360 * (config.end_angle - config.start_angle) + config.start_angle;
    }
    const conf = {
      x: 0,
      y: 0,
      w: canvas.width,
      h: canvas.height,
      center_x: config.center_x,
      center_y: config.center_y,
      pos_x: config.center_x - config.x,
      pos_y: config.center_y - config.y,
      angle
    };
    ImageWidget.draw(img, canvas, player2, conf);
  }
};
var MissingWidget = class extends ImageWidget {
  constructor(config) {
    super(config);
  }
  async render(a, b) {
    await super.render(a, b);
    if (!this.flag) {
      console.warn("Widget missing", this.config);
      this.flag = true;
    }
  }
};
var TextImageWidget = class extends BaseWidget {
  constructor() {
    super(...arguments);
    __publicField(this, "setPropertyBanlist", ["text"]);
  }
  static getAlignOffsetX(align2, boxWidth, contentWidth) {
    switch (align2) {
      case "center_h":
        return (boxWidth - contentWidth) / 2;
      case "right":
        return boxWidth - contentWidth;
      default:
        return 0;
    }
  }
  static async draw(runtime, text2, maxLength, config) {
    if (!config.font_array || config.font_array.length < 1)
      return null;
    text2 = String(text2);
    const countNums = text2.replace(/\D/g, "").length;
    const valueMissing = text2 === "" || text2 === null || text2 === void 0;
    const hSpace = config.h_space ? config.h_space : 0;
    const iconSpace = config.icon_space ? config.icon_space : 0;
    const basementImage = await runtime.getAssetImage(config.font_array[0]);
    let fullWidth = countNums * basementImage.width + Math.max(0, countNums - 1) * hSpace;
    let iconImg = null, unitImg = null, dotImage = null, negativeImage = null, invalidImage = null;
    if (config.invalid_image && valueMissing) {
      invalidImage = await runtime.getAssetImage(config.invalid_image);
      fullWidth = invalidImage;
    }
    if (config.negative_image) {
      negativeImage = await runtime.getAssetImage(config.negative_image);
      if (text2.indexOf("-") > -1)
        fullWidth += negativeImage.width + hSpace;
    }
    if (config.dot_image) {
      dotImage = await runtime.getAssetImage(config.dot_image);
      if (text2.indexOf(".") > -1)
        fullWidth += dotImage.width + hSpace;
    } else if (text2.indexOf(".") > -1) {
      fullWidth += hSpace;
    }
    if (config.icon) {
      iconImg = await runtime.getAssetImage(config.icon);
      fullWidth += iconImg.width + iconSpace;
    }
    if (config["unit_" + runtime.language]) {
      try {
        unitImg = await runtime.getAssetImage(config["unit_" + runtime.language]);
        if (text2.indexOf("u") < 0)
          text2 += "u";
      } catch (e) {
      }
    }
    let boxHeight = config.h;
    if (boxHeight === void 0) {
      boxHeight = basementImage.height;
    }
    let boxWidth = config.w;
    if (boxWidth === void 0) {
      const autoNumCount = maxLength === 0 ? countNums : maxLength;
      boxWidth = basementImage.width * autoNumCount + hSpace * (autoNumCount - 1);
      if (iconImg)
        boxWidth += iconImg.width + iconSpace;
      if (negativeImage)
        boxWidth += hSpace + negativeImage.width;
      if (unitImg)
        boxWidth += unitImg.width;
      if (dotImage)
        boxWidth += hSpace + dotImage.width;
    }
    if (boxWidth === 0 || boxHeight === 0)
      return null;
    const tmp = runtime.newCanvas();
    tmp.width = boxWidth;
    tmp.height = boxHeight;
    const ctx = tmp.getContext("2d");
    if (valueMissing && invalidImage) {
      let px2 = TextImageWidget.getAlignOffsetX(config.align_h, tmp.width, invalidImage.width);
      ctx.drawImage(invalidImage, px2, 0);
      return tmp;
    } else if (valueMissing) {
      text2 = "";
    }
    let px = TextImageWidget.getAlignOffsetX(config.align_h, tmp.width, fullWidth);
    function drawIfDefined(image) {
      if (image == null)
        return;
      ctx.drawImage(image, px, 0);
      px += image.width + hSpace;
    }
    drawIfDefined(iconImg);
    for (const liter of text2) {
      switch (liter) {
        case "-":
          drawIfDefined(negativeImage);
          break;
        case ".":
        case ":":
          drawIfDefined(dotImage);
          break;
        case "u":
          drawIfDefined(unitImg);
          break;
        default:
          if (!isNaN(parseInt(liter))) {
            const img = await runtime.getAssetImage(config.font_array[parseInt(liter)]);
            ctx.drawImage(img, px, 0);
            px += basementImage.width + hSpace;
          }
      }
    }
    return tmp;
  }
  async render(canvas, player2) {
    const config = this.config;
    let text2 = "", maxLength = 0;
    if (config.text !== void 0) {
      text2 = config.text;
    } else if (config.type) {
      text2 = player2.getDeviceState(config.type, "string");
      maxLength = player2.getDeviceState(config.type, "maxLength");
      if (config.padding && text2 !== "") {
        const countNums = text2.replace(/\D/g, "").length;
        text2 = text2.padStart(maxLength - countNums + text2.length, "0");
      }
    }
    if (typeof text2 == "string") {
      if (text2 === "" && config.type === "ALARM_CLOCK" && !config.invalid_image) {
        text2 = "0";
      }
      if (text2.indexOf(".") > -1 && !config.dot_image) {
        text2 = text2.substring(0, text2.lastIndexOf("."));
      }
    }
    if (text2 === null || text2 === void 0) {
      if (!this.failed) {
        console.warn("No text to display...");
        this.failed = true;
      }
      return;
    }
    let tmp;
    try {
      tmp = await TextImageWidget.draw(player2, text2, maxLength, config);
      if (tmp === null)
        return;
    } catch (e) {
      console.warn(e);
      return;
    }
    canvas.getContext("2d").drawImage(tmp, config.x, config.y);
    super.dropEvents(player2, [
      config.x,
      config.y,
      config.x + tmp.width,
      config.y + tmp.height
    ]);
  }
};
var AnimationWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    this.renderCounter = 0;
  }
  async render(canvas, player2) {
    const config = this.config;
    player2.refresh_required = "img_anim";
    if (config.anim_status === 0)
      return;
    let x = config.x, y = config.y;
    let currentFrame = Math.floor(this.renderCounter / 60 * config.anim_fps);
    if (player2.animMaxFPS) {
      currentFrame = this.renderCounter;
    }
    if (config.repeat_count === 1) {
      currentFrame = Math.min(currentFrame, config.anim_size - 1);
    } else {
      currentFrame %= config.anim_size;
    }
    const path = config.anim_path + "/" + config.anim_prefix + "_" + currentFrame + "." + config.anim_ext;
    try {
      const img = await player2.getAssetImage(path);
      canvas.getContext("2d").drawImage(img, x, y);
      super.dropEvents(player2, [x, y, x + img.width, y + img.height]);
    } catch (e) {
      player2.uiPause = true;
      throw e;
    }
    this.renderCounter++;
  }
};
var ImageStatusWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    const type = this.config.type;
    let x = config.x, y = config.y;
    if (config.pos_x)
      x += config.pos_x;
    if (config.pos_y)
      y += config.pos_y;
    try {
      const img = await player2.getAssetImage(config.src);
      if (player2.getDeviceState(type, "boolean") === true) {
        canvas.getContext("2d").drawImage(img, x, y);
      }
      super.dropEvents(player2, [x, y, x + img.width, y + img.height]);
    } catch (e) {
      return;
    }
  }
};
var ImageProgressWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const ctx = canvas.getContext("2d");
    let level = this.config.level;
    if (this.config.type) {
      level = Math.floor(player2.getDeviceState(this.config.type, "progress") * this.config.image_length);
    }
    for (let i = 0; i < level; i++) {
      const img = await player2.getAssetImage(this.config.image_array[i]);
      ctx.drawImage(img, this.config.x[i], this.config.y[i]);
    }
  }
};
var LevelWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const ctx = canvas.getContext("2d");
    let level = this.config.level;
    if (this.config.type) {
      let val = player2.getDeviceState(this.config.type, "progress");
      if (!val)
        val = 0;
      level = Math.floor(val * (this.config.image_length - 1));
    }
    const img = await player2.getAssetImage(this.config.image_array[level]);
    ctx.drawImage(img, this.config.x, this.config.y);
  }
};

// src/zepp_player/ui/DrawingWidgets.js
var TextWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    config.alpha = void 0;
  }
  static drawText(config, player2) {
    const textSize = config.text_size ? config.text_size : 18;
    const fontConf = textSize + "px allfont";
    const colorConf = config.color ? zeppColorToHex(config.color) : "#000";
    const offsetX = config.char_space ? config.char_space : 0;
    let canvas = player2.newCanvas();
    let context = canvas.getContext("2d");
    context.textBaseline = "top";
    context.font = fontConf;
    let lines = [], preLines = config.text.toString().split("\n");
    let currentLine = -1, width, word, newLine, forceBreak;
    for (let i in preLines) {
      let data = preLines[i];
      currentLine++;
      if (!lines[currentLine])
        lines[currentLine] = "";
      while (data !== "") {
        if (!lines[currentLine])
          lines[currentLine] = "";
        if (config.text_style === 3) {
          newLine = lines[currentLine] += data[0];
          width = context.measureText(newLine).width + offsetX * (newLine.length - 1);
          if (width < config.w - 20) {
            data = data.substring(1);
          } else {
            lines[currentLine] += "..";
            console.log(lines[currentLine]);
            data = "";
          }
        } else if (config.text_style >= 1) {
          forceBreak = false;
          if (config.text_style === 2) {
            word = data.indexOf(" ") >= 0 ? data.substring(0, data.indexOf(" ") + 1) : data;
          } else if (config.text_style === 1) {
            word = data[0];
          }
          newLine = lines[currentLine] + word;
          width = context.measureText(newLine).width + offsetX * (newLine.length - 1);
          if (width < config.w || lines[currentLine].length === 0) {
            while (context.measureText(word).width > config.w) {
              word = word.substring(0, word.length - 1);
            }
            lines[currentLine] += word;
            data = data.substring(word.length);
          } else {
            currentLine++;
          }
        } else {
          lines[currentLine] += data[0];
          data = data.substring(1);
        }
      }
    }
    let totalHeight = 0, px, maxWidth = 0;
    for (let i in lines) {
      let data = lines[i];
      let lineCanvas = player2.newCanvas();
      let lineContext = lineCanvas.getContext("2d");
      lineContext.textBaseline = "top";
      lineContext.font = fontConf;
      let sizes = lineContext.measureText(data);
      lineCanvas.width = sizes.width + offsetX * data.length + 2;
      lineCanvas.height = textSize * 1.5;
      lineContext.textBaseline = "top";
      lineContext.fillStyle = colorConf;
      lineContext.font = fontConf;
      px = 0;
      for (let j in data) {
        lineContext.fillText(data[j], px, textSize * 0.25);
        px += lineContext.measureText(data[j]).width + offsetX;
      }
      lines[i] = lineCanvas;
      maxWidth = Math.max(maxWidth, lineCanvas.width);
      totalHeight += lineCanvas.height + (config.line_space ? config.line_space : 0);
    }
    if (config._metricsOnly)
      return {
        height: totalHeight,
        width: maxWidth
      };
    canvas.width = config.w;
    canvas.height = config.h;
    if (!canvas.height)
      canvas.height = totalHeight;
    if (!canvas.width)
      canvas.width = maxWidth;
    let py = 0;
    if (config.align_v === "center_v")
      py = (canvas.height - totalHeight) / 2;
    if (config.align_v === "bottom")
      py = canvas.height - totalHeight;
    for (let i in lines) {
      let lineCanvas = lines[i];
      let px2 = 0;
      if (config.align_h === "center_h")
        px2 = Math.max(0, (config.w - lineCanvas.width) / 2);
      if (config.align_h === "right")
        px2 = Math.max(0, config.w - lineCanvas.width);
      if (!config.text_style && maxWidth > config.w) {
        const progress = (player2.render_counter + 100) % 300 / 100;
        const w = maxWidth + config.w;
        if (progress < 1)
          px2 += (1 - progress) * w;
        else if (progress > 2)
          px2 -= (progress - 2) * w;
        player2.refresh_required = "text_scroll";
      }
      context.drawImage(lineCanvas, px2, py);
      py += lineCanvas.height + (config.line_space ? config.line_space : 0);
    }
    return canvas;
  }
  async render(canvas, player2) {
    const config = this.config;
    let width = config.w, height = config.h;
    if (config.text) {
      const text2 = await TextWidget.drawText(config, player2);
      canvas.getContext("2d").drawImage(text2, config.x, config.y);
      width = text2.width;
      height = text2.height;
    }
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + width,
      config.y + height
    ]);
  }
};
var CircleWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = zeppColorToHex(config.color);
    ctx.beginPath();
    ctx.arc(config.center_x, config.center_y, config.radius, 0, Math.PI * 2);
    ctx.fill();
    this.dropEvents(player2, [
      config.center_x - config.radius,
      config.center_y - config.radius,
      config.center_x + config.radius,
      config.center_y + config.radius
    ]);
  }
};
var FillRectWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    this.mode = "fill";
    config.alpha = void 0;
  }
  static draw(canvas, config, mode, player2) {
    const img = player2.newCanvas();
    img.width = config.w;
    img.height = config.h;
    const ctx = img.getContext("2d");
    const color = config.color ? config.color : 0;
    const round = Math.floor(Math.min(config.radius ? config.radius : 0, Math.abs(config.h) / 2, Math.abs(config.w) / 2));
    ctx.fillStyle = zeppColorToHex(color);
    ctx.strokeStyle = zeppColorToHex(color);
    ctx.lineWidth = config.line_width ? config.line_width : 1;
    ctx.beginPath();
    FillRectWidget._makePath(ctx, config.w, config.h, 0, 0, round);
    ctx.fill();
    if (mode === "stroke") {
      ctx.beginPath();
      ctx.globalCompositeOperation = "destination-out";
      FillRectWidget._makePath(ctx, config.w - ctx.lineWidth * 2, config.h - ctx.lineWidth * 2, ctx.lineWidth, ctx.lineWidth, Math.max(0, round - ctx.lineWidth));
      ctx.fill();
    }
    const rad = config.angle % 180 / 180 * Math.PI;
    const b = Math.abs(config.w * Math.sin(rad)) + Math.abs(config.h * Math.cos(rad));
    const a = Math.abs(config.w * Math.cos(rad)) + Math.abs(config.h * Math.sin(rad));
    return ImageWidget.draw(img, canvas, player2, {
      x: config.x,
      y: config.y,
      w: config.w,
      h: config.h,
      pos_x: (a - config.w) / 2,
      pos_y: (b - config.h) / 2,
      center_x: config.w / 2 + (a - config.w) / 2,
      center_y: config.h / 2 + (b - config.h) / 2,
      angle: config.angle
    });
  }
  static _makePath(ctx, w, h, x, y, round) {
    ctx.moveTo(x + round, y);
    ctx.lineTo(x + w - round, y);
    ctx.arc(x + w - round, y + round, round, 3 * Math.PI / 2, 0);
    ctx.lineTo(x + w, y + h - round);
    ctx.arc(x + w - round, y + h - round, round, 0, Math.PI / 2);
    ctx.lineTo(x + round, y + h);
    ctx.arc(x + round, y + h - round, round, Math.PI / 2, Math.PI);
    ctx.lineTo(x, y + round);
    ctx.arc(x + round, y + round, round, Math.PI, -Math.PI / 2);
  }
  async render(canvas, player2) {
    const config = this.config;
    config.w = Math.round(config.w);
    config.h = Math.round(config.h);
    if (config.w === 0 || config.h === 0)
      return;
    const box = FillRectWidget.draw(canvas, config, this.mode, player2);
    this.dropEvents(player2, box);
  }
};
var StrokeRectWidget = class extends FillRectWidget {
  constructor(config) {
    super(config);
    this.mode = "stroke";
    config.alpha = void 0;
  }
};
var ArcProgressWidget = class extends BaseWidget {
  static draw(canvas, level, config) {
    const len = (config.end_angle - config.start_angle) * level;
    if (len === 0)
      return;
    const ctx = canvas.getContext("2d");
    const width = config.line_width ? config.line_width : 1;
    const direction = config.end_angle - config.start_angle < 0;
    ctx.save();
    ctx.lineWidth = width;
    ctx.strokeStyle = zeppColorToHex(config.color);
    if (Math.abs(len) >= 360) {
      ctx.beginPath();
      ctx.arc(config.center_x, config.center_y, config.radius, config.start_angle * Math.PI, config.end_angle * Math.PI, direction);
      ctx.stroke();
      ctx.restore();
      return;
    }
    const dN = 90 * width / (Math.PI * config.radius) * (config.start_angle < config.end_angle ? -1 : 1);
    const isLargerThanDot = Math.abs(config.radius * len / 180 * Math.PI) > width;
    const getRadian = (len2) => (-90 + config.start_angle + len2) / 180 * Math.PI;
    ctx.beginPath();
    ctx.arc(config.center_x, config.center_y, config.radius, getRadian(-dN), getRadian(isLargerThanDot ? len + dN : -dN), direction);
    ctx.stroke();
    ctx.lineCap = "round";
    if (config.corner_flag !== 2 && config.corner_flag !== 3) {
      ctx.beginPath();
      ctx.arc(config.center_x, config.center_y, config.radius, getRadian(-dN), getRadian(-dN), direction);
      ctx.stroke();
    }
    if (config.corner_flag !== 1 && config.corner_flag !== 3 && isLargerThanDot) {
      ctx.beginPath();
      ctx.arc(config.center_x, config.center_y, config.radius, getRadian(len + dN), getRadian(len + dN), direction);
      ctx.stroke();
    }
    ctx.restore();
  }
  async render(canvas, player2) {
    const config = this.config;
    if (config.color === void 0)
      return;
    let level = config.level / 100;
    if (config.type)
      level = player2.getDeviceState(config.type, "progress");
    ArcProgressWidget.draw(canvas, level, config);
  }
};
var ArcWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    if (!config.color)
      return;
    const radius = config.radius ? config.radius : config.w / 2;
    ArcProgressWidget.draw(canvas, 1, {
      center_x: config.x + radius,
      center_y: config.y + radius,
      color: config.color,
      line_width: config.line_width ? config.line_width : 1,
      radius: radius - (config.line_width ? config.line_width / 2 : 1),
      start_angle: 90 + config.start_angle,
      end_angle: 90 + config.end_angle
    });
  }
};

// src/zepp_player/zepp_env/DeviceRuntimeCore.js
var HmUtilsMock = class {
  constructor(runtime, currentAppContext) {
    __publicField(this, "Lang", class {
      constructor(a) {
      }
    });
    this.runtime = runtime;
    this.currentAppContext = currentAppContext;
  }
  gettextFactory(table, lang, fallback) {
    let data = table[fallback];
    if (table[lang])
      data = table[lang];
    return (key) => data[key];
  }
  getLanguage() {
    return this.runtime.fullLanguage;
  }
  getPx() {
    return (v) => v;
  }
  measureTextWidth(text2, text_size) {
    const canvas = TextWidget.drawText({
      text: text2,
      text_size,
      _metricsOnly: true
    }, this.runtime);
    return canvas.width;
  }
};
var DeviceRuntimeCoreMock = class {
  constructor(runtime) {
    __publicField(this, "WidgetFactory", class {
      constructor(a1, a2, a3) {
      }
    });
    __publicField(this, "HmDomApi", class {
      constructor(a1, a2) {
      }
    });
    __publicField(this, "HmLogger", class {
      static getLogger(name) {
        return {
          log: (data) => console.log("hmLogger", "[" + name + "]", data)
        };
      }
    });
    this.runtime = runtime;
    this.HmUtils = new HmUtilsMock(runtime);
  }
  App(config) {
    const defTemplate = {
      __globals__: {},
      _options: config,
      onCreate: () => {
      }
    };
    return {
      ...defTemplate,
      ...config
    };
  }
  WatchFace(config) {
    return config;
  }
  Page(config) {
    return config;
  }
};

// src/zepp_player/zepp_env/HuamiFs.js
var CONSTANT_FOLDER = 1;
var HuamiFsMock = class {
  constructor(runtime) {
    __publicField(this, "O_RDONLY", 0);
    __publicField(this, "O_WRONLY", 0);
    __publicField(this, "O_RDWR", 0);
    __publicField(this, "O_APPEND", 1);
    __publicField(this, "O_CREAT", 2);
    __publicField(this, "O_EXCL", 0);
    __publicField(this, "O_TRUNC", 0);
    __publicField(this, "SEEK_SET", 0);
    this.runtime = runtime;
    const setters = ["SysProSetBool", "SysProSetInt64", "SysProSetDouble", "SysProSetChars"];
    const getters = ["SysProGetBool", "SysProGetInt64", "SysProGetDouble", "SysProGetChars"];
    for (let a in setters)
      this[setters[a]] = this.SysProSetInt;
    for (let a in getters)
      this[getters[a]] = this.SysProGetInt;
    const id = runtime.appConfig.app.appId.toString(16).padStart(8, "0").toUpperCase();
    const type = runtime.appConfig.app.appType;
    this.vfsPrefix = "/storage/js_" + type + "s/" + id + "/";
    this.vfs = runtime.vfs;
  }
  getFile(path) {
    if (!this.vfs[path]) {
      for (let key in this.vfs) {
        if (key.startsWith(path + "/"))
          return CONSTANT_FOLDER;
      }
    }
    return this.vfs[path];
  }
  parsePath(path) {
    const normalize2 = require_lib();
    if (path[0] !== "/")
      path = this.vfsPrefix + "assets/" + path;
    return normalize2(path);
  }
  newFile(path) {
    const data = new ArrayBuffer(0);
    this.vfs[path] = data;
    return data;
  }
  stat(path) {
    path = this.parsePath(path);
    const file = this.getFile(path);
    if (!file)
      return [null, -1];
    return [{
      mode: (file !== CONSTANT_FOLDER ? 32768 : 16384) + 511,
      size: file === CONSTANT_FOLDER ? 0 : file.byteLength,
      mtime: Date.now()
    }, 0];
  }
  stat_asset(path) {
    return this.stat(path);
  }
  open(path, flag) {
    path = this.parsePath(path);
    let f = this.getFile(path);
    if (!f && (flag & 2) !== 0) {
      f = this.newFile(path);
    }
    return { data: f, flag, path, position: flag === 1 ? f.length : 0, store: "appFs" };
  }
  open_asset(path, flag) {
    return this.open(path, flag);
  }
  seek(file, pos) {
    file.position = pos;
  }
  read(file, buffer, buffOffset, len) {
    const view = new Uint8Array(buffer);
    const { position } = file;
    const fileView = new Uint8Array(file.data);
    for (let i = 0; i < len; i++) {
      view[buffOffset + i] = fileView[position + i];
    }
    file.position += len;
    return 0;
  }
  close() {
    return 0;
  }
  write(file, buf, buffOffset, len) {
    const view = new Uint8Array(buf);
    const { data, position } = file;
    if (position + len > data.byteLength) {
      const newBuffer = new ArrayBuffer(position + len);
      new Uint8Array(newBuffer).set(new Uint8Array(file.data));
      file.data = newBuffer;
      this.vfs[file.path] = newBuffer;
    }
    const fileView = new Uint8Array(file.data);
    for (let i = 0; i < len; i++) {
      fileView[position + i] = view[buffOffset + i];
    }
    file.position += len;
    return 0;
  }
  remove(path) {
    delete this.vfs[path];
    return 0;
  }
  rename(path, dest) {
    const data = PersistentStorage.get("fs", path);
    PersistentStorage.set("fs", dest, data);
    PersistentStorage.del("fs", path);
    return 0;
  }
  mkdir() {
    return 0;
  }
  readdir(path) {
    const normalize2 = require_lib();
    path = normalize2(path);
    let content = [];
    if (path[path.length - 1] !== "/" && path !== "")
      path += "/";
    for (let a in this.vfs) {
      if (a.startsWith(path)) {
        const fn = a.substring(path.length).split("/")[0];
        if (content.indexOf(fn) < 0)
          content.push(fn);
      }
    }
    return [content, 0];
  }
  SysProGetInt(key) {
    return PersistentStorage.get("SysProRegistery", key);
  }
  SysProSetInt(key, val) {
    PersistentStorage.set("SysProRegistery", key, val);
  }
};

// src/zepp_player/zepp_env/HuamiSetting.js
var LANG_VALUE_TABLE = [
  "zh-CN",
  "zh-TW",
  "en-US",
  "es-ES",
  "ru-RU",
  "ko-KR",
  "fr-FR",
  "de-DE",
  "id-ID",
  "pl-PL",
  "it-IT",
  "ja-JP",
  "th-TH",
  "ar-EG",
  "vi-VN",
  "pt-PT",
  "nl-NL",
  "tr-TR",
  "uk-UA",
  "iw-IL",
  "pt-BR",
  "ro-RO",
  "cs-CZ",
  "el-GR",
  "sr-RS",
  "ca-ES",
  "fi-FI",
  "nb-NO",
  "da-DK",
  "sv-SE",
  "hu-HU",
  "ms-MY",
  "sk-SK",
  "hi-IN"
];
var HuamiSettingMock = class {
  constructor(runtime) {
    __publicField(this, "mockedProperties", [
      ["getScreenAutoBright", "setScreenAutoBright", true],
      ["getBrightness", "setBrightness", 90],
      ["setBrightScreenCancel", "setBrightScreen", 0],
      ["setScreenOff", "", true],
      ["getMileageUnit", "", 0],
      ["getDateFormat", "", 0],
      ["getWeightTarget", "", 50.5],
      ["getSleepTarget", "", 8 * 60],
      ["getWeightUnit", "", 0]
    ]);
    __publicField(this, "screen_type", {
      WATCHFACE: 1,
      AOD: 2,
      SETTINGS: 4,
      APP: 16
    });
    this.runtime = runtime;
    this.store = [];
    for (let a in this.mockedProperties) {
      this._spawnMockedProperty(...this.mockedProperties[a]);
    }
  }
  _spawnMockedProperty(getter, setter, def) {
    this.store[getter] = def;
    this[getter] = () => this.store[getter];
    if (setter !== "")
      this[setter] = (val) => {
        console.info("[hmSettings]", getter, "=", val);
        this.runtime.onConsole("device", [setter, "=", val]);
        this.store[getter] = val;
        return 0;
      };
  }
  getLanguage() {
    if (LANG_VALUE_TABLE.indexOf(this.runtime.fullLanguage) < 0)
      return 2;
    return LANG_VALUE_TABLE.indexOf(this.runtime.fullLanguage);
  }
  getUserData() {
    return {
      age: 20,
      height: 180,
      weight: 55.5,
      gender: 0,
      nickName: "NotARobot",
      region: "ru"
    };
  }
  getDiskInfo() {
    return {
      total: 10314e4,
      free: 3013e4,
      app: 1442e3,
      watchface: 435e4,
      music: 0,
      system: 669e5
    };
  }
  getDeviceInfo() {
    return {
      width: this.runtime.profileData.screenWidth,
      height: this.runtime.profileData.screenHeight,
      screenShape: 1,
      deviceName: this.runtime.profileData.deviceName,
      keyNumber: 0,
      deviceSource: 0
    };
  }
  getTimeFormat() {
    return this.runtime.getDeviceState("AM_PM") === "hide" ? 1 : 0;
  }
  getScreenType() {
    return this.runtime.showLevel;
  }
  getDateFormat() {
    return 0;
  }
};

// src/zepp_player/ui/ApplicationWidgets.js
var DelegateWidget = class extends BaseWidget {
  async render() {
  }
};
var _GroupWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    this.widgets = [];
    config.__content = this.widgets;
  }
  async render(canvas, player2) {
    const tempCanvas = player2.newCanvas();
    tempCanvas.width = this.config.w;
    tempCanvas.height = this.config.h;
    for (let i in this.widgets) {
      const widget = this.widgets[i];
      widget.config.__eventOffsetX = this.config.x;
      widget.config.__eventOffsetY = this.config.y;
      await player2.renderWidget(widget, tempCanvas);
    }
    canvas.getContext("2d").drawImage(tempCanvas, this.config.x, this.config.y);
  }
  createWidget(type, config) {
    let Widget;
    if (!type) {
      Widget = MissingWidget;
    } else {
      Widget = new HuamiUIMock()._widget[type];
    }
    if (typeof config !== "object") {
      config = {};
    }
    if (_GroupWidget.banlist.indexOf(type) > -1) {
      this.runtime.onConsole("SystemWarning", ["You can't place", type, "into group"]);
      return null;
    }
    config.__widget = type;
    config.__id = (this.config.__id + 1 << 8) + this.widgets.length;
    config.__runtime = this.runtime;
    const i = new Widget(config);
    this.widgets.push(i);
    this.config.__runtime.refresh_required = "add_widget_group";
    return i;
  }
};
var GroupWidget = _GroupWidget;
__publicField(GroupWidget, "banlist", [
  "WATCHFACE_EDIT_MASK",
  "WATCHFACE_EDIT_FG_MASK",
  "WATCHFACE_EDIT_BG",
  "WATCHFACE_EDIT_GROUP",
  "GROUP"
]);
var StateButtonWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    this.addEventListener("onmouseup", () => {
      this.config.__radioGroup.setProperty("checked", this);
    });
  }
  async render(canvas, player2) {
    const groupConfig = this.config.__radioGroup.config;
    const src = groupConfig.checked === this ? groupConfig.select_src : groupConfig.unselect_src;
    const img = await player2.getAssetImage(src);
    const defaults = { x: 0, y: 0, w: img.width, h: img.height };
    const config = { ...defaults, ...this.config };
    canvas.getContext("2d").drawImage(img, config.x + groupConfig.x, config.y + groupConfig.y);
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + config.w,
      config.y + config.h
    ]);
  }
};
var RadioGroupWidget = class extends GroupWidget {
  constructor(config) {
    super(config);
    this.optIndex = 0;
  }
  setProperty(prop, val) {
    if (prop === "checked") {
      const { __radioGroup, __index } = val.config;
      this.config.check_func(__radioGroup, __index, true);
      this.runtime.refresh_required = "group_switch";
    }
    return super.setProperty(prop, val);
  }
  async render(canvas, player2) {
    for (let i in this.widgets) {
      const widget = this.widgets[i];
      widget.config.__eventOffsetX = this.config.x;
      widget.config.__eventOffsetY = this.config.y;
      await player2.renderWidget(widget, canvas);
    }
  }
  createWidget(type, config) {
    if (type === "STATE_BUTTON") {
      config.__radioGroup = this;
      config.__index = this.optIndex;
      this.optIndex++;
    }
    return super.createWidget(type, config);
  }
};

// src/zepp_player/ui/DatetimeWidgets.js
var DatePointer = class extends BaseWidget {
  constructor(config) {
    super(config);
  }
  async render(canvas, player2) {
    const config = this.config;
    let angle = 360 * player2.getDeviceState(config.type, "progress");
    const pointer = await player2.getAssetImage(config.src);
    ImageWidget.draw(pointer, canvas, player2, {
      x: 0,
      y: 0,
      w: canvas.width,
      h: canvas.height,
      center_x: config.center_x,
      center_y: config.center_y,
      pos_x: config.center_x - config.posX,
      pos_y: config.center_y - config.posY,
      angle
    });
    if (config.cover_path) {
      const cover = await player2.getAssetImage(config.cover_path);
      ImageWidget.draw(cover, player2, canvas, {
        x: config.cover_x,
        y: config.cover_y
      });
    }
  }
};
var TimePointer = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    const hourProgress = player2.getDeviceState("HOUR", "pointer_progress");
    const minuteProgress = player2.getDeviceState("MINUTE", "pointer_progress");
    const secondProgress = player2.getDeviceState("SECOND", "pointer_progress");
    const data = [
      ["hour_", hourProgress + minuteProgress / 12],
      ["minute_", minuteProgress + secondProgress / 60],
      ["second_", secondProgress]
    ];
    for (let i in data) {
      const [prefix, value] = data[i];
      let img;
      if (config[prefix + "path"]) {
        img = await player2.getAssetImage(config[prefix + "path"]);
        ImageWidget.draw(img, canvas, player2, {
          x: 0,
          y: 0,
          w: canvas.width,
          h: canvas.height,
          center_x: config[prefix + "centerX"],
          center_y: config[prefix + "centerY"],
          pos_x: config[prefix + "centerX"] - config[prefix + "posX"],
          pos_y: config[prefix + "centerY"] - config[prefix + "posY"],
          angle: 360 * value
        });
      }
      if (config[prefix + "cover_path"] && config[prefix + "cover_y"] && config[prefix + "cover_x"]) {
        img = await player2.getAssetImage(config[prefix + "cover_path"]);
        ImageWidget.draw(img, canvas, player2, {
          x: config[prefix + "cover_x"],
          y: config[prefix + "cover_y"]
        });
      }
    }
  }
};
var TimeWidget = class extends BaseWidget {
  async render(canvas, runtime) {
    const config = this.config;
    const ctx = canvas.getContext("2d");
    const timeParts = [
      ["hour_", "HOUR"],
      ["minute_", "MINUTE"],
      ["second_", "SECOND"]
    ];
    let images = [];
    for (let i in timeParts) {
      let [prefix, value] = timeParts[i];
      if (!config[prefix + "array"])
        continue;
      value = runtime.getDeviceState(value, "string");
      if (config[prefix + "zero"] > 0)
        value = value.padStart(2, "0");
      let basementImg;
      try {
        basementImg = await runtime.getAssetImage(config[prefix + "array"][0]);
      } catch (e) {
        continue;
      }
      let img;
      try {
        img = await TextImageWidget.draw(runtime, value, 0, {
          font_array: config[prefix + "array"],
          h_space: config[prefix + "space"],
          unit_sc: config[prefix + "unit_sc"],
          unit_tc: config[prefix + "unit_tc"],
          unit_en: config[prefix + "unit_en"],
          align: config[prefix + "align"]
        });
      } catch (e) {
        console.warn(e);
        continue;
      }
      if (img === null)
        continue;
      if (config[prefix + "follow"] > 0) {
        let [lastImg, lastPrefix, expectedWidth] = images.pop();
        let offset = config[lastPrefix + "space"];
        if (!offset)
          offset = 0;
        const combinedImg = runtime.newCanvas();
        combinedImg.width = lastImg.width + img.width;
        combinedImg.height = Math.max(lastImg.height, img.height);
        const cctx = combinedImg.getContext("2d");
        cctx.drawImage(lastImg, 0, 0);
        cctx.drawImage(img, lastImg.width, 0);
        expectedWidth += 2 * (basementImg.width + offset);
        if (config[prefix + "unit_en"]) {
          let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
          expectedWidth += unit.width;
        }
        images.push([combinedImg, lastPrefix, expectedWidth]);
      } else {
        let offset = config[prefix + "space"];
        if (!offset)
          offset = 0;
        let expectedWidth = 2 * (basementImg.width + offset);
        if (config[prefix + "unit_en"]) {
          try {
            let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
            expectedWidth += unit.width;
          } catch (e) {
          }
        }
        images.push([img, prefix, expectedWidth]);
      }
    }
    for (let i in images) {
      const [img, prefix, expWidth] = images[i];
      let x = config[prefix + "startX"];
      let y = config[prefix + "startY"];
      let px = 0;
      switch (config[prefix + "align"]) {
        case "center_h":
          px = Math.max(0, (expWidth - img.width) / 2);
          break;
        case "right":
          px = expWidth - img.width;
      }
      ctx.drawImage(img, x + px, y);
    }
    const ampmState = runtime.getDeviceState("AM_PM");
    const lang = runtime.language;
    const ampmData = ["am", "pm"];
    for (let i in ampmData) {
      let value = ampmData[i];
      let prefix = value + "_", langPrefix = prefix + lang + "_";
      if (config[langPrefix + "path"] && ampmState === value) {
        const img = await runtime.getAssetImage(config[langPrefix + "path"]);
        ctx.drawImage(img, config[prefix + "x"], config[prefix + "y"]);
      }
    }
    this.dropEvents(runtime, [
      0,
      0,
      canvas.width,
      canvas.height
    ]);
  }
};
var DateWidget = class extends BaseWidget {
  async render(canvas, runtime) {
    const ctx = canvas.getContext("2d");
    const lang = runtime.language;
    const config = this.config;
    const data = [
      ["year_", runtime.getDeviceState("YEAR", "string"), 2],
      ["month_", runtime.getDeviceState("MONTH", "string"), 2],
      ["day_", runtime.getDeviceState("DAY", "string"), 2]
    ];
    if (config.year_zero) {
      data[0][1] = "20" + data[0][1];
      data[0][2] = 4;
    }
    let images = [];
    for (let i2 in data) {
      let [prefix, value, fullLength] = data[i2];
      if (!config[prefix + lang + "_array"])
        continue;
      const imgs = config[prefix + lang + "_array"];
      let basementImg;
      try {
        basementImg = await runtime.getAssetImage(imgs[0]);
      } catch (e) {
        continue;
      }
      let img = null;
      if (config[prefix + "is_character"]) {
        try {
          img = await runtime.getAssetImage(imgs[value - 1]);
        } catch (e) {
          continue;
        }
      } else {
        value = value.toString();
        if (config[prefix + "zero"]) {
          value = value.padStart(fullLength, "0");
        }
        try {
          img = await TextImageWidget.draw(runtime, value, 0, {
            font_array: config[prefix + lang + "_array"],
            h_space: config[prefix + "space"],
            unit_sc: config[prefix + "unit_sc"],
            unit_tc: config[prefix + "unit_tc"],
            unit_en: config[prefix + "unit_en"],
            align: config[prefix + "align"]
          });
        } catch (e) {
          console.warn(e);
          continue;
        }
      }
      if (!img)
        continue;
      if (config[prefix + "follow"] > 0 && images.length > 0) {
        let [lastImg, lastPrefix, expectedWidth] = images.pop();
        let offset = config[lastPrefix + "space"];
        if (!offset)
          offset = 0;
        const combinedImg = runtime.newCanvas();
        combinedImg.width = lastImg.width + img.width + offset;
        combinedImg.height = Math.max(lastImg.height, img.height);
        const cctx = combinedImg.getContext("2d");
        cctx.drawImage(lastImg, 0, 0);
        cctx.drawImage(img, lastImg.width + offset, 0);
        expectedWidth += fullLength * (basementImg.width + offset);
        if (config[prefix + "unit_en"]) {
          let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
          expectedWidth += unit.width;
        }
        images.push([combinedImg, lastPrefix, expectedWidth]);
      } else {
        let offset = config[prefix + "space"];
        if (!offset)
          offset = 0;
        let expectedWidth = fullLength * (basementImg.width + offset);
        if (config[prefix + "unit_en"]) {
          let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
          expectedWidth += unit.width;
        }
        images.push([img, prefix, expectedWidth]);
      }
    }
    for (var i in images) {
      const [img, prefix, expWidth] = images[i];
      let x = config[prefix + "startX"];
      let y = config[prefix + "startY"];
      let px = 0;
      switch (config[prefix + "align"]) {
        case "center_h":
          px = Math.max(0, (expWidth - img.width) / 2);
          break;
        case "right":
          px = expWidth - img.width;
      }
      ctx.drawImage(img, x + px, y);
      this.dropEvents(runtime, [
        x,
        y,
        x + img.width,
        y + img.height
      ]);
    }
  }
};
var WeekdayWidget = class extends BaseWidget {
  async render(canvas, runtime) {
    const config = this.config;
    let val = runtime.getDeviceState("WEEKDAY");
    if (!val || val < 0)
      val = 0;
    let font = config["week_" + runtime.language];
    if (!font || val >= font.length)
      return;
    try {
      const img = await runtime.getAssetImage(font[val]);
      canvas.getContext("2d").drawImage(img, config.x, config.y);
      this.dropEvents(runtime, [
        config.x,
        config.y,
        config.x + img.width,
        config.y + img.height
      ]);
    } catch (e) {
    }
  }
};

// src/zepp_player/ui/EditableWatchfaceWidgets.js
var BaseEditableWidget = class extends BaseWidget {
  zp_isActive() {
    return PersistentStorage.get("wfEdit", "focus") === this.config.edit_id;
  }
  zp_setActive() {
    PersistentStorage.set("wfEdit", "focus", this.config.edit_id);
    this.runtime.refresh_required = "edit";
  }
  getProperty(key, second) {
    if (key === "current_type" && this.runtime.showLevel === 4)
      return -1;
    return super.getProperty(key, second);
  }
};
var EditableBackground = class extends BaseEditableWidget {
  constructor(config) {
    super(config);
    config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
    if (config.current_type === null || config.current_type === void 0)
      config.current_type = config.default_id;
    this.addEventListener("onmouseup", () => {
      if (this.runtime.showLevel !== 4)
        return;
      if (!this.zp_isActive())
        return this.zp_setActive();
      this._switch();
    });
  }
  _findCurrent() {
    const id = this.config.current_type;
    for (let i in this.config.bg_config) {
      i = parseInt(i);
      if (this.config.bg_config[i].id === id) {
        return i;
      }
    }
    return this.config.default_id;
  }
  _switch() {
    const i = this._findCurrent();
    const nextIndex = (i + 1) % this.config.bg_config.length;
    const val = this.config.bg_config[nextIndex].id;
    PersistentStorage.set("wfEdit", this.config.edit_id, val);
    this.config.current_type = val;
    this.runtime.refresh_required = "edit";
  }
  async render(canvas, player2) {
    const config = this.config;
    const ctx = canvas.getContext("2d");
    const data = this.config.bg_config[this._findCurrent()];
    if (this.runtime.showLevel === 4) {
      const img = await player2.getAssetImage(data.preview);
      const fg = await player2.getAssetImage(config.fg);
      const eventsZone = ImageWidget.draw(img, canvas, player2, config);
      ImageWidget.draw(fg, canvas, player2, config);
      if (this.zp_isActive())
        player2.addPostRenderTask(async () => {
          const tips = await player2.getAssetImage(config.tips_bg);
          ImageWidget.draw(tips, canvas, player2, {
            x: config.tips_x,
            y: config.tips_y
          });
          const textImg = await TextWidget.drawText({
            color: 0,
            text: `Background ${data.id}/${config.count}`,
            text_size: 18,
            w: tips.width,
            h: tips.height,
            align_h: "center_h",
            align_v: "center_v"
          }, player2);
          ctx.drawImage(textImg, config.x + config.tips_x, config.y + config.tips_y);
        });
      this.dropEvents(player2, eventsZone);
    } else {
      const img = await player2.getAssetImage(data.path);
      ImageWidget.draw(img, canvas, player2, config);
    }
  }
};
var EditPointerWidget = class extends BaseEditableWidget {
  constructor(config) {
    super(config);
    config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
    if (config.current_type === null || config.current_type === void 0)
      config.current_type = config.default_id;
    this.addEventListener("onmouseup", () => {
      if (!this.zp_isActive())
        return this.zp_setActive();
      this._switch();
    });
  }
  _switch() {
    const currentType = this.config.current_type;
    for (let i = 0; i < this.config.count; i++) {
      if (this.config.config[i].id === currentType) {
        const nextIndex = (i + 1) % this.config.count;
        const val = this.config.config[nextIndex];
        PersistentStorage.set("wfEdit", this.config.edit_id, val.id);
        this.config.current_type = val.id;
        this.runtime.refresh_required = "edit";
        return;
      }
    }
  }
  _findCurrent() {
    const id = this.config.current_type;
    for (let i = 0; i < this.config.count; i++) {
      if (this.config.config[i].id === id) {
        return i;
      }
    }
    return -1;
  }
  getProperty(key, second) {
    if (key === "current_config") {
      if (this.runtime.showLevel === 4)
        return {};
      const i = this._findCurrent();
      const data = this.config.config[i];
      const config = {};
      for (const key2 of ["hour", "minute", "second"]) {
        if (!data[key2])
          continue;
        for (const prop in data[key2]) {
          config[`${key2}_${prop}`] = data[key2][prop];
        }
      }
      return config;
    }
    return super.getProperty(key, second);
  }
  async render(canvas, runtime) {
    if (runtime.showLevel !== 4)
      return;
    const config = this.config;
    const ctx = canvas.getContext("2d");
    const i = this._findCurrent();
    const preview = await runtime.getAssetImage(config.config[i].preview);
    ctx.drawImage(preview, config.x, config.y);
    try {
      const fg = await runtime.getAssetImage(config.fg);
      ctx.drawImage(fg, config.x, config.y);
    } catch (e) {
    }
    if (this.zp_isActive())
      runtime.addPostRenderTask(async () => {
        const tips = await player.getAssetImage(config.tips_bg);
        ImageWidget.draw(tips, canvas, player, {
          x: config.tips_x,
          y: config.tips_y
        });
        const textImg = await TextWidget.drawText({
          color: 0,
          text: `Pointers ${i + 1}/${config.count}`,
          text_size: 18,
          w: tips.width,
          h: tips.height,
          align_h: "center_h",
          align_v: "center_v"
        }, player);
        ctx.drawImage(textImg, config.x + config.tips_x, config.y + config.tips_y);
      });
    const boxWidth = Math.min(preview.width, 100);
    const boxHeight = Math.min(preview.height, 100);
    this.dropEvents(runtime, [
      config.x + (preview.width - boxWidth) / 2,
      config.y + (preview.height - boxHeight) / 2,
      config.x + (preview.width - boxWidth) / 2 + boxWidth,
      config.y + (preview.height - boxHeight) / 2 + boxHeight
    ]);
  }
};
var EditGroupWidget = class extends BaseEditableWidget {
  get _renderStage() {
    if (this.runtime.showLevel !== 4)
      return "";
    return this.zp_isActive() ? "toplevel" : "postReverse";
  }
  constructor(config) {
    super(config);
    config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
    if (config.current_type === null || config.current_type === void 0) {
      config.current_type = config.default_type;
      PersistentStorage.set("wfEdit", config.edit_id, config.default_type);
    }
    this.addEventListener("onmouseup", () => {
      if (!this.zp_isActive())
        return this.zp_setActive();
      this._switch();
    });
  }
  async render(canvas, player2) {
    if (player2.showLevel !== 4)
      return;
    const config = this.config;
    const ctx = canvas.getContext("2d");
    const isActive = this.zp_isActive();
    const currentType = config.current_type;
    let width = config.w ? config.w : 0;
    let height = config.h ? config.h : 0;
    let preview = null, text2 = "";
    for (let i = 0; i < config.count; i++) {
      const option = config.optional_types[i];
      if (option.type === currentType) {
        preview = option.preview;
        text2 = option.title_en;
      }
    }
    try {
      preview = await player2.getAssetImage(preview);
      if (width === 0)
        width = preview.width;
      if (height === 0)
        height = preview.height;
      const ox = (width - preview.width) / 2;
      const oy = (height - preview.height) / 2;
      ctx.drawImage(preview, config.x + ox, config.y + oy);
    } catch (e) {
    }
    let dx = config.x, dy = config.y;
    try {
      const overlay = await player2.getAssetImage(isActive ? config.select_image : config.un_select_image);
      ctx.drawImage(overlay, config.x, config.y);
    } catch (e) {
    }
    if (isActive)
      player2.addPostRenderTask(async () => {
        let tipsBg;
        try {
          tipsBg = await player2.getAssetImage(config.tips_BG);
        } catch (e) {
          return;
        }
        const tipsImg = player2.newCanvas();
        tipsImg.width = config.tips_width;
        tipsImg.height = tipsBg.height;
        const tipsCtx = tipsImg.getContext("2d");
        tipsCtx.drawImage(tipsBg, 0, 0);
        if (text2) {
          const textImg = await TextWidget.drawText({
            color: 0,
            text: text2,
            text_size: 18,
            w: config.tips_width - config.tips_margin * 2,
            h: tipsBg.height,
            align_h: "center_h",
            align_v: "center_v"
          }, player2);
          tipsCtx.drawImage(textImg, config.tips_margin, 0);
        }
        ctx.drawImage(tipsImg, dx + config.tips_x, dy + config.tips_y);
      });
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + width,
      config.y + height
    ]);
  }
  _switch() {
    const currentType = this.config.current_type;
    for (let i = 0; i < this.config.count; i++) {
      if (this.config.optional_types[i].type === currentType) {
        const nextIndex = (i + 1) % this.config.count;
        const val = this.config.optional_types[nextIndex];
        PersistentStorage.set("wfEdit", this.config.edit_id, val.type);
        this.config.current_type = val.type;
        this.runtime.render_counter = 0;
        this.runtime.refresh_required = "edit";
        return;
      }
    }
  }
};

// src/zepp_player/ui/FormWidgets.js
var ButtonWidget = class extends BaseWidget {
  constructor(config) {
    super(config);
    this.pressed = false;
    config.alpha = void 0;
    this.addEventListener("onmousedown", () => {
      this.pressed = true;
      config.__runtime.refresh_required = "button";
    });
    this.addEventListener("onmouseup", (info) => {
      this.pressed = false;
      config.__runtime.refresh_required = "button";
      if (config.click_func)
        config.click_func(this);
    });
    this.addEventListener = () => {
    };
  }
  async render(canvas, player2) {
    const config = this.config;
    const w = config.w ? config.w : 0;
    const h = config.h ? config.h : 0;
    if (config.press_src && config.normal_src) {
      const src = this.pressed ? config.press_src : config.normal_src;
      const img = await player2.getAssetImage(src);
      ImageWidget.draw(img, canvas, player2, {
        x: config.x + Math.max(0, (w - img.width) / 2),
        y: config.y + Math.max(0, (h - img.height) / 2)
      });
    } else {
      const normalColor = config.normal_color ? zeppColorToHex(config.normal_color) : "#000000";
      const pressedColor = config.press_color ? zeppColorToHex(config.press_color) : "#CCCCCC";
      const color = this.pressed ? pressedColor : normalColor;
      FillRectWidget.draw(canvas, {
        ...config,
        color
      }, "fill", player2);
    }
    const textLayer = await TextWidget.drawText({
      ...config,
      align_h: "center_h",
      align_v: "center_v",
      color: config.color !== void 0 ? config.color : 16777215
    }, player2);
    canvas.getContext("2d").drawImage(textLayer, config.x, config.y);
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + config.w,
      config.y + config.h
    ]);
  }
};

// src/zepp_player/ui/HistogramWidget.js
var HistogramWidget = class extends BaseWidget {
  async render(canvas, player2) {
    const config = this.config;
    const internalCanvas = player2.newCanvas();
    internalCanvas.width = config.w;
    internalCanvas.height = config.h;
    await this.drawBg(internalCanvas, player2);
    await this.drawData(internalCanvas, player2);
    canvas.getContext("2d").drawImage(internalCanvas, config.x, config.y);
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + config.w,
      config.y + config.h
    ]);
  }
  async drawData(canvas, player2) {
    const config = this.config;
    const ctx = canvas.getContext("2d");
    const height = config.item_max_height ? config.item_max_height : config.h;
    const dataHeight = config.data_max_value - config.data_min_value;
    ctx.fillStyle = zeppColorToHex(config.item_color);
    let x = 0;
    for (let i = 0; i < config.data_count; i++) {
      const perc = Math.max(0, config.data_array[i] - config.data_min_value) / dataHeight;
      const lineHeight = perc * height;
      ctx.fillRect(x, height - lineHeight, config.item_width, lineHeight);
      x += config.item_width + config.item_space;
    }
  }
  async drawBg(canvas, player2) {
    const ctx = canvas.getContext("2d");
    const xline = this.config.xline;
    ctx.strokeStyle = zeppColorToHex(xline.color !== void 0 ? xline.color : 16777215);
    ctx.lineWidth = xline.width ? xline.width : 1;
    let x = xline.pading;
    while (x < canvas.width) {
      ctx.beginPath();
      ctx.moveTo(x, xline.start);
      ctx.lineTo(x, xline.end);
      ctx.stroke();
      x += xline.space;
    }
    const yline = this.config.yline;
    ctx.strokeStyle = zeppColorToHex(yline.color !== void 0 ? yline.color : 16777215);
    ctx.lineWidth = yline.width ? yline.width : 1;
    let y = yline.pading;
    while (y < canvas.height) {
      ctx.beginPath();
      ctx.moveTo(yline.start, y);
      ctx.lineTo(yline.end, y);
      ctx.stroke();
      y += yline.space;
    }
    const xText = this.config.xText;
    for (let i = 0; i < xText.count; i++) {
      let cw = await TextWidget.drawText({
        text: xText.data_array[i],
        align_h: xText.align,
        color: xText.color,
        w: xText.w,
        h: xText.h,
        text_size: 18
      }, player2);
      ctx.drawImage(cw, xText.x + (xText.space + xText.w) * i, xText.y);
    }
    const yText = this.config.yText;
    for (let i = 0; i < yText.count; i++) {
      let cw = await TextWidget.drawText({
        text: yText.data_array[i],
        align_h: yText.align,
        color: yText.color,
        w: yText.w,
        h: yText.h,
        text_size: 18
      }, player2);
      ctx.drawImage(cw, yText.x, yText.y + (yText.space + yText.h) * i);
    }
  }
};

// src/zepp_player/ui/ScrollList.js
var ScrollList = class extends BaseWidget {
  constructor(conf) {
    super(conf);
    this.scrollY = 0;
    this.isMouseDown = false;
    this.lastScrollY = 0;
    this.mouseStartEv = {};
    this.innerHeight = 0;
    this.addEventListener("onmouseup", (e) => this.eventUp(e));
    this.addEventListener("onmousedown", (e) => this.eventDown(e));
    this.addEventListener("onmousemove", (e) => this.eventMove(e));
  }
  async render(canvas, player2) {
    const config = this.config;
    const view = player2.newCanvas();
    view.width = config.w;
    view.height = config.h;
    let posY = this.scrollY, dtc, ic;
    for (let i = 0; i < config.data_type_config_count; i++) {
      dtc = config.data_type_config[i];
      ic = this._getItemType(dtc.type_id);
      for (let j = dtc.start; j <= dtc.end; j++) {
        posY += await this._drawLine(ic, j, posY, view, player2);
      }
    }
    this.innerHeight = posY - this.scrollY;
    canvas.getContext("2d").drawImage(view, config.x, config.y);
    this.dropEvents(player2, [
      config.x,
      config.y,
      config.x + config.w,
      config.y + config.h
    ]);
  }
  _getItemType(type_id) {
    for (let i = 0; i < this.config.item_config_count; i++) {
      if (this.config.item_config[i].type_id === type_id)
        return this.config.item_config[i];
    }
    throw new Error("TypeID " + type_id + " missing");
  }
  async _drawLine(ic, index, posY, canvas, player2) {
    const config = this.config;
    const item = config.data_array[index];
    const ctx = canvas.getContext("2d");
    FillRectWidget.draw(canvas, {
      x: 0,
      y: posY,
      w: config.w,
      h: ic.item_height,
      color: ic.item_bg_color,
      radius: ic.item_bg_radius
    }, "fill", player2);
    for (let i = 0; i < ic.text_view_count; i++) {
      const tv = ic.text_view[i];
      const cnv = TextWidget.drawText({
        ...tv,
        text: item[tv.key],
        align_h: "center_h",
        align_v: "center_v"
      }, player2);
      ctx.drawImage(cnv, tv.x, posY + tv.y);
    }
    for (let i = 0; i < ic.image_view_count; i++) {
      try {
        const iv = ic.image_view[i];
        const img = await player2.getAssetImage(item[iv.key]);
        ImageWidget.draw(img, canvas, player2, {
          x: iv.x,
          y: iv.y + posY
        });
      } catch (e) {
      }
    }
    return ic.item_height + config.item_space;
  }
  eventUp(e) {
    this.isMouseDown = false;
    if (this.lastScrollY === this.scrollY) {
      this.handleClick(e);
    }
    const lim = this.innerHeight - this.config.h;
    if (this.scrollY < -lim)
      this.scrollY = -lim;
    if (this.scrollY > 0)
      this.scrollY = 0;
    this.runtime.refresh_required = "scroll";
  }
  eventDown(e) {
    this.mouseStartEv = e;
    this.lastScrollY = this.scrollY;
    this.isMouseDown = true;
  }
  handleClick(e) {
    const config = this.config;
    const clickY = e.y - config.y;
    let posY = this.scrollY;
    for (let i = 0; i < config.data_type_config_count; i++) {
      const dtc = config.data_type_config[i];
      const ic = this._getItemType(dtc.type_id);
      for (let j = dtc.start; j <= dtc.end; j++) {
        if (clickY > posY && clickY < posY + ic.item_height) {
          config.item_click_func(config.data_array, j);
          return;
        }
        posY += ic.item_height + config.item_space;
      }
    }
  }
  eventMove(e) {
    if (!this.isMouseDown)
      return;
    if (Math.abs(e.y - this.mouseStartEv.y) < 5)
      return;
    const delta = e.y - this.mouseStartEv.y + this.lastScrollY;
    this.scrollY = delta;
    this.runtime.refresh_required = "scroll";
  }
};

// src/zepp_player/ui/HuamiUI.js
var HuamiUIMock = class {
  constructor(runtime) {
    __publicField(this, "_idCounter", 0);
    __publicField(this, "_widget", {
      IMG: ImageWidget,
      IMG_POINTER: PointerWidget,
      IMG_STATUS: ImageStatusWidget,
      TEXT_IMG: TextImageWidget,
      IMG_PROGRESS: ImageProgressWidget,
      IMG_LEVEL: LevelWidget,
      IMG_ANIM: AnimationWidget,
      GROUP: GroupWidget,
      FILL_RECT: FillRectWidget,
      STROKE_RECT: StrokeRectWidget,
      IMG_WEEK: WeekdayWidget,
      IMG_TIME: TimeWidget,
      IMG_DATE: DateWidget,
      ARC_PROGRESS: ArcProgressWidget,
      ARC: ArcWidget,
      WATCHFACE_EDIT_MASK: ImageWidget,
      WATCHFACE_EDIT_FG_MASK: ImageWidget,
      WATCHFACE_EDIT_BG: EditableBackground,
      WATCHFACE_EDIT_GROUP: EditGroupWidget,
      WATCHFACE_EDIT_POINTER: EditPointerWidget,
      TIME_POINTER: TimePointer,
      DATE_POINTER: DatePointer,
      IMG_CLICK: ClickableImageWidget,
      WIDGET_DELEGATE: DelegateWidget,
      TEXT: TextWidget,
      CIRCLE: CircleWidget,
      BUTTON: ButtonWidget,
      HISTOGRAM: HistogramWidget,
      SCROLL_LIST: ScrollList,
      RADIO_GROUP: RadioGroupWidget,
      STATE_BUTTON: StateButtonWidget
    });
    __publicField(this, "prop", {
      VISIBLE: "visible",
      ANIM_STATUS: "anim_status",
      ANGLE: "angle",
      SRC: "src",
      CURRENT_TYPE: "current_type",
      CURRENT_CONFIG: "current_config",
      MORE: "more",
      ANIM: "more",
      UPDATE_DATA: "more",
      X: "x",
      Y: "y",
      W: "w",
      H: "h",
      POS_X: "pos_x",
      POS_Y: "pos_y",
      CENTER_X: "center_x",
      CENTER_Y: "center_y",
      TEXT: "text",
      TEXT_SIZE: "text_size",
      COLOR: "color",
      RADIUS: "radius",
      START_ANGLE: "start_angle",
      END_ANGLE: "end_angle",
      LINE_WIDTH: "line_width",
      WORD_WRAP: "word_wrap",
      DATASET: "dataset",
      INIT: "checked",
      CHECKED: "checked",
      CURRENT_SELECT: "checked"
    });
    __publicField(this, "show_level", {
      ONLY_NORMAL: 1,
      ONLY_AOD: 2,
      ONAL_AOD: 2,
      ONLY_EDIT: 4,
      ALL: 1 | 2 | 4
    });
    __publicField(this, "align", {
      LEFT: "left",
      RIGHT: "right",
      CENTER_H: "center_h",
      CENTER_V: "center_v",
      TOP: "top",
      BOTTOM: "bottom"
    });
    __publicField(this, "date", {
      MONTH: "MONTH",
      DAY: "DAY",
      YEAR: "YEAR",
      WEEK: "WEEKDAY"
    });
    __publicField(this, "event", {
      CLICK_DOWN: "onmousedown",
      CLICK_UP: "onmouseup",
      MOVE: "onmousemove",
      SELECT: "onmouseup"
    });
    __publicField(this, "text_style", {
      WRAP: 2,
      CHAR_WRAP: 2,
      ELLIPSIS: 3,
      NONE: 0
    });
    __publicField(this, "system_status", {
      CLOCK: "ALARM_CLOCK",
      DISCONNECT: "DISCONNECT",
      DISTURB: "DISTURB",
      LOCK: "LOCK"
    });
    __publicField(this, "anim_status", {
      START: 1,
      PAUSE: 0,
      RESUME: 1,
      STOP: 0
    });
    __publicField(this, "data_type", {
      "BATTERY": "BATTERY",
      "STEP": "STEP",
      "STEP_TARGET": "STEP_TARGET",
      "CAL": "CAL",
      "CAL_TARGET": "CAL_TARGET",
      "HEART": "HEART",
      "PAI_DAILY": "PAI_DAILY",
      "PAI_WEEKLY": "PAI_WEEKLY",
      "DISTANCE": "DISTANCE",
      "STAND": "STAND",
      "STAND_TARGET": "STAND_TARGET",
      "WEATHER": "WEATHER_CURRENT",
      "WEATHER_CURRENT": "WEATHER_CURRENT",
      "WEATHER_LOW": "WEATHER_LOW",
      "WEATHER_HIGH": "WEATHER_HIGH",
      "UVI": "UVI",
      "AQI": "AQI",
      "HUMIDITY": "HUMIDITY",
      "ACTIVITY": "ACTIVITY",
      "ACTIVITY_TARGET": "ACTIVITY_TARGET",
      "FAT_BURNING": "FAT_BURNING",
      "FAT_BURNING_TARGET": "FAT_BURNING_TARGET",
      "SUN_CURRENT": "SUN_CURRENT",
      "SUN_RISE": "SUN_RISE",
      "SUN_SET": "SUN_SET",
      "WIND": "WIND",
      "WIND_DIRECTION": "WIND_DIRECTION",
      "STRESS": "STRESS",
      "SPO2": "SPO2",
      "ALTIMETER": "ALTIMETER",
      "MOON": "MOON",
      "FLOOR": "FLOOR",
      "ALARM_CLOCK": "ALARM_CLOCK",
      "COUNT_DOWN": "COUNT_DOWN",
      "STOP_WATCH": "STOP_WATCH",
      "SLEEP": "SLEEP"
    });
    __publicField(this, "edit_type", {
      "BATTERY": "BATTERY",
      "STEP": "STEP",
      "STEP_TARGET": "STEP_TARGET",
      "CAL": "CAL",
      "CAL_TARGET": "CAL_TARGET",
      "HEART": "HEART",
      "PAI_DAILY": "PAI_DAILY",
      "PAI_WEEKLY": "PAI_WEEKLY",
      "DISTANCE": "DISTANCE",
      "STAND": "STAND",
      "STAND_TARGET": "STAND_TARGET",
      "WEATHER_CURRENT": "WEATHER_CURRENT",
      "WEATHER_LOW": "WEATHER_LOW",
      "WEATHER_HIGH": "WEATHER_HIGH",
      "UVI": "UVI",
      "AQI": "AQI",
      "HUMIDITY": "HUMIDITY",
      "FAT_BURN": "FAT_BURNING",
      "FAT_BURNING": "FAT_BURNING",
      "FAT_BURNING_TARGET": "FAT_BURNING_TARGET",
      "SUN_CURRENT": "SUN_CURRENT",
      "SUN_RISE": "SUN_RISE",
      "SUN_SET": "SUN_SET",
      "WIND": "WIND",
      "STRESS": "STRESS",
      "SPO2": "SPO2",
      "BODY_TEMP": "BODY_TEMP",
      "ALTIMETER": "ALTIMETER",
      "MOON": "MOON",
      "FLOOR": "FLOOR",
      "ALARM_CLOCK": "ALARM_CLOCK",
      "COUNT_DOWN": "COUNT_DOWN",
      "STOP_WATCH": "STOP_WATCH",
      "WEATHER": "WEATHER",
      "SLEEP": "SLEEP"
    });
    this.runtime = runtime;
    this.widget = {};
    this.toastWidget = null;
    for (let a in this._widget)
      this.widget[a] = a;
  }
  deleteWidget(widget) {
    const widgets = this.runtime.widgets;
    const targetId = widget.config.__id;
    for (let i in widgets) {
      if (widgets[i].config.__id === targetId) {
        widgets.splice(parseInt(i), 1);
        this.runtime.refresh_required = "del_widget";
        return;
      } else if (widgets[i].config.__content) {
        const groupContent = widgets[i].config.__content;
        for (let j in groupContent) {
          if (groupContent[j].config.__id === targetId) {
            widgets[i].config.__content.splice(parseInt(j), 1);
            this.runtime.refresh_required = "del_widget";
            return;
          }
        }
      }
    }
    console.warn("can't delete undefined widget", widget);
  }
  createWidget(type, config) {
    let Widget = this._widget[type];
    if (!Widget) {
      Widget = MissingWidget;
    }
    if (typeof config !== "object") {
      config = {};
    }
    config.__widget = type;
    config.__id = this._idCounter;
    config.__runtime = this.runtime;
    const i = new Widget(config);
    this.runtime.widgets.push(i);
    this._idCounter++;
    this.runtime.refresh_required = "add_widget";
    return i;
  }
  showToast(options) {
    if (!this.toastWidget) {
      const screenWidth = this.runtime.screen[0];
      const toastWidth = Math.max(170, Math.round(screenWidth / 2));
      this.toastWidget = this.createWidget(this.widget.BUTTON, {
        x: Math.round((screenWidth - toastWidth) / 2),
        y: 70,
        w: toastWidth,
        h: 50,
        text: "",
        visible: false,
        text_size: 22,
        radius: 25,
        press_color: 2236962,
        normal_color: 2236962,
        click_func: () => this.toastWidget.setProperty(this.prop.VISIBLE, false)
      });
    }
    this.toastWidget.setProperty("visible", true);
    this.toastWidget.setProperty(this.prop.MORE, {
      text: options.text
    });
    setTimeout(() => {
      this.toastWidget.setProperty("visible", false);
    }, 3e3);
  }
  setLayerScrolling(val) {
  }
  setStatusBarVisible() {
  }
  updateStatusBarTitle() {
  }
  setScrollView() {
  }
  getTextLayout(text2, options) {
    const canvas = TextWidget.drawText({
      text: text2,
      text_size: options.text_size,
      w: options.text_width,
      text_style: 2,
      _metricsOnly: true
    }, this.runtime);
    return {
      width: canvas.width,
      height: canvas.height
    };
  }
};

// src/zepp_player/zepp_env/Timer.js
var TimerMock = class {
  constructor(runtime) {
    this.runtime = runtime;
    this.timers = [];
    runtime.onDestroy.push(() => {
      for (let a in this.timers)
        try {
          this.stopTimer(a);
        } catch (e) {
        }
    });
  }
  createTimer(delay, period, callable, option) {
    const runtime = this.runtime;
    const id = this.timers.length;
    this.timers[id] = {
      interval: -1,
      timeout: -1,
      func: callable
    };
    (async () => {
      if (!!runtime.initTime) {
        await this.wait(delay, id);
      }
      if (!period) {
        callable.apply(this, option);
        return;
      }
      this.timers[id].interval = setInterval(() => {
        if (runtime.uiPause)
          return;
        callable.apply(this, option);
      }, Math.max(period, 25));
    })();
    return id;
  }
  wait(delay, id) {
    return new Promise((resolve5) => {
      if (delay === 0)
        return resolve5();
      this.timers[id].timeout = setTimeout(() => resolve5(), delay);
    });
  }
  stopTimer(timerID) {
    if (!this.timers[timerID])
      return;
    if (this.timers[timerID].timeout > -1)
      clearTimeout(this.timers[timerID].timeout);
    if (this.timers[timerID].interval > -1)
      clearInterval(this.timers[timerID].interval);
    this.timers[timerID] = null;
  }
};

// src/zepp_player/zepp_env/HuamiBLE.js
var HuamiBLEMock = class {
  constructor(runtime) {
    this.runtime = runtime;
  }
  createConnect() {
  }
  disConnect() {
  }
  send() {
  }
  connectStatus() {
    return !this.runtime.getDeviceState("DISCONNECT", "boolean");
  }
  addListener() {
  }
  removeListener() {
  }
};

// src/zepp_player/zepp_env/HmApp.js
var HmApp = class {
  constructor(runtime) {
    __publicField(this, "gesture", {
      UP: "up",
      LEFT: "left",
      RIGHT: "right",
      DOWN: "down"
    });
    this.runtime = runtime;
    this.timers = [];
    runtime.onDestroy.push(() => {
      for (const a of this.timers)
        try {
          clearTimeout(a);
        } catch (e) {
        }
    });
  }
  alarmNew(options) {
    let delta = options.delay ? options.delay : options.date - Date.now() / 1e3;
    delta = Math.floor(delta);
    if (delta <= 0)
      return -1;
    this.timers.push(setTimeout(() => {
      this.runtime.requestPageSwitch(options);
    }, delta * 1e3));
  }
  alarmCancel() {
  }
  startApp(options) {
    const appId = this.runtime.player.appConfig.app.appId;
    if (options.appid === appId)
      return this.gotoPage(options);
    this.runtime.onConsole("device", ["startApp", options]);
  }
  gotoPage(conf) {
    console.log("gotoPage", conf);
    if (!conf.url)
      return;
    this.runtime.requestPageSwitch(conf);
  }
  reloadPage(conf) {
    return this.gotoPage(conf);
  }
  setLayerX() {
  }
  setLayerY(y) {
    this.runtime.renderScroll = -y;
  }
  exit() {
  }
  gotoHome() {
    this.runtime.onConsole("ZeppPlayer", [
      "gotoHome requested"
    ]);
  }
  goBack() {
    this.runtime.back();
  }
  setScreenKeep() {
  }
  packageInfo() {
    const data = this.runtime.appConfig.app;
    return {
      type: data.appType,
      appId: data.appId,
      name: data.name,
      version: data.version.name,
      icon: data.icon,
      description: data.description,
      vendor: data.vendor,
      pages: []
    };
  }
  registerGestureEvent(callback) {
    this.runtime.appGestureHandler = callback;
  }
  unregisterGestureEvent() {
    this.runtime.appGestureHandler = () => false;
  }
  registerKeyEvent() {
  }
  unregisterKeyEvent() {
  }
  unregistKeyEvent() {
  }
  registerSpinEvent() {
  }
  unregistSpinEvent() {
  }
};

// src/zepp_player/SyystemEnvironment.js
function createAppEnv(player2) {
  const object = {};
  const core = new DeviceRuntimeCoreMock(player2);
  object.DeviceRuntimeCore = core;
  object.__$$module$$__ = {};
  object.__$$hmAppManager$$__ = {
    currentApp: {
      pid: 10,
      current: {},
      app: {
        __globals__: {}
      }
    }
  };
  return object;
}
function createPageEnv(runtime, appRuntime) {
  const object = {};
  const core = new DeviceRuntimeCoreMock(runtime);
  object.SLEEP_REFERENCE_ZERO = 24 * 60;
  object.DeviceRuntimeCore = core;
  object.hmUI = new HuamiUIMock(runtime);
  object.hmFS = new HuamiFsMock(runtime);
  object.hmApp = new HmApp(runtime);
  object.hmBle = new HuamiBLEMock(runtime);
  object.hmSensor = new HuamiSensorMock(runtime);
  object.hmSetting = new HuamiSettingMock(runtime);
  object.timer = new TimerMock(runtime);
  object.console = new ConsoleMock(runtime, console);
  object.__$$module$$__ = {};
  object.__$$hmAppManager$$__ = appRuntime.__$$hmAppManager$$__;
  object.Logger = object.DeviceRuntimeCore.HmLogger;
  object.WatchFace = (conf) => object.DeviceRuntimeCore.WatchFace(conf);
  const glob = appRuntime.__$$hmAppManager$$__.currentApp.app.__globals__;
  for (let i in glob) {
    object[i] = glob[i];
  }
  return object;
}

// src/zepp_player/ui/ScreenRootEventHandler.js
var DIRECTION_THR = 30;
var ScreenRootEventHandler = class {
  constructor(runtime) {
    this.runtime = runtime;
  }
  onwheel(delta) {
    const maxScroll = this.runtime.contentHeight - this.runtime.screen[1];
    if (maxScroll <= 0)
      return false;
    this.runtime.player.renderScroll = Math.min(maxScroll, this.runtime.player.renderScroll + delta);
    return true;
  }
  onmousedown(info) {
    this.startCoords = [info.x, info.y];
    this.direction = 0;
    this.inScroll = false;
    this.performGesture = "";
    this.startScroll = this.runtime.player.renderScroll;
    this.maxScroll = this.runtime.contentHeight - this.runtime.screen[1];
  }
  onmouseup() {
    if (this.performGesture) {
      let response = this.runtime.appGestureHandler(this.direction);
      if (!response && this.direction === "right")
        this.runtime.back();
    }
  }
  onmousemove(info) {
    const { x, y } = info;
    if (!this.direction) {
      if (x - this.startCoords[0] > DIRECTION_THR) {
        this.direction = "right";
      } else if (this.startCoords[0] - x > DIRECTION_THR) {
        this.direction = "left";
      } else if (y - this.startCoords[1] > DIRECTION_THR) {
        this.direction = "down";
        if (this.startScroll > 0)
          this.inScroll = true;
      } else if (this.startCoords[1] - y > DIRECTION_THR) {
        this.direction = "up";
        if (this.startScroll < this.maxScroll)
          this.inScroll = true;
      } else
        return;
    }
    const runtime = this.runtime;
    const player2 = this.runtime.player;
    if (this.inScroll) {
      player2.renderScroll = this.startScroll + (this.startCoords[1] - y);
    } else {
      let delta, target;
      switch (this.direction) {
        case "right":
          delta = x - this.startCoords[0];
          target = this.runtime.screen[0];
          break;
        case "left":
          delta = this.startCoords[0] - x;
          target = this.runtime.screen[0];
          break;
        case "up":
          delta = this.startCoords[1] - y;
          target = this.runtime.screen[1];
          break;
        case "down":
          delta = y - this.startCoords[1];
          target = this.runtime.screen[1];
          break;
      }
      this.performGesture = delta / target > 0.25;
    }
  }
};

// src/zepp_player/ZeppRuntime.js
var ZeppRuntime = class {
  constructor(player2, scriptPath, showLevel) {
    __publicField(this, "widgets", []);
    __publicField(this, "events", []);
    __publicField(this, "postRenderTasks", []);
    __publicField(this, "onDestroy", []);
    __publicField(this, "env", null);
    __publicField(this, "module", null);
    __publicField(this, "initTime", null);
    __publicField(this, "onInitParam", null);
    __publicField(this, "uiPause", false);
    __publicField(this, "refresh_required", false);
    __publicField(this, "animMaxFPS", false);
    this.player = player2;
    this.scriptPath = scriptPath;
    this.showLevel = showLevel;
    this.render_counter = 0;
    this.vfs = this.player.vfs;
    this.screen = this.player.screen;
    this.profileData = this.player.profileData;
    this.appConfig = this.player.appConfig;
    this.withScriptConsole = this.player.withScriptConsole;
  }
  get renderScroll() {
    return this.player.renderScroll;
  }
  set renderScroll(val) {
    this.player.renderScroll = val;
  }
  get language() {
    switch (this.fullLanguage) {
      case "zh-CN":
        return "sc";
      case "zh-TW":
        return "tc";
      default:
        return "en";
    }
  }
  get fullLanguage() {
    return this.getDeviceState("OS_LANGUAGE", "string");
  }
  async start() {
    if (this.initTime)
      this.destroy();
    console.debug("ZeppRuntime.start()", this.scriptPath.split("/").pop() + ":" + this.scriptPath);
    const extra = this.player.getEvalAdditionalData(this.scriptPath);
    const scriptFile = await this.player.loadFile(this.scriptPath);
    const text = new TextDecoder().decode(scriptFile);
    this.appGestureHandler = () => false;
    this.rootEventHandler = new ScreenRootEventHandler(this);
    const env = createPageEnv(this, this.player.appEnv);
    if (this.player.globalScopeFix.length > 0) {
      for (let i in this.player.globalScopeFix)
        env[this.player.globalScopeFix[i]] = 0;
      this.onConsole("SystemWarning", [
        "Fix global var defination, please do not declare variables  without var/let/const, this is legacy way. List:",
        this.player.globalScopeFix
      ]);
    }
    const script = `${extra}
(${Object.keys(env).toString()}) => {${text}}`;
    try {
      const fnc = eval(script);
      fnc(...Object.values(env));
    } catch (e) {
      this.onConsole("error", ["Script load failed", e]);
      throw e;
    }
    if (!env.__$$hmAppManager$$__.currentApp.current.module) {
      this.onConsole("SystemWarning", ["Page/Watchface don't exported."]);
      return;
    }
    this.env = env;
    this.module = env.__$$hmAppManager$$__.currentApp.current.module;
    this.render_counter = 0;
    try {
      if (this.module.onInit)
        this.module.onInit(this.onInitParam);
      if (this.module.build)
        this.module.build();
    } catch (e) {
      this.onConsole("error", ["Module start failed", e]);
      throw e;
    }
    this.callDelegates("resume_call");
    this.initTime = Date.now();
  }
  async render(canvas) {
    this.events = [];
    this.postRenderTasks = [];
    this.contentHeight = 0;
    this.refresh_required = false;
    this.render_counter = (this.render_counter + 1) % 3e3;
    const stages = {
      normal: [],
      postReverse: [],
      toplevel: []
    };
    for (let i in this.widgets) {
      const widget = this.widgets[i];
      if (!widget)
        continue;
      const stage = widget._renderStage ? widget._renderStage : "normal";
      if (stages[stage])
        stages[stage].push(widget);
    }
    stages.postReverse.reverse();
    for (let stage in stages) {
      for (let i in stages[stage]) {
        const widget = stages[stage][i];
        if (!widget)
          continue;
        await this.renderWidget(widget, canvas);
      }
    }
    const maxScroll = this.contentHeight - this.screen[1];
    if (this.renderScroll > maxScroll) {
      this.renderScroll = maxScroll;
    }
    for (const fnc2 of this.postRenderTasks) {
      try {
        await fnc2();
      } catch (e) {
        console.warn("Post-render task failed", fnc2, e);
      }
    }
  }
  setPause(val) {
    this.callDelegates(val ? "pause_call" : "resume_call");
    this.uiPause = val;
  }
  requestPageSwitch(conf) {
    return this.player.enterPage(conf.url, conf.param);
  }
  destroy() {
    if (this.module && this.module.onDestroy)
      this.module.onDestroy();
    for (let i in this.onDestroy) {
      this.onDestroy[i]();
    }
    this.onDestroy = [];
    this.widgets = [];
    this.events = [];
    this.module = null;
    this.env = null;
    this.initTime = null;
    this.contentHeight = 0;
    console.debug("ZeppRuntime.destroy()", this.scriptPath.split("/").pop() + ":" + this.scriptPath);
  }
  handleEvent(name, x, y, info) {
    y += this.player.renderScroll;
    if (this.rootEventHandler[name])
      this.rootEventHandler[name](info);
    for (let i = this.events.length - 1; i >= 0; i--) {
      const data = this.events[i];
      if (data.x1 < x && x < data.x2 && data.y1 < y && y < data.y2) {
        if (data.events[name])
          data.events[name](info);
        return;
      }
    }
  }
  dropEvents(events, x1, y1, x2, y2) {
    this.events.push({
      events,
      x1,
      y1,
      x2,
      y2
    });
    if (y2 > this.contentHeight)
      this.contentHeight = y2;
  }
  callDelegates(delegateName) {
    for (let i in this.widgets) {
      const w = this.widgets[i].config;
      if (w.__widget === "WIDGET_DELEGATE" && w[delegateName]) {
        w[delegateName]();
      }
    }
  }
  addPostRenderTask(fnc2) {
    this.postRenderTasks.push(fnc2);
  }
  async renderWidget(widget, canvas) {
    const ctx = canvas.getContext("2d");
    const show_level = widget.config.show_level;
    ctx.globalAlpha = widget.config.alpha !== void 0 ? widget.config.alpha / 255 : 1;
    if ((show_level & this.showLevel) === 0 && show_level)
      return;
    if (!widget.config.visible)
      return;
    try {
      await widget.render(canvas, this);
    } catch (e) {
      const [title, subtitle] = widget.playerWidgetIdentify();
      console.warn(`%c Widget %c${title} %c${subtitle} %crender failed`, "font-weight: bold", "color: initial; font-weight: bold", "color: #999; font-weight: bold", "font-weight: bold", "\n\n", "CONFIG: ", widget.config, "\n", "ERROR: ", e);
      throw new Error("widget_fail");
    }
    ctx.globalAlpha = 1;
  }
  getImageFormat(path) {
    path = this.player.getVfsAssetPath(path);
    if (!this.vfs[path])
      throw new Error("Undefined asset: " + path);
    const data = this.vfs[path];
    const uint = new Uint8Array(data);
    if (uint[0] === 137 && uint[1] === 80) {
      return "PNG";
    } else if (uint[2] === 9) {
      return "TGA-RLP";
    } else if (uint[2] === 1) {
      return "TGA-P";
    } else if (uint[2] === 2) {
      return "TGA-RGB";
    }
    return "N/A";
  }
  onConsole(tag, data) {
    this.player.onConsole(tag, data, {
      runtimeID: `SL:${this.showLevel}`
    });
  }
  async getAssetImage() {
    return await this.player.getAssetImage(...arguments);
  }
  addDeviceStateChangeEvent() {
    this.player.addDeviceStateChangeEvent(...arguments);
  }
  newCanvas() {
    return this.player.newCanvas(...arguments);
  }
  getDeviceState() {
    return this.player.getDeviceState(...arguments);
  }
  autoFixGlobalScopeError() {
    this.player.autoFixGlobalScopeError(...arguments);
  }
  back() {
    return this.player.back(...arguments);
  }
};

// src/zepp_player/TgaImage.js
var import_buffer = require("buffer");
var import_canvas = require("canvas");
var _ImageType = {
  noImage: 0,
  colorMapped: 1,
  RGB: 2,
  blackAndWhite: 3,
  runlengthColorMapped: 9,
  runlengthRGB: 10,
  compressedBlackAndWhite: 11,
  compressedColorMapped: 32,
  compressed4PassQTColorMapped: 33
};
var _headerLength = 18;
var TGAImage = class {
  constructor(data, config) {
    if (data instanceof import_buffer.Buffer) {
      this._buffer = data;
    } else if (typeof data === "string") {
      this._buffer = import_buffer.Buffer.from(data, "binary");
    } else if (data) {
      this._buffer = import_buffer.Buffer.from(data);
    } else {
      this._buffer = null;
    }
    this.config = config;
    this._idLength = 0;
    this._colorMapType = 0;
    this._imageType = 0;
    this._colorMapOrigin = 0;
    this._colorMapLength = 0;
    this._colorMapDepth = 0;
    this._imageWidth = 0;
    this._imageCropWidth = 0;
    this._imageHeight = 0;
    this._imageDepth = 0;
    this._leftToRight = true;
    this._topToBottom = false;
    this._hasAlpha = false;
    this._imageID = null;
    this._canvas = null;
    this._context = null;
    this._imageData = null;
    this._image = null;
    this._src = null;
    this.onload = null;
    this.onerror = null;
    this._resolveFunc = null;
    this._rejectFunc = null;
    this._didLoad = new Promise((resolve5, reject) => {
      this._resolveFunc = resolve5;
      this._rejectFunc = reject;
    });
    if (data) {
      this._parseData();
    }
  }
  static imageWithData(data) {
    return new TGAImage(data);
  }
  static imageWithURL(url) {
    const image = new TGAImage();
    image._loadURL(url);
    return image;
  }
  _loadURL(url) {
    this._src = url;
    this._requestBinaryFile(url).then((data) => {
      this._buffer = import_buffer.Buffer.from(data);
      this._parseData();
    }).catch((error) => {
      this._reject(error);
    });
  }
  _requestBinaryFile(url) {
    return new Promise((resolve5, reject) => {
      const request = new XMLHttpRequest();
      request.open("GET", url);
      request.responseType = "arraybuffer";
      request.onload = (ev) => {
        if (request.response) {
          resolve5(request.response);
        } else {
          reject(request);
        }
      };
      request.onerror = (ev) => {
        reject(ev);
      };
      request.send(null);
    });
  }
  _parseData() {
    this._readHeader();
    this._readImageID();
    this._initImage();
    const data = this._getImageData();
    switch (this._imageType) {
      case _ImageType.noImage: {
        break;
      }
      case _ImageType.colorMapped: {
        this._parseColorMapData(data);
        break;
      }
      case _ImageType.RGB: {
        this._parseRGBData(data);
        break;
      }
      case _ImageType.blackAndWhite: {
        this._parseBlackAndWhiteData(data);
        break;
      }
      case _ImageType.runlengthColorMapped: {
        this._parseColorMapData(data);
        break;
      }
      case _ImageType.runlengthRGB: {
        this._parseRGBData(data);
        break;
      }
      case _ImageType.compressedBlackAndWhite: {
        this._parseBlackAndWhiteData(data);
        break;
      }
      case _ImageType.compressedColorMapped: {
        console.error("parser for compressed TGA is not implemeneted");
        break;
      }
      case _ImageType.compressed4PassQTColorMapped: {
        console.error("parser for compressed TGA is not implemeneted");
        break;
      }
      default: {
        throw new Error("unknown imageType: " + this._imageType);
      }
    }
    this._setImage();
    this._deleteBuffer();
    this._resolve();
  }
  _readHeader() {
    this._idLength = this._buffer.readUIntLE(0, 1);
    this._colorMapType = this._buffer.readUIntLE(1, 1);
    this._imageType = this._buffer.readUIntLE(2, 1);
    this._colorMapOrigin = this._buffer.readUIntLE(3, 2);
    this._colorMapLength = this._buffer.readUIntLE(5, 2);
    this._colorMapDepth = this._buffer.readUIntLE(7, 1);
    this._imageXOrigin = this._buffer.readUIntLE(8, 2);
    this._imageYOrigin = this._buffer.readUIntLE(10, 2);
    this._imageWidth = this._buffer.readUIntLE(12, 2);
    this._imageHeight = this._buffer.readUIntLE(14, 2);
    this._imageDepth = this._buffer.readUIntLE(16, 1);
    const descriptor = this._buffer.readUIntLE(17, 1);
    this._alphaDepth = descriptor & 15;
    this._leftToRight = (descriptor & 16) === 0;
    this._topToBottom = (descriptor & 32) > 0;
    this._interleave = descriptor & 192;
  }
  _readImageID() {
    const sign = new Uint8Array([83, 79, 77, 72]);
    if (this._idLength > 0) {
      this._imageID = this._buffer.subarray(_headerLength, this._idLength);
      if (this._imageID.subarray(0, 5).compare(sign) === 1) {
        this._imageCropWidth = this._imageID.readUIntLE(4, 2);
      }
    }
  }
  _initImage() {
    if (this._imageType === _ImageType.noImage) {
      return;
    }
    if (this._imageWidth <= 0 || this._imageHeight <= 0) {
      return;
    }
    const { createCanvas: createCanvas3 } = require("canvas");
    this._canvas = createCanvas3(this._imageWidth, this._imageHeight);
    this._canvas.width = this._imageWidth;
    this._canvas.height = this._imageHeight;
    this._context = this._canvas.getContext("2d");
    this._imageData = this._context.createImageData(this._imageWidth, this._imageHeight);
  }
  _setImage() {
    this._context.putImageData(this._imageData, 0, 0);
    if (this._imageCropWidth !== 0 && this._imageWidth !== this._imageCropWidth) {
      const outCanvas = (0, import_canvas.createCanvas)(this._imageCropWidth, this._imageHeight);
      outCanvas.getContext("2d").drawImage(this._canvas, 0, 0);
      this._canvas = outCanvas;
    }
  }
  _deleteBuffer() {
    if (this._buffer) {
      delete this._buffer;
      this._buffer = null;
    }
    if (this._imageData) {
      delete this._imageData;
      this._imageData = null;
    }
  }
  _parseColorMapData(buf) {
    if (this._colorMapDepth === 24 || this._colorMapDepth === 16 || this._colorMapDepth === 15) {
      this._hasAlpha = false;
    } else if (this._colorMapDepth === 32) {
      this._hasAlpha = true;
    } else {
      throw new Error("unknown colorMapDepth: " + this._colorMapDepth);
    }
    const colorMapDataPos = _headerLength + this._idLength;
    const colorMapDataSize = Math.ceil(this._colorMapDepth / 8);
    const colorMapDataLen = colorMapDataSize * this._colorMapLength;
    const imageDataSize = 1;
    const colorMap = [];
    let pos = colorMapDataPos;
    for (let i = 0; i < this._colorMapLength; i++) {
      const rgba = this._getRGBA(this._buffer, pos, this._colorMapDepth);
      colorMap.push(rgba);
      pos += colorMapDataSize;
    }
    const data = this._imageData.data;
    let initX = 0;
    let initY = 0;
    let xStep = 1;
    let yStep = 1;
    if (!this._leftToRight) {
      initX = this._imageWidth - 1;
      xStep = -1;
    }
    if (!this._topToBottom) {
      initY = this._imageHeight - 1;
      yStep = -1;
    }
    pos = 0;
    let y = initY;
    const defaultColor = [255, 255, 255, 255];
    for (let iy = 0; iy < this._imageHeight; iy++) {
      let x = initX;
      for (let ix = 0; ix < this._imageWidth; ix++) {
        const index = (y * this._imageWidth + x) * 4;
        let color = defaultColor;
        const mapNo = buf[pos] - this._colorMapOrigin;
        if (mapNo >= 0) {
          color = colorMap[mapNo];
        }
        data[index + 1] = color[1];
        data[index + 3] = color[3];
        if (this.config.swapRedAndBlueTGA) {
          data[index] = color[2];
          data[index + 2] = color[0];
        } else {
          data[index] = color[0];
          data[index + 2] = color[2];
        }
        x += xStep;
        pos += imageDataSize;
      }
      y += yStep;
    }
  }
  _parseRGBData(buf) {
    if (this._imageDepth === 24 || this._imageDepth === 16 || this._imageDepth === 15) {
      this._hasAlpha = false;
    } else if (this._imageDepth === 32) {
      this._hasAlpha = true;
    } else {
      throw new Error("unknown imageDepth: " + this._imageDepth);
    }
    const imageDataSize = Math.ceil(this._imageDepth / 8);
    const data = this._imageData.data;
    let initX = 0;
    let initY = 0;
    let xStep = 1;
    let yStep = 1;
    if (!this._leftToRight) {
      initX = this._imageWidth - 1;
      xStep = -1;
    }
    if (!this._topToBottom) {
      initY = this._imageHeight - 1;
      yStep = -1;
    }
    let pos = 0;
    let y = initY;
    for (let iy = 0; iy < this._imageHeight; iy++) {
      let x = initX;
      for (let ix = 0; ix < this._imageWidth; ix++) {
        const index = (y * this._imageWidth + x) * 4;
        const rgba = this._getRGBA(buf, pos, this._imageDepth);
        data[index] = rgba[0];
        data[index + 1] = rgba[1];
        data[index + 2] = rgba[2];
        data[index + 3] = rgba[3];
        x += xStep;
        pos += imageDataSize;
      }
      y += yStep;
    }
  }
  _getRGBA(buf, offset, depth) {
    if (depth === 15) {
      const r = (buf[offset + 1] & 124) << 1;
      const g = (buf[offset + 1] & 3) << 6 | (buf[offset] & 224) >> 2;
      const b = (buf[offset] & 31) << 3;
      const a = 255;
      return [r, g, b, a];
    } else if (depth === 16) {
      const pixel = (buf[offset + 1] << 8) + buf[offset];
      const r = Math.floor(255 / 31 * ((pixel & 63488) >> 11));
      const g = Math.floor(255 / 63 * ((pixel & 2016) >> 5));
      const b = Math.floor(255 / 31 * (pixel & 31));
      const a = 255;
      return [r, g, b, a];
    } else if (depth === 24) {
      return [buf[offset + 2], buf[offset + 1], buf[offset], 255];
    } else if (depth === 32) {
      return [buf[offset + 2], buf[offset + 1], buf[offset], buf[offset + 3]];
    }
    throw new Error("unsupported imageDepth: " + depth);
  }
  _parseBlackAndWhiteData(buf) {
    if (this._imageDepth == 8) {
      this._hasAlpha = false;
    } else if (this._imageDepth == 16) {
      this._hasAlpha = true;
    } else {
      throw new Error("unknown imageDepth: " + this._imageDepth);
    }
    const imageDataSize = this._imageDepth / 8;
    const data = this._imageData.data;
    let initX = 0;
    let initY = 0;
    let xStep = 1;
    let yStep = 1;
    if (!this._leftToRight) {
      initX = this._imageWidth - 1;
      xStep = -1;
    }
    if (!this._topToBottom) {
      initY = this._imageHeight - 1;
      yStep = -1;
    }
    let pos = 0;
    if (this._hasAlpha) {
      let y = initY;
      for (let iy = 0; iy < this._imageHeight; iy++) {
        let x = initX;
        for (let ix = 0; ix < this._imageWidth; ix++) {
          const index = (y * this._imageWidth + x) * 4;
          const c = buf[pos];
          const a = buf[pos + 1];
          data[index] = c;
          data[index + 1] = c;
          data[index + 2] = c;
          data[index + 3] = a;
          x += xStep;
          pos += imageDataSize;
        }
        y += yStep;
      }
    } else {
      let y = initY;
      for (let iy = 0; iy < this._imageHeight; iy++) {
        let x = initX;
        for (let ix = 0; ix < this._imageWidth; ix++) {
          const index = (y * this._imageWidth + x) * 4;
          const c = buf[pos];
          const a = 255;
          data[index] = c;
          data[index + 1] = c;
          data[index + 2] = c;
          data[index + 3] = a;
          x += xStep;
          pos += imageDataSize;
        }
        y += yStep;
      }
    }
  }
  _getImageData() {
    let data = null;
    if (this._imageType !== _ImageType.none) {
      const colorMapDataLen = Math.ceil(this._colorMapDepth / 8) * this._colorMapLength;
      const start = _headerLength + this._idLength + colorMapDataLen;
      data = this._buffer.subarray(start);
    }
    if (this._imageType === _ImageType.runlengthColorMapped || this._imageType === _ImageType.runlengthRGB) {
      data = this._decompressRunlengthData(data);
    } else if (this._imageType === _ImageType.compressedBlackAndWhite) {
      data = this._decompressRunlengthData(data);
    } else if (this._imageType === _ImageType.compressedColorMapped) {
      console.error("Compressed Color Mapped TGA Image data is not supported");
    } else if (this._imageType === _ImageType.compressed4PassQTColorMapped) {
      console.error("Compressed Color Mapped TGA Image data is not supported");
    }
    return data;
  }
  _decompressRunlengthData(data) {
    const d = [];
    const elementCount = Math.ceil(this._imageDepth / 8);
    const dataLength = elementCount * this._imageWidth * this._imageHeight;
    let pos = 0;
    while (d.length < dataLength) {
      const packet = data[pos];
      pos += 1;
      if ((packet & 128) !== 0) {
        const elements = data.slice(pos, pos + elementCount);
        pos += elementCount;
        const count = (packet & 127) + 1;
        for (let i = 0; i < count; i++) {
          d.push(...elements);
        }
      } else {
        const len = (packet + 1) * elementCount;
        d.push(...data.slice(pos, pos + len));
        pos += len;
      }
    }
    return d;
  }
  get canvas() {
    return this._canvas;
  }
  get didLoad() {
    return this._didLoad;
  }
  _resolve(e) {
    if (this.onload) {
      this.onload(e);
    }
    this._resolveFunc(e);
  }
  _reject(e) {
    if (this.onerror) {
      this.onerror(e);
    }
    this._rejectFunc(e);
  }
  get src() {
    return this._src;
  }
  set src(newValue) {
    this._loadURL(newValue);
  }
};

// src/zepp_player/DeviceProfiles.js
var DeviceProfiles = {
  sb7: {
    hasOverlay: true,
    screenWidth: 192,
    screenHeight: 490,
    deviceName: "Xiaomi Smart Band 7"
  },
  ab7: {
    hasOverlay: true,
    screenWidth: 194,
    screenHeight: 368,
    deviceName: "Amazfit Band 7"
  },
  gtr3: {
    hasOverlay: true,
    screenWidth: 454,
    screenHeight: 454,
    swapRedAndBlueTGA: true,
    deviceName: "GTR 3"
  },
  gtr3pro: {
    hasOverlay: true,
    screenWidth: 480,
    screenHeight: 480,
    swapRedAndBlueTGA: true
  },
  gtr4: {
    hasOverlay: true,
    screenWidth: 466,
    screenHeight: 466,
    swapRedAndBlueTGA: true
  },
  gts4mini: {
    hasOverlay: true,
    screenWidth: 336,
    screenHeight: 384,
    deviceName: "GTS 4 mini"
  },
  gts4: {
    hasOverlay: true,
    screenWidth: 390,
    screenHeight: 450,
    swapRedAndBlueTGA: true,
    deviceName: "GTS 4"
  }
};

// src/zepp_player/ZeppPlayer.js
var ZeppPlayer = class extends ZeppPlayerConfig {
  constructor() {
    super();
    this._lastCanvas = null;
    this.profileName = "sb7";
    this.projectPath = "";
    this.appEnv = null;
    this.render_counter = 0;
    this.currentRuntime = null;
    this.wfBaseRuntime = null;
    this.wfSubRuntime = null;
    this.backStack = [];
    this.globalScopeFix = [];
    this._deviceState = createDeviceState();
    this._deviceStateChangeEvents = {};
  }
  onConsole() {
  }
  onRestart() {
  }
  get profileData() {
    return DeviceProfiles[this.profileName];
  }
  get screen() {
    return [this.profileData.screenWidth, this.profileData.screenHeight];
  }
  get appType() {
    return this.appConfig.app.appType;
  }
  async getAssetImage(path) {
    path = this.getVfsAssetPath(path);
    if (this.imgCache[path])
      return this.imgCache[path];
    if (!this.vfs[path])
      throw new Error("Undefined asset: " + path);
    const data = this.vfs[path];
    const uint = new Uint8Array(data);
    let img;
    if (uint[0] === 137 && uint[1] === 80) {
      img = await this._loadPNG(data);
    } else {
      const tga = new TGAImage(data, this.profileData);
      await tga.didLoad;
      img = tga.canvas;
    }
    this.imgCache[path] = img;
    return img;
  }
  wipeSettings() {
    this._deviceState = createDeviceState();
    PersistentStorage.wipe();
  }
  autoFixGlobalScopeError(e) {
    if (e.message.endsWith("is not defined")) {
      const name = e.message.split(" ")[0];
      if (this.globalScopeFix.indexOf(name) < 0) {
        console.log("%cAuto-fix global define of " + name, "color: #8cf");
        this.globalScopeFix.push(name);
        return true;
      }
    }
    return false;
  }
  getVfsAppPath() {
    const pkg2 = this.appConfig.app;
    const idn = pkg2.appId.toString(16).padStart(8, "0").toUpperCase();
    return "/storage/js_" + pkg2.appType + "s/" + idn;
  }
  getVfsAssetPath(path) {
    return this.getVfsAppPath() + "/assets/" + path;
  }
  getStateEntry(type) {
    if (!this._deviceState[type])
      return null;
    return this._deviceState[type];
  }
  getDeviceState(type, dataType = "null") {
    const v = this._deviceState[type];
    switch (dataType) {
      case "progress":
        return Math.min(1, v.getProgress(v));
      case "pointer_progress":
        return v.getProgress(v);
      case "string":
        return v.getString(v);
      case "maxLength":
        return v.maxLength;
      case "boolean":
        return v.getBoolean(v);
      default:
        return v.value;
    }
  }
  addDeviceStateChangeEvent(type, callback) {
    if (!this._deviceStateChangeEvents[type])
      this._deviceStateChangeEvents[type] = [];
    this._deviceStateChangeEvents[type].push(callback);
  }
  setDeviceState(type, value, requireRefresh = true) {
    this._deviceState[type].value = value;
    if (this._deviceStateChangeEvents[type]) {
      for (let i in this._deviceStateChangeEvents[type]) {
        this._deviceStateChangeEvents[type][i]();
      }
    }
    if (this.currentRuntime && requireRefresh)
      this.currentRuntime.refresh_required = "set_state";
  }
  setDeviceStateMany(data) {
    for (const type in data) {
      this.setDeviceState(type, data[type], false);
    }
    if (this.currentRuntime)
      this.currentRuntime.refresh_required = "set_state";
  }
  async setProject(path) {
    this.projectPath = path;
    this.overlayTool = new Overlay(this);
    this.vfs = {};
    this.imgCache = {};
    this.renderScroll = 0;
    await this._loadAppConfig();
    await this._loadAppJs();
    await this.overlayTool.init();
    await this.preloadProjectAssets(path + "/");
  }
  async restart() {
    await this.finish();
    await this.setProject(this.projectPath);
    await this.init();
  }
  async _loadAppJs() {
    const appJsFile = await this.loadFile(this.projectPath + "/app.js");
    const appJsText = new TextDecoder().decode(appJsFile);
    const appEnv = createAppEnv(this);
    try {
      const str = `(${Object.keys(appEnv).toString()}) => {${appJsText};}`;
      const appJs = eval(str);
      appJs(...Object.values(appEnv));
    } catch (e) {
      console.warn("app.js exec failed", e);
    }
    this.appEnv = appEnv;
  }
  async _loadAppConfig() {
    const jsonFile = await this.loadFile(this.projectPath + "/app.json");
    const jsonText = new TextDecoder().decode(jsonFile);
    this.appConfig = JSON.parse(jsonText);
  }
  getInitModuleName() {
    const appConfig = this.appConfig;
    if (appConfig.targets) {
      const ident = Object.keys(appConfig.targets)[0];
      appConfig.module = appConfig.targets[ident].module;
    }
    if (appConfig.app.appType === "watchface") {
      let modulePath = "watchface/index";
      if (appConfig.module && appConfig.module.watchface)
        modulePath = appConfig.module.watchface.path;
      return modulePath;
    } else if (appConfig.app.appType === "app") {
      return appConfig.module.page.pages[0];
    } else
      throw new Error("Unsupported appType");
  }
  async readDirectoryRecursive(path, arr = null) {
    if (!arr)
      arr = [];
    const dirContent = await this.listDirectory(path);
    for (let i in dirContent) {
      const filePath = path + dirContent[i].name;
      if (dirContent[i].type === "file") {
        arr.push(filePath);
      } else {
        await this.readDirectoryRecursive(filePath, arr);
      }
    }
    return arr;
  }
  async preloadProjectAssets(path) {
    const urls = await this.readDirectoryRecursive(path);
    const contents = await Promise.all(urls.map(this.loadFile));
    const vfsRoot = this.getVfsAppPath();
    for (let i = 0; i < urls.length; i++) {
      const vfsPath = urls[i].replace(this.projectPath, vfsRoot);
      this.vfs[vfsPath] = contents[i];
    }
  }
  _finishCurrentRuntime() {
    this.currentRuntime.callDelegates("pause_call");
    this.currentRuntime.uiPause = true;
    this.currentRuntime.destroy();
  }
  _attachRuntime(runtime) {
    const SL_DESCRIPTOR = {
      1: "(normal)",
      2: "(aod)",
      4: "(settings)"
    };
    this._lastCanvas = null;
    this.currentRuntime = runtime;
    runtime.refresh_required = "attach";
    this.onConsole("ZeppPlayer", [
      "Switch to",
      runtime.scriptPath.split("/").pop(),
      SL_DESCRIPTOR[runtime.showLevel]
    ]);
  }
  getModulePath(modulePath) {
    return this.projectPath + "/" + modulePath + ".js";
  }
  async enterPage(url, param) {
    this._finishCurrentRuntime();
    this.backStack.push([
      this.currentRuntime.scriptPath,
      this.currentRuntime.onInitParam
    ]);
    this.renderScroll = 0;
    const runtime = new ZeppRuntime(this, this.getModulePath(url), 1);
    runtime.onInitParam = param;
    await runtime.start();
    this._attachRuntime(runtime);
  }
  async back() {
    if (this.backStack.length < 1) {
      this.onConsole("device", ["back(): backStack is empty"]);
      return;
    }
    this._finishCurrentRuntime();
    const [script2, param] = this.backStack.pop();
    const runtime = new ZeppRuntime(this, script2, 1);
    runtime.onInitParam = param;
    await runtime.start();
    this._attachRuntime(runtime);
  }
  async finish() {
    for (const runtime of [this.wfBaseRuntime, this.wfSubRuntime, this.currentRuntime]) {
      if (runtime)
        await runtime.destroy();
    }
    this.wfBaseRuntime = null;
    this.wfSubRuntime = null;
    this.currentRuntime = null;
    this.render_counter = 0;
    this._deviceStateChangeEvents = {};
    this.onDestroy = [];
    this.backStack = [];
  }
  getEvalAdditionalData() {
    return "";
  }
  async init() {
    await this.finish();
    await this.onRestart();
    const path = this.getModulePath(this.getInitModuleName());
    const runtime = new ZeppRuntime(this, path, 1);
    this.wfBaseRuntime = runtime;
    try {
      await runtime.start();
    } catch (e) {
      if (this.autoFixGlobalScopeError(e)) {
        this.onConsole("ZeppPlayer", ["Auto-fix applied, restarting..."]);
        return await this.init();
      }
      console.error(e);
      this.onConsole("ZeppPlayer", ["Init failed"]);
    }
    this._attachRuntime(runtime);
    if (this._currentRenderLevel !== 1) {
      const val = this._currentRenderLevel;
      this._currentRenderLevel = 1;
      await this.setRenderLevel(val);
    }
  }
  async setRenderLevel(val) {
    if (this.appType !== "watchface")
      return;
    if (val === this.current_level)
      return;
    const currentVal = this._currentRenderLevel;
    if (this.wfSubRuntime) {
      this.wfSubRuntime.destroy();
      this.wfSubRuntime = null;
    }
    if (val !== 1) {
      const path = this.getModulePath(this.getInitModuleName());
      this.wfSubRuntime = new ZeppRuntime(this, path, val);
      await this.wfSubRuntime.start();
    }
    if (val === 1 && currentVal !== 4) {
      this.wfBaseRuntime.callDelegates("resume_call");
      this.wfBaseRuntime.uiPause = false;
    } else if (currentVal === 1) {
      this.wfBaseRuntime.callDelegates("pause_call");
      this.wfBaseRuntime.uiPause = true;
    }
    this._currentRenderLevel = val;
    this._attachRuntime(val === 1 ? this.wfBaseRuntime : this.wfSubRuntime);
    if (currentVal === 4)
      await this.init();
  }
  async render(force = false) {
    let runtime = this.currentRuntime;
    if (!runtime.refresh_required && this._lastCanvas && !force)
      return this._lastCanvas;
    let canvas = this.newCanvas();
    let ctx = canvas.getContext("2d");
    canvas.width = this.screen[0];
    canvas.height = this.screen[1] + this.renderScroll;
    if (this.withoutTransparency) {
      ctx.fillStyle = "#000000";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    await this.currentRuntime.render(canvas);
    if (this.showEventZones) {
      await this.overlayTool.drawEventZones(canvas, runtime.events);
    }
    if (this.withShift) {
      if (this.render_counter % 15 === 0)
        this.performShift(this.render_counter / 15);
      runtime.refresh_required = "shift";
    }
    if (this.renderScroll !== 0) {
      const newCanvas = this.newCanvas();
      newCanvas.width = canvas.width;
      newCanvas.height = this.screen[1];
      newCanvas.getContext("2d").drawImage(canvas, 0, -this.renderScroll);
      canvas = newCanvas;
    }
    if (this.render_overlay && this.profileData.hasOverlay) {
      await this.overlayTool.drawDeviceFrame(canvas);
    }
    this.render_counter = (this.render_counter + 1) % 3e3;
    this._lastCanvas = canvas;
    return canvas;
  }
  performShift(tick) {
    for (let i in this._deviceState) {
      if (this._deviceState[i].shift) {
        const v = this._deviceState[i].shift(tick, this._deviceState[i]);
        if (v !== null)
          this.setDeviceState(i, v);
      }
    }
  }
  async listDirectory(path) {
  }
  async loadFile() {
  }
  newCanvas() {
    throw new Error("not overriden");
  }
};

// src/zepp_player/NodeZeppPlayer.js
var import_tga = __toESM(require_src2());
var fs = __toESM(require("fs"));
var NodeZeppPlayer = class extends ZeppPlayer {
  constructor() {
    super();
    __publicField(this, "imgCache", {});
    global.localStorage = {};
    this.withScriptConsole = false;
  }
  async listDirectory(path) {
    const out = [];
    const content = fs.readdirSync(path);
    for (let i in content) {
      const stat = fs.statSync(path + "/" + content[i]);
      out.push({
        name: content[i] + (stat.isDirectory() ? "/" : ""),
        type: stat.isDirectory() ? "dir" : "file"
      });
    }
    return out;
  }
  async loadFile(path) {
    if (path.startsWith("/app"))
      path = __dirname + "/" + path.substring(4);
    return fs.readFileSync(path);
  }
  newCanvas() {
    return (0, import_canvas2.createCanvas)(20, 20);
  }
  async _loadPNG(data) {
    return (0, import_canvas2.loadImage)(data);
  }
};

// src/index.cli.js
var import_canvas3 = require("canvas");
var import_gif_encoder_2 = __toESM(require_gif_encoder_2());
var fs2 = __toESM(require("fs"));
var argv = yargs_default(hideBin(process.argv)).command("<projects...>", "Preview a list of projects").option("gif", {
  describe: "With GIF preview",
  boolean: true
}).option("png", {
  describe: "With PNG preview",
  default: true,
  boolean: true
}).option("o", {
  describe: "Output path, {} will be replaced with current project path",
  type: "string",
  default: "{}"
}).parse();
async function createGif(player2) {
  const FPS = 5;
  const SECONDS = 4;
  player2.render_counter = 0;
  const gif = new import_gif_encoder_2.default(player2.screen[0], player2.screen[1]);
  gif.setDelay(Math.round(1e3 / FPS));
  gif.start();
  for (let i = 0; i < FPS * SECONDS * 2; i++) {
    if (i === FPS * SECONDS)
      player2.setRenderLevel(2);
    const canvas = await player2.render();
    gif.addFrame(canvas.getContext("2d"));
    player2.performShift(i);
    player2.currentRuntime.callDelegates("resume_call");
  }
  gif.finish();
  return gif.out.getData();
}
async function main() {
  let success = 0, fail = 0;
  (0, import_canvas3.registerFont)(__dirname + "/allfont-Medium.ttf", { family: "allfont" });
  for (let a in argv._) {
    const project = argv._[a];
    try {
      let player2 = new NodeZeppPlayer();
      console.info("Processing " + project + "...");
      await player2.setProject(project);
      await player2.init();
      player2.currentRuntime.animMaxFPS = true;
      player2.withStagingDump = argv.stage;
      let output = argv.o.replace("{}", project);
      if (argv.png) {
        console.log("[ZeppPlayer] Rendering PNG...");
        const png = await player2.render();
        fs2.writeFileSync(output + "/preview.png", png.toBuffer());
        console.log("[ZeppPlayer] PNG saved to: " + output + "/preview.png");
      }
      if (argv.gif) {
        console.log("[ZeppPlayer] Rendering GIF...");
        const gif = await createGif(player2);
        fs2.writeFileSync(output + "/preview.gif", gif);
        console.log("[ZeppPlayer] GIF saved to: " + output + "/preview.gif");
      }
      await player2.finish();
      success++;
    } catch (e) {
      console.error(e);
      fail++;
    }
  }
  console.log("");
  console.info("Processed: " + success);
  if (fail > 0)
    console.warn("Failed: " + fail);
  process.exit();
}
main();
/**
 * @fileoverview Main entrypoint for libraries using yargs-parser in Node.js
 * CJS and ESM environments.
 *
 * @license
 * Copyright (c) 2016, Contributors
 * SPDX-License-Identifier: ISC
 */
/**
 * @license
 * Copyright (c) 2016, Contributors
 * SPDX-License-Identifier: ISC
 */
