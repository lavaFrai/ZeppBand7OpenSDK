(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };

  // node_modules/file-saver/dist/FileSaver.min.js
  var require_FileSaver_min = __commonJS({
    "node_modules/file-saver/dist/FileSaver.min.js"(exports, module) {
      (function(a3, b3) {
        if ("function" == typeof define && define.amd)
          define([], b3);
        else if ("undefined" != typeof exports)
          b3();
        else {
          b3(), a3.FileSaver = { exports: {} }.exports;
        }
      })(exports, function() {
        "use strict";
        function b3(a4, b4) {
          return "undefined" == typeof b4 ? b4 = { autoBom: false } : "object" != typeof b4 && (console.warn("Deprecated: Expected third argument to be a object"), b4 = { autoBom: !b4 }), b4.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(a4.type) ? new Blob(["\uFEFF", a4], { type: a4.type }) : a4;
        }
        function c3(a4, b4, c4) {
          var d4 = new XMLHttpRequest();
          d4.open("GET", a4), d4.responseType = "blob", d4.onload = function() {
            g4(d4.response, b4, c4);
          }, d4.onerror = function() {
            console.error("could not download file");
          }, d4.send();
        }
        function d3(a4) {
          var b4 = new XMLHttpRequest();
          b4.open("HEAD", a4, false);
          try {
            b4.send();
          } catch (a5) {
          }
          return 200 <= b4.status && 299 >= b4.status;
        }
        function e3(a4) {
          try {
            a4.dispatchEvent(new MouseEvent("click"));
          } catch (c4) {
            var b4 = document.createEvent("MouseEvents");
            b4.initMouseEvent("click", true, true, window, 0, 0, 0, 80, 20, false, false, false, false, 0, null), a4.dispatchEvent(b4);
          }
        }
        var f3 = "object" == typeof window && window.window === window ? window : "object" == typeof self && self.self === self ? self : "object" == typeof global && global.global === global ? global : void 0, a3 = f3.navigator && /Macintosh/.test(navigator.userAgent) && /AppleWebKit/.test(navigator.userAgent) && !/Safari/.test(navigator.userAgent), g4 = f3.saveAs || ("object" != typeof window || window !== f3 ? function() {
        } : "download" in HTMLAnchorElement.prototype && !a3 ? function(b4, g5, h3) {
          var i3 = f3.URL || f3.webkitURL, j4 = document.createElement("a");
          g5 = g5 || b4.name || "download", j4.download = g5, j4.rel = "noopener", "string" == typeof b4 ? (j4.href = b4, j4.origin === location.origin ? e3(j4) : d3(j4.href) ? c3(b4, g5, h3) : e3(j4, j4.target = "_blank")) : (j4.href = i3.createObjectURL(b4), setTimeout(function() {
            i3.revokeObjectURL(j4.href);
          }, 4e4), setTimeout(function() {
            e3(j4);
          }, 0));
        } : "msSaveOrOpenBlob" in navigator ? function(f4, g5, h3) {
          if (g5 = g5 || f4.name || "download", "string" != typeof f4)
            navigator.msSaveOrOpenBlob(b3(f4, h3), g5);
          else if (d3(f4))
            c3(f4, g5, h3);
          else {
            var i3 = document.createElement("a");
            i3.href = f4, i3.target = "_blank", setTimeout(function() {
              e3(i3);
            });
          }
        } : function(b4, d4, e4, g5) {
          if (g5 = g5 || open("", "_blank"), g5 && (g5.document.title = g5.document.body.innerText = "downloading..."), "string" == typeof b4)
            return c3(b4, d4, e4);
          var h3 = "application/octet-stream" === b4.type, i3 = /constructor/i.test(f3.HTMLElement) || f3.safari, j4 = /CriOS\/[\d]+/.test(navigator.userAgent);
          if ((j4 || h3 && i3 || a3) && "undefined" != typeof FileReader) {
            var k4 = new FileReader();
            k4.onloadend = function() {
              var a4 = k4.result;
              a4 = j4 ? a4 : a4.replace(/^data:[^;]*;/, "data:attachment/file;"), g5 ? g5.location.href = a4 : location = a4, g5 = null;
            }, k4.readAsDataURL(b4);
          } else {
            var l3 = f3.URL || f3.webkitURL, m3 = l3.createObjectURL(b4);
            g5 ? g5.location = m3 : location.href = m3, g5 = null, setTimeout(function() {
              l3.revokeObjectURL(m3);
            }, 4e4);
          }
        });
        f3.saveAs = g4.saveAs = g4, "undefined" != typeof module && (module.exports = g4);
      });
    }
  });

  // node_modules/path-normalize/lib/index.js
  var require_lib = __commonJS({
    "node_modules/path-normalize/lib/index.js"(exports, module) {
      "use strict";
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports["default"] = void 0;
      function _typeof(obj) {
        "@babel/helpers - typeof";
        return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
          return typeof obj2;
        } : function(obj2) {
          return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        }, _typeof(obj);
      }
      var SLASH = 47;
      var DOT = 46;
      var assertPath = function assertPath2(path) {
        var t3 = _typeof(path);
        if (t3 !== "string") {
          throw new TypeError("Expected a string, got a ".concat(t3));
        }
      };
      var posixNormalize = function posixNormalize2(path, allowAboveRoot) {
        var res = "";
        var lastSegmentLength = 0;
        var lastSlash = -1;
        var dots = 0;
        var code;
        for (var i3 = 0; i3 <= path.length; ++i3) {
          if (i3 < path.length) {
            code = path.charCodeAt(i3);
          } else if (code === SLASH) {
            break;
          } else {
            code = SLASH;
          }
          if (code === SLASH) {
            if (lastSlash === i3 - 1 || dots === 1) {
            } else if (lastSlash !== i3 - 1 && dots === 2) {
              if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== DOT || res.charCodeAt(res.length - 2) !== DOT) {
                if (res.length > 2) {
                  var lastSlashIndex = res.lastIndexOf("/");
                  if (lastSlashIndex !== res.length - 1) {
                    if (lastSlashIndex === -1) {
                      res = "";
                      lastSegmentLength = 0;
                    } else {
                      res = res.slice(0, lastSlashIndex);
                      lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
                    }
                    lastSlash = i3;
                    dots = 0;
                    continue;
                  }
                } else if (res.length === 2 || res.length === 1) {
                  res = "";
                  lastSegmentLength = 0;
                  lastSlash = i3;
                  dots = 0;
                  continue;
                }
              }
              if (allowAboveRoot) {
                if (res.length > 0) {
                  res += "/..";
                } else {
                  res = "..";
                }
                lastSegmentLength = 2;
              }
            } else {
              if (res.length > 0) {
                res += "/" + path.slice(lastSlash + 1, i3);
              } else {
                res = path.slice(lastSlash + 1, i3);
              }
              lastSegmentLength = i3 - lastSlash - 1;
            }
            lastSlash = i3;
            dots = 0;
          } else if (code === DOT && dots !== -1) {
            ++dots;
          } else {
            dots = -1;
          }
        }
        return res;
      };
      var decode = function decode2(s3) {
        try {
          return decodeURIComponent(s3);
        } catch (_unused) {
          return s3;
        }
      };
      var normalize2 = function normalize3(p3) {
        assertPath(p3);
        var path = p3;
        if (path.length === 0) {
          return ".";
        }
        var isAbsolute = path.charCodeAt(0) === SLASH;
        var trailingSeparator = path.charCodeAt(path.length - 1) === SLASH;
        path = decode(path);
        path = posixNormalize(path, !isAbsolute);
        if (path.length === 0 && !isAbsolute) {
          path = ".";
        }
        if (path.length > 0 && trailingSeparator) {
          path += "/";
        }
        if (isAbsolute) {
          return "/" + path;
        }
        return path;
      };
      var _default = normalize2;
      exports["default"] = _default;
      module.exports = exports.default;
    }
  });

  // node_modules/base64-js/index.js
  var require_base64_js = __commonJS({
    "node_modules/base64-js/index.js"(exports) {
      "use strict";
      exports.byteLength = byteLength;
      exports.toByteArray = toByteArray;
      exports.fromByteArray = fromByteArray;
      var lookup = [];
      var revLookup = [];
      var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
      var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for (i3 = 0, len = code.length; i3 < len; ++i3) {
        lookup[i3] = code[i3];
        revLookup[code.charCodeAt(i3)] = i3;
      }
      var i3;
      var len;
      revLookup["-".charCodeAt(0)] = 62;
      revLookup["_".charCodeAt(0)] = 63;
      function getLens(b64) {
        var len2 = b64.length;
        if (len2 % 4 > 0) {
          throw new Error("Invalid string. Length must be a multiple of 4");
        }
        var validLen = b64.indexOf("=");
        if (validLen === -1)
          validLen = len2;
        var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
        return [validLen, placeHoldersLen];
      }
      function byteLength(b64) {
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function _byteLength(b64, validLen, placeHoldersLen) {
        return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
      }
      function toByteArray(b64) {
        var tmp;
        var lens = getLens(b64);
        var validLen = lens[0];
        var placeHoldersLen = lens[1];
        var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
        var curByte = 0;
        var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
        var i4;
        for (i4 = 0; i4 < len2; i4 += 4) {
          tmp = revLookup[b64.charCodeAt(i4)] << 18 | revLookup[b64.charCodeAt(i4 + 1)] << 12 | revLookup[b64.charCodeAt(i4 + 2)] << 6 | revLookup[b64.charCodeAt(i4 + 3)];
          arr[curByte++] = tmp >> 16 & 255;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 2) {
          tmp = revLookup[b64.charCodeAt(i4)] << 2 | revLookup[b64.charCodeAt(i4 + 1)] >> 4;
          arr[curByte++] = tmp & 255;
        }
        if (placeHoldersLen === 1) {
          tmp = revLookup[b64.charCodeAt(i4)] << 10 | revLookup[b64.charCodeAt(i4 + 1)] << 4 | revLookup[b64.charCodeAt(i4 + 2)] >> 2;
          arr[curByte++] = tmp >> 8 & 255;
          arr[curByte++] = tmp & 255;
        }
        return arr;
      }
      function tripletToBase64(num) {
        return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
      }
      function encodeChunk(uint8, start3, end) {
        var tmp;
        var output = [];
        for (var i4 = start3; i4 < end; i4 += 3) {
          tmp = (uint8[i4] << 16 & 16711680) + (uint8[i4 + 1] << 8 & 65280) + (uint8[i4 + 2] & 255);
          output.push(tripletToBase64(tmp));
        }
        return output.join("");
      }
      function fromByteArray(uint8) {
        var tmp;
        var len2 = uint8.length;
        var extraBytes = len2 % 3;
        var parts = [];
        var maxChunkLength = 16383;
        for (var i4 = 0, len22 = len2 - extraBytes; i4 < len22; i4 += maxChunkLength) {
          parts.push(encodeChunk(uint8, i4, i4 + maxChunkLength > len22 ? len22 : i4 + maxChunkLength));
        }
        if (extraBytes === 1) {
          tmp = uint8[len2 - 1];
          parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "==");
        } else if (extraBytes === 2) {
          tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
          parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "=");
        }
        return parts.join("");
      }
    }
  });

  // node_modules/ieee754/index.js
  var require_ieee754 = __commonJS({
    "node_modules/ieee754/index.js"(exports) {
      exports.read = function(buffer, offset, isLE, mLen, nBytes) {
        var e3, m3;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var nBits = -7;
        var i3 = isLE ? nBytes - 1 : 0;
        var d3 = isLE ? -1 : 1;
        var s3 = buffer[offset + i3];
        i3 += d3;
        e3 = s3 & (1 << -nBits) - 1;
        s3 >>= -nBits;
        nBits += eLen;
        for (; nBits > 0; e3 = e3 * 256 + buffer[offset + i3], i3 += d3, nBits -= 8) {
        }
        m3 = e3 & (1 << -nBits) - 1;
        e3 >>= -nBits;
        nBits += mLen;
        for (; nBits > 0; m3 = m3 * 256 + buffer[offset + i3], i3 += d3, nBits -= 8) {
        }
        if (e3 === 0) {
          e3 = 1 - eBias;
        } else if (e3 === eMax) {
          return m3 ? NaN : (s3 ? -1 : 1) * Infinity;
        } else {
          m3 = m3 + Math.pow(2, mLen);
          e3 = e3 - eBias;
        }
        return (s3 ? -1 : 1) * m3 * Math.pow(2, e3 - mLen);
      };
      exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
        var e3, m3, c3;
        var eLen = nBytes * 8 - mLen - 1;
        var eMax = (1 << eLen) - 1;
        var eBias = eMax >> 1;
        var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
        var i3 = isLE ? 0 : nBytes - 1;
        var d3 = isLE ? 1 : -1;
        var s3 = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
        value = Math.abs(value);
        if (isNaN(value) || value === Infinity) {
          m3 = isNaN(value) ? 1 : 0;
          e3 = eMax;
        } else {
          e3 = Math.floor(Math.log(value) / Math.LN2);
          if (value * (c3 = Math.pow(2, -e3)) < 1) {
            e3--;
            c3 *= 2;
          }
          if (e3 + eBias >= 1) {
            value += rt / c3;
          } else {
            value += rt * Math.pow(2, 1 - eBias);
          }
          if (value * c3 >= 2) {
            e3++;
            c3 /= 2;
          }
          if (e3 + eBias >= eMax) {
            m3 = 0;
            e3 = eMax;
          } else if (e3 + eBias >= 1) {
            m3 = (value * c3 - 1) * Math.pow(2, mLen);
            e3 = e3 + eBias;
          } else {
            m3 = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e3 = 0;
          }
        }
        for (; mLen >= 8; buffer[offset + i3] = m3 & 255, i3 += d3, m3 /= 256, mLen -= 8) {
        }
        e3 = e3 << mLen | m3;
        eLen += mLen;
        for (; eLen > 0; buffer[offset + i3] = e3 & 255, i3 += d3, e3 /= 256, eLen -= 8) {
        }
        buffer[offset + i3 - d3] |= s3 * 128;
      };
    }
  });

  // node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "node_modules/buffer/index.js"(exports) {
      "use strict";
      var base64 = require_base64_js();
      var ieee754 = require_ieee754();
      var customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer3;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      var K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer3.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer3.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e3) {
          return false;
        }
      }
      Object.defineProperty(Buffer3.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this))
            return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer3.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer3.isBuffer(this))
            return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function Buffer3(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError('The "string" argument must be of type string. Received type number');
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer3.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError('The "value" argument must not be of type number. Received type number');
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer3.from(valueOf, encodingOrOffset, length);
        }
        const b3 = fromObject(value);
        if (b3)
          return b3;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer3.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
      }
      Buffer3.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer3.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer3, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer3.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer3.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer3.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer3.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i3 = 0; i3 < length; i3 += 1) {
          buf[i3] = array[i3] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer3.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer3.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer3.alloc(+length);
      }
      Buffer3.isBuffer = function isBuffer(b3) {
        return b3 != null && b3._isBuffer === true && b3 !== Buffer3.prototype;
      };
      Buffer3.compare = function compare(a3, b3) {
        if (isInstance(a3, Uint8Array))
          a3 = Buffer3.from(a3, a3.offset, a3.byteLength);
        if (isInstance(b3, Uint8Array))
          b3 = Buffer3.from(b3, b3.offset, b3.byteLength);
        if (!Buffer3.isBuffer(a3) || !Buffer3.isBuffer(b3)) {
          throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
        }
        if (a3 === b3)
          return 0;
        let x4 = a3.length;
        let y3 = b3.length;
        for (let i3 = 0, len = Math.min(x4, y3); i3 < len; ++i3) {
          if (a3[i3] !== b3[i3]) {
            x4 = a3[i3];
            y3 = b3[i3];
            break;
          }
        }
        if (x4 < y3)
          return -1;
        if (y3 < x4)
          return 1;
        return 0;
      };
      Buffer3.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer3.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer3.alloc(0);
        }
        let i3;
        if (length === void 0) {
          length = 0;
          for (i3 = 0; i3 < list.length; ++i3) {
            length += list[i3].length;
          }
        }
        const buffer = Buffer3.allocUnsafe(length);
        let pos = 0;
        for (i3 = 0; i3 < list.length; ++i3) {
          let buf = list[i3];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer.length) {
              if (!Buffer3.isBuffer(buf))
                buf = Buffer3.from(buf);
              buf.copy(buffer, pos);
            } else {
              Uint8Array.prototype.set.call(buffer, buf, pos);
            }
          } else if (!Buffer3.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer, pos);
          }
          pos += buf.length;
        }
        return buffer;
      };
      function byteLength(string, encoding) {
        if (Buffer3.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string);
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0)
          return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.byteLength = byteLength;
      function slowToString(encoding, start3, end) {
        let loweredCase = false;
        if (start3 === void 0 || start3 < 0) {
          start3 = 0;
        }
        if (start3 > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start3 >>>= 0;
        if (end <= start3) {
          return "";
        }
        if (!encoding)
          encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start3, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start3, end);
            case "ascii":
              return asciiSlice(this, start3, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start3, end);
            case "base64":
              return base64Slice(this, start3, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start3, end);
            default:
              if (loweredCase)
                throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer3.prototype._isBuffer = true;
      function swap(b3, n2, m3) {
        const i3 = b3[n2];
        b3[n2] = b3[m3];
        b3[m3] = i3;
      }
      Buffer3.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i3 = 0; i3 < len; i3 += 2) {
          swap(this, i3, i3 + 1);
        }
        return this;
      };
      Buffer3.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i3 = 0; i3 < len; i3 += 4) {
          swap(this, i3, i3 + 3);
          swap(this, i3 + 1, i3 + 2);
        }
        return this;
      };
      Buffer3.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i3 = 0; i3 < len; i3 += 8) {
          swap(this, i3, i3 + 7);
          swap(this, i3 + 1, i3 + 6);
          swap(this, i3 + 2, i3 + 5);
          swap(this, i3 + 3, i3 + 4);
        }
        return this;
      };
      Buffer3.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0)
          return "";
        if (arguments.length === 0)
          return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer3.prototype.toLocaleString = Buffer3.prototype.toString;
      Buffer3.prototype.equals = function equals(b3) {
        if (!Buffer3.isBuffer(b3))
          throw new TypeError("Argument must be a Buffer");
        if (this === b3)
          return true;
        return Buffer3.compare(this, b3) === 0;
      };
      Buffer3.prototype.inspect = function inspect() {
        let str2 = "";
        const max = exports.INSPECT_MAX_BYTES;
        str2 = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max)
          str2 += " ... ";
        return "<Buffer " + str2 + ">";
      };
      if (customInspectSymbol) {
        Buffer3.prototype[customInspectSymbol] = Buffer3.prototype.inspect;
      }
      Buffer3.prototype.compare = function compare(target, start3, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer3.from(target, target.offset, target.byteLength);
        }
        if (!Buffer3.isBuffer(target)) {
          throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target);
        }
        if (start3 === void 0) {
          start3 = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start3 < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start3 >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start3 >= end) {
          return 1;
        }
        start3 >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target)
          return 0;
        let x4 = thisEnd - thisStart;
        let y3 = end - start3;
        const len = Math.min(x4, y3);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start3, end);
        for (let i3 = 0; i3 < len; ++i3) {
          if (thisCopy[i3] !== targetCopy[i3]) {
            x4 = thisCopy[i3];
            y3 = targetCopy[i3];
            break;
          }
        }
        if (x4 < y3)
          return -1;
        if (y3 < x4)
          return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
        if (buffer.length === 0)
          return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer.length - 1;
        }
        if (byteOffset < 0)
          byteOffset = buffer.length + byteOffset;
        if (byteOffset >= buffer.length) {
          if (dir)
            return -1;
          else
            byteOffset = buffer.length - 1;
        } else if (byteOffset < 0) {
          if (dir)
            byteOffset = 0;
          else
            return -1;
        }
        if (typeof val === "string") {
          val = Buffer3.from(val, encoding);
        }
        if (Buffer3.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i4) {
          if (indexSize === 1) {
            return buf[i4];
          } else {
            return buf.readUInt16BE(i4 * indexSize);
          }
        }
        let i3;
        if (dir) {
          let foundIndex = -1;
          for (i3 = byteOffset; i3 < arrLength; i3++) {
            if (read(arr, i3) === read(val, foundIndex === -1 ? 0 : i3 - foundIndex)) {
              if (foundIndex === -1)
                foundIndex = i3;
              if (i3 - foundIndex + 1 === valLength)
                return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1)
                i3 -= i3 - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength)
            byteOffset = arrLength - valLength;
          for (i3 = byteOffset; i3 >= 0; i3--) {
            let found = true;
            for (let j4 = 0; j4 < valLength; j4++) {
              if (read(arr, i3 + j4) !== read(val, j4)) {
                found = false;
                break;
              }
            }
            if (found)
              return i3;
          }
        }
        return -1;
      }
      Buffer3.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer3.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer3.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i3;
        for (i3 = 0; i3 < length; ++i3) {
          const parsed = parseInt(string.substr(i3 * 2, 2), 16);
          if (numberIsNaN(parsed))
            return i3;
          buf[offset + i3] = parsed;
        }
        return i3;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer3.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0)
              encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining)
          length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding)
          encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase)
                throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer3.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start3, end) {
        if (start3 === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start3, end));
        }
      }
      function utf8Slice(buf, start3, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i3 = start3;
        while (i3 < end) {
          const firstByte = buf[i3];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i3 + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i3 + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i3 + 1];
                thirdByte = buf[i3 + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i3 + 1];
                thirdByte = buf[i3 + 2];
                fourthByte = buf[i3 + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i3 += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      var MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i3 = 0;
        while (i3 < len) {
          res += String.fromCharCode.apply(String, codePoints.slice(i3, i3 += MAX_ARGUMENTS_LENGTH));
        }
        return res;
      }
      function asciiSlice(buf, start3, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i3 = start3; i3 < end; ++i3) {
          ret += String.fromCharCode(buf[i3] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start3, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i3 = start3; i3 < end; ++i3) {
          ret += String.fromCharCode(buf[i3]);
        }
        return ret;
      }
      function hexSlice(buf, start3, end) {
        const len = buf.length;
        if (!start3 || start3 < 0)
          start3 = 0;
        if (!end || end < 0 || end > len)
          end = len;
        let out = "";
        for (let i3 = start3; i3 < end; ++i3) {
          out += hexSliceLookupTable[buf[i3]];
        }
        return out;
      }
      function utf16leSlice(buf, start3, end) {
        const bytes = buf.slice(start3, end);
        let res = "";
        for (let i3 = 0; i3 < bytes.length - 1; i3 += 2) {
          res += String.fromCharCode(bytes[i3] + bytes[i3 + 1] * 256);
        }
        return res;
      }
      Buffer3.prototype.slice = function slice(start3, end) {
        const len = this.length;
        start3 = ~~start3;
        end = end === void 0 ? len : ~~end;
        if (start3 < 0) {
          start3 += len;
          if (start3 < 0)
            start3 = 0;
        } else if (start3 > len) {
          start3 = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0)
            end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start3)
          end = start3;
        const newBuf = this.subarray(start3, end);
        Object.setPrototypeOf(newBuf, Buffer3.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0)
          throw new RangeError("offset is not uint");
        if (offset + ext > length)
          throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer3.prototype.readUintLE = Buffer3.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert)
          checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i3 = 0;
        while (++i3 < byteLength2 && (mul *= 256)) {
          val += this[offset + i3] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUintBE = Buffer3.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer3.prototype.readUint8 = Buffer3.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer3.prototype.readUint16LE = Buffer3.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer3.prototype.readUint16BE = Buffer3.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer3.prototype.readUint32LE = Buffer3.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer3.prototype.readUint32BE = Buffer3.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer3.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer3.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer3.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert)
          checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i3 = 0;
        while (++i3 < byteLength2 && (mul *= 256)) {
          val += this[offset + i3] * mul;
        }
        mul *= 128;
        if (val >= mul)
          val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert)
          checkOffset(offset, byteLength2, this.length);
        let i3 = byteLength2;
        let mul = 1;
        let val = this[offset + --i3];
        while (i3 > 0 && (mul *= 256)) {
          val += this[offset + --i3] * mul;
        }
        mul *= 128;
        if (val >= mul)
          val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer3.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128))
          return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer3.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer3.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer3.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer3.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer3.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
      });
      Buffer3.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, true, 23, 4);
      };
      Buffer3.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 4, this.length);
        return ieee754.read(this, offset, false, 23, 4);
      };
      Buffer3.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, true, 52, 8);
      };
      Buffer3.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert)
          checkOffset(offset, 8, this.length);
        return ieee754.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer3.isBuffer(buf))
          throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min)
          throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length)
          throw new RangeError("Index out of range");
      }
      Buffer3.prototype.writeUintLE = Buffer3.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i3 = 0;
        this[offset] = value & 255;
        while (++i3 < byteLength2 && (mul *= 256)) {
          this[offset + i3] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUintBE = Buffer3.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i3 = byteLength2 - 1;
        let mul = 1;
        this[offset + i3] = value & 255;
        while (--i3 >= 0 && (mul *= 256)) {
          this[offset + i3] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeUint8 = Buffer3.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeUint16LE = Buffer3.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeUint16BE = Buffer3.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeUint32LE = Buffer3.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeUint32BE = Buffer3.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer3.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer3.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i3 = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i3 < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i3 - 1] !== 0) {
            sub = 1;
          }
          this[offset + i3] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i3 = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i3] = value & 255;
        while (--i3 >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i3 + 1] !== 0) {
            sub = 1;
          }
          this[offset + i3] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer3.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 1, 127, -128);
        if (value < 0)
          value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer3.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer3.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer3.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer3.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert)
          checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0)
          value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer3.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer3.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length)
          throw new RangeError("Index out of range");
        if (offset < 0)
          throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4, 34028234663852886e22, -34028234663852886e22);
        }
        ieee754.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer3.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8, 17976931348623157e292, -17976931348623157e292);
        }
        ieee754.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer3.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer3.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer3.prototype.copy = function copy(target, targetStart, start3, end) {
        if (!Buffer3.isBuffer(target))
          throw new TypeError("argument should be a Buffer");
        if (!start3)
          start3 = 0;
        if (!end && end !== 0)
          end = this.length;
        if (targetStart >= target.length)
          targetStart = target.length;
        if (!targetStart)
          targetStart = 0;
        if (end > 0 && end < start3)
          end = start3;
        if (end === start3)
          return 0;
        if (target.length === 0 || this.length === 0)
          return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start3 < 0 || start3 >= this.length)
          throw new RangeError("Index out of range");
        if (end < 0)
          throw new RangeError("sourceEnd out of bounds");
        if (end > this.length)
          end = this.length;
        if (target.length - targetStart < end - start3) {
          end = target.length - targetStart + start3;
        }
        const len = end - start3;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start3, end);
        } else {
          Uint8Array.prototype.set.call(target, this.subarray(start3, end), targetStart);
        }
        return len;
      };
      Buffer3.prototype.fill = function fill(val, start3, end, encoding) {
        if (typeof val === "string") {
          if (typeof start3 === "string") {
            encoding = start3;
            start3 = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer3.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start3 < 0 || this.length < start3 || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start3) {
          return this;
        }
        start3 = start3 >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val)
          val = 0;
        let i3;
        if (typeof val === "number") {
          for (i3 = start3; i3 < end; ++i3) {
            this[i3] = val;
          }
        } else {
          const bytes = Buffer3.isBuffer(val) ? val : Buffer3.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i3 = 0; i3 < end - start3; ++i3) {
            this[i3 + start3] = bytes[i3 % len];
          }
        }
        return this;
      };
      var errors = {};
      function E3(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E3("ERR_BUFFER_OUT_OF_BOUNDS", function(name) {
        if (name) {
          return `${name} is outside of buffer bounds`;
        }
        return "Attempt to access memory outside buffer bounds";
      }, RangeError);
      E3("ERR_INVALID_ARG_TYPE", function(name, actual) {
        return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
      }, TypeError);
      E3("ERR_OUT_OF_RANGE", function(str2, range, input) {
        let msg = `The value of "${str2}" is out of range.`;
        let received = input;
        if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
          received = addNumericalSeparator(String(input));
        } else if (typeof input === "bigint") {
          received = String(input);
          if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
            received = addNumericalSeparator(received);
          }
          received += "n";
        }
        msg += ` It must be ${range}. Received ${received}`;
        return msg;
      }, RangeError);
      function addNumericalSeparator(val) {
        let res = "";
        let i3 = val.length;
        const start3 = val[0] === "-" ? 1 : 0;
        for (; i3 >= start3 + 4; i3 -= 3) {
          res = `_${val.slice(i3 - 3, i3)}${res}`;
        }
        return `${val.slice(0, i3)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n2 = typeof min === "bigint" ? "n" : "";
          let range;
          if (byteLength2 > 3) {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n2} and < 2${n2} ** ${(byteLength2 + 1) * 8}${n2}`;
            } else {
              range = `>= -(2${n2} ** ${(byteLength2 + 1) * 8 - 1}${n2}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n2}`;
            }
          } else {
            range = `>= ${min}${n2} and <= ${max}${n2}`;
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(type || "offset", `>= ${type ? 1 : 0} and <= ${length}`, value);
      }
      var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str2) {
        str2 = str2.split("=")[0];
        str2 = str2.trim().replace(INVALID_BASE64_RE, "");
        if (str2.length < 2)
          return "";
        while (str2.length % 4 !== 0) {
          str2 = str2 + "=";
        }
        return str2;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i3 = 0; i3 < length; ++i3) {
          codePoint = string.charCodeAt(i3);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1)
                  bytes.push(239, 191, 189);
                continue;
              } else if (i3 + 1 === length) {
                if ((units -= 3) > -1)
                  bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1)
                bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1)
              bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0)
              break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0)
              break;
            bytes.push(codePoint >> 6 | 192, codePoint & 63 | 128);
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0)
              break;
            bytes.push(codePoint >> 12 | 224, codePoint >> 6 & 63 | 128, codePoint & 63 | 128);
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0)
              break;
            bytes.push(codePoint >> 18 | 240, codePoint >> 12 & 63 | 128, codePoint >> 6 & 63 | 128, codePoint & 63 | 128);
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str2) {
        const byteArray = [];
        for (let i3 = 0; i3 < str2.length; ++i3) {
          byteArray.push(str2.charCodeAt(i3) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str2, units) {
        let c3, hi, lo;
        const byteArray = [];
        for (let i3 = 0; i3 < str2.length; ++i3) {
          if ((units -= 2) < 0)
            break;
          c3 = str2.charCodeAt(i3);
          hi = c3 >> 8;
          lo = c3 % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str2) {
        return base64.toByteArray(base64clean(str2));
      }
      function blitBuffer(src, dst, offset, length) {
        let i3;
        for (i3 = 0; i3 < length; ++i3) {
          if (i3 + offset >= dst.length || i3 >= src.length)
            break;
          dst[i3 + offset] = src[i3];
        }
        return i3;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      var hexSliceLookupTable = function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i3 = 0; i3 < 16; ++i3) {
          const i16 = i3 * 16;
          for (let j4 = 0; j4 < 16; ++j4) {
            table[i16 + j4] = alphabet[i3] + alphabet[j4];
          }
        }
        return table;
      }();
      function defineBigIntMethod(fn2) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn2;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    }
  });

  // node_modules/canvas/lib/parse-font.js
  var require_parse_font = __commonJS({
    "node_modules/canvas/lib/parse-font.js"(exports, module) {
      "use strict";
      var weights = "bold|bolder|lighter|[1-9]00";
      var styles = "italic|oblique";
      var variants = "small-caps";
      var stretches = "ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded";
      var units = "px|pt|pc|in|cm|mm|%|em|ex|ch|rem|q";
      var string = `'([^']+)'|"([^"]+)"|[\\w\\s-]+`;
      var weightRe = new RegExp(`(${weights}) +`, "i");
      var styleRe = new RegExp(`(${styles}) +`, "i");
      var variantRe = new RegExp(`(${variants}) +`, "i");
      var stretchRe = new RegExp(`(${stretches}) +`, "i");
      var sizeFamilyRe = new RegExp(`([\\d\\.]+)(${units}) *((?:${string})( *, *(?:${string}))*)`);
      var cache = {};
      var defaultHeight = 16;
      module.exports = (str2) => {
        if (cache[str2])
          return cache[str2];
        const sizeFamily = sizeFamilyRe.exec(str2);
        if (!sizeFamily)
          return;
        const font = {
          weight: "normal",
          style: "normal",
          stretch: "normal",
          variant: "normal",
          size: parseFloat(sizeFamily[1]),
          unit: sizeFamily[2],
          family: sizeFamily[3].replace(/["']/g, "").replace(/ *, */g, ",")
        };
        let weight, style, variant, stretch;
        const substr = str2.substring(0, sizeFamily.index);
        if (weight = weightRe.exec(substr))
          font.weight = weight[1];
        if (style = styleRe.exec(substr))
          font.style = style[1];
        if (variant = variantRe.exec(substr))
          font.variant = variant[1];
        if (stretch = stretchRe.exec(substr))
          font.stretch = stretch[1];
        switch (font.unit) {
          case "pt":
            font.size /= 0.75;
            break;
          case "pc":
            font.size *= 16;
            break;
          case "in":
            font.size *= 96;
            break;
          case "cm":
            font.size *= 96 / 2.54;
            break;
          case "mm":
            font.size *= 96 / 25.4;
            break;
          case "%":
            break;
          case "em":
          case "rem":
            font.size *= defaultHeight / 0.75;
            break;
          case "q":
            font.size *= 96 / 25.4 / 4;
            break;
        }
        return cache[str2] = font;
      };
    }
  });

  // node_modules/canvas/browser.js
  var require_browser = __commonJS({
    "node_modules/canvas/browser.js"(exports) {
      var parseFont = require_parse_font();
      exports.parseFont = parseFont;
      exports.createCanvas = function(width, height) {
        return Object.assign(document.createElement("canvas"), { width, height });
      };
      exports.createImageData = function(array, width, height) {
        switch (arguments.length) {
          case 0:
            return new ImageData();
          case 1:
            return new ImageData(array);
          case 2:
            return new ImageData(array, width);
          default:
            return new ImageData(array, width, height);
        }
      };
      exports.loadImage = function(src, options) {
        return new Promise(function(resolve, reject) {
          const image = Object.assign(document.createElement("img"), options);
          function cleanup() {
            image.onload = null;
            image.onerror = null;
          }
          image.onload = function() {
            cleanup();
            resolve(image);
          };
          image.onerror = function() {
            cleanup();
            reject(new Error('Failed to load the image "' + src + '"'));
          };
          image.src = src;
        });
      };
    }
  });

  // src/ui_managment/ConsoleManager.js
  var ConsoleManager = class {
    constructor(player2) {
      __publicField(this, "view", document.getElementById("view_console"));
      __publicField(this, "colors", {
        ZeppPlayer: "#ff7043",
        device: "#96ffa0",
        SystemWarning: "#ff9900",
        runtime: "#4cf",
        error: "#f22",
        warn: "#ff6600"
      });
      this.player = player2;
      player2.onRestart = () => this.wipe();
      player2.onConsole = (level, data, extra2) => {
        this.writeBrowserConsole(level, data, extra2);
        this.write(level, data, extra2);
      };
    }
    static init(player2) {
      new ConsoleManager(player2);
    }
    wipe() {
      this.view.innerHTML = "";
    }
    writeBrowserConsole(level, data, extra2) {
      const color = this.colors[level] ? this.colors[level] : "initial";
      const id = extra2 && extra2.runtimeID ? extra2.runtimeID : "";
      const args = [`%c[${level}] %c${id}`, `color: ${color}`, `color: #999`];
      if (["log", "error", "warn", "info"].indexOf(level) > -1) {
        console[level](...args, ...data);
      } else {
        console.log(...args, ...data);
      }
    }
    write(level, data, extra2) {
      const div = document.createElement("div");
      const lv = document.createElement("span");
      lv.style.color = this.colors[level] ? this.colors[level] : "#999";
      lv.innerText = level;
      div.appendChild(lv);
      if (extra2 && extra2.runtimeID) {
        let arg = document.createElement("span");
        arg.style.opacity = "0.5";
        arg.innerText = extra2.runtimeID;
        div.appendChild(arg);
      }
      for (let i3 in data) {
        let arg = document.createElement("span");
        if (data[i3] instanceof Error) {
          arg.innerText = data[i3].stack;
        } else if (data[i3] instanceof Object) {
          arg.innerText = JSON.stringify(data[i3]);
        } else {
          arg.innerText = data[i3].toString();
        }
        div.appendChild(arg);
      }
      this.view.appendChild(div);
      this.view.scrollTop = this.view.scrollHeight;
    }
  };

  // src/ui_managment/ExplorerManager.js
  var _ExplorerManager = class {
    static init(player2) {
      _ExplorerManager.player = player2;
      _ExplorerManager.reloadWidgets.onclick = _ExplorerManager.doReloadWidgets;
      _ExplorerManager.reloadTimers.onclick = _ExplorerManager.doReloadTimers;
    }
    static doReloadWidgets() {
      _ExplorerManager.view.innerHTML = "";
      _ExplorerManager.addWidgetsArray(_ExplorerManager.player.currentRuntime.widgets, _ExplorerManager.view);
    }
    static doReloadTimers() {
      const timers = _ExplorerManager.player.currentRuntime.env.timer.timers;
      _ExplorerManager.view.innerHTML = "";
      for (let i3 in timers) {
        if (timers[i3] === null)
          continue;
        const data = timers[i3];
        const widgetView = document.createElement("details");
        const header = document.createElement("summary");
        let preview = data.func.name;
        if (!preview)
          preview = data.func.toString().substring(0, 48) + "...";
        header.innerHTML = "Timer ID" + i3.toString();
        header.innerHTML += " <aside>" + preview + "</aside>";
        widgetView.appendChild(header);
        const row1 = document.createElement("div");
        row1.className = "prop_row";
        row1.innerHTML = `<strong>Delay</strong><span>${data.delay}</span>`;
        widgetView.append(row1);
        const row2 = document.createElement("div");
        row2.className = "prop_row";
        row2.innerHTML = `<strong>Period</strong><span>${data.period}</span>`;
        widgetView.append(row2);
        _ExplorerManager.view.appendChild(widgetView);
      }
    }
    static addWidgetsArray(widgets, root) {
      for (let i3 in widgets) {
        _ExplorerManager.addWidget(widgets[i3], root);
      }
    }
    static addWidget(widget, root) {
      const widgetView = document.createElement("details");
      const header = document.createElement("summary");
      widgetView.appendChild(header);
      const [title, subtitle, subtitleClass] = widget.playerWidgetIdentify();
      header.innerHTML = title + " <aside class='" + subtitleClass + "'>" + subtitle + "</aside>";
      if (widget.config.visible === false || widget.config.visible === 0)
        widgetView.style.opacity = "0.5";
      for (let prop in widget.config) {
        if (prop.startsWith("_"))
          continue;
        const row = document.createElement("div");
        row.className = "prop_row";
        row.innerHTML = `<strong>${prop}</strong><span>${widget.config[prop]}</span>`;
        row.onclick = _ExplorerManager.makePropEditFunc(widget, prop);
        widgetView.appendChild(row);
      }
      if (widget.config.__content)
        _ExplorerManager.addWidgetsArray(widget.config.__content, widgetView);
      widgetView.appendChild(document.createElement("br"));
      root.appendChild(widgetView);
    }
    static makePropEditFunc(widget, prop) {
      return () => {
        const current = widget.config[prop];
        const input = prompt("Change prop", JSON.stringify(current));
        if (input === null || input === current)
          return;
        const data = {};
        data[prop] = JSON.parse(input);
        widget.setProperty("more", data);
        _ExplorerManager.doReloadWidgets();
      };
    }
  };
  var ExplorerManager = _ExplorerManager;
  __publicField(ExplorerManager, "reloadWidgets", document.getElementById("explorer_reload_widgets"));
  __publicField(ExplorerManager, "reloadTimers", document.getElementById("explorer_reload_timers"));
  __publicField(ExplorerManager, "view", document.getElementById("explorer_data"));
  __publicField(ExplorerManager, "player", null);

  // src/ui_managment/AppSettingsManager.js
  var AppSettingsManager = class {
    static getString(key, fallback) {
      if (localStorage[`zp_${key}`] === void 0)
        return fallback;
      return localStorage[`zp_${key}`];
    }
    static setString(key, value) {
      localStorage[`zp_${key}`] = value;
    }
    static getObject(key, fallback) {
      if (localStorage[`zp_${key}`] === void 0)
        return fallback;
      return JSON.parse(localStorage[`zp_${key}`]);
    }
    static setObject(key, value) {
      localStorage[`zp_${key}`] = JSON.stringify(value);
    }
  };

  // src/ui_managment/ChangesWatcher.js
  var _ChangesWatcher = class {
    static async init(player2) {
      if (!AppSettingsManager.getObject("cfgAutoRefresh", true))
        return;
      await _ChangesWatcher.onProjectChange(player2);
      setInterval(async () => {
        if (await _ChangesWatcher.isChanged()) {
          await player2.restart();
        }
      }, 2500);
    }
    static async onProjectChange(player2) {
      if (!AppSettingsManager.getObject("cfgAutoRefresh", true))
        return;
      const projectName = player2.projectPath.substring(10);
      await fetch("/api/watch/" + projectName);
      await _ChangesWatcher.isChanged();
      console.log("Now watching for changes in", projectName);
    }
    static async isChanged() {
      const resp = await fetch("/api/change_count");
      const value = await resp.text();
      const result = value !== _ChangesWatcher.lastChangesCount;
      _ChangesWatcher.lastChangesCount = value;
      if (result) {
        console.info("Detect changes in proj", value);
      }
      return result;
    }
  };
  var ChangesWatcher = _ChangesWatcher;
  __publicField(ChangesWatcher, "lastChangesCount", "");

  // src/ui_managment/ProjectPicker.ts
  var _ProjectPicker = class {
    static getProject() {
      return _ProjectPicker.view.value;
    }
    static async setup(player2) {
      const preferBuildDir = AppSettingsManager.getObject("preferBuildDir", true);
      const response = await fetch(`/api/list_projects?preferBuildDir=${preferBuildDir}`);
      const projects = await response.json();
      _ProjectPicker.projects = projects;
      _ProjectPicker.player = player2;
      for (const row of projects) {
        const opt3 = document.createElement("option");
        opt3.value = row.url;
        opt3.innerText = row.title;
        _ProjectPicker.view.appendChild(opt3);
      }
      const opt = document.createElement("option");
      opt.value = "<open_folder>";
      opt.innerText = "<file manager...>";
      _ProjectPicker.view.appendChild(opt);
      const opt2 = document.createElement("option");
      opt2.value = "<change_folder>";
      opt2.innerText = "<change directory...>";
      _ProjectPicker.view.appendChild(opt2);
      if (localStorage.zepp_player_last_project) {
        _ProjectPicker.view.value = localStorage.zepp_player_last_project;
      }
      _ProjectPicker.view.onchange = async () => {
        if (_ProjectPicker.view.value === "<open_folder>") {
          await fetch("/api/open_projects");
          _ProjectPicker.view.value = localStorage.zepp_player_last_project;
          return;
        } else if (this.view.value === "<change_folder>") {
          window._setReactPane("change_projects_dir");
          _ProjectPicker.view.value = localStorage.zepp_player_last_project;
          return;
        }
        await _ProjectPicker.applyProjectUrl(_ProjectPicker.view.value);
      };
    }
    static async applyProjectUrl(url) {
      localStorage.zepp_player_last_project = url;
      _ProjectPicker.view.value = url;
      await _ProjectPicker.player.finish();
      await _ProjectPicker.player.setProject(_ProjectPicker.getProject());
      await _ProjectPicker.player.init();
      await ChangesWatcher.onProjectChange(this.player);
    }
  };
  var ProjectPicker = _ProjectPicker;
  ProjectPicker.projects = [];
  ProjectPicker.view = document.getElementById("project_select");

  // src/zepp_player/PersistentStorage.js
  var PersistentStorage = class {
    static get(group, key) {
      let data = PersistentStorage._getStorage();
      if (!data[group])
        return null;
      return data[group][key];
    }
    static set(group, key, value) {
      let data = PersistentStorage._getStorage();
      if (!data[group])
        data[group] = {};
      data[group][key] = value;
      localStorage._zeppPlayer_storage = JSON.stringify(data);
    }
    static wipe() {
      localStorage._zeppPlayer_storage = "{}";
    }
    static del(group, key) {
      PersistentStorage.set(group, key, null);
    }
    static keys(group) {
      return Object.keys(PersistentStorage._getStorage()[group]);
    }
    static _getStorage() {
      try {
        return JSON.parse(localStorage._zeppPlayer_storage);
      } catch (e3) {
        return {};
      }
    }
  };

  // src/ui_managment/GifRecorder.js
  var import_file_saver = __toESM(require_FileSaver_min());
  var GifRecorder = class {
    constructor(player2) {
      __publicField(this, "loading", document.getElementById("loading"));
      this.player = player2;
    }
    async record() {
      const FPS = 5;
      const SECONDS = 4;
      this.loading.style.display = "";
      this.player.withShift = false;
      this.player.showEventZones = false;
      this.player.wipeSettings();
      await this.player.setRenderLevel(1);
      await this.player.init();
      this.player.currentRuntime.animMaxFPS = true;
      this.player.currentRuntime.uiPause = true;
      const gif = new GIF({
        width: this.player.screen[0],
        height: this.player.screen[1],
        workerScript: "/app/lib/gif.worker.js"
      });
      for (let i3 = 0; i3 < FPS * SECONDS * 2; i3++) {
        if (i3 === FPS * SECONDS)
          await this.player.setRenderLevel(2);
        const canvas = await this.player.render();
        gif.addFrame(canvas, { delay: Math.round(1e3 / FPS) });
        this.player.performShift(i3);
        this.player.currentRuntime.callDelegates("resume_call");
      }
      const blob = await this._renderGif(gif);
      this.loading.style.display = "none";
      this.blob = blob;
      await this.player.setRenderLevel(1);
      this.player.currentRuntime.animMaxFPS = false;
      this.player.currentRuntime.uiPause = false;
      ToolbarManager._refresh();
    }
    _renderGif(gif) {
      return new Promise((resolve, reject) => {
        gif.on("finished", function(blob) {
          resolve(blob);
        });
        gif.render();
      });
    }
    export() {
      const projectSelect = document.getElementById("project_select");
      const project = projectSelect.value;
      (0, import_file_saver.saveAs)(this.blob, project + ".gif");
    }
  };

  // src/zepp_player/DeviceProfiles.js
  var DeviceProfiles = {
    sb7: {
      hasOverlay: true,
      screenWidth: 192,
      screenHeight: 490,
      deviceName: "Xiaomi Smart Band 7"
    },
    ab7: {
      hasOverlay: true,
      screenWidth: 194,
      screenHeight: 368,
      deviceName: "Amazfit Band 7"
    },
    gtr3: {
      hasOverlay: true,
      screenWidth: 454,
      screenHeight: 454,
      swapRedAndBlueTGA: true,
      deviceName: "GTR 3"
    },
    gtr3pro: {
      hasOverlay: true,
      screenWidth: 480,
      screenHeight: 480,
      swapRedAndBlueTGA: true
    },
    gtr4: {
      hasOverlay: true,
      screenWidth: 466,
      screenHeight: 466,
      swapRedAndBlueTGA: true
    },
    gts4mini: {
      hasOverlay: true,
      screenWidth: 336,
      screenHeight: 384,
      deviceName: "GTS 4 mini"
    },
    gts4: {
      hasOverlay: true,
      screenWidth: 390,
      screenHeight: 450,
      swapRedAndBlueTGA: true,
      deviceName: "GTS 4"
    }
  };

  // src/ui_managment/ToolbarManager.js
  var _ToolbarManager = class {
    static bindSwitchBtn(config) {
      const { blockId, configId, fallback, handler } = config;
      const block = document.getElementById(blockId);
      const handleValue = (val) => {
        if (block.tagName === "INPUT") {
          block.checked = val;
        }
        val ? block.classList.add("active") : block.classList.remove("active");
      };
      const performChange = () => {
        const val = !AppSettingsManager.getObject(configId, fallback);
        AppSettingsManager.setObject(configId, val);
        handleValue(val);
        handler(val, false);
      };
      const current = AppSettingsManager.getObject(configId, fallback);
      handleValue(current);
      handler(current, true);
      block.onclick = performChange;
      return performChange;
    }
    static init(player2) {
      _ToolbarManager.player = player2;
      _ToolbarManager.actionToggleEditor = _ToolbarManager.bindSwitchBtn({
        blockId: "toggle_edit",
        configId: "panelEditorVisible",
        fallback: false,
        handler: (v3) => {
          document.getElementById("view_edit").style.display = v3 ? "" : "none";
        }
      });
      _ToolbarManager.actionToggleConsole = _ToolbarManager.bindSwitchBtn({
        blockId: "toggle_console",
        configId: "panelConsoleVisible",
        fallback: true,
        handler: (v3) => {
          document.getElementById("view_console").style.display = v3 ? "" : "none";
        }
      });
      _ToolbarManager.actionToggleExplorer = _ToolbarManager.bindSwitchBtn({
        blockId: "toggle_explorer",
        configId: "panelExplorerVisible",
        fallback: true,
        handler: (v3) => {
          document.getElementById("view_explorer").style.display = v3 ? "" : "none";
        }
      });
      _ToolbarManager.actionToggleOverlay = _ToolbarManager.bindSwitchBtn({
        blockId: "toggle_overlay",
        configId: "overlayVisible",
        fallback: true,
        handler: (v3) => {
          _ToolbarManager.player.render_overlay = v3;
          if (_ToolbarManager.player.currentRuntime)
            _ToolbarManager.player.currentRuntime.refresh_required = "ui";
        }
      });
      if (localStorage.zepp_player_rotation !== void 0) {
        _ToolbarManager.player.rotation = parseInt(localStorage.zepp_player_rotation);
      }
      _ToolbarManager._refresh();
      _ToolbarManager.toggleMode1.onclick = () => _ToolbarManager.doToggleMode(1);
      _ToolbarManager.toggleMode2.onclick = () => _ToolbarManager.doToggleMode(2);
      _ToolbarManager.toggleMode4.onclick = () => _ToolbarManager.doToggleMode(4);
      _ToolbarManager.toggleEventZones.onclick = _ToolbarManager.doToggleEventZones;
      _ToolbarManager.togglePause.onclick = _ToolbarManager.doTogglePause;
      _ToolbarManager.toggleShift.onclick = _ToolbarManager.doToggleShift;
      _ToolbarManager.doReloadBtn.onclick = _ToolbarManager.doReload;
      _ToolbarManager.doGifBtn.onclick = _ToolbarManager.doGif;
      _ToolbarManager.doRotateBtn.onclick = _ToolbarManager.doRotate;
      _ToolbarManager.doBackBtn.onclick = _ToolbarManager.doBack;
      _ToolbarManager.doUpBtn.onclick = () => _ToolbarManager.doScroll(-1);
      _ToolbarManager.doDownBtn.onclick = () => _ToolbarManager.doScroll(1);
      _ToolbarManager.doRestartBtn.onclick = () => _ToolbarManager.doRestart();
      document.addEventListener("keyup", _ToolbarManager.handleKeypress);
      document.addEventListener("keydown", _ToolbarManager.handleControlKey);
      document.getElementById("toolbar_side").classList.add(player2.appType);
    }
    static initProfileSelect(player2) {
      let current = "sb7";
      if (localStorage.zp_profile_name && DeviceProfiles[localStorage.zp_profile_name]) {
        current = localStorage.zp_profile_name;
      }
      const picker = document.getElementById("player_profile_select");
      for (const name in DeviceProfiles) {
        const opt = document.createElement("option");
        opt.value = name;
        opt.innerText = name;
        picker.appendChild(opt);
      }
      picker.value = current;
      picker.onchange = async () => {
        localStorage.zp_profile_name = picker.value;
        player2.profileName = picker.value;
        player2.imgCache = {};
        await player2.overlayTool.init();
        await player2.init();
        if (player2.currentRuntime) {
          player2.currentRuntime.refresh_required = "profile_ch";
        }
      };
      player2.profileName = current;
    }
    static handleControlKey(e3) {
      if (e3.ctrlKey && e3.key === "p") {
        e3.preventDefault();
        return false;
      }
    }
    static handleKeypress(e3) {
      switch (e3.key) {
        case "1":
          _ToolbarManager.doToggleMode(1);
          return;
        case "2":
          _ToolbarManager.doToggleMode(2);
          return;
        case "3":
          _ToolbarManager.doToggleMode(4);
          return;
        case "p":
          if (e3.ctrlKey)
            window._setReactPane("command_picker");
          return;
        case "P":
          _ToolbarManager.doTogglePause();
          return;
        case "S":
          _ToolbarManager.doToggleShift();
          return;
        case "Z":
          _ToolbarManager.doToggleEventZones();
          return;
        case "W":
          _ToolbarManager.doReload();
          return;
        case "c":
          _ToolbarManager.actionToggleConsole();
          return;
        case "e":
          _ToolbarManager.actionToggleEditor();
          return;
        case "+":
          _ToolbarManager.switchProject(1);
          return;
        case "_":
          _ToolbarManager.switchProject(-1);
          return;
        case "Escape":
          _ToolbarManager.doBack();
          return;
      }
    }
    static _refresh() {
      const runtime = _ToolbarManager.player.currentRuntime;
      const data = [
        [_ToolbarManager.toggleEventZones, _ToolbarManager.player.showEventZones],
        [_ToolbarManager.togglePause, runtime && runtime.uiPause],
        [_ToolbarManager.toggleShift, _ToolbarManager.player.withShift],
        [_ToolbarManager.toggleMode1, _ToolbarManager.player.current_level === 1],
        [_ToolbarManager.toggleMode2, _ToolbarManager.player.current_level === 2],
        [_ToolbarManager.toggleMode4, _ToolbarManager.player.current_level === 4]
      ];
      for (let i3 in data) {
        const [button, enabled] = data[i3];
        enabled ? button.classList.add("active") : button.classList.remove("active");
      }
    }
    static async doRestart() {
      await _ToolbarManager.player.restart();
    }
    static doScroll(d3) {
      _ToolbarManager.player.renderScroll += d3 * 40;
    }
    static doBack() {
      _ToolbarManager.player.back();
    }
    static switchProject(delta) {
      const picker = document.getElementById("project_select");
      const current = picker.value;
      let index = -1;
      for (let i3 = 0; i3 < picker.options.length; i3++) {
        if (picker.options[i3].value === current) {
          index = i3;
          break;
        }
      }
      index += delta;
      if (!picker.options[index])
        return;
      console.log("switch to", picker.options[index].value);
      picker.value = picker.options[index].value;
      picker.onchange();
    }
    static doRotate() {
      _ToolbarManager.player.rotation = (_ToolbarManager.player.rotation + 90) % 360;
      localStorage.zepp_player_rotation = _ToolbarManager.player.rotation;
      _ToolbarManager.player.currentRuntime.refresh_required = "ui";
    }
    static doToggleMode(val) {
      const player2 = _ToolbarManager.player;
      player2.setRenderLevel(val).then(() => _ToolbarManager._refresh());
    }
    static doTogglePause() {
      const player2 = _ToolbarManager.player;
      player2.currentRuntime.setPause(!player2.currentRuntime.uiPause);
      _ToolbarManager._refresh();
    }
    static doToggleEventZones() {
      const player2 = _ToolbarManager.player;
      player2.showEventZones = !player2.showEventZones;
      _ToolbarManager._refresh();
    }
    static doToggleShift() {
      const player2 = _ToolbarManager.player;
      player2.withShift = !player2.withShift;
      _ToolbarManager._refresh();
    }
    static doReload() {
      PersistentStorage.wipe();
      const player2 = _ToolbarManager.player;
      player2.init();
    }
    static async doGif() {
      const gifRecorder = new GifRecorder(_ToolbarManager.player);
      await gifRecorder.record();
      gifRecorder.export();
    }
  };
  var ToolbarManager = _ToolbarManager;
  __publicField(ToolbarManager, "player", null);
  __publicField(ToolbarManager, "toggleMode1", document.getElementById("mode_1"));
  __publicField(ToolbarManager, "toggleMode2", document.getElementById("mode_2"));
  __publicField(ToolbarManager, "toggleMode4", document.getElementById("mode_4"));
  __publicField(ToolbarManager, "toggleEventZones", document.getElementById("toggle_events"));
  __publicField(ToolbarManager, "togglePause", document.getElementById("toggle_pause"));
  __publicField(ToolbarManager, "toggleShift", document.getElementById("toggle_shift"));
  __publicField(ToolbarManager, "doReloadBtn", document.getElementById("do_reload"));
  __publicField(ToolbarManager, "doGifBtn", document.getElementById("do_gif"));
  __publicField(ToolbarManager, "doRotateBtn", document.getElementById("do_rotate"));
  __publicField(ToolbarManager, "doRestartBtn", document.getElementById("do_restart"));
  __publicField(ToolbarManager, "doBackBtn", document.getElementById("app_back"));
  __publicField(ToolbarManager, "doUpBtn", document.getElementById("app_up"));
  __publicField(ToolbarManager, "doDownBtn", document.getElementById("app_down"));

  // src/ui_managment/Updater.js
  async function initVersionUI() {
    const pkg = await fetch("/package.json");
    const pkgJson = await pkg.json();
    const APP_VERSION = pkgJson.version;
    const view = document.getElementById("version_box");
    const versionDiv = document.createElement("div");
    versionDiv.innerHTML = "<span>ZeppPlayer v" + APP_VERSION + ", by <a href='https://melianmiko.ru' target='_blank'>melianmiko</a></span>";
    view.innerHTML = "";
    view.appendChild(versionDiv);
    if (!pkgJson._legacyUpdateChecker)
      return;
    let data = {};
    try {
      const resp = await fetch("https://st.melianmiko.ru/zepp_player/release.json");
      data = await resp.json();
    } catch (e3) {
      console.warn("Update check failed. You can check manually here https://melianmiko.ru");
      return;
    }
    if (data.version === APP_VERSION)
      return;
    const updateLink = document.createElement("a");
    updateLink.className = "update";
    updateLink.href = data.website;
    updateLink.target = "_blank";
    updateLink.innerText = "New version is available (v" + data.version + "). Download it now.";
    view.appendChild(updateLink);
  }

  // src/zepp_player/DeviceStateObject.js
  function createDeviceState() {
    const state = {
      HOUR: {
        value: 9,
        type: "number",
        groupIcon: "calendar_month",
        maxLength: 0,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 12,
        shift: (tick) => tick % 2 === 0 ? (state.HOUR.value + 1) % 24 : null
      },
      MINUTE: {
        value: 30,
        type: "number",
        maxLength: 0,
        groupIcon: "calendar_month",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 60,
        shift: () => (state.MINUTE.value + 5) % 60
      },
      SECOND: {
        value: 45,
        type: "number",
        maxLength: 0,
        groupIcon: "calendar_month",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 60,
        shift: () => (state.SECOND.value + 1) % 60
      },
      DAY: {
        value: 25,
        type: "number",
        maxLength: 2,
        groupIcon: "calendar_month",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value % 31 / 31,
        shift: () => state.DAY.value % 30 + 1
      },
      MONTH: {
        value: 7,
        type: "number",
        maxLength: 2,
        groupIcon: "calendar_month",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value % 12 / 12,
        shift: (tick) => tick % 2 === 0 ? state.MONTH.value % 12 + 1 : null
      },
      YEAR: {
        value: 22,
        type: "number",
        groupIcon: "calendar_month",
        maxLength: 2,
        getString: (t3) => t3.value.toString()
      },
      WEEKDAY: {
        value: 0,
        type: "number",
        groupIcon: "calendar_month",
        maxLength: 1,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => (t3.value + 1) / 7,
        shift: (tick) => tick % 2 === 0 ? (state.WEEKDAY.value + 1) % 7 : null
      },
      AM_PM: {
        value: "hide",
        type: "select",
        options: ["hide", "am", "pm"],
        groupIcon: "calendar_month",
        info: "AM/PM state: hide - 24h mode, am/pm - 12h mode",
        maxLength: 4,
        getString: (t3) => t3.value,
        shift: () => {
          if (state.AM_PM === "hidden")
            return "am";
          if (state.AM_PM === "am")
            return "pm";
          return "hidden";
        }
      },
      OS_LANGUAGE: {
        value: "en-US",
        type: "string",
        groupIcon: "settings",
        maxLength: 5,
        getString: (t3) => t3.value
      },
      OVERLAY_COLOR: {
        value: "#FFFFFF",
        type: "string",
        groupIcon: "settings",
        maxLength: 7,
        getString: (t3) => t3.value
      },
      ALARM_CLOCK: {
        value: "09:30",
        type: "string",
        groupIcon: "settings",
        maxLength: 4,
        getBoolean: (v3) => v3.value !== "0",
        getString: (t3) => t3.value.replaceAll(":", "."),
        getProgress: (t3) => {
          try {
            const v3 = t3.value.split(":");
            const float = parseInt(v3[0]) + parseInt(v3[1]) / 100;
            return Math.min(1, float / 24);
          } catch (e3) {
            return 0;
          }
        },
        shift: (tick, t3) => {
          if (tick % 2 !== 0)
            return null;
          const vals = ["0", "06:00", "09:30", "11:00"];
          let index = vals.indexOf(t3.value);
          if (index < 0)
            index = 0;
          return vals[(index + 1) % vals.length];
        }
      },
      BATTERY: {
        value: 60,
        type: "number",
        groupIcon: "settings",
        maxLength: 3,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: (_3, t3) => t3.value % 100 + 10
      },
      WEAR_STATE: {
        value: 0,
        groupIcon: "settings",
        displayName: "Wear",
        info: "Wear state: 0 - Not worn, 1 - Wearing, 2 - In motion, 3 - not sure"
      },
      DISCONNECT: {
        value: true,
        type: "boolean",
        groupIcon: "settings",
        maxLength: 1,
        getBoolean: (v3) => v3.value,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value ? 1 : 0,
        shift: (tick, t3) => tick % 3 === 1 ? !t3.value : null
      },
      DISTURB: {
        value: true,
        type: "boolean",
        groupIcon: "settings",
        maxLength: 1,
        getBoolean: (v3) => v3.value,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value ? 1 : 0,
        shift: (tick, t3) => tick % 3 === 2 ? !t3.value : null
      },
      LOCK: {
        value: true,
        type: "boolean",
        groupIcon: "settings",
        maxLength: 1,
        getBoolean: (v3) => v3.value,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value ? 1 : 0,
        shift: (tick, t3) => tick % 3 === 0 ? !t3.value : null
      },
      STEP: {
        value: 4500,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 5,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / state.STEP_TARGET.value,
        shift: (_3, t3) => (t3.value + 500) % state.STEP_TARGET.value
      },
      STEP_TARGET: {
        value: 9e3,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 5,
        getString: (t3) => t3.value.toString()
      },
      DISTANCE: {
        value: 1.5,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 4,
        getString: (t3) => {
          return t3.value.toFixed(2);
        },
        shift: () => (state.DISTANCE.value + 0.75) % 20
      },
      CAL: {
        value: 320,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 4,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / state.CAL_TARGET.value,
        shift: (_3, t3) => (t3.value + 30) % state.CAL_TARGET.value
      },
      CAL_TARGET: {
        value: 500,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 4,
        getString: (t3) => t3.value.toString()
      },
      STAND: {
        value: 12,
        type: "number",
        maxLength: 2,
        groupIcon: "fitness_center",
        getString: (t3) => {
          return t3.value + "." + state.STAND_TARGET.value;
        },
        getProgress: (t3) => t3.value / state.STAND_TARGET.value,
        shift: (tick) => tick % 2 === 0 ? state.STAND.value % state.STAND_TARGET.value + 1 : null
      },
      STAND_TARGET: {
        value: 13,
        type: "number",
        groupIcon: "fitness_center",
        maxLength: 2,
        getString: (t3) => t3.value.toString()
      },
      HEART: {
        value: 99,
        type: "number",
        groupIcon: "monitor_heart",
        maxLength: 3,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 180,
        shift: () => (state.HEART.value + 15) % 180
      },
      SLEEP: {
        value: "9:0",
        type: "string",
        groupIcon: "monitor_heart",
        maxLength: 5,
        getBoolean: (v3) => v3.value !== "0",
        getString: (t3) => t3.value,
        getProgress: (t3) => {
          try {
            const v3 = t3.value.split(":");
            const float = parseInt(v3[0]) + parseInt(v3[1]) / 100;
            return Math.min(1, float / 24);
          } catch (e3) {
            return 0;
          }
        },
        shift: (tick, t3) => {
          if (tick % 2 !== 0)
            return null;
          const vals = ["0", "06:00", "09:30", "11:00"];
          let index = vals.indexOf(t3.value);
          if (index < 0)
            index = 0;
          return vals[index + 1 % vals.length];
        }
      },
      SPO2: {
        value: 30,
        type: "number",
        maxLength: 3,
        groupIcon: "monitor_heart",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.SPO2.value + 2 % 100
      },
      PAI_WEEKLY: {
        value: 55,
        type: "number",
        maxLength: 3,
        groupIcon: "monitor_heart",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: (tick) => tick % 3 == 0 ? state.PAI_WEEKLY.value % 100 + 4 : null
      },
      PAI_DAILY: {
        value: 80,
        type: "number",
        maxLength: 3,
        groupIcon: "monitor_heart",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.PAI_DAILY.value % 100 + 4
      },
      STRESS: {
        value: 50,
        type: "number",
        maxLength: 3,
        groupIcon: "monitor_heart",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.STRESS.value % 100 + 5
      },
      WEATHER_CURRENT: {
        value: 12,
        type: "number",
        groupIcon: "sunny",
        displayName: "Current",
        maxLength: 2,
        getString: (t3) => t3.value.toString(),
        getProgress: () => state.WEATHER_CURRENT_ICON.value / 28,
        shift: (tick, t3) => (Math.abs(t3.value) + 2) % 30 * (tick % 4 < 2 ? -1 : 1)
      },
      WEATHER_HIGH: {
        value: 14,
        type: "number",
        groupIcon: "sunny",
        displayName: "High",
        maxLength: 2,
        getString: (t3) => t3.value.toString(),
        shift: (tick, t3) => (Math.abs(t3.value) + 2) % 30
      },
      WEATHER_LOW: {
        value: 14,
        type: "number",
        groupIcon: "sunny",
        displayName: "Low",
        maxLength: 2,
        getString: (t3) => t3.value.toString(),
        shift: (tick, t3) => (Math.abs(t3.value) + 2) % 15 * (tick % 4 < 2 ? -1 : 1)
      },
      WEATHER_CURRENT_ICON: {
        value: 0,
        maxLength: 2,
        groupIcon: "sunny",
        displayName: "Icon",
        shift: () => (state.WEATHER_CURRENT_ICON.value + 1) % 29
      },
      WEATHER_CITY: {
        value: "Barnaul",
        type: "string",
        maxLength: 15,
        groupIcon: "sunny",
        displayName: "City name",
        getString: (t3) => t3.value
      },
      WIND: {
        value: 2,
        type: "number",
        maxLength: 2,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.HUMIDITY.value % 16 + 1
      },
      AQI: {
        value: 20,
        type: "number",
        maxLength: 3,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.HUMIDITY.value % 100 + 5
      },
      HUMIDITY: {
        value: 10,
        type: "number",
        maxLength: 3,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.HUMIDITY.value % 92 + 8
      },
      ALTIMETER: {
        value: 0,
        type: "number",
        maxLength: 4,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100
      },
      WIND_DIRECTION: {
        value: 0,
        type: "number",
        maxLength: 3,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 7
      },
      UVI: {
        value: 10,
        type: "number",
        maxLength: 2,
        groupIcon: "sunny",
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / 100,
        shift: () => state.UVI.value % 100 + 5
      },
      MUSIC_IS_PLAYING: {
        value: true,
        type: "boolean",
        groupIcon: "music_note",
        maxLength: 1,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value ? 1 : 0,
        shift: (tick, t3) => tick % 3 === 0 ? !t3.value : null
      },
      MUSIC_ARTIST: {
        value: "Crusher-P",
        groupIcon: "music_note",
        type: "string",
        maxLength: 8
      },
      MUSIC_TITLE: {
        value: "ECHO",
        groupIcon: "music_note",
        type: "string",
        maxLength: 12
      },
      FAT_BURNING: {
        value: 0,
        type: "number",
        maxLength: 3,
        getString: (t3) => t3.value.toString(),
        getProgress: (t3) => t3.value / state.FAT_BURNING_TARGET.value,
        shift: () => (state.FAT_BURNING.value + 1) % state.FAT_BURNING_TARGET.value
      },
      FAT_BURNING_TARGET: {
        value: 20,
        type: "number",
        maxLength: 3
      },
      BODY_TEMP: {
        value: 36.5,
        type: "number",
        maxLength: 4,
        getString: (t3) => {
          const km = Math.floor(t3.value).toString(), dm = Math.round(t3.value % 1 * 100).toString();
          return km.padStart(2, "0") + "." + dm.padStart(1, "0");
        },
        getProgress: (t3) => t3.value / 45
      },
      MOON: {
        value: 0,
        maxLength: 1,
        type: "number",
        getProgress: (t3) => Math.max(0, t3.value / 7)
      },
      SUN_CURRENT: {
        value: 0,
        notEditable: true,
        maxLength: 5,
        getString: () => {
          const current = state.HOUR.value + state.MINUTE.value / 100;
          if (current <= 6.3 || current >= 21.3) {
            return state.SUN_RISE.value;
          }
          return state.SUN_SET.value;
        }
      },
      SUN_SET: {
        value: "21.30",
        notEditable: true,
        maxLength: 5,
        getString: (t3) => t3.value
      },
      SUN_RISE: {
        value: "06.30",
        notEditable: true,
        maxLength: 5,
        getString: (t3) => t3.value
      }
    };
    return state;
  }

  // src/zepp_player/ZeppPlayerConfig.js
  var ZeppPlayerConfig = class {
    constructor() {
      __publicField(this, "refresh_required", true);
      __publicField(this, "_currentRenderLevel", 1);
      __publicField(this, "_renderEventZones", false);
      __publicField(this, "_renderWithoutTransparency", true);
      __publicField(this, "_renderAutoShift", false);
      __publicField(this, "_renderOverlay", true);
      __publicField(this, "_renderLanguage", "en");
      __publicField(this, "_renderScroll", 0);
      __publicField(this, "withScriptConsole", true);
    }
    get renderScroll() {
      return this._renderScroll;
    }
    set renderScroll(v3) {
      this._renderScroll = Math.max(0, v3);
      if (this.currentRuntime)
        this.currentRuntime.refresh_required = true;
    }
    get current_level() {
      return this._currentRenderLevel;
    }
    set current_level(_3) {
      throw new Error("Can't set directly, use setRenderLevel()");
    }
    get render_overlay() {
      return this._renderOverlay;
    }
    set render_overlay(val) {
      this._renderOverlay = val;
      if (this.currentRuntime)
        this.currentRuntime.refresh_required = true;
    }
    get showEventZones() {
      return this._renderEventZones;
    }
    set showEventZones(val) {
      this._renderEventZones = val;
      if (this.currentRuntime)
        this.currentRuntime.refresh_required = true;
    }
    get withoutTransparency() {
      return this._renderWithoutTransparency;
    }
    set withoutTransparency(val) {
      this._renderWithoutTransparency = val;
      this.refresh_required = true;
    }
    get withShift() {
      return this._renderAutoShift;
    }
    set withShift(val) {
      this._renderAutoShift = val;
      if (this.currentRuntime)
        this.currentRuntime.refresh_required = true;
    }
  };

  // src/zepp_player/ui/Overlay.js
  var Overlay = class {
    constructor(player2) {
      __publicField(this, "maskData", null);
      __publicField(this, "mask", null);
      this.player = player2;
    }
    async init() {
      if (!this.player.profileData.hasOverlay)
        return this;
      const maskFile = await this.player.loadFile(`/app/overlay/${this.player.profileName}.png`);
      const mask = await this.player._loadPNG(maskFile);
      const maskCanvas = this.player.newCanvas();
      maskCanvas.width = mask.width;
      maskCanvas.height = mask.height;
      const ctx = maskCanvas.getContext("2d");
      ctx.drawImage(mask, 0, 0);
      this.mask = maskCanvas;
      this.maskData = ctx.getImageData(0, 0, maskCanvas.width, maskCanvas.height).data;
      return this;
    }
    async drawEventZones(canvas, eventGroups) {
      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = "rgba(0, 153, 255, 0.5)";
      ctx.lineWidth = 2;
      for (let group of eventGroups) {
        let hasNoNull = false;
        for (let i3 in group.events) {
          if (group.events[i3] !== null) {
            hasNoNull = true;
            break;
          }
        }
        if (!hasNoNull)
          continue;
        const { x1, y1, x2: x22, y2: y22 } = group;
        ctx.strokeRect(x1, y1, x22 - x1, y22 - y1);
      }
    }
    async drawDeviceFrame(canvas) {
      if (canvas.width !== this.mask.width || canvas.height !== this.mask.height)
        return;
      const ctx = canvas.getContext("2d");
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      for (let i3 = 3; i3 < imgData.data.length; i3 += 4) {
        imgData.data[i3] = 255 - this.maskData[i3];
      }
      ctx.putImageData(imgData, 0, 0);
    }
  };

  // src/zepp_player/Errors.js
  var ZeppNotImplementedError = class extends TypeError {
    constructor(propertyName) {
      super(`Not implemented in ZeppPlayer: ${propertyName}. Please contact developer.`);
    }
  };

  // src/zepp_player/zepp_env/HuamiSensor.js
  var HuamiSensorMock = class {
    constructor(runtime) {
      __publicField(this, "id", {
        TIME: TimeSensor,
        BATTERY: BatterySensor,
        STEP: StepSensor,
        CALORIE: CalorieSensor,
        HEART: HeartSensor,
        PAI: PaiSensor,
        DISTANCE: DistanceSensor,
        STAND: StandSensor,
        WEATHER: WeatherSensor,
        FAT_BURRING: FatBurningSensor,
        SPO2: SPO2Sensor,
        BODY_TEMP: BodyTempSensor,
        STRESS: StressSensor,
        VIBRATE: VibrateSensor,
        WEAR: WearSensor,
        WORLD_CLOCK: WorldClockSensor,
        SLEEP: SleepSensor,
        MUSIC: MusicSensor,
        ACTIVITY: ActivitySensor
      });
      __publicField(this, "event", {
        CHANGE: "CHANGE",
        CURRENT: "CURRENT",
        LAST: "LAST"
      });
      this._runtime = runtime;
    }
    createSensor(id) {
      if (id === void 0)
        throw new ZeppNotImplementedError(`hmSensor.id.?`);
      return new id(this._runtime);
    }
  };
  var TimeSensor = class {
    constructor(player2) {
      __publicField(this, "event", {
        MINUTEEND: "MINUTEEND",
        DAYCHANGE: "DAYCHANGE"
      });
      this.player = player2;
      this.lunar_day = this.day;
      this.lunar_month = this.month;
      this.lunar_solar_term = "ZeppPlayer";
      this.solar_festival = "New year";
    }
    addEventListener(name, callback) {
      if (name === "MINUTEEND") {
        this.player.addDeviceStateChangeEvent("HOUR", () => {
          callback();
        });
        this.player.addDeviceStateChangeEvent("MINUTE", () => {
          callback();
        });
      } else if (name === "DAYCHANGE") {
        this.player.addDeviceStateChangeEvent("DAY", () => {
          callback();
        });
        this.player.addDeviceStateChangeEvent("MONTH", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
    get utc() {
      return Date.now();
    }
    get week() {
      return this.player.getDeviceState("WEEKDAY") + 1;
    }
    get hour() {
      return this.player.getDeviceState("HOUR");
    }
    get minute() {
      return this.player.getDeviceState("MINUTE");
    }
    get second() {
      return this.player.getDeviceState("SECOND");
    }
    get day() {
      return this.player.getDeviceState("DAY");
    }
    get month() {
      return this.player.getDeviceState("MONTH");
    }
    get year() {
      return this.player.getDeviceState("YEAR") + 2e3;
    }
    get format_hour() {
      return this.player.getDeviceState("HOUR");
    }
    getLunarMonthCalendar() {
      return { lunar_days_array: [], day_count: 0 };
    }
    getShowFestival() {
      return this.solar_festival;
    }
  };
  var BatterySensor = class {
    get current() {
      return this.player.getDeviceState("BATTERY");
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("BATTERY", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var StepSensor = class {
    get target() {
      return this.player.getDeviceState("STEP_TARGET");
    }
    get current() {
      return this.player.getDeviceState("STEP");
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("STEP", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var CalorieSensor = class {
    get current() {
      return this.player.getDeviceState("CAL");
    }
    get target() {
      return this.player.getDeviceState("CAL_TARGET");
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("CAL", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var HeartSensor = class {
    constructor(player2) {
      __publicField(this, "event", {
        CURRENT: "CHANGE",
        LAST: "LAST"
      });
      this.player = player2;
      this.today = [];
      for (let i3 = 0; i3 < 3600; i3++) {
        this.today[i3] = Math.round(90 + 90 * (i3 % 120) / 120);
      }
    }
    get current() {
      return this.player.getDeviceState("HEART");
    }
    get last() {
      return this.player.getDeviceState("HEART");
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
    addEventListener(name, callback) {
      this.player.addDeviceStateChangeEvent("HEART", () => {
        callback();
      });
    }
  };
  var PaiSensor = class {
    constructor(player2) {
      this.player = player2;
    }
    get totalpai() {
      return this.player.getDeviceState("PAI_DAILY") * 4.5;
    }
    get dailypai() {
      return this.player.getDeviceState("PAI_DAILY");
    }
    get prepai0() {
      return this.player.getDeviceState("PAI_DAILY") * 0.2;
    }
    get prepai1() {
      return this.player.getDeviceState("PAI_DAILY") * 0.3;
    }
    get prepai2() {
      return this.player.getDeviceState("PAI_DAILY") * 0.4;
    }
    get prepai3() {
      return this.player.getDeviceState("PAI_DAILY") * 0.5;
    }
    get prepai4() {
      return this.player.getDeviceState("PAI_DAILY") * 0.6;
    }
    get prepai5() {
      return this.player.getDeviceState("PAI_DAILY") * 0.7;
    }
    get prepai6() {
      return this.player.getDeviceState("PAI_DAILY") * 0.8;
    }
    addEventListener(name, callback) {
    }
  };
  var DistanceSensor = class {
    get current() {
      return this.player.getDeviceState("DISTANCE") * 1e3;
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("DISTANCE", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var StandSensor = class {
    get target() {
      return this.player.getDeviceState("STAND_TARGET");
    }
    get current() {
      return this.player.getDeviceState("STAND");
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("STAND", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var WeatherSensor = class {
    constructor(player2) {
      this.player = player2;
    }
    getForecastWeather() {
      return {
        cityName: this.player.getDeviceState("WEATHER_CITY", "string"),
        forecastData: {
          data: [
            { high: 15, low: 12, index: 0 },
            { high: 10, low: 8, index: 1 },
            { high: 5, low: 2, index: 2 },
            { high: -1, low: -3, index: 3 }
          ],
          count: 4
        },
        tideData: {
          data: [
            {
              sunrise: { hour: 9, minute: 30 },
              sunset: { hour: 21, minute: 30 }
            },
            {
              sunrise: { hour: 9, minute: 30 },
              sunset: { hour: 21, minute: 30 }
            },
            {
              sunrise: { hour: 9, minute: 30 },
              sunset: { hour: 21, minute: 30 }
            },
            {
              sunrise: { hour: 9, minute: 30 },
              sunset: { hour: 21, minute: 30 }
            }
          ],
          count: 4
        }
      };
    }
  };
  var FatBurningSensor = class {
    get target() {
      return this.player.getDeviceState("FAT_BURNING_TARGET");
    }
    get current() {
      return this.player.getDeviceState("FAT_BURNING");
    }
    constructor(player2) {
      this.player = player2;
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("FAT_BURNING", () => {
          callback();
        });
      }
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var SPO2Sensor = class {
    get current() {
      return this.player.getDeviceState("SPO2");
    }
    constructor(player2) {
      this.player = player2;
      this.time = 0;
      this.hourAvgofDay = [];
      for (let i3 = 0; i3 < 24; i3++) {
        this.hourAvgofDay.push(this.current);
      }
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("SPO2", () => {
          callback();
        });
      }
    }
    start() {
      console.log("[SPO2] start()");
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
  };
  var BodyTempSensor = class {
    constructor(player2) {
      this.current = player2.getDeviceState("BODY_TEMP");
      this.timeinterval = 10;
    }
  };
  var StressSensor = class {
    get current() {
      return this.player.getDeviceState("STRESS");
    }
    constructor(player2) {
      this.player = player2;
      this.time = Date.now();
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("STRESS", () => {
          callback();
        });
      }
    }
  };
  var VibrateSensor = class {
    constructor() {
      this.motortype = 0;
      this.motorenable = 0;
      this.crowneffecton = 0;
      this.scene = 0;
    }
    start() {
      console.log("[VIBRATE] start");
    }
    stop() {
      console.log("[VIBRATE] stop");
    }
  };
  var WearSensor = class {
    get current() {
      return this.player.getDeviceState("WEAR_STATE");
    }
    constructor(player2) {
      this.player = player2;
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("WEAR_STATE", () => {
          callback();
        });
      }
    }
  };
  var WorldClockSensor = class {
    constructor(player2) {
      this.player = player2;
    }
    init() {
      console.log("[WC] Init");
    }
    uninit() {
      console.log("[WC] unInit");
    }
    getWorldClockCount() {
      return 2;
    }
    getWorldClockInfo() {
      return {
        city: "Moscow",
        hour: this.player.getDeviceState("HOUR") - 4,
        minute: this.player.getDeviceState("MINUTE")
      };
    }
  };
  var SleepSensor = class {
    updateInfo() {
      console.log("[SLEEP] Fetching new info (really not)...");
    }
    getSleepStageData() {
      const out = [];
      for (let i3 = 0; i3 < 4; i3++)
        out.push({
          model: i3,
          start: i3 * 60 + 22 * 60,
          stop: i3 * 60 + 23 * 60
        });
      return out;
    }
    getSleepStageModel() {
      return {
        WAKE_STAGE: 0,
        REM_STAGE: 1,
        LIGHT_STAGE: 2,
        DEEP_STAGE: 3
      };
    }
  };
  var MusicSensor = class {
    get title() {
      return this.player.getDeviceState("MUSIC_TITLE");
    }
    get artist() {
      return this.player.getDeviceState("MUSIC_ARTIST");
    }
    get isPlaying() {
      return this.player.getDeviceState("MUSIC_IS_PLAYING");
    }
    constructor(player2) {
      this.player = player2;
    }
    audInit() {
    }
    audPlay() {
      this.isPlaying = !this.isPlaying;
      this.player.setDeviceState("MUSIC_IS_PLAYING", this.isPlaying);
    }
    audPause() {
      this.audPlay();
    }
    audPrev() {
      console.log("[MUSIC] prev track");
    }
    audNext() {
      console.log("[MUSIC] next track");
    }
    removeEventListener(_3) {
      this.player.onConsole("ZeppPlayer", ["Sensor removeEventList not implemented, sorry"]);
    }
    addEventListener(name, callback) {
      if (name === "CHANGE") {
        this.player.addDeviceStateChangeEvent("MUSIC_TITLE", () => {
          callback();
        });
        this.player.addDeviceStateChangeEvent("MUSIC_ARTIST", () => {
          callback();
        });
        this.player.addDeviceStateChangeEvent("MUSIC_IS_PLAYING", () => {
          callback();
        });
      }
    }
  };
  var ActivitySensor = class {
    constructor(player2) {
      this.player = player2;
    }
    getActivityInfo() {
      return {
        displayMode: 1
      };
    }
  };

  // src/zepp_player/zepp_env/ConsoleCatch.js
  var ConsoleMock = class {
    constructor(player2, console2) {
      this.console = console2;
      this.player = player2;
    }
    _parse(level, args) {
      try {
        this.player.onConsole(level, args);
        if (args[0] instanceof Error) {
          this.player.autoFixGlobalScopeError(args[0]);
        }
      } catch (e3) {
      }
    }
    log() {
      this._parse("log", arguments);
    }
    info() {
      this._parse("info", arguments);
    }
    warn() {
      this._parse("warn", arguments);
    }
    error() {
      this._parse("error", arguments);
    }
  };

  // src/zepp_player/ui/BaseWidget.js
  var BaseWidget = class {
    constructor(config) {
      __publicField(this, "setPropertyBanlist", []);
      this.config = config;
      this.runtime = config.__runtime;
      this.positionInfo = false;
      if (!this.config.visible)
        this.config.visible = true;
      this.events = {
        "onmousemove": null,
        "onmouseup": null,
        "onmousedown": null
      };
      this.init();
    }
    async render() {
    }
    init() {
    }
    playerWidgetIdentify() {
      let title = this.config.__widget;
      let subtitle = "", subtitleClass = "";
      if (this.config._name) {
        subtitle = this.config._name;
        subtitleClass = "userDefined";
      } else if (this.config.type) {
        subtitle = this.config.type;
      } else if (this.config.src) {
        subtitle = this.config.src;
      } else if (this.config.text) {
        subtitle = this.config.text;
      }
      return [title, subtitle, subtitleClass];
    }
    _isVisible() {
      if (!this.config.visible)
        return false;
      const show_level = this.config.show_level;
      return !((show_level & this.runtime.showLevel) === 0 && show_level);
    }
    _getPlainConfig() {
      const out = {};
      for (let i3 in this.config) {
        if (i3[0] !== "_")
          out[i3] = this.config[i3];
      }
      return out;
    }
    setProperty(prop, val) {
      if (prop === void 0) {
        console.warn("This prop was missing in simulator. Please, debug me...");
      }
      if (prop === "more") {
        for (var a3 in val) {
          if (this.setPropertyBanlist.indexOf(a3) > -1) {
            const info = `You can't set ${a3} in ${this.constructor.name} via hmUI.prop.MORE. Player crashed.`;
            this.runtime.onConsole("SystemWarning", [info]);
            this.runtime.destroy();
            throw new Error(info);
          }
          this.config[a3] = val[a3];
        }
        this.runtime.refresh_required = "set_prop";
        return;
      }
      this.config[prop] = val;
      this.runtime.refresh_required = "set_prop";
    }
    getProperty(key, second) {
      if (!this._isVisible()) {
        console.warn("attempt to getprop on invisible", this, key);
        return void 0;
      }
      if (key === "more") {
        if (typeof second !== "object")
          this.player.onConsole("SystemWarning", [
            "When using getProperty with MORE, you must give empty object as second param."
          ]);
        return this.config;
      }
      return this.config[key];
    }
    addEventListener(event, fn2) {
      this.events[event] = fn2;
    }
    removeEventListener(event, fn2) {
      for (let a3 in this.events) {
        if (this.events[a3][0] === event && this.events[a3][1] + "" === fn2 + "") {
          this.events.splice(a3, 1);
          return;
        }
      }
    }
    dropEvents(player2, zone = null) {
      const config = this.config;
      if (zone == null)
        zone = [config.x, config.y, config.w, config.h];
      let [x1, y1, x22, y22] = zone;
      if (config.__eventOffsetX) {
        x1 += config.__eventOffsetX;
        x22 += config.__eventOffsetX;
      }
      if (config.__eventOffsetY) {
        y1 += config.__eventOffsetY;
        y22 += config.__eventOffsetY;
      }
      player2.dropEvents(this.events, x1, y1, x22, y22);
      this.positionInfo = [x1, y1, x22, y22];
    }
  };

  // src/zepp_player/Utils.js
  function zeppColorToHex(i3) {
    if (typeof i3 == "string") {
      if (i3.startsWith("0x")) {
        i3 = parseInt(i3);
      } else
        return i3;
    }
    let s3 = i3.toString(16);
    if (s3.length > 6)
      s3 = s3.substring(s3.length - 6, s3.length);
    s3 = "#" + s3.padStart(6, "0");
    return s3;
  }

  // src/zepp_player/ui/ImagingWidgets.js
  var ImageWidget = class extends BaseWidget {
    static draw(img, canvas, player2, config) {
      let w4 = config.w, h3 = config.h;
      if (!config.w)
        w4 = img.width;
      if (!config.h)
        h3 = img.height;
      const cnv = player2.newCanvas();
      cnv.width = w4;
      cnv.height = h3;
      let centerX = config.center_x ? config.center_x : 0, centerY = config.center_y ? config.center_y : 0, posX = config.pos_x ? config.pos_x : 0, posY = config.pos_y ? config.pos_y : 0;
      const ctx = cnv.getContext("2d");
      if (config.angle === void 0 || config.angle === 0) {
        ctx.drawImage(img, posX, posY);
      } else {
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(config.angle * Math.PI / 180);
        ctx.drawImage(img, posX - centerX, posY - centerY);
        ctx.restore();
      }
      const x4 = config.x ? config.x : 0;
      const y3 = config.y ? config.y : 0;
      canvas.getContext("2d").drawImage(cnv, x4, y3);
      return [x4, y3, x4 + w4, y3 + h3];
    }
    async render(canvas, player2) {
      const item = this.config;
      let img, evZone;
      try {
        img = await player2.getAssetImage(item.src);
        if (player2.getImageFormat(item.src) === "TGA-RLP" && item.angle) {
          player2.onConsole("SystemWarning", [
            "WARN: MB7 can't rotate images in TGA-RLP format.",
            "Re-convert file",
            item.src,
            "to TGA-P format."
          ]);
          item.angle = 0;
        }
        evZone = ImageWidget.draw(img, canvas, player2, item);
      } catch (e3) {
        evZone = [
          item.x,
          item.y,
          item.x + item.w,
          item.y + item.h
        ];
      }
      if (!item.angle) {
        super.dropEvents(player2, evZone);
      }
    }
  };
  var ClickableImageWidget = class extends ImageWidget {
    constructor(config) {
      super(config);
      this.addEventListener("onmousedown", () => {
        console.info("[IMG_CLICK] " + config.type);
        config.__runtime.onConsole("IMG_CLICK", ["clicked", config.type]);
      });
    }
  };
  var PointerWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      const img = await player2.getAssetImage(config.src);
      let angle = config.angle;
      if (config.type)
        angle = player2.getDeviceState(config.type, "progress") * 360;
      if (config.start_angle !== void 0 && config.end_angle !== void 0) {
        angle = angle / 360 * (config.end_angle - config.start_angle) + config.start_angle;
      }
      const conf = {
        x: 0,
        y: 0,
        w: canvas.width,
        h: canvas.height,
        center_x: config.center_x,
        center_y: config.center_y,
        pos_x: config.center_x - config.x,
        pos_y: config.center_y - config.y,
        angle
      };
      ImageWidget.draw(img, canvas, player2, conf);
    }
  };
  var MissingWidget = class extends ImageWidget {
    constructor(config) {
      super(config);
    }
    async render(a3, b3) {
      await super.render(a3, b3);
      if (!this.flag) {
        console.warn("Widget missing", this.config);
        this.flag = true;
      }
    }
  };
  var TextImageWidget = class extends BaseWidget {
    constructor() {
      super(...arguments);
      __publicField(this, "setPropertyBanlist", ["text"]);
    }
    static getAlignOffsetX(align, boxWidth, contentWidth) {
      switch (align) {
        case "center_h":
          return (boxWidth - contentWidth) / 2;
        case "right":
          return boxWidth - contentWidth;
        default:
          return 0;
      }
    }
    static async draw(runtime, text2, maxLength, config) {
      if (!config.font_array || config.font_array.length < 1)
        return null;
      text2 = String(text2);
      const countNums = text2.replace(/\D/g, "").length;
      const valueMissing = text2 === "" || text2 === null || text2 === void 0;
      const hSpace = config.h_space ? config.h_space : 0;
      const iconSpace = config.icon_space ? config.icon_space : 0;
      const basementImage = await runtime.getAssetImage(config.font_array[0]);
      let fullWidth = countNums * basementImage.width + Math.max(0, countNums - 1) * hSpace;
      let iconImg = null, unitImg = null, dotImage = null, negativeImage = null, invalidImage = null;
      if (config.invalid_image && valueMissing) {
        invalidImage = await runtime.getAssetImage(config.invalid_image);
        fullWidth = invalidImage;
      }
      if (config.negative_image) {
        negativeImage = await runtime.getAssetImage(config.negative_image);
        if (text2.indexOf("-") > -1)
          fullWidth += negativeImage.width + hSpace;
      }
      if (config.dot_image) {
        dotImage = await runtime.getAssetImage(config.dot_image);
        if (text2.indexOf(".") > -1)
          fullWidth += dotImage.width + hSpace;
      } else if (text2.indexOf(".") > -1) {
        fullWidth += hSpace;
      }
      if (config.icon) {
        iconImg = await runtime.getAssetImage(config.icon);
        fullWidth += iconImg.width + iconSpace;
      }
      if (config["unit_" + runtime.language]) {
        try {
          unitImg = await runtime.getAssetImage(config["unit_" + runtime.language]);
          if (text2.indexOf("u") < 0)
            text2 += "u";
        } catch (e3) {
        }
      }
      let boxHeight = config.h;
      if (boxHeight === void 0) {
        boxHeight = basementImage.height;
      }
      let boxWidth = config.w;
      if (boxWidth === void 0) {
        const autoNumCount = maxLength === 0 ? countNums : maxLength;
        boxWidth = basementImage.width * autoNumCount + hSpace * (autoNumCount - 1);
        if (iconImg)
          boxWidth += iconImg.width + iconSpace;
        if (negativeImage)
          boxWidth += hSpace + negativeImage.width;
        if (unitImg)
          boxWidth += unitImg.width;
        if (dotImage)
          boxWidth += hSpace + dotImage.width;
      }
      if (boxWidth === 0 || boxHeight === 0)
        return null;
      const tmp = runtime.newCanvas();
      tmp.width = boxWidth;
      tmp.height = boxHeight;
      const ctx = tmp.getContext("2d");
      if (valueMissing && invalidImage) {
        let px2 = TextImageWidget.getAlignOffsetX(config.align_h, tmp.width, invalidImage.width);
        ctx.drawImage(invalidImage, px2, 0);
        return tmp;
      } else if (valueMissing) {
        text2 = "";
      }
      let px = TextImageWidget.getAlignOffsetX(config.align_h, tmp.width, fullWidth);
      function drawIfDefined(image) {
        if (image == null)
          return;
        ctx.drawImage(image, px, 0);
        px += image.width + hSpace;
      }
      drawIfDefined(iconImg);
      for (const liter of text2) {
        switch (liter) {
          case "-":
            drawIfDefined(negativeImage);
            break;
          case ".":
          case ":":
            drawIfDefined(dotImage);
            break;
          case "u":
            drawIfDefined(unitImg);
            break;
          default:
            if (!isNaN(parseInt(liter))) {
              const img = await runtime.getAssetImage(config.font_array[parseInt(liter)]);
              ctx.drawImage(img, px, 0);
              px += basementImage.width + hSpace;
            }
        }
      }
      return tmp;
    }
    async render(canvas, player2) {
      const config = this.config;
      let text2 = "", maxLength = 0;
      if (config.text !== void 0) {
        text2 = config.text;
      } else if (config.type) {
        text2 = player2.getDeviceState(config.type, "string");
        maxLength = player2.getDeviceState(config.type, "maxLength");
        if (config.padding && text2 !== "") {
          const countNums = text2.replace(/\D/g, "").length;
          text2 = text2.padStart(maxLength - countNums + text2.length, "0");
        }
      }
      if (typeof text2 == "string") {
        if (text2 === "" && config.type === "ALARM_CLOCK" && !config.invalid_image) {
          text2 = "0";
        }
        if (text2.indexOf(".") > -1 && !config.dot_image) {
          text2 = text2.substring(0, text2.lastIndexOf("."));
        }
      }
      if (text2 === null || text2 === void 0) {
        if (!this.failed) {
          console.warn("No text to display...");
          this.failed = true;
        }
        return;
      }
      let tmp;
      try {
        tmp = await TextImageWidget.draw(player2, text2, maxLength, config);
        if (tmp === null)
          return;
      } catch (e3) {
        console.warn(e3);
        return;
      }
      canvas.getContext("2d").drawImage(tmp, config.x, config.y);
      super.dropEvents(player2, [
        config.x,
        config.y,
        config.x + tmp.width,
        config.y + tmp.height
      ]);
    }
  };
  var AnimationWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      this.renderCounter = 0;
    }
    async render(canvas, player2) {
      const config = this.config;
      player2.refresh_required = "img_anim";
      if (config.anim_status === 0)
        return;
      let x4 = config.x, y3 = config.y;
      let currentFrame = Math.floor(this.renderCounter / 60 * config.anim_fps);
      if (player2.animMaxFPS) {
        currentFrame = this.renderCounter;
      }
      if (config.repeat_count === 1) {
        currentFrame = Math.min(currentFrame, config.anim_size - 1);
      } else {
        currentFrame %= config.anim_size;
      }
      const path = config.anim_path + "/" + config.anim_prefix + "_" + currentFrame + "." + config.anim_ext;
      try {
        const img = await player2.getAssetImage(path);
        canvas.getContext("2d").drawImage(img, x4, y3);
        super.dropEvents(player2, [x4, y3, x4 + img.width, y3 + img.height]);
      } catch (e3) {
        player2.uiPause = true;
        throw e3;
      }
      this.renderCounter++;
    }
  };
  var ImageStatusWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      const type = this.config.type;
      let x4 = config.x, y3 = config.y;
      if (config.pos_x)
        x4 += config.pos_x;
      if (config.pos_y)
        y3 += config.pos_y;
      try {
        const img = await player2.getAssetImage(config.src);
        if (player2.getDeviceState(type, "boolean") === true) {
          canvas.getContext("2d").drawImage(img, x4, y3);
        }
        super.dropEvents(player2, [x4, y3, x4 + img.width, y3 + img.height]);
      } catch (e3) {
        return;
      }
    }
  };
  var ImageProgressWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const ctx = canvas.getContext("2d");
      let level = this.config.level;
      if (this.config.type) {
        level = Math.floor(player2.getDeviceState(this.config.type, "progress") * this.config.image_length);
      }
      for (let i3 = 0; i3 < level; i3++) {
        const img = await player2.getAssetImage(this.config.image_array[i3]);
        ctx.drawImage(img, this.config.x[i3], this.config.y[i3]);
      }
    }
  };
  var LevelWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const ctx = canvas.getContext("2d");
      let level = this.config.level;
      if (this.config.type) {
        let val = player2.getDeviceState(this.config.type, "progress");
        if (!val)
          val = 0;
        level = Math.floor(val * (this.config.image_length - 1));
      }
      const img = await player2.getAssetImage(this.config.image_array[level]);
      ctx.drawImage(img, this.config.x, this.config.y);
    }
  };

  // src/zepp_player/ui/DrawingWidgets.js
  var TextWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      config.alpha = void 0;
    }
    static drawText(config, player2) {
      const textSize = config.text_size ? config.text_size : 18;
      const fontConf = textSize + "px allfont";
      const colorConf = config.color ? zeppColorToHex(config.color) : "#000";
      const offsetX = config.char_space ? config.char_space : 0;
      let canvas = player2.newCanvas();
      let context = canvas.getContext("2d");
      context.textBaseline = "top";
      context.font = fontConf;
      let lines = [], preLines = config.text.toString().split("\n");
      let currentLine = -1, width, word, newLine, forceBreak;
      for (let i3 in preLines) {
        let data = preLines[i3];
        currentLine++;
        if (!lines[currentLine])
          lines[currentLine] = "";
        while (data !== "") {
          if (!lines[currentLine])
            lines[currentLine] = "";
          if (config.text_style === 3) {
            newLine = lines[currentLine] += data[0];
            width = context.measureText(newLine).width + offsetX * (newLine.length - 1);
            if (width < config.w - 20) {
              data = data.substring(1);
            } else {
              lines[currentLine] += "..";
              console.log(lines[currentLine]);
              data = "";
            }
          } else if (config.text_style >= 1) {
            forceBreak = false;
            if (config.text_style === 2) {
              word = data.indexOf(" ") >= 0 ? data.substring(0, data.indexOf(" ") + 1) : data;
            } else if (config.text_style === 1) {
              word = data[0];
            }
            newLine = lines[currentLine] + word;
            width = context.measureText(newLine).width + offsetX * (newLine.length - 1);
            if (width < config.w || lines[currentLine].length === 0) {
              while (context.measureText(word).width > config.w) {
                word = word.substring(0, word.length - 1);
              }
              lines[currentLine] += word;
              data = data.substring(word.length);
            } else {
              currentLine++;
            }
          } else {
            lines[currentLine] += data[0];
            data = data.substring(1);
          }
        }
      }
      let totalHeight = 0, px, maxWidth = 0;
      for (let i3 in lines) {
        let data = lines[i3];
        let lineCanvas = player2.newCanvas();
        let lineContext = lineCanvas.getContext("2d");
        lineContext.textBaseline = "top";
        lineContext.font = fontConf;
        let sizes = lineContext.measureText(data);
        lineCanvas.width = sizes.width + offsetX * data.length + 2;
        lineCanvas.height = textSize * 1.5;
        lineContext.textBaseline = "top";
        lineContext.fillStyle = colorConf;
        lineContext.font = fontConf;
        px = 0;
        for (let j4 in data) {
          lineContext.fillText(data[j4], px, textSize * 0.25);
          px += lineContext.measureText(data[j4]).width + offsetX;
        }
        lines[i3] = lineCanvas;
        maxWidth = Math.max(maxWidth, lineCanvas.width);
        totalHeight += lineCanvas.height + (config.line_space ? config.line_space : 0);
      }
      if (config._metricsOnly)
        return {
          height: totalHeight,
          width: maxWidth
        };
      canvas.width = config.w;
      canvas.height = config.h;
      if (!canvas.height)
        canvas.height = totalHeight;
      if (!canvas.width)
        canvas.width = maxWidth;
      let py = 0;
      if (config.align_v === "center_v")
        py = (canvas.height - totalHeight) / 2;
      if (config.align_v === "bottom")
        py = canvas.height - totalHeight;
      for (let i3 in lines) {
        let lineCanvas = lines[i3];
        let px2 = 0;
        if (config.align_h === "center_h")
          px2 = Math.max(0, (config.w - lineCanvas.width) / 2);
        if (config.align_h === "right")
          px2 = Math.max(0, config.w - lineCanvas.width);
        if (!config.text_style && maxWidth > config.w) {
          const progress = (player2.render_counter + 100) % 300 / 100;
          const w4 = maxWidth + config.w;
          if (progress < 1)
            px2 += (1 - progress) * w4;
          else if (progress > 2)
            px2 -= (progress - 2) * w4;
          player2.refresh_required = "text_scroll";
        }
        context.drawImage(lineCanvas, px2, py);
        py += lineCanvas.height + (config.line_space ? config.line_space : 0);
      }
      return canvas;
    }
    async render(canvas, player2) {
      const config = this.config;
      let width = config.w, height = config.h;
      if (config.text) {
        const text2 = await TextWidget.drawText(config, player2);
        canvas.getContext("2d").drawImage(text2, config.x, config.y);
        width = text2.width;
        height = text2.height;
      }
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + width,
        config.y + height
      ]);
    }
  };
  var CircleWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = zeppColorToHex(config.color);
      ctx.beginPath();
      ctx.arc(config.center_x, config.center_y, config.radius, 0, Math.PI * 2);
      ctx.fill();
      this.dropEvents(player2, [
        config.center_x - config.radius,
        config.center_y - config.radius,
        config.center_x + config.radius,
        config.center_y + config.radius
      ]);
    }
  };
  var FillRectWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      this.mode = "fill";
      config.alpha = void 0;
    }
    static draw(canvas, config, mode, player2) {
      const img = player2.newCanvas();
      img.width = config.w;
      img.height = config.h;
      const ctx = img.getContext("2d");
      const color = config.color ? config.color : 0;
      const round = Math.floor(Math.min(config.radius ? config.radius : 0, Math.abs(config.h) / 2, Math.abs(config.w) / 2));
      ctx.fillStyle = zeppColorToHex(color);
      ctx.strokeStyle = zeppColorToHex(color);
      ctx.lineWidth = config.line_width ? config.line_width : 1;
      ctx.beginPath();
      FillRectWidget._makePath(ctx, config.w, config.h, 0, 0, round);
      ctx.fill();
      if (mode === "stroke") {
        ctx.beginPath();
        ctx.globalCompositeOperation = "destination-out";
        FillRectWidget._makePath(ctx, config.w - ctx.lineWidth * 2, config.h - ctx.lineWidth * 2, ctx.lineWidth, ctx.lineWidth, Math.max(0, round - ctx.lineWidth));
        ctx.fill();
      }
      const rad = config.angle % 180 / 180 * Math.PI;
      const b3 = Math.abs(config.w * Math.sin(rad)) + Math.abs(config.h * Math.cos(rad));
      const a3 = Math.abs(config.w * Math.cos(rad)) + Math.abs(config.h * Math.sin(rad));
      return ImageWidget.draw(img, canvas, player2, {
        x: config.x,
        y: config.y,
        w: config.w,
        h: config.h,
        pos_x: (a3 - config.w) / 2,
        pos_y: (b3 - config.h) / 2,
        center_x: config.w / 2 + (a3 - config.w) / 2,
        center_y: config.h / 2 + (b3 - config.h) / 2,
        angle: config.angle
      });
    }
    static _makePath(ctx, w4, h3, x4, y3, round) {
      ctx.moveTo(x4 + round, y3);
      ctx.lineTo(x4 + w4 - round, y3);
      ctx.arc(x4 + w4 - round, y3 + round, round, 3 * Math.PI / 2, 0);
      ctx.lineTo(x4 + w4, y3 + h3 - round);
      ctx.arc(x4 + w4 - round, y3 + h3 - round, round, 0, Math.PI / 2);
      ctx.lineTo(x4 + round, y3 + h3);
      ctx.arc(x4 + round, y3 + h3 - round, round, Math.PI / 2, Math.PI);
      ctx.lineTo(x4, y3 + round);
      ctx.arc(x4 + round, y3 + round, round, Math.PI, -Math.PI / 2);
    }
    async render(canvas, player2) {
      const config = this.config;
      config.w = Math.round(config.w);
      config.h = Math.round(config.h);
      if (config.w === 0 || config.h === 0)
        return;
      const box = FillRectWidget.draw(canvas, config, this.mode, player2);
      this.dropEvents(player2, box);
    }
  };
  var StrokeRectWidget = class extends FillRectWidget {
    constructor(config) {
      super(config);
      this.mode = "stroke";
      config.alpha = void 0;
    }
  };
  var ArcProgressWidget = class extends BaseWidget {
    static draw(canvas, level, config) {
      const len = (config.end_angle - config.start_angle) * level;
      if (len === 0)
        return;
      const ctx = canvas.getContext("2d");
      const width = config.line_width ? config.line_width : 1;
      const direction = config.end_angle - config.start_angle < 0;
      ctx.save();
      ctx.lineWidth = width;
      ctx.strokeStyle = zeppColorToHex(config.color);
      if (Math.abs(len) >= 360) {
        ctx.beginPath();
        ctx.arc(config.center_x, config.center_y, config.radius, config.start_angle * Math.PI, config.end_angle * Math.PI, direction);
        ctx.stroke();
        ctx.restore();
        return;
      }
      const dN = 90 * width / (Math.PI * config.radius) * (config.start_angle < config.end_angle ? -1 : 1);
      const isLargerThanDot = Math.abs(config.radius * len / 180 * Math.PI) > width;
      const getRadian = (len2) => (-90 + config.start_angle + len2) / 180 * Math.PI;
      ctx.beginPath();
      ctx.arc(config.center_x, config.center_y, config.radius, getRadian(-dN), getRadian(isLargerThanDot ? len + dN : -dN), direction);
      ctx.stroke();
      ctx.lineCap = "round";
      if (config.corner_flag !== 2 && config.corner_flag !== 3) {
        ctx.beginPath();
        ctx.arc(config.center_x, config.center_y, config.radius, getRadian(-dN), getRadian(-dN), direction);
        ctx.stroke();
      }
      if (config.corner_flag !== 1 && config.corner_flag !== 3 && isLargerThanDot) {
        ctx.beginPath();
        ctx.arc(config.center_x, config.center_y, config.radius, getRadian(len + dN), getRadian(len + dN), direction);
        ctx.stroke();
      }
      ctx.restore();
    }
    async render(canvas, player2) {
      const config = this.config;
      if (config.color === void 0)
        return;
      let level = config.level / 100;
      if (config.type)
        level = player2.getDeviceState(config.type, "progress");
      ArcProgressWidget.draw(canvas, level, config);
    }
  };
  var ArcWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      if (!config.color)
        return;
      const radius = config.radius ? config.radius : config.w / 2;
      ArcProgressWidget.draw(canvas, 1, {
        center_x: config.x + radius,
        center_y: config.y + radius,
        color: config.color,
        line_width: config.line_width ? config.line_width : 1,
        radius: radius - (config.line_width ? config.line_width / 2 : 1),
        start_angle: 90 + config.start_angle,
        end_angle: 90 + config.end_angle
      });
    }
  };

  // src/zepp_player/zepp_env/DeviceRuntimeCore.js
  var HmUtilsMock = class {
    constructor(runtime, currentAppContext) {
      __publicField(this, "Lang", class {
        constructor(a3) {
        }
      });
      this.runtime = runtime;
      this.currentAppContext = currentAppContext;
    }
    gettextFactory(table, lang, fallback) {
      let data = table[fallback];
      if (table[lang])
        data = table[lang];
      return (key) => data[key];
    }
    getLanguage() {
      return this.runtime.fullLanguage;
    }
    getPx() {
      return (v3) => v3;
    }
    measureTextWidth(text2, text_size) {
      const canvas = TextWidget.drawText({
        text: text2,
        text_size,
        _metricsOnly: true
      }, this.runtime);
      return canvas.width;
    }
  };
  var DeviceRuntimeCoreMock = class {
    constructor(runtime) {
      __publicField(this, "WidgetFactory", class {
        constructor(a1, a22, a3) {
        }
      });
      __publicField(this, "HmDomApi", class {
        constructor(a1, a22) {
        }
      });
      __publicField(this, "HmLogger", class {
        static getLogger(name) {
          return {
            log: (data) => console.log("hmLogger", "[" + name + "]", data)
          };
        }
      });
      this.runtime = runtime;
      this.HmUtils = new HmUtilsMock(runtime);
    }
    App(config) {
      const defTemplate = {
        __globals__: {},
        _options: config,
        onCreate: () => {
        }
      };
      return {
        ...defTemplate,
        ...config
      };
    }
    WatchFace(config) {
      return config;
    }
    Page(config) {
      return config;
    }
  };

  // src/zepp_player/zepp_env/HuamiFs.js
  var CONSTANT_FOLDER = 1;
  var HuamiFsMock = class {
    constructor(runtime) {
      __publicField(this, "O_RDONLY", 0);
      __publicField(this, "O_WRONLY", 0);
      __publicField(this, "O_RDWR", 0);
      __publicField(this, "O_APPEND", 1);
      __publicField(this, "O_CREAT", 2);
      __publicField(this, "O_EXCL", 0);
      __publicField(this, "O_TRUNC", 0);
      __publicField(this, "SEEK_SET", 0);
      this.runtime = runtime;
      const setters = ["SysProSetBool", "SysProSetInt64", "SysProSetDouble", "SysProSetChars"];
      const getters = ["SysProGetBool", "SysProGetInt64", "SysProGetDouble", "SysProGetChars"];
      for (let a3 in setters)
        this[setters[a3]] = this.SysProSetInt;
      for (let a3 in getters)
        this[getters[a3]] = this.SysProGetInt;
      const id = runtime.appConfig.app.appId.toString(16).padStart(8, "0").toUpperCase();
      const type = runtime.appConfig.app.appType;
      this.vfsPrefix = "/storage/js_" + type + "s/" + id + "/";
      this.vfs = runtime.vfs;
    }
    getFile(path) {
      if (!this.vfs[path]) {
        for (let key in this.vfs) {
          if (key.startsWith(path + "/"))
            return CONSTANT_FOLDER;
        }
      }
      return this.vfs[path];
    }
    parsePath(path) {
      const normalize2 = require_lib();
      if (path[0] !== "/")
        path = this.vfsPrefix + "assets/" + path;
      return normalize2(path);
    }
    newFile(path) {
      const data = new ArrayBuffer(0);
      this.vfs[path] = data;
      return data;
    }
    stat(path) {
      path = this.parsePath(path);
      const file = this.getFile(path);
      if (!file)
        return [null, -1];
      return [{
        mode: (file !== CONSTANT_FOLDER ? 32768 : 16384) + 511,
        size: file === CONSTANT_FOLDER ? 0 : file.byteLength,
        mtime: Date.now()
      }, 0];
    }
    stat_asset(path) {
      return this.stat(path);
    }
    open(path, flag) {
      path = this.parsePath(path);
      let f3 = this.getFile(path);
      if (!f3 && (flag & 2) !== 0) {
        f3 = this.newFile(path);
      }
      return { data: f3, flag, path, position: flag === 1 ? f3.length : 0, store: "appFs" };
    }
    open_asset(path, flag) {
      return this.open(path, flag);
    }
    seek(file, pos) {
      file.position = pos;
    }
    read(file, buffer, buffOffset, len) {
      const view = new Uint8Array(buffer);
      const { position } = file;
      const fileView = new Uint8Array(file.data);
      for (let i3 = 0; i3 < len; i3++) {
        view[buffOffset + i3] = fileView[position + i3];
      }
      file.position += len;
      return 0;
    }
    close() {
      return 0;
    }
    write(file, buf, buffOffset, len) {
      const view = new Uint8Array(buf);
      const { data, position } = file;
      if (position + len > data.byteLength) {
        const newBuffer = new ArrayBuffer(position + len);
        new Uint8Array(newBuffer).set(new Uint8Array(file.data));
        file.data = newBuffer;
        this.vfs[file.path] = newBuffer;
      }
      const fileView = new Uint8Array(file.data);
      for (let i3 = 0; i3 < len; i3++) {
        fileView[position + i3] = view[buffOffset + i3];
      }
      file.position += len;
      return 0;
    }
    remove(path) {
      delete this.vfs[path];
      return 0;
    }
    rename(path, dest) {
      const data = PersistentStorage.get("fs", path);
      PersistentStorage.set("fs", dest, data);
      PersistentStorage.del("fs", path);
      return 0;
    }
    mkdir() {
      return 0;
    }
    readdir(path) {
      const normalize2 = require_lib();
      path = normalize2(path);
      let content = [];
      if (path[path.length - 1] !== "/" && path !== "")
        path += "/";
      for (let a3 in this.vfs) {
        if (a3.startsWith(path)) {
          const fn2 = a3.substring(path.length).split("/")[0];
          if (content.indexOf(fn2) < 0)
            content.push(fn2);
        }
      }
      return [content, 0];
    }
    SysProGetInt(key) {
      return PersistentStorage.get("SysProRegistery", key);
    }
    SysProSetInt(key, val) {
      PersistentStorage.set("SysProRegistery", key, val);
    }
  };

  // src/zepp_player/zepp_env/HuamiSetting.js
  var LANG_VALUE_TABLE = [
    "zh-CN",
    "zh-TW",
    "en-US",
    "es-ES",
    "ru-RU",
    "ko-KR",
    "fr-FR",
    "de-DE",
    "id-ID",
    "pl-PL",
    "it-IT",
    "ja-JP",
    "th-TH",
    "ar-EG",
    "vi-VN",
    "pt-PT",
    "nl-NL",
    "tr-TR",
    "uk-UA",
    "iw-IL",
    "pt-BR",
    "ro-RO",
    "cs-CZ",
    "el-GR",
    "sr-RS",
    "ca-ES",
    "fi-FI",
    "nb-NO",
    "da-DK",
    "sv-SE",
    "hu-HU",
    "ms-MY",
    "sk-SK",
    "hi-IN"
  ];
  var HuamiSettingMock = class {
    constructor(runtime) {
      __publicField(this, "mockedProperties", [
        ["getScreenAutoBright", "setScreenAutoBright", true],
        ["getBrightness", "setBrightness", 90],
        ["setBrightScreenCancel", "setBrightScreen", 0],
        ["setScreenOff", "", true],
        ["getMileageUnit", "", 0],
        ["getDateFormat", "", 0],
        ["getWeightTarget", "", 50.5],
        ["getSleepTarget", "", 8 * 60],
        ["getWeightUnit", "", 0]
      ]);
      __publicField(this, "screen_type", {
        WATCHFACE: 1,
        AOD: 2,
        SETTINGS: 4,
        APP: 16
      });
      this.runtime = runtime;
      this.store = [];
      for (let a3 in this.mockedProperties) {
        this._spawnMockedProperty(...this.mockedProperties[a3]);
      }
    }
    _spawnMockedProperty(getter, setter, def) {
      this.store[getter] = def;
      this[getter] = () => this.store[getter];
      if (setter !== "")
        this[setter] = (val) => {
          console.info("[hmSettings]", getter, "=", val);
          this.runtime.onConsole("device", [setter, "=", val]);
          this.store[getter] = val;
          return 0;
        };
    }
    getLanguage() {
      if (LANG_VALUE_TABLE.indexOf(this.runtime.fullLanguage) < 0)
        return 2;
      return LANG_VALUE_TABLE.indexOf(this.runtime.fullLanguage);
    }
    getUserData() {
      return {
        age: 20,
        height: 180,
        weight: 55.5,
        gender: 0,
        nickName: "NotARobot",
        region: "ru"
      };
    }
    getDiskInfo() {
      return {
        total: 10314e4,
        free: 3013e4,
        app: 1442e3,
        watchface: 435e4,
        music: 0,
        system: 669e5
      };
    }
    getDeviceInfo() {
      return {
        width: this.runtime.profileData.screenWidth,
        height: this.runtime.profileData.screenHeight,
        screenShape: 1,
        deviceName: this.runtime.profileData.deviceName,
        keyNumber: 0,
        deviceSource: 0
      };
    }
    getTimeFormat() {
      return this.runtime.getDeviceState("AM_PM") === "hide" ? 1 : 0;
    }
    getScreenType() {
      return this.runtime.showLevel;
    }
    getDateFormat() {
      return 0;
    }
  };

  // src/zepp_player/ui/ApplicationWidgets.js
  var DelegateWidget = class extends BaseWidget {
    async render() {
    }
  };
  var _GroupWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      this.widgets = [];
      config.__content = this.widgets;
    }
    async render(canvas, player2) {
      const tempCanvas = player2.newCanvas();
      tempCanvas.width = this.config.w;
      tempCanvas.height = this.config.h;
      for (let i3 in this.widgets) {
        const widget = this.widgets[i3];
        widget.config.__eventOffsetX = this.config.x;
        widget.config.__eventOffsetY = this.config.y;
        await player2.renderWidget(widget, tempCanvas);
      }
      canvas.getContext("2d").drawImage(tempCanvas, this.config.x, this.config.y);
    }
    createWidget(type, config) {
      let Widget;
      if (!type) {
        Widget = MissingWidget;
      } else {
        Widget = new HuamiUIMock()._widget[type];
      }
      if (typeof config !== "object") {
        config = {};
      }
      if (_GroupWidget.banlist.indexOf(type) > -1) {
        this.runtime.onConsole("SystemWarning", ["You can't place", type, "into group"]);
        return null;
      }
      config.__widget = type;
      config.__id = (this.config.__id + 1 << 8) + this.widgets.length;
      config.__runtime = this.runtime;
      const i3 = new Widget(config);
      this.widgets.push(i3);
      this.config.__runtime.refresh_required = "add_widget_group";
      return i3;
    }
  };
  var GroupWidget = _GroupWidget;
  __publicField(GroupWidget, "banlist", [
    "WATCHFACE_EDIT_MASK",
    "WATCHFACE_EDIT_FG_MASK",
    "WATCHFACE_EDIT_BG",
    "WATCHFACE_EDIT_GROUP",
    "GROUP"
  ]);
  var StateButtonWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      this.addEventListener("onmouseup", () => {
        this.config.__radioGroup.setProperty("checked", this);
      });
    }
    async render(canvas, player2) {
      const groupConfig = this.config.__radioGroup.config;
      const src = groupConfig.checked === this ? groupConfig.select_src : groupConfig.unselect_src;
      const img = await player2.getAssetImage(src);
      const defaults = { x: 0, y: 0, w: img.width, h: img.height };
      const config = { ...defaults, ...this.config };
      canvas.getContext("2d").drawImage(img, config.x + groupConfig.x, config.y + groupConfig.y);
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + config.w,
        config.y + config.h
      ]);
    }
  };
  var RadioGroupWidget = class extends GroupWidget {
    constructor(config) {
      super(config);
      this.optIndex = 0;
    }
    setProperty(prop, val) {
      if (prop === "checked") {
        const { __radioGroup, __index } = val.config;
        this.config.check_func(__radioGroup, __index, true);
        this.runtime.refresh_required = "group_switch";
      }
      return super.setProperty(prop, val);
    }
    async render(canvas, player2) {
      for (let i3 in this.widgets) {
        const widget = this.widgets[i3];
        widget.config.__eventOffsetX = this.config.x;
        widget.config.__eventOffsetY = this.config.y;
        await player2.renderWidget(widget, canvas);
      }
    }
    createWidget(type, config) {
      if (type === "STATE_BUTTON") {
        config.__radioGroup = this;
        config.__index = this.optIndex;
        this.optIndex++;
      }
      return super.createWidget(type, config);
    }
  };

  // src/zepp_player/ui/DatetimeWidgets.js
  var DatePointer = class extends BaseWidget {
    constructor(config) {
      super(config);
    }
    async render(canvas, player2) {
      const config = this.config;
      let angle = 360 * player2.getDeviceState(config.type, "progress");
      const pointer = await player2.getAssetImage(config.src);
      ImageWidget.draw(pointer, canvas, player2, {
        x: 0,
        y: 0,
        w: canvas.width,
        h: canvas.height,
        center_x: config.center_x,
        center_y: config.center_y,
        pos_x: config.center_x - config.posX,
        pos_y: config.center_y - config.posY,
        angle
      });
      if (config.cover_path) {
        const cover = await player2.getAssetImage(config.cover_path);
        ImageWidget.draw(cover, player2, canvas, {
          x: config.cover_x,
          y: config.cover_y
        });
      }
    }
  };
  var TimePointer = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      const hourProgress = player2.getDeviceState("HOUR", "pointer_progress");
      const minuteProgress = player2.getDeviceState("MINUTE", "pointer_progress");
      const secondProgress = player2.getDeviceState("SECOND", "pointer_progress");
      const data = [
        ["hour_", hourProgress + minuteProgress / 12],
        ["minute_", minuteProgress + secondProgress / 60],
        ["second_", secondProgress]
      ];
      for (let i3 in data) {
        const [prefix, value] = data[i3];
        let img;
        if (config[prefix + "path"]) {
          img = await player2.getAssetImage(config[prefix + "path"]);
          ImageWidget.draw(img, canvas, player2, {
            x: 0,
            y: 0,
            w: canvas.width,
            h: canvas.height,
            center_x: config[prefix + "centerX"],
            center_y: config[prefix + "centerY"],
            pos_x: config[prefix + "centerX"] - config[prefix + "posX"],
            pos_y: config[prefix + "centerY"] - config[prefix + "posY"],
            angle: 360 * value
          });
        }
        if (config[prefix + "cover_path"] && config[prefix + "cover_y"] && config[prefix + "cover_x"]) {
          img = await player2.getAssetImage(config[prefix + "cover_path"]);
          ImageWidget.draw(img, canvas, player2, {
            x: config[prefix + "cover_x"],
            y: config[prefix + "cover_y"]
          });
        }
      }
    }
  };
  var TimeWidget = class extends BaseWidget {
    async render(canvas, runtime) {
      const config = this.config;
      const ctx = canvas.getContext("2d");
      const timeParts = [
        ["hour_", "HOUR"],
        ["minute_", "MINUTE"],
        ["second_", "SECOND"]
      ];
      let images = [];
      for (let i3 in timeParts) {
        let [prefix, value] = timeParts[i3];
        if (!config[prefix + "array"])
          continue;
        value = runtime.getDeviceState(value, "string");
        if (config[prefix + "zero"] > 0)
          value = value.padStart(2, "0");
        let basementImg;
        try {
          basementImg = await runtime.getAssetImage(config[prefix + "array"][0]);
        } catch (e3) {
          continue;
        }
        let img;
        try {
          img = await TextImageWidget.draw(runtime, value, 0, {
            font_array: config[prefix + "array"],
            h_space: config[prefix + "space"],
            unit_sc: config[prefix + "unit_sc"],
            unit_tc: config[prefix + "unit_tc"],
            unit_en: config[prefix + "unit_en"],
            align: config[prefix + "align"]
          });
        } catch (e3) {
          console.warn(e3);
          continue;
        }
        if (img === null)
          continue;
        if (config[prefix + "follow"] > 0) {
          let [lastImg, lastPrefix, expectedWidth] = images.pop();
          let offset = config[lastPrefix + "space"];
          if (!offset)
            offset = 0;
          const combinedImg = runtime.newCanvas();
          combinedImg.width = lastImg.width + img.width;
          combinedImg.height = Math.max(lastImg.height, img.height);
          const cctx = combinedImg.getContext("2d");
          cctx.drawImage(lastImg, 0, 0);
          cctx.drawImage(img, lastImg.width, 0);
          expectedWidth += 2 * (basementImg.width + offset);
          if (config[prefix + "unit_en"]) {
            let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
            expectedWidth += unit.width;
          }
          images.push([combinedImg, lastPrefix, expectedWidth]);
        } else {
          let offset = config[prefix + "space"];
          if (!offset)
            offset = 0;
          let expectedWidth = 2 * (basementImg.width + offset);
          if (config[prefix + "unit_en"]) {
            try {
              let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
              expectedWidth += unit.width;
            } catch (e3) {
            }
          }
          images.push([img, prefix, expectedWidth]);
        }
      }
      for (let i3 in images) {
        const [img, prefix, expWidth] = images[i3];
        let x4 = config[prefix + "startX"];
        let y3 = config[prefix + "startY"];
        let px = 0;
        switch (config[prefix + "align"]) {
          case "center_h":
            px = Math.max(0, (expWidth - img.width) / 2);
            break;
          case "right":
            px = expWidth - img.width;
        }
        ctx.drawImage(img, x4 + px, y3);
      }
      const ampmState = runtime.getDeviceState("AM_PM");
      const lang = runtime.language;
      const ampmData = ["am", "pm"];
      for (let i3 in ampmData) {
        let value = ampmData[i3];
        let prefix = value + "_", langPrefix = prefix + lang + "_";
        if (config[langPrefix + "path"] && ampmState === value) {
          const img = await runtime.getAssetImage(config[langPrefix + "path"]);
          ctx.drawImage(img, config[prefix + "x"], config[prefix + "y"]);
        }
      }
      this.dropEvents(runtime, [
        0,
        0,
        canvas.width,
        canvas.height
      ]);
    }
  };
  var DateWidget = class extends BaseWidget {
    async render(canvas, runtime) {
      const ctx = canvas.getContext("2d");
      const lang = runtime.language;
      const config = this.config;
      const data = [
        ["year_", runtime.getDeviceState("YEAR", "string"), 2],
        ["month_", runtime.getDeviceState("MONTH", "string"), 2],
        ["day_", runtime.getDeviceState("DAY", "string"), 2]
      ];
      if (config.year_zero) {
        data[0][1] = "20" + data[0][1];
        data[0][2] = 4;
      }
      let images = [];
      for (let i4 in data) {
        let [prefix, value, fullLength] = data[i4];
        if (!config[prefix + lang + "_array"])
          continue;
        const imgs = config[prefix + lang + "_array"];
        let basementImg;
        try {
          basementImg = await runtime.getAssetImage(imgs[0]);
        } catch (e3) {
          continue;
        }
        let img = null;
        if (config[prefix + "is_character"]) {
          try {
            img = await runtime.getAssetImage(imgs[value - 1]);
          } catch (e3) {
            continue;
          }
        } else {
          value = value.toString();
          if (config[prefix + "zero"]) {
            value = value.padStart(fullLength, "0");
          }
          try {
            img = await TextImageWidget.draw(runtime, value, 0, {
              font_array: config[prefix + lang + "_array"],
              h_space: config[prefix + "space"],
              unit_sc: config[prefix + "unit_sc"],
              unit_tc: config[prefix + "unit_tc"],
              unit_en: config[prefix + "unit_en"],
              align: config[prefix + "align"]
            });
          } catch (e3) {
            console.warn(e3);
            continue;
          }
        }
        if (!img)
          continue;
        if (config[prefix + "follow"] > 0 && images.length > 0) {
          let [lastImg, lastPrefix, expectedWidth] = images.pop();
          let offset = config[lastPrefix + "space"];
          if (!offset)
            offset = 0;
          const combinedImg = runtime.newCanvas();
          combinedImg.width = lastImg.width + img.width + offset;
          combinedImg.height = Math.max(lastImg.height, img.height);
          const cctx = combinedImg.getContext("2d");
          cctx.drawImage(lastImg, 0, 0);
          cctx.drawImage(img, lastImg.width + offset, 0);
          expectedWidth += fullLength * (basementImg.width + offset);
          if (config[prefix + "unit_en"]) {
            let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
            expectedWidth += unit.width;
          }
          images.push([combinedImg, lastPrefix, expectedWidth]);
        } else {
          let offset = config[prefix + "space"];
          if (!offset)
            offset = 0;
          let expectedWidth = fullLength * (basementImg.width + offset);
          if (config[prefix + "unit_en"]) {
            let unit = await runtime.getAssetImage(config[prefix + "unit_en"]);
            expectedWidth += unit.width;
          }
          images.push([img, prefix, expectedWidth]);
        }
      }
      for (var i3 in images) {
        const [img, prefix, expWidth] = images[i3];
        let x4 = config[prefix + "startX"];
        let y3 = config[prefix + "startY"];
        let px = 0;
        switch (config[prefix + "align"]) {
          case "center_h":
            px = Math.max(0, (expWidth - img.width) / 2);
            break;
          case "right":
            px = expWidth - img.width;
        }
        ctx.drawImage(img, x4 + px, y3);
        this.dropEvents(runtime, [
          x4,
          y3,
          x4 + img.width,
          y3 + img.height
        ]);
      }
    }
  };
  var WeekdayWidget = class extends BaseWidget {
    async render(canvas, runtime) {
      const config = this.config;
      let val = runtime.getDeviceState("WEEKDAY");
      if (!val || val < 0)
        val = 0;
      let font = config["week_" + runtime.language];
      if (!font || val >= font.length)
        return;
      try {
        const img = await runtime.getAssetImage(font[val]);
        canvas.getContext("2d").drawImage(img, config.x, config.y);
        this.dropEvents(runtime, [
          config.x,
          config.y,
          config.x + img.width,
          config.y + img.height
        ]);
      } catch (e3) {
      }
    }
  };

  // src/zepp_player/ui/EditableWatchfaceWidgets.js
  var BaseEditableWidget = class extends BaseWidget {
    zp_isActive() {
      return PersistentStorage.get("wfEdit", "focus") === this.config.edit_id;
    }
    zp_setActive() {
      PersistentStorage.set("wfEdit", "focus", this.config.edit_id);
      this.runtime.refresh_required = "edit";
    }
    getProperty(key, second) {
      if (key === "current_type" && this.runtime.showLevel === 4)
        return -1;
      return super.getProperty(key, second);
    }
  };
  var EditableBackground = class extends BaseEditableWidget {
    constructor(config) {
      super(config);
      config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
      if (config.current_type === null || config.current_type === void 0)
        config.current_type = config.default_id;
      this.addEventListener("onmouseup", () => {
        if (this.runtime.showLevel !== 4)
          return;
        if (!this.zp_isActive())
          return this.zp_setActive();
        this._switch();
      });
    }
    _findCurrent() {
      const id = this.config.current_type;
      for (let i3 in this.config.bg_config) {
        i3 = parseInt(i3);
        if (this.config.bg_config[i3].id === id) {
          return i3;
        }
      }
      return this.config.default_id;
    }
    _switch() {
      const i3 = this._findCurrent();
      const nextIndex = (i3 + 1) % this.config.bg_config.length;
      const val = this.config.bg_config[nextIndex].id;
      PersistentStorage.set("wfEdit", this.config.edit_id, val);
      this.config.current_type = val;
      this.runtime.refresh_required = "edit";
    }
    async render(canvas, player2) {
      const config = this.config;
      const ctx = canvas.getContext("2d");
      const data = this.config.bg_config[this._findCurrent()];
      if (this.runtime.showLevel === 4) {
        const img = await player2.getAssetImage(data.preview);
        const fg = await player2.getAssetImage(config.fg);
        const eventsZone = ImageWidget.draw(img, canvas, player2, config);
        ImageWidget.draw(fg, canvas, player2, config);
        if (this.zp_isActive())
          player2.addPostRenderTask(async () => {
            const tips = await player2.getAssetImage(config.tips_bg);
            ImageWidget.draw(tips, canvas, player2, {
              x: config.tips_x,
              y: config.tips_y
            });
            const textImg = await TextWidget.drawText({
              color: 0,
              text: `Background ${data.id}/${config.count}`,
              text_size: 18,
              w: tips.width,
              h: tips.height,
              align_h: "center_h",
              align_v: "center_v"
            }, player2);
            ctx.drawImage(textImg, config.x + config.tips_x, config.y + config.tips_y);
          });
        this.dropEvents(player2, eventsZone);
      } else {
        const img = await player2.getAssetImage(data.path);
        ImageWidget.draw(img, canvas, player2, config);
      }
    }
  };
  var EditPointerWidget = class extends BaseEditableWidget {
    constructor(config) {
      super(config);
      config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
      if (config.current_type === null || config.current_type === void 0)
        config.current_type = config.default_id;
      this.addEventListener("onmouseup", () => {
        if (!this.zp_isActive())
          return this.zp_setActive();
        this._switch();
      });
    }
    _switch() {
      const currentType = this.config.current_type;
      for (let i3 = 0; i3 < this.config.count; i3++) {
        if (this.config.config[i3].id === currentType) {
          const nextIndex = (i3 + 1) % this.config.count;
          const val = this.config.config[nextIndex];
          PersistentStorage.set("wfEdit", this.config.edit_id, val.id);
          this.config.current_type = val.id;
          this.runtime.refresh_required = "edit";
          return;
        }
      }
    }
    _findCurrent() {
      const id = this.config.current_type;
      for (let i3 = 0; i3 < this.config.count; i3++) {
        if (this.config.config[i3].id === id) {
          return i3;
        }
      }
      return -1;
    }
    getProperty(key, second) {
      if (key === "current_config") {
        if (this.runtime.showLevel === 4)
          return {};
        const i3 = this._findCurrent();
        const data = this.config.config[i3];
        const config = {};
        for (const key2 of ["hour", "minute", "second"]) {
          if (!data[key2])
            continue;
          for (const prop in data[key2]) {
            config[`${key2}_${prop}`] = data[key2][prop];
          }
        }
        return config;
      }
      return super.getProperty(key, second);
    }
    async render(canvas, runtime) {
      if (runtime.showLevel !== 4)
        return;
      const config = this.config;
      const ctx = canvas.getContext("2d");
      const i3 = this._findCurrent();
      const preview = await runtime.getAssetImage(config.config[i3].preview);
      ctx.drawImage(preview, config.x, config.y);
      try {
        const fg = await runtime.getAssetImage(config.fg);
        ctx.drawImage(fg, config.x, config.y);
      } catch (e3) {
      }
      if (this.zp_isActive())
        runtime.addPostRenderTask(async () => {
          const tips = await player.getAssetImage(config.tips_bg);
          ImageWidget.draw(tips, canvas, player, {
            x: config.tips_x,
            y: config.tips_y
          });
          const textImg = await TextWidget.drawText({
            color: 0,
            text: `Pointers ${i3 + 1}/${config.count}`,
            text_size: 18,
            w: tips.width,
            h: tips.height,
            align_h: "center_h",
            align_v: "center_v"
          }, player);
          ctx.drawImage(textImg, config.x + config.tips_x, config.y + config.tips_y);
        });
      const boxWidth = Math.min(preview.width, 100);
      const boxHeight = Math.min(preview.height, 100);
      this.dropEvents(runtime, [
        config.x + (preview.width - boxWidth) / 2,
        config.y + (preview.height - boxHeight) / 2,
        config.x + (preview.width - boxWidth) / 2 + boxWidth,
        config.y + (preview.height - boxHeight) / 2 + boxHeight
      ]);
    }
  };
  var EditGroupWidget = class extends BaseEditableWidget {
    get _renderStage() {
      if (this.runtime.showLevel !== 4)
        return "";
      return this.zp_isActive() ? "toplevel" : "postReverse";
    }
    constructor(config) {
      super(config);
      config.current_type = PersistentStorage.get("wfEdit", config.edit_id);
      if (config.current_type === null || config.current_type === void 0) {
        config.current_type = config.default_type;
        PersistentStorage.set("wfEdit", config.edit_id, config.default_type);
      }
      this.addEventListener("onmouseup", () => {
        if (!this.zp_isActive())
          return this.zp_setActive();
        this._switch();
      });
    }
    async render(canvas, player2) {
      if (player2.showLevel !== 4)
        return;
      const config = this.config;
      const ctx = canvas.getContext("2d");
      const isActive = this.zp_isActive();
      const currentType = config.current_type;
      let width = config.w ? config.w : 0;
      let height = config.h ? config.h : 0;
      let preview = null, text2 = "";
      for (let i3 = 0; i3 < config.count; i3++) {
        const option = config.optional_types[i3];
        if (option.type === currentType) {
          preview = option.preview;
          text2 = option.title_en;
        }
      }
      try {
        preview = await player2.getAssetImage(preview);
        if (width === 0)
          width = preview.width;
        if (height === 0)
          height = preview.height;
        const ox = (width - preview.width) / 2;
        const oy = (height - preview.height) / 2;
        ctx.drawImage(preview, config.x + ox, config.y + oy);
      } catch (e3) {
      }
      let dx = config.x, dy = config.y;
      try {
        const overlay = await player2.getAssetImage(isActive ? config.select_image : config.un_select_image);
        ctx.drawImage(overlay, config.x, config.y);
      } catch (e3) {
      }
      if (isActive)
        player2.addPostRenderTask(async () => {
          let tipsBg;
          try {
            tipsBg = await player2.getAssetImage(config.tips_BG);
          } catch (e3) {
            return;
          }
          const tipsImg = player2.newCanvas();
          tipsImg.width = config.tips_width;
          tipsImg.height = tipsBg.height;
          const tipsCtx = tipsImg.getContext("2d");
          tipsCtx.drawImage(tipsBg, 0, 0);
          if (text2) {
            const textImg = await TextWidget.drawText({
              color: 0,
              text: text2,
              text_size: 18,
              w: config.tips_width - config.tips_margin * 2,
              h: tipsBg.height,
              align_h: "center_h",
              align_v: "center_v"
            }, player2);
            tipsCtx.drawImage(textImg, config.tips_margin, 0);
          }
          ctx.drawImage(tipsImg, dx + config.tips_x, dy + config.tips_y);
        });
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + width,
        config.y + height
      ]);
    }
    _switch() {
      const currentType = this.config.current_type;
      for (let i3 = 0; i3 < this.config.count; i3++) {
        if (this.config.optional_types[i3].type === currentType) {
          const nextIndex = (i3 + 1) % this.config.count;
          const val = this.config.optional_types[nextIndex];
          PersistentStorage.set("wfEdit", this.config.edit_id, val.type);
          this.config.current_type = val.type;
          this.runtime.render_counter = 0;
          this.runtime.refresh_required = "edit";
          return;
        }
      }
    }
  };

  // src/zepp_player/ui/FormWidgets.js
  var ButtonWidget = class extends BaseWidget {
    constructor(config) {
      super(config);
      this.pressed = false;
      config.alpha = void 0;
      this.addEventListener("onmousedown", () => {
        this.pressed = true;
        config.__runtime.refresh_required = "button";
      });
      this.addEventListener("onmouseup", (info) => {
        this.pressed = false;
        config.__runtime.refresh_required = "button";
        if (config.click_func)
          config.click_func(this);
      });
      this.addEventListener = () => {
      };
    }
    async render(canvas, player2) {
      const config = this.config;
      const w4 = config.w ? config.w : 0;
      const h3 = config.h ? config.h : 0;
      if (config.press_src && config.normal_src) {
        const src = this.pressed ? config.press_src : config.normal_src;
        const img = await player2.getAssetImage(src);
        ImageWidget.draw(img, canvas, player2, {
          x: config.x + Math.max(0, (w4 - img.width) / 2),
          y: config.y + Math.max(0, (h3 - img.height) / 2)
        });
      } else {
        const normalColor = config.normal_color ? zeppColorToHex(config.normal_color) : "#000000";
        const pressedColor = config.press_color ? zeppColorToHex(config.press_color) : "#CCCCCC";
        const color = this.pressed ? pressedColor : normalColor;
        FillRectWidget.draw(canvas, {
          ...config,
          color
        }, "fill", player2);
      }
      const textLayer = await TextWidget.drawText({
        ...config,
        align_h: "center_h",
        align_v: "center_v",
        color: config.color !== void 0 ? config.color : 16777215
      }, player2);
      canvas.getContext("2d").drawImage(textLayer, config.x, config.y);
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + config.w,
        config.y + config.h
      ]);
    }
  };

  // src/zepp_player/ui/HistogramWidget.js
  var HistogramWidget = class extends BaseWidget {
    async render(canvas, player2) {
      const config = this.config;
      const internalCanvas = player2.newCanvas();
      internalCanvas.width = config.w;
      internalCanvas.height = config.h;
      await this.drawBg(internalCanvas, player2);
      await this.drawData(internalCanvas, player2);
      canvas.getContext("2d").drawImage(internalCanvas, config.x, config.y);
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + config.w,
        config.y + config.h
      ]);
    }
    async drawData(canvas, player2) {
      const config = this.config;
      const ctx = canvas.getContext("2d");
      const height = config.item_max_height ? config.item_max_height : config.h;
      const dataHeight = config.data_max_value - config.data_min_value;
      ctx.fillStyle = zeppColorToHex(config.item_color);
      let x4 = 0;
      for (let i3 = 0; i3 < config.data_count; i3++) {
        const perc = Math.max(0, config.data_array[i3] - config.data_min_value) / dataHeight;
        const lineHeight = perc * height;
        ctx.fillRect(x4, height - lineHeight, config.item_width, lineHeight);
        x4 += config.item_width + config.item_space;
      }
    }
    async drawBg(canvas, player2) {
      const ctx = canvas.getContext("2d");
      const xline = this.config.xline;
      ctx.strokeStyle = zeppColorToHex(xline.color !== void 0 ? xline.color : 16777215);
      ctx.lineWidth = xline.width ? xline.width : 1;
      let x4 = xline.pading;
      while (x4 < canvas.width) {
        ctx.beginPath();
        ctx.moveTo(x4, xline.start);
        ctx.lineTo(x4, xline.end);
        ctx.stroke();
        x4 += xline.space;
      }
      const yline = this.config.yline;
      ctx.strokeStyle = zeppColorToHex(yline.color !== void 0 ? yline.color : 16777215);
      ctx.lineWidth = yline.width ? yline.width : 1;
      let y3 = yline.pading;
      while (y3 < canvas.height) {
        ctx.beginPath();
        ctx.moveTo(yline.start, y3);
        ctx.lineTo(yline.end, y3);
        ctx.stroke();
        y3 += yline.space;
      }
      const xText = this.config.xText;
      for (let i3 = 0; i3 < xText.count; i3++) {
        let cw = await TextWidget.drawText({
          text: xText.data_array[i3],
          align_h: xText.align,
          color: xText.color,
          w: xText.w,
          h: xText.h,
          text_size: 18
        }, player2);
        ctx.drawImage(cw, xText.x + (xText.space + xText.w) * i3, xText.y);
      }
      const yText = this.config.yText;
      for (let i3 = 0; i3 < yText.count; i3++) {
        let cw = await TextWidget.drawText({
          text: yText.data_array[i3],
          align_h: yText.align,
          color: yText.color,
          w: yText.w,
          h: yText.h,
          text_size: 18
        }, player2);
        ctx.drawImage(cw, yText.x, yText.y + (yText.space + yText.h) * i3);
      }
    }
  };

  // src/zepp_player/ui/ScrollList.js
  var ScrollList = class extends BaseWidget {
    constructor(conf) {
      super(conf);
      this.scrollY = 0;
      this.isMouseDown = false;
      this.lastScrollY = 0;
      this.mouseStartEv = {};
      this.innerHeight = 0;
      this.addEventListener("onmouseup", (e3) => this.eventUp(e3));
      this.addEventListener("onmousedown", (e3) => this.eventDown(e3));
      this.addEventListener("onmousemove", (e3) => this.eventMove(e3));
    }
    async render(canvas, player2) {
      const config = this.config;
      const view = player2.newCanvas();
      view.width = config.w;
      view.height = config.h;
      let posY = this.scrollY, dtc, ic;
      for (let i3 = 0; i3 < config.data_type_config_count; i3++) {
        dtc = config.data_type_config[i3];
        ic = this._getItemType(dtc.type_id);
        for (let j4 = dtc.start; j4 <= dtc.end; j4++) {
          posY += await this._drawLine(ic, j4, posY, view, player2);
        }
      }
      this.innerHeight = posY - this.scrollY;
      canvas.getContext("2d").drawImage(view, config.x, config.y);
      this.dropEvents(player2, [
        config.x,
        config.y,
        config.x + config.w,
        config.y + config.h
      ]);
    }
    _getItemType(type_id) {
      for (let i3 = 0; i3 < this.config.item_config_count; i3++) {
        if (this.config.item_config[i3].type_id === type_id)
          return this.config.item_config[i3];
      }
      throw new Error("TypeID " + type_id + " missing");
    }
    async _drawLine(ic, index, posY, canvas, player2) {
      const config = this.config;
      const item = config.data_array[index];
      const ctx = canvas.getContext("2d");
      FillRectWidget.draw(canvas, {
        x: 0,
        y: posY,
        w: config.w,
        h: ic.item_height,
        color: ic.item_bg_color,
        radius: ic.item_bg_radius
      }, "fill", player2);
      for (let i3 = 0; i3 < ic.text_view_count; i3++) {
        const tv = ic.text_view[i3];
        const cnv = TextWidget.drawText({
          ...tv,
          text: item[tv.key],
          align_h: "center_h",
          align_v: "center_v"
        }, player2);
        ctx.drawImage(cnv, tv.x, posY + tv.y);
      }
      for (let i3 = 0; i3 < ic.image_view_count; i3++) {
        try {
          const iv = ic.image_view[i3];
          const img = await player2.getAssetImage(item[iv.key]);
          ImageWidget.draw(img, canvas, player2, {
            x: iv.x,
            y: iv.y + posY
          });
        } catch (e3) {
        }
      }
      return ic.item_height + config.item_space;
    }
    eventUp(e3) {
      this.isMouseDown = false;
      if (this.lastScrollY === this.scrollY) {
        this.handleClick(e3);
      }
      const lim = this.innerHeight - this.config.h;
      if (this.scrollY < -lim)
        this.scrollY = -lim;
      if (this.scrollY > 0)
        this.scrollY = 0;
      this.runtime.refresh_required = "scroll";
    }
    eventDown(e3) {
      this.mouseStartEv = e3;
      this.lastScrollY = this.scrollY;
      this.isMouseDown = true;
    }
    handleClick(e3) {
      const config = this.config;
      const clickY = e3.y - config.y;
      let posY = this.scrollY;
      for (let i3 = 0; i3 < config.data_type_config_count; i3++) {
        const dtc = config.data_type_config[i3];
        const ic = this._getItemType(dtc.type_id);
        for (let j4 = dtc.start; j4 <= dtc.end; j4++) {
          if (clickY > posY && clickY < posY + ic.item_height) {
            config.item_click_func(config.data_array, j4);
            return;
          }
          posY += ic.item_height + config.item_space;
        }
      }
    }
    eventMove(e3) {
      if (!this.isMouseDown)
        return;
      if (Math.abs(e3.y - this.mouseStartEv.y) < 5)
        return;
      const delta = e3.y - this.mouseStartEv.y + this.lastScrollY;
      this.scrollY = delta;
      this.runtime.refresh_required = "scroll";
    }
  };

  // src/zepp_player/ui/HuamiUI.js
  var HuamiUIMock = class {
    constructor(runtime) {
      __publicField(this, "_idCounter", 0);
      __publicField(this, "_widget", {
        IMG: ImageWidget,
        IMG_POINTER: PointerWidget,
        IMG_STATUS: ImageStatusWidget,
        TEXT_IMG: TextImageWidget,
        IMG_PROGRESS: ImageProgressWidget,
        IMG_LEVEL: LevelWidget,
        IMG_ANIM: AnimationWidget,
        GROUP: GroupWidget,
        FILL_RECT: FillRectWidget,
        STROKE_RECT: StrokeRectWidget,
        IMG_WEEK: WeekdayWidget,
        IMG_TIME: TimeWidget,
        IMG_DATE: DateWidget,
        ARC_PROGRESS: ArcProgressWidget,
        ARC: ArcWidget,
        WATCHFACE_EDIT_MASK: ImageWidget,
        WATCHFACE_EDIT_FG_MASK: ImageWidget,
        WATCHFACE_EDIT_BG: EditableBackground,
        WATCHFACE_EDIT_GROUP: EditGroupWidget,
        WATCHFACE_EDIT_POINTER: EditPointerWidget,
        TIME_POINTER: TimePointer,
        DATE_POINTER: DatePointer,
        IMG_CLICK: ClickableImageWidget,
        WIDGET_DELEGATE: DelegateWidget,
        TEXT: TextWidget,
        CIRCLE: CircleWidget,
        BUTTON: ButtonWidget,
        HISTOGRAM: HistogramWidget,
        SCROLL_LIST: ScrollList,
        RADIO_GROUP: RadioGroupWidget,
        STATE_BUTTON: StateButtonWidget
      });
      __publicField(this, "prop", {
        VISIBLE: "visible",
        ANIM_STATUS: "anim_status",
        ANGLE: "angle",
        SRC: "src",
        CURRENT_TYPE: "current_type",
        CURRENT_CONFIG: "current_config",
        MORE: "more",
        ANIM: "more",
        UPDATE_DATA: "more",
        X: "x",
        Y: "y",
        W: "w",
        H: "h",
        POS_X: "pos_x",
        POS_Y: "pos_y",
        CENTER_X: "center_x",
        CENTER_Y: "center_y",
        TEXT: "text",
        TEXT_SIZE: "text_size",
        COLOR: "color",
        RADIUS: "radius",
        START_ANGLE: "start_angle",
        END_ANGLE: "end_angle",
        LINE_WIDTH: "line_width",
        WORD_WRAP: "word_wrap",
        DATASET: "dataset",
        INIT: "checked",
        CHECKED: "checked",
        CURRENT_SELECT: "checked"
      });
      __publicField(this, "show_level", {
        ONLY_NORMAL: 1,
        ONLY_AOD: 2,
        ONAL_AOD: 2,
        ONLY_EDIT: 4,
        ALL: 1 | 2 | 4
      });
      __publicField(this, "align", {
        LEFT: "left",
        RIGHT: "right",
        CENTER_H: "center_h",
        CENTER_V: "center_v",
        TOP: "top",
        BOTTOM: "bottom"
      });
      __publicField(this, "date", {
        MONTH: "MONTH",
        DAY: "DAY",
        YEAR: "YEAR",
        WEEK: "WEEKDAY"
      });
      __publicField(this, "event", {
        CLICK_DOWN: "onmousedown",
        CLICK_UP: "onmouseup",
        MOVE: "onmousemove",
        SELECT: "onmouseup"
      });
      __publicField(this, "text_style", {
        WRAP: 2,
        CHAR_WRAP: 2,
        ELLIPSIS: 3,
        NONE: 0
      });
      __publicField(this, "system_status", {
        CLOCK: "ALARM_CLOCK",
        DISCONNECT: "DISCONNECT",
        DISTURB: "DISTURB",
        LOCK: "LOCK"
      });
      __publicField(this, "anim_status", {
        START: 1,
        PAUSE: 0,
        RESUME: 1,
        STOP: 0
      });
      __publicField(this, "data_type", {
        "BATTERY": "BATTERY",
        "STEP": "STEP",
        "STEP_TARGET": "STEP_TARGET",
        "CAL": "CAL",
        "CAL_TARGET": "CAL_TARGET",
        "HEART": "HEART",
        "PAI_DAILY": "PAI_DAILY",
        "PAI_WEEKLY": "PAI_WEEKLY",
        "DISTANCE": "DISTANCE",
        "STAND": "STAND",
        "STAND_TARGET": "STAND_TARGET",
        "WEATHER": "WEATHER_CURRENT",
        "WEATHER_CURRENT": "WEATHER_CURRENT",
        "WEATHER_LOW": "WEATHER_LOW",
        "WEATHER_HIGH": "WEATHER_HIGH",
        "UVI": "UVI",
        "AQI": "AQI",
        "HUMIDITY": "HUMIDITY",
        "ACTIVITY": "ACTIVITY",
        "ACTIVITY_TARGET": "ACTIVITY_TARGET",
        "FAT_BURNING": "FAT_BURNING",
        "FAT_BURNING_TARGET": "FAT_BURNING_TARGET",
        "SUN_CURRENT": "SUN_CURRENT",
        "SUN_RISE": "SUN_RISE",
        "SUN_SET": "SUN_SET",
        "WIND": "WIND",
        "WIND_DIRECTION": "WIND_DIRECTION",
        "STRESS": "STRESS",
        "SPO2": "SPO2",
        "ALTIMETER": "ALTIMETER",
        "MOON": "MOON",
        "FLOOR": "FLOOR",
        "ALARM_CLOCK": "ALARM_CLOCK",
        "COUNT_DOWN": "COUNT_DOWN",
        "STOP_WATCH": "STOP_WATCH",
        "SLEEP": "SLEEP"
      });
      __publicField(this, "edit_type", {
        "BATTERY": "BATTERY",
        "STEP": "STEP",
        "STEP_TARGET": "STEP_TARGET",
        "CAL": "CAL",
        "CAL_TARGET": "CAL_TARGET",
        "HEART": "HEART",
        "PAI_DAILY": "PAI_DAILY",
        "PAI_WEEKLY": "PAI_WEEKLY",
        "DISTANCE": "DISTANCE",
        "STAND": "STAND",
        "STAND_TARGET": "STAND_TARGET",
        "WEATHER_CURRENT": "WEATHER_CURRENT",
        "WEATHER_LOW": "WEATHER_LOW",
        "WEATHER_HIGH": "WEATHER_HIGH",
        "UVI": "UVI",
        "AQI": "AQI",
        "HUMIDITY": "HUMIDITY",
        "FAT_BURN": "FAT_BURNING",
        "FAT_BURNING": "FAT_BURNING",
        "FAT_BURNING_TARGET": "FAT_BURNING_TARGET",
        "SUN_CURRENT": "SUN_CURRENT",
        "SUN_RISE": "SUN_RISE",
        "SUN_SET": "SUN_SET",
        "WIND": "WIND",
        "STRESS": "STRESS",
        "SPO2": "SPO2",
        "BODY_TEMP": "BODY_TEMP",
        "ALTIMETER": "ALTIMETER",
        "MOON": "MOON",
        "FLOOR": "FLOOR",
        "ALARM_CLOCK": "ALARM_CLOCK",
        "COUNT_DOWN": "COUNT_DOWN",
        "STOP_WATCH": "STOP_WATCH",
        "WEATHER": "WEATHER",
        "SLEEP": "SLEEP"
      });
      this.runtime = runtime;
      this.widget = {};
      this.toastWidget = null;
      for (let a3 in this._widget)
        this.widget[a3] = a3;
    }
    deleteWidget(widget) {
      const widgets = this.runtime.widgets;
      const targetId = widget.config.__id;
      for (let i3 in widgets) {
        if (widgets[i3].config.__id === targetId) {
          widgets.splice(parseInt(i3), 1);
          this.runtime.refresh_required = "del_widget";
          return;
        } else if (widgets[i3].config.__content) {
          const groupContent = widgets[i3].config.__content;
          for (let j4 in groupContent) {
            if (groupContent[j4].config.__id === targetId) {
              widgets[i3].config.__content.splice(parseInt(j4), 1);
              this.runtime.refresh_required = "del_widget";
              return;
            }
          }
        }
      }
      console.warn("can't delete undefined widget", widget);
    }
    createWidget(type, config) {
      let Widget = this._widget[type];
      if (!Widget) {
        Widget = MissingWidget;
      }
      if (typeof config !== "object") {
        config = {};
      }
      config.__widget = type;
      config.__id = this._idCounter;
      config.__runtime = this.runtime;
      const i3 = new Widget(config);
      this.runtime.widgets.push(i3);
      this._idCounter++;
      this.runtime.refresh_required = "add_widget";
      return i3;
    }
    showToast(options) {
      if (!this.toastWidget) {
        const screenWidth = this.runtime.screen[0];
        const toastWidth = Math.max(170, Math.round(screenWidth / 2));
        this.toastWidget = this.createWidget(this.widget.BUTTON, {
          x: Math.round((screenWidth - toastWidth) / 2),
          y: 70,
          w: toastWidth,
          h: 50,
          text: "",
          visible: false,
          text_size: 22,
          radius: 25,
          press_color: 2236962,
          normal_color: 2236962,
          click_func: () => this.toastWidget.setProperty(this.prop.VISIBLE, false)
        });
      }
      this.toastWidget.setProperty("visible", true);
      this.toastWidget.setProperty(this.prop.MORE, {
        text: options.text
      });
      setTimeout(() => {
        this.toastWidget.setProperty("visible", false);
      }, 3e3);
    }
    setLayerScrolling(val) {
    }
    setStatusBarVisible() {
    }
    updateStatusBarTitle() {
    }
    setScrollView() {
    }
    getTextLayout(text2, options) {
      const canvas = TextWidget.drawText({
        text: text2,
        text_size: options.text_size,
        w: options.text_width,
        text_style: 2,
        _metricsOnly: true
      }, this.runtime);
      return {
        width: canvas.width,
        height: canvas.height
      };
    }
  };

  // src/zepp_player/zepp_env/Timer.js
  var TimerMock = class {
    constructor(runtime) {
      this.runtime = runtime;
      this.timers = [];
      runtime.onDestroy.push(() => {
        for (let a3 in this.timers)
          try {
            this.stopTimer(a3);
          } catch (e3) {
          }
      });
    }
    createTimer(delay, period, callable, option) {
      const runtime = this.runtime;
      const id = this.timers.length;
      this.timers[id] = {
        interval: -1,
        timeout: -1,
        func: callable
      };
      (async () => {
        if (!!runtime.initTime) {
          await this.wait(delay, id);
        }
        if (!period) {
          callable.apply(this, option);
          return;
        }
        this.timers[id].interval = setInterval(() => {
          if (runtime.uiPause)
            return;
          callable.apply(this, option);
        }, Math.max(period, 25));
      })();
      return id;
    }
    wait(delay, id) {
      return new Promise((resolve) => {
        if (delay === 0)
          return resolve();
        this.timers[id].timeout = setTimeout(() => resolve(), delay);
      });
    }
    stopTimer(timerID) {
      if (!this.timers[timerID])
        return;
      if (this.timers[timerID].timeout > -1)
        clearTimeout(this.timers[timerID].timeout);
      if (this.timers[timerID].interval > -1)
        clearInterval(this.timers[timerID].interval);
      this.timers[timerID] = null;
    }
  };

  // src/zepp_player/zepp_env/HuamiBLE.js
  var HuamiBLEMock = class {
    constructor(runtime) {
      this.runtime = runtime;
    }
    createConnect() {
    }
    disConnect() {
    }
    send() {
    }
    connectStatus() {
      return !this.runtime.getDeviceState("DISCONNECT", "boolean");
    }
    addListener() {
    }
    removeListener() {
    }
  };

  // src/zepp_player/zepp_env/HmApp.js
  var HmApp = class {
    constructor(runtime) {
      __publicField(this, "gesture", {
        UP: "up",
        LEFT: "left",
        RIGHT: "right",
        DOWN: "down"
      });
      this.runtime = runtime;
      this.timers = [];
      runtime.onDestroy.push(() => {
        for (const a3 of this.timers)
          try {
            clearTimeout(a3);
          } catch (e3) {
          }
      });
    }
    alarmNew(options) {
      let delta = options.delay ? options.delay : options.date - Date.now() / 1e3;
      delta = Math.floor(delta);
      if (delta <= 0)
        return -1;
      this.timers.push(setTimeout(() => {
        this.runtime.requestPageSwitch(options);
      }, delta * 1e3));
    }
    alarmCancel() {
    }
    startApp(options) {
      const appId = this.runtime.player.appConfig.app.appId;
      if (options.appid === appId)
        return this.gotoPage(options);
      this.runtime.onConsole("device", ["startApp", options]);
    }
    gotoPage(conf) {
      console.log("gotoPage", conf);
      if (!conf.url)
        return;
      this.runtime.requestPageSwitch(conf);
    }
    reloadPage(conf) {
      return this.gotoPage(conf);
    }
    setLayerX() {
    }
    setLayerY(y3) {
      this.runtime.renderScroll = -y3;
    }
    exit() {
    }
    gotoHome() {
      this.runtime.onConsole("ZeppPlayer", [
        "gotoHome requested"
      ]);
    }
    goBack() {
      this.runtime.back();
    }
    setScreenKeep() {
    }
    packageInfo() {
      const data = this.runtime.appConfig.app;
      return {
        type: data.appType,
        appId: data.appId,
        name: data.name,
        version: data.version.name,
        icon: data.icon,
        description: data.description,
        vendor: data.vendor,
        pages: []
      };
    }
    registerGestureEvent(callback) {
      this.runtime.appGestureHandler = callback;
    }
    unregisterGestureEvent() {
      this.runtime.appGestureHandler = () => false;
    }
    registerKeyEvent() {
    }
    unregisterKeyEvent() {
    }
    unregistKeyEvent() {
    }
    registerSpinEvent() {
    }
    unregistSpinEvent() {
    }
  };

  // src/zepp_player/SyystemEnvironment.js
  function createAppEnv(player2) {
    const object = {};
    const core = new DeviceRuntimeCoreMock(player2);
    object.DeviceRuntimeCore = core;
    object.__$$module$$__ = {};
    object.__$$hmAppManager$$__ = {
      currentApp: {
        pid: 10,
        current: {},
        app: {
          __globals__: {}
        }
      }
    };
    return object;
  }
  function createPageEnv(runtime, appRuntime) {
    const object = {};
    const core = new DeviceRuntimeCoreMock(runtime);
    object.SLEEP_REFERENCE_ZERO = 24 * 60;
    object.DeviceRuntimeCore = core;
    object.hmUI = new HuamiUIMock(runtime);
    object.hmFS = new HuamiFsMock(runtime);
    object.hmApp = new HmApp(runtime);
    object.hmBle = new HuamiBLEMock(runtime);
    object.hmSensor = new HuamiSensorMock(runtime);
    object.hmSetting = new HuamiSettingMock(runtime);
    object.timer = new TimerMock(runtime);
    object.console = new ConsoleMock(runtime, console);
    object.__$$module$$__ = {};
    object.__$$hmAppManager$$__ = appRuntime.__$$hmAppManager$$__;
    object.Logger = object.DeviceRuntimeCore.HmLogger;
    object.WatchFace = (conf) => object.DeviceRuntimeCore.WatchFace(conf);
    const glob = appRuntime.__$$hmAppManager$$__.currentApp.app.__globals__;
    for (let i3 in glob) {
      object[i3] = glob[i3];
    }
    return object;
  }

  // src/zepp_player/ui/ScreenRootEventHandler.js
  var DIRECTION_THR = 30;
  var ScreenRootEventHandler = class {
    constructor(runtime) {
      this.runtime = runtime;
    }
    onwheel(delta) {
      const maxScroll = this.runtime.contentHeight - this.runtime.screen[1];
      if (maxScroll <= 0)
        return false;
      this.runtime.player.renderScroll = Math.min(maxScroll, this.runtime.player.renderScroll + delta);
      return true;
    }
    onmousedown(info) {
      this.startCoords = [info.x, info.y];
      this.direction = 0;
      this.inScroll = false;
      this.performGesture = "";
      this.startScroll = this.runtime.player.renderScroll;
      this.maxScroll = this.runtime.contentHeight - this.runtime.screen[1];
    }
    onmouseup() {
      if (this.performGesture) {
        let response = this.runtime.appGestureHandler(this.direction);
        if (!response && this.direction === "right")
          this.runtime.back();
      }
    }
    onmousemove(info) {
      const { x: x4, y: y3 } = info;
      if (!this.direction) {
        if (x4 - this.startCoords[0] > DIRECTION_THR) {
          this.direction = "right";
        } else if (this.startCoords[0] - x4 > DIRECTION_THR) {
          this.direction = "left";
        } else if (y3 - this.startCoords[1] > DIRECTION_THR) {
          this.direction = "down";
          if (this.startScroll > 0)
            this.inScroll = true;
        } else if (this.startCoords[1] - y3 > DIRECTION_THR) {
          this.direction = "up";
          if (this.startScroll < this.maxScroll)
            this.inScroll = true;
        } else
          return;
      }
      const runtime = this.runtime;
      const player2 = this.runtime.player;
      if (this.inScroll) {
        player2.renderScroll = this.startScroll + (this.startCoords[1] - y3);
      } else {
        let delta, target;
        switch (this.direction) {
          case "right":
            delta = x4 - this.startCoords[0];
            target = this.runtime.screen[0];
            break;
          case "left":
            delta = this.startCoords[0] - x4;
            target = this.runtime.screen[0];
            break;
          case "up":
            delta = this.startCoords[1] - y3;
            target = this.runtime.screen[1];
            break;
          case "down":
            delta = y3 - this.startCoords[1];
            target = this.runtime.screen[1];
            break;
        }
        this.performGesture = delta / target > 0.25;
      }
    }
  };

  // src/zepp_player/ZeppRuntime.js
  var ZeppRuntime = class {
    constructor(player2, scriptPath, showLevel) {
      __publicField(this, "widgets", []);
      __publicField(this, "events", []);
      __publicField(this, "postRenderTasks", []);
      __publicField(this, "onDestroy", []);
      __publicField(this, "env", null);
      __publicField(this, "module", null);
      __publicField(this, "initTime", null);
      __publicField(this, "onInitParam", null);
      __publicField(this, "uiPause", false);
      __publicField(this, "refresh_required", false);
      __publicField(this, "animMaxFPS", false);
      this.player = player2;
      this.scriptPath = scriptPath;
      this.showLevel = showLevel;
      this.render_counter = 0;
      this.vfs = this.player.vfs;
      this.screen = this.player.screen;
      this.profileData = this.player.profileData;
      this.appConfig = this.player.appConfig;
      this.withScriptConsole = this.player.withScriptConsole;
    }
    get renderScroll() {
      return this.player.renderScroll;
    }
    set renderScroll(val) {
      this.player.renderScroll = val;
    }
    get language() {
      switch (this.fullLanguage) {
        case "zh-CN":
          return "sc";
        case "zh-TW":
          return "tc";
        default:
          return "en";
      }
    }
    get fullLanguage() {
      return this.getDeviceState("OS_LANGUAGE", "string");
    }
    async start() {
      if (this.initTime)
        this.destroy();
      console.debug("ZeppRuntime.start()", this.scriptPath.split("/").pop() + ":" + this.scriptPath);
      const extra = this.player.getEvalAdditionalData(this.scriptPath);
      const scriptFile = await this.player.loadFile(this.scriptPath);
      const text = new TextDecoder().decode(scriptFile);
      this.appGestureHandler = () => false;
      this.rootEventHandler = new ScreenRootEventHandler(this);
      const env = createPageEnv(this, this.player.appEnv);
      if (this.player.globalScopeFix.length > 0) {
        for (let i3 in this.player.globalScopeFix)
          env[this.player.globalScopeFix[i3]] = 0;
        this.onConsole("SystemWarning", [
          "Fix global var defination, please do not declare variables  without var/let/const, this is legacy way. List:",
          this.player.globalScopeFix
        ]);
      }
      const script = `${extra}
(${Object.keys(env).toString()}) => {${text}}`;
      try {
        const fnc = eval(script);
        fnc(...Object.values(env));
      } catch (e3) {
        this.onConsole("error", ["Script load failed", e3]);
        throw e3;
      }
      if (!env.__$$hmAppManager$$__.currentApp.current.module) {
        this.onConsole("SystemWarning", ["Page/Watchface don't exported."]);
        return;
      }
      this.env = env;
      this.module = env.__$$hmAppManager$$__.currentApp.current.module;
      this.render_counter = 0;
      try {
        if (this.module.onInit)
          this.module.onInit(this.onInitParam);
        if (this.module.build)
          this.module.build();
      } catch (e3) {
        this.onConsole("error", ["Module start failed", e3]);
        throw e3;
      }
      this.callDelegates("resume_call");
      this.initTime = Date.now();
    }
    async render(canvas) {
      this.events = [];
      this.postRenderTasks = [];
      this.contentHeight = 0;
      this.refresh_required = false;
      this.render_counter = (this.render_counter + 1) % 3e3;
      const stages = {
        normal: [],
        postReverse: [],
        toplevel: []
      };
      for (let i3 in this.widgets) {
        const widget = this.widgets[i3];
        if (!widget)
          continue;
        const stage = widget._renderStage ? widget._renderStage : "normal";
        if (stages[stage])
          stages[stage].push(widget);
      }
      stages.postReverse.reverse();
      for (let stage in stages) {
        for (let i3 in stages[stage]) {
          const widget = stages[stage][i3];
          if (!widget)
            continue;
          await this.renderWidget(widget, canvas);
        }
      }
      const maxScroll = this.contentHeight - this.screen[1];
      if (this.renderScroll > maxScroll) {
        this.renderScroll = maxScroll;
      }
      for (const fnc2 of this.postRenderTasks) {
        try {
          await fnc2();
        } catch (e3) {
          console.warn("Post-render task failed", fnc2, e3);
        }
      }
    }
    setPause(val) {
      this.callDelegates(val ? "pause_call" : "resume_call");
      this.uiPause = val;
    }
    requestPageSwitch(conf) {
      return this.player.enterPage(conf.url, conf.param);
    }
    destroy() {
      if (this.module && this.module.onDestroy)
        this.module.onDestroy();
      for (let i3 in this.onDestroy) {
        this.onDestroy[i3]();
      }
      this.onDestroy = [];
      this.widgets = [];
      this.events = [];
      this.module = null;
      this.env = null;
      this.initTime = null;
      this.contentHeight = 0;
      console.debug("ZeppRuntime.destroy()", this.scriptPath.split("/").pop() + ":" + this.scriptPath);
    }
    handleEvent(name, x4, y3, info) {
      y3 += this.player.renderScroll;
      if (this.rootEventHandler[name])
        this.rootEventHandler[name](info);
      for (let i3 = this.events.length - 1; i3 >= 0; i3--) {
        const data = this.events[i3];
        if (data.x1 < x4 && x4 < data.x2 && data.y1 < y3 && y3 < data.y2) {
          if (data.events[name])
            data.events[name](info);
          return;
        }
      }
    }
    dropEvents(events, x1, y1, x22, y22) {
      this.events.push({
        events,
        x1,
        y1,
        x2: x22,
        y2: y22
      });
      if (y22 > this.contentHeight)
        this.contentHeight = y22;
    }
    callDelegates(delegateName) {
      for (let i3 in this.widgets) {
        const w4 = this.widgets[i3].config;
        if (w4.__widget === "WIDGET_DELEGATE" && w4[delegateName]) {
          w4[delegateName]();
        }
      }
    }
    addPostRenderTask(fnc2) {
      this.postRenderTasks.push(fnc2);
    }
    async renderWidget(widget, canvas) {
      const ctx = canvas.getContext("2d");
      const show_level = widget.config.show_level;
      ctx.globalAlpha = widget.config.alpha !== void 0 ? widget.config.alpha / 255 : 1;
      if ((show_level & this.showLevel) === 0 && show_level)
        return;
      if (!widget.config.visible)
        return;
      try {
        await widget.render(canvas, this);
      } catch (e3) {
        const [title, subtitle] = widget.playerWidgetIdentify();
        console.warn(`%c Widget %c${title} %c${subtitle} %crender failed`, "font-weight: bold", "color: initial; font-weight: bold", "color: #999; font-weight: bold", "font-weight: bold", "\n\n", "CONFIG: ", widget.config, "\n", "ERROR: ", e3);
        throw new Error("widget_fail");
      }
      ctx.globalAlpha = 1;
    }
    getImageFormat(path) {
      path = this.player.getVfsAssetPath(path);
      if (!this.vfs[path])
        throw new Error("Undefined asset: " + path);
      const data = this.vfs[path];
      const uint = new Uint8Array(data);
      if (uint[0] === 137 && uint[1] === 80) {
        return "PNG";
      } else if (uint[2] === 9) {
        return "TGA-RLP";
      } else if (uint[2] === 1) {
        return "TGA-P";
      } else if (uint[2] === 2) {
        return "TGA-RGB";
      }
      return "N/A";
    }
    onConsole(tag, data) {
      this.player.onConsole(tag, data, {
        runtimeID: `SL:${this.showLevel}`
      });
    }
    async getAssetImage() {
      return await this.player.getAssetImage(...arguments);
    }
    addDeviceStateChangeEvent() {
      this.player.addDeviceStateChangeEvent(...arguments);
    }
    newCanvas() {
      return this.player.newCanvas(...arguments);
    }
    getDeviceState() {
      return this.player.getDeviceState(...arguments);
    }
    autoFixGlobalScopeError() {
      this.player.autoFixGlobalScopeError(...arguments);
    }
    back() {
      return this.player.back(...arguments);
    }
  };

  // src/zepp_player/TgaImage.js
  var import_buffer = __toESM(require_buffer());
  var import_canvas = __toESM(require_browser());
  var _ImageType = {
    noImage: 0,
    colorMapped: 1,
    RGB: 2,
    blackAndWhite: 3,
    runlengthColorMapped: 9,
    runlengthRGB: 10,
    compressedBlackAndWhite: 11,
    compressedColorMapped: 32,
    compressed4PassQTColorMapped: 33
  };
  var _headerLength = 18;
  var TGAImage = class {
    constructor(data, config) {
      if (data instanceof import_buffer.Buffer) {
        this._buffer = data;
      } else if (typeof data === "string") {
        this._buffer = import_buffer.Buffer.from(data, "binary");
      } else if (data) {
        this._buffer = import_buffer.Buffer.from(data);
      } else {
        this._buffer = null;
      }
      this.config = config;
      this._idLength = 0;
      this._colorMapType = 0;
      this._imageType = 0;
      this._colorMapOrigin = 0;
      this._colorMapLength = 0;
      this._colorMapDepth = 0;
      this._imageWidth = 0;
      this._imageCropWidth = 0;
      this._imageHeight = 0;
      this._imageDepth = 0;
      this._leftToRight = true;
      this._topToBottom = false;
      this._hasAlpha = false;
      this._imageID = null;
      this._canvas = null;
      this._context = null;
      this._imageData = null;
      this._image = null;
      this._src = null;
      this.onload = null;
      this.onerror = null;
      this._resolveFunc = null;
      this._rejectFunc = null;
      this._didLoad = new Promise((resolve, reject) => {
        this._resolveFunc = resolve;
        this._rejectFunc = reject;
      });
      if (data) {
        this._parseData();
      }
    }
    static imageWithData(data) {
      return new TGAImage(data);
    }
    static imageWithURL(url) {
      const image = new TGAImage();
      image._loadURL(url);
      return image;
    }
    _loadURL(url) {
      this._src = url;
      this._requestBinaryFile(url).then((data) => {
        this._buffer = import_buffer.Buffer.from(data);
        this._parseData();
      }).catch((error) => {
        this._reject(error);
      });
    }
    _requestBinaryFile(url) {
      return new Promise((resolve, reject) => {
        const request = new XMLHttpRequest();
        request.open("GET", url);
        request.responseType = "arraybuffer";
        request.onload = (ev) => {
          if (request.response) {
            resolve(request.response);
          } else {
            reject(request);
          }
        };
        request.onerror = (ev) => {
          reject(ev);
        };
        request.send(null);
      });
    }
    _parseData() {
      this._readHeader();
      this._readImageID();
      this._initImage();
      const data = this._getImageData();
      switch (this._imageType) {
        case _ImageType.noImage: {
          break;
        }
        case _ImageType.colorMapped: {
          this._parseColorMapData(data);
          break;
        }
        case _ImageType.RGB: {
          this._parseRGBData(data);
          break;
        }
        case _ImageType.blackAndWhite: {
          this._parseBlackAndWhiteData(data);
          break;
        }
        case _ImageType.runlengthColorMapped: {
          this._parseColorMapData(data);
          break;
        }
        case _ImageType.runlengthRGB: {
          this._parseRGBData(data);
          break;
        }
        case _ImageType.compressedBlackAndWhite: {
          this._parseBlackAndWhiteData(data);
          break;
        }
        case _ImageType.compressedColorMapped: {
          console.error("parser for compressed TGA is not implemeneted");
          break;
        }
        case _ImageType.compressed4PassQTColorMapped: {
          console.error("parser for compressed TGA is not implemeneted");
          break;
        }
        default: {
          throw new Error("unknown imageType: " + this._imageType);
        }
      }
      this._setImage();
      this._deleteBuffer();
      this._resolve();
    }
    _readHeader() {
      this._idLength = this._buffer.readUIntLE(0, 1);
      this._colorMapType = this._buffer.readUIntLE(1, 1);
      this._imageType = this._buffer.readUIntLE(2, 1);
      this._colorMapOrigin = this._buffer.readUIntLE(3, 2);
      this._colorMapLength = this._buffer.readUIntLE(5, 2);
      this._colorMapDepth = this._buffer.readUIntLE(7, 1);
      this._imageXOrigin = this._buffer.readUIntLE(8, 2);
      this._imageYOrigin = this._buffer.readUIntLE(10, 2);
      this._imageWidth = this._buffer.readUIntLE(12, 2);
      this._imageHeight = this._buffer.readUIntLE(14, 2);
      this._imageDepth = this._buffer.readUIntLE(16, 1);
      const descriptor = this._buffer.readUIntLE(17, 1);
      this._alphaDepth = descriptor & 15;
      this._leftToRight = (descriptor & 16) === 0;
      this._topToBottom = (descriptor & 32) > 0;
      this._interleave = descriptor & 192;
    }
    _readImageID() {
      const sign = new Uint8Array([83, 79, 77, 72]);
      if (this._idLength > 0) {
        this._imageID = this._buffer.subarray(_headerLength, this._idLength);
        if (this._imageID.subarray(0, 5).compare(sign) === 1) {
          this._imageCropWidth = this._imageID.readUIntLE(4, 2);
        }
      }
    }
    _initImage() {
      if (this._imageType === _ImageType.noImage) {
        return;
      }
      if (this._imageWidth <= 0 || this._imageHeight <= 0) {
        return;
      }
      const { createCanvas: createCanvas2 } = require_browser();
      this._canvas = createCanvas2(this._imageWidth, this._imageHeight);
      this._canvas.width = this._imageWidth;
      this._canvas.height = this._imageHeight;
      this._context = this._canvas.getContext("2d");
      this._imageData = this._context.createImageData(this._imageWidth, this._imageHeight);
    }
    _setImage() {
      this._context.putImageData(this._imageData, 0, 0);
      if (this._imageCropWidth !== 0 && this._imageWidth !== this._imageCropWidth) {
        const outCanvas = (0, import_canvas.createCanvas)(this._imageCropWidth, this._imageHeight);
        outCanvas.getContext("2d").drawImage(this._canvas, 0, 0);
        this._canvas = outCanvas;
      }
    }
    _deleteBuffer() {
      if (this._buffer) {
        delete this._buffer;
        this._buffer = null;
      }
      if (this._imageData) {
        delete this._imageData;
        this._imageData = null;
      }
    }
    _parseColorMapData(buf) {
      if (this._colorMapDepth === 24 || this._colorMapDepth === 16 || this._colorMapDepth === 15) {
        this._hasAlpha = false;
      } else if (this._colorMapDepth === 32) {
        this._hasAlpha = true;
      } else {
        throw new Error("unknown colorMapDepth: " + this._colorMapDepth);
      }
      const colorMapDataPos = _headerLength + this._idLength;
      const colorMapDataSize = Math.ceil(this._colorMapDepth / 8);
      const colorMapDataLen = colorMapDataSize * this._colorMapLength;
      const imageDataSize = 1;
      const colorMap = [];
      let pos = colorMapDataPos;
      for (let i3 = 0; i3 < this._colorMapLength; i3++) {
        const rgba = this._getRGBA(this._buffer, pos, this._colorMapDepth);
        colorMap.push(rgba);
        pos += colorMapDataSize;
      }
      const data = this._imageData.data;
      let initX = 0;
      let initY = 0;
      let xStep = 1;
      let yStep = 1;
      if (!this._leftToRight) {
        initX = this._imageWidth - 1;
        xStep = -1;
      }
      if (!this._topToBottom) {
        initY = this._imageHeight - 1;
        yStep = -1;
      }
      pos = 0;
      let y3 = initY;
      const defaultColor = [255, 255, 255, 255];
      for (let iy = 0; iy < this._imageHeight; iy++) {
        let x4 = initX;
        for (let ix = 0; ix < this._imageWidth; ix++) {
          const index = (y3 * this._imageWidth + x4) * 4;
          let color = defaultColor;
          const mapNo = buf[pos] - this._colorMapOrigin;
          if (mapNo >= 0) {
            color = colorMap[mapNo];
          }
          data[index + 1] = color[1];
          data[index + 3] = color[3];
          if (this.config.swapRedAndBlueTGA) {
            data[index] = color[2];
            data[index + 2] = color[0];
          } else {
            data[index] = color[0];
            data[index + 2] = color[2];
          }
          x4 += xStep;
          pos += imageDataSize;
        }
        y3 += yStep;
      }
    }
    _parseRGBData(buf) {
      if (this._imageDepth === 24 || this._imageDepth === 16 || this._imageDepth === 15) {
        this._hasAlpha = false;
      } else if (this._imageDepth === 32) {
        this._hasAlpha = true;
      } else {
        throw new Error("unknown imageDepth: " + this._imageDepth);
      }
      const imageDataSize = Math.ceil(this._imageDepth / 8);
      const data = this._imageData.data;
      let initX = 0;
      let initY = 0;
      let xStep = 1;
      let yStep = 1;
      if (!this._leftToRight) {
        initX = this._imageWidth - 1;
        xStep = -1;
      }
      if (!this._topToBottom) {
        initY = this._imageHeight - 1;
        yStep = -1;
      }
      let pos = 0;
      let y3 = initY;
      for (let iy = 0; iy < this._imageHeight; iy++) {
        let x4 = initX;
        for (let ix = 0; ix < this._imageWidth; ix++) {
          const index = (y3 * this._imageWidth + x4) * 4;
          const rgba = this._getRGBA(buf, pos, this._imageDepth);
          data[index] = rgba[0];
          data[index + 1] = rgba[1];
          data[index + 2] = rgba[2];
          data[index + 3] = rgba[3];
          x4 += xStep;
          pos += imageDataSize;
        }
        y3 += yStep;
      }
    }
    _getRGBA(buf, offset, depth) {
      if (depth === 15) {
        const r3 = (buf[offset + 1] & 124) << 1;
        const g4 = (buf[offset + 1] & 3) << 6 | (buf[offset] & 224) >> 2;
        const b3 = (buf[offset] & 31) << 3;
        const a3 = 255;
        return [r3, g4, b3, a3];
      } else if (depth === 16) {
        const pixel = (buf[offset + 1] << 8) + buf[offset];
        const r3 = Math.floor(255 / 31 * ((pixel & 63488) >> 11));
        const g4 = Math.floor(255 / 63 * ((pixel & 2016) >> 5));
        const b3 = Math.floor(255 / 31 * (pixel & 31));
        const a3 = 255;
        return [r3, g4, b3, a3];
      } else if (depth === 24) {
        return [buf[offset + 2], buf[offset + 1], buf[offset], 255];
      } else if (depth === 32) {
        return [buf[offset + 2], buf[offset + 1], buf[offset], buf[offset + 3]];
      }
      throw new Error("unsupported imageDepth: " + depth);
    }
    _parseBlackAndWhiteData(buf) {
      if (this._imageDepth == 8) {
        this._hasAlpha = false;
      } else if (this._imageDepth == 16) {
        this._hasAlpha = true;
      } else {
        throw new Error("unknown imageDepth: " + this._imageDepth);
      }
      const imageDataSize = this._imageDepth / 8;
      const data = this._imageData.data;
      let initX = 0;
      let initY = 0;
      let xStep = 1;
      let yStep = 1;
      if (!this._leftToRight) {
        initX = this._imageWidth - 1;
        xStep = -1;
      }
      if (!this._topToBottom) {
        initY = this._imageHeight - 1;
        yStep = -1;
      }
      let pos = 0;
      if (this._hasAlpha) {
        let y3 = initY;
        for (let iy = 0; iy < this._imageHeight; iy++) {
          let x4 = initX;
          for (let ix = 0; ix < this._imageWidth; ix++) {
            const index = (y3 * this._imageWidth + x4) * 4;
            const c3 = buf[pos];
            const a3 = buf[pos + 1];
            data[index] = c3;
            data[index + 1] = c3;
            data[index + 2] = c3;
            data[index + 3] = a3;
            x4 += xStep;
            pos += imageDataSize;
          }
          y3 += yStep;
        }
      } else {
        let y3 = initY;
        for (let iy = 0; iy < this._imageHeight; iy++) {
          let x4 = initX;
          for (let ix = 0; ix < this._imageWidth; ix++) {
            const index = (y3 * this._imageWidth + x4) * 4;
            const c3 = buf[pos];
            const a3 = 255;
            data[index] = c3;
            data[index + 1] = c3;
            data[index + 2] = c3;
            data[index + 3] = a3;
            x4 += xStep;
            pos += imageDataSize;
          }
          y3 += yStep;
        }
      }
    }
    _getImageData() {
      let data = null;
      if (this._imageType !== _ImageType.none) {
        const colorMapDataLen = Math.ceil(this._colorMapDepth / 8) * this._colorMapLength;
        const start3 = _headerLength + this._idLength + colorMapDataLen;
        data = this._buffer.subarray(start3);
      }
      if (this._imageType === _ImageType.runlengthColorMapped || this._imageType === _ImageType.runlengthRGB) {
        data = this._decompressRunlengthData(data);
      } else if (this._imageType === _ImageType.compressedBlackAndWhite) {
        data = this._decompressRunlengthData(data);
      } else if (this._imageType === _ImageType.compressedColorMapped) {
        console.error("Compressed Color Mapped TGA Image data is not supported");
      } else if (this._imageType === _ImageType.compressed4PassQTColorMapped) {
        console.error("Compressed Color Mapped TGA Image data is not supported");
      }
      return data;
    }
    _decompressRunlengthData(data) {
      const d3 = [];
      const elementCount = Math.ceil(this._imageDepth / 8);
      const dataLength = elementCount * this._imageWidth * this._imageHeight;
      let pos = 0;
      while (d3.length < dataLength) {
        const packet = data[pos];
        pos += 1;
        if ((packet & 128) !== 0) {
          const elements = data.slice(pos, pos + elementCount);
          pos += elementCount;
          const count = (packet & 127) + 1;
          for (let i3 = 0; i3 < count; i3++) {
            d3.push(...elements);
          }
        } else {
          const len = (packet + 1) * elementCount;
          d3.push(...data.slice(pos, pos + len));
          pos += len;
        }
      }
      return d3;
    }
    get canvas() {
      return this._canvas;
    }
    get didLoad() {
      return this._didLoad;
    }
    _resolve(e3) {
      if (this.onload) {
        this.onload(e3);
      }
      this._resolveFunc(e3);
    }
    _reject(e3) {
      if (this.onerror) {
        this.onerror(e3);
      }
      this._rejectFunc(e3);
    }
    get src() {
      return this._src;
    }
    set src(newValue) {
      this._loadURL(newValue);
    }
  };

  // src/zepp_player/ZeppPlayer.js
  var ZeppPlayer = class extends ZeppPlayerConfig {
    constructor() {
      super();
      this._lastCanvas = null;
      this.profileName = "sb7";
      this.projectPath = "";
      this.appEnv = null;
      this.render_counter = 0;
      this.currentRuntime = null;
      this.wfBaseRuntime = null;
      this.wfSubRuntime = null;
      this.backStack = [];
      this.globalScopeFix = [];
      this._deviceState = createDeviceState();
      this._deviceStateChangeEvents = {};
    }
    onConsole() {
    }
    onRestart() {
    }
    get profileData() {
      return DeviceProfiles[this.profileName];
    }
    get screen() {
      return [this.profileData.screenWidth, this.profileData.screenHeight];
    }
    get appType() {
      return this.appConfig.app.appType;
    }
    async getAssetImage(path) {
      path = this.getVfsAssetPath(path);
      if (this.imgCache[path])
        return this.imgCache[path];
      if (!this.vfs[path])
        throw new Error("Undefined asset: " + path);
      const data = this.vfs[path];
      const uint = new Uint8Array(data);
      let img;
      if (uint[0] === 137 && uint[1] === 80) {
        img = await this._loadPNG(data);
      } else {
        const tga = new TGAImage(data, this.profileData);
        await tga.didLoad;
        img = tga.canvas;
      }
      this.imgCache[path] = img;
      return img;
    }
    wipeSettings() {
      this._deviceState = createDeviceState();
      PersistentStorage.wipe();
    }
    autoFixGlobalScopeError(e3) {
      if (e3.message.endsWith("is not defined")) {
        const name = e3.message.split(" ")[0];
        if (this.globalScopeFix.indexOf(name) < 0) {
          console.log("%cAuto-fix global define of " + name, "color: #8cf");
          this.globalScopeFix.push(name);
          return true;
        }
      }
      return false;
    }
    getVfsAppPath() {
      const pkg = this.appConfig.app;
      const idn = pkg.appId.toString(16).padStart(8, "0").toUpperCase();
      return "/storage/js_" + pkg.appType + "s/" + idn;
    }
    getVfsAssetPath(path) {
      return this.getVfsAppPath() + "/assets/" + path;
    }
    getStateEntry(type) {
      if (!this._deviceState[type])
        return null;
      return this._deviceState[type];
    }
    getDeviceState(type, dataType = "null") {
      const v3 = this._deviceState[type];
      switch (dataType) {
        case "progress":
          return Math.min(1, v3.getProgress(v3));
        case "pointer_progress":
          return v3.getProgress(v3);
        case "string":
          return v3.getString(v3);
        case "maxLength":
          return v3.maxLength;
        case "boolean":
          return v3.getBoolean(v3);
        default:
          return v3.value;
      }
    }
    addDeviceStateChangeEvent(type, callback) {
      if (!this._deviceStateChangeEvents[type])
        this._deviceStateChangeEvents[type] = [];
      this._deviceStateChangeEvents[type].push(callback);
    }
    setDeviceState(type, value, requireRefresh = true) {
      this._deviceState[type].value = value;
      if (this._deviceStateChangeEvents[type]) {
        for (let i3 in this._deviceStateChangeEvents[type]) {
          this._deviceStateChangeEvents[type][i3]();
        }
      }
      if (this.currentRuntime && requireRefresh)
        this.currentRuntime.refresh_required = "set_state";
    }
    setDeviceStateMany(data) {
      for (const type in data) {
        this.setDeviceState(type, data[type], false);
      }
      if (this.currentRuntime)
        this.currentRuntime.refresh_required = "set_state";
    }
    async setProject(path) {
      this.projectPath = path;
      this.overlayTool = new Overlay(this);
      this.vfs = {};
      this.imgCache = {};
      this.renderScroll = 0;
      await this._loadAppConfig();
      await this._loadAppJs();
      await this.overlayTool.init();
      await this.preloadProjectAssets(path + "/");
    }
    async restart() {
      await this.finish();
      await this.setProject(this.projectPath);
      await this.init();
    }
    async _loadAppJs() {
      const appJsFile = await this.loadFile(this.projectPath + "/app.js");
      const appJsText = new TextDecoder().decode(appJsFile);
      const appEnv = createAppEnv(this);
      try {
        const str = `(${Object.keys(appEnv).toString()}) => {${appJsText};}`;
        const appJs = eval(str);
        appJs(...Object.values(appEnv));
      } catch (e3) {
        console.warn("app.js exec failed", e3);
      }
      this.appEnv = appEnv;
    }
    async _loadAppConfig() {
      const jsonFile = await this.loadFile(this.projectPath + "/app.json");
      const jsonText = new TextDecoder().decode(jsonFile);
      this.appConfig = JSON.parse(jsonText);
    }
    getInitModuleName() {
      const appConfig = this.appConfig;
      if (appConfig.targets) {
        const ident = Object.keys(appConfig.targets)[0];
        appConfig.module = appConfig.targets[ident].module;
      }
      if (appConfig.app.appType === "watchface") {
        let modulePath = "watchface/index";
        if (appConfig.module && appConfig.module.watchface)
          modulePath = appConfig.module.watchface.path;
        return modulePath;
      } else if (appConfig.app.appType === "app") {
        return appConfig.module.page.pages[0];
      } else
        throw new Error("Unsupported appType");
    }
    async readDirectoryRecursive(path, arr = null) {
      if (!arr)
        arr = [];
      const dirContent = await this.listDirectory(path);
      for (let i3 in dirContent) {
        const filePath = path + dirContent[i3].name;
        if (dirContent[i3].type === "file") {
          arr.push(filePath);
        } else {
          await this.readDirectoryRecursive(filePath, arr);
        }
      }
      return arr;
    }
    async preloadProjectAssets(path) {
      const urls = await this.readDirectoryRecursive(path);
      const contents = await Promise.all(urls.map(this.loadFile));
      const vfsRoot = this.getVfsAppPath();
      for (let i3 = 0; i3 < urls.length; i3++) {
        const vfsPath = urls[i3].replace(this.projectPath, vfsRoot);
        this.vfs[vfsPath] = contents[i3];
      }
    }
    _finishCurrentRuntime() {
      this.currentRuntime.callDelegates("pause_call");
      this.currentRuntime.uiPause = true;
      this.currentRuntime.destroy();
    }
    _attachRuntime(runtime) {
      const SL_DESCRIPTOR = {
        1: "(normal)",
        2: "(aod)",
        4: "(settings)"
      };
      this._lastCanvas = null;
      this.currentRuntime = runtime;
      runtime.refresh_required = "attach";
      this.onConsole("ZeppPlayer", [
        "Switch to",
        runtime.scriptPath.split("/").pop(),
        SL_DESCRIPTOR[runtime.showLevel]
      ]);
    }
    getModulePath(modulePath) {
      return this.projectPath + "/" + modulePath + ".js";
    }
    async enterPage(url, param) {
      this._finishCurrentRuntime();
      this.backStack.push([
        this.currentRuntime.scriptPath,
        this.currentRuntime.onInitParam
      ]);
      this.renderScroll = 0;
      const runtime = new ZeppRuntime(this, this.getModulePath(url), 1);
      runtime.onInitParam = param;
      await runtime.start();
      this._attachRuntime(runtime);
    }
    async back() {
      if (this.backStack.length < 1) {
        this.onConsole("device", ["back(): backStack is empty"]);
        return;
      }
      this._finishCurrentRuntime();
      const [script2, param] = this.backStack.pop();
      const runtime = new ZeppRuntime(this, script2, 1);
      runtime.onInitParam = param;
      await runtime.start();
      this._attachRuntime(runtime);
    }
    async finish() {
      for (const runtime of [this.wfBaseRuntime, this.wfSubRuntime, this.currentRuntime]) {
        if (runtime)
          await runtime.destroy();
      }
      this.wfBaseRuntime = null;
      this.wfSubRuntime = null;
      this.currentRuntime = null;
      this.render_counter = 0;
      this._deviceStateChangeEvents = {};
      this.onDestroy = [];
      this.backStack = [];
    }
    getEvalAdditionalData() {
      return "";
    }
    async init() {
      await this.finish();
      await this.onRestart();
      const path = this.getModulePath(this.getInitModuleName());
      const runtime = new ZeppRuntime(this, path, 1);
      this.wfBaseRuntime = runtime;
      try {
        await runtime.start();
      } catch (e3) {
        if (this.autoFixGlobalScopeError(e3)) {
          this.onConsole("ZeppPlayer", ["Auto-fix applied, restarting..."]);
          return await this.init();
        }
        console.error(e3);
        this.onConsole("ZeppPlayer", ["Init failed"]);
      }
      this._attachRuntime(runtime);
      if (this._currentRenderLevel !== 1) {
        const val = this._currentRenderLevel;
        this._currentRenderLevel = 1;
        await this.setRenderLevel(val);
      }
    }
    async setRenderLevel(val) {
      if (this.appType !== "watchface")
        return;
      if (val === this.current_level)
        return;
      const currentVal = this._currentRenderLevel;
      if (this.wfSubRuntime) {
        this.wfSubRuntime.destroy();
        this.wfSubRuntime = null;
      }
      if (val !== 1) {
        const path = this.getModulePath(this.getInitModuleName());
        this.wfSubRuntime = new ZeppRuntime(this, path, val);
        await this.wfSubRuntime.start();
      }
      if (val === 1 && currentVal !== 4) {
        this.wfBaseRuntime.callDelegates("resume_call");
        this.wfBaseRuntime.uiPause = false;
      } else if (currentVal === 1) {
        this.wfBaseRuntime.callDelegates("pause_call");
        this.wfBaseRuntime.uiPause = true;
      }
      this._currentRenderLevel = val;
      this._attachRuntime(val === 1 ? this.wfBaseRuntime : this.wfSubRuntime);
      if (currentVal === 4)
        await this.init();
    }
    async render(force = false) {
      let runtime = this.currentRuntime;
      if (!runtime.refresh_required && this._lastCanvas && !force)
        return this._lastCanvas;
      let canvas = this.newCanvas();
      let ctx = canvas.getContext("2d");
      canvas.width = this.screen[0];
      canvas.height = this.screen[1] + this.renderScroll;
      if (this.withoutTransparency) {
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      await this.currentRuntime.render(canvas);
      if (this.showEventZones) {
        await this.overlayTool.drawEventZones(canvas, runtime.events);
      }
      if (this.withShift) {
        if (this.render_counter % 15 === 0)
          this.performShift(this.render_counter / 15);
        runtime.refresh_required = "shift";
      }
      if (this.renderScroll !== 0) {
        const newCanvas = this.newCanvas();
        newCanvas.width = canvas.width;
        newCanvas.height = this.screen[1];
        newCanvas.getContext("2d").drawImage(canvas, 0, -this.renderScroll);
        canvas = newCanvas;
      }
      if (this.render_overlay && this.profileData.hasOverlay) {
        await this.overlayTool.drawDeviceFrame(canvas);
      }
      this.render_counter = (this.render_counter + 1) % 3e3;
      this._lastCanvas = canvas;
      return canvas;
    }
    performShift(tick) {
      for (let i3 in this._deviceState) {
        if (this._deviceState[i3].shift) {
          const v3 = this._deviceState[i3].shift(tick, this._deviceState[i3]);
          if (v3 !== null)
            this.setDeviceState(i3, v3);
        }
      }
    }
    async listDirectory(path) {
    }
    async loadFile() {
    }
    newCanvas() {
      throw new Error("not overriden");
    }
  };

  // src/zepp_player/ChromeZeppPlayer.js
  var ChromeZeppPlayer = class extends ZeppPlayer {
    constructor() {
      super();
      __publicField(this, "imgCache", {});
      this.rotation = 0;
      this._uiOverlayVisible = false;
      this._htmlRootBlock = null;
      this.uiOverlayPosition = [0, 0];
    }
    async loadFile(path) {
      const resp = await fetch(path);
      return await resp.arrayBuffer();
    }
    get uiOverlayVisible() {
      return this._uiOverlayVisible;
    }
    set uiOverlayVisible(value) {
      if (this._htmlRootBlock)
        this._htmlRootBlock.style.cursor = value ? "crosshair" : "";
      this._uiOverlayVisible = value;
    }
    async listDirectory(path) {
      const resp = await fetch(path);
      const html = await resp.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const links = Array.from(doc.getElementsByTagName("a"));
      const content = [];
      for (let i3 in links) {
        const name = links[i3].innerText;
        let type = "file";
        if (name.endsWith("/"))
          type = "dir";
        content.push({ name, type });
      }
      return content;
    }
    saveDeviceStates() {
      const out = {};
      for (const type in this._deviceState) {
        out[type] = this._deviceState[type].value;
      }
      localStorage.zp_deviceState = JSON.stringify(out);
    }
    getEvalAdditionalData(scriptPath) {
      return `//# sourceURL=${location.href.substring(0, location.href.length - 1)}${scriptPath}`;
    }
    setupHTMLEvents(block) {
      let isMouseDown = false;
      this._htmlRootBlock = block;
      document.documentElement.onkeydown = (e3) => {
        if (e3.key === "Shift") {
          this.uiOverlayVisible = true;
          this.currentRuntime.refresh_required = "uiOverlay";
        }
      };
      document.documentElement.onkeyup = (e3) => {
        if (e3.key === "Shift") {
          this.uiOverlayVisible = false;
          this.currentRuntime.refresh_required = "uiOverlay";
        }
      };
      block.onwheel = (e3) => {
        if (this.currentRuntime) {
          if (this.currentRuntime.rootEventHandler.onwheel(e3.deltaY))
            e3.preventDefault();
        }
      };
      block.onmousedown = (e3) => {
        e3.preventDefault();
        const [x4, y3] = this._fetchCoordinates(e3);
        isMouseDown = true;
        this.currentRuntime.handleEvent("onmousedown", x4, y3, { x: x4, y: y3 });
      };
      block.onmouseup = (e3) => {
        const [x4, y3] = this._fetchCoordinates(e3);
        isMouseDown = false;
        this.currentRuntime.handleEvent("onmouseup", x4, y3, { x: x4, y: y3 });
      };
      block.onmouseout = (e3) => {
        const [x4, y3] = this._fetchCoordinates(e3);
        if (isMouseDown)
          this.currentRuntime.handleEvent("onmouseup", { x: x4, y: y3 });
        isMouseDown = false;
      };
      block.onmousemove = (e3) => {
        e3.preventDefault();
        const [x4, y3] = this._fetchCoordinates(e3);
        if (isMouseDown)
          this.currentRuntime.handleEvent("onmousemove", x4, y3, { x: x4, y: y3 });
        if (this._uiOverlayVisible) {
          const rect = e3.target.getBoundingClientRect();
          const uiX = e3.clientX - rect.left;
          const uiY = e3.clientY - rect.top;
          this.uiOverlayPosition = [uiX, uiY];
          this.currentRuntime.refresh_required = "uiOverlay";
        }
      };
      block.oncontextmenu = (e3) => {
        const [x4, y3] = this._fetchCoordinates(e3);
        console.log("click coords", x4, y3);
      };
    }
    async render(force = false) {
      const canvas = await super.render(force);
      if (this._uiOverlayVisible) {
        let [x4, y3] = this.uiOverlayPosition;
        y3 += this.renderScroll;
        const context = canvas.getContext("2d");
        const baseColor = this.getDeviceState("OVERLAY_COLOR");
        context.save();
        context.lineWidth = 1;
        context.globalAlpha = 1;
        context.fillStyle = "rgba(0, 0, 0, 0.5)";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.globalAlpha = 0.6;
        context.strokeStyle = baseColor;
        context.beginPath();
        context.setLineDash([]);
        context.moveTo(Math.floor(canvas.width / 2), 0);
        context.lineTo(Math.floor(canvas.width / 2), canvas.height);
        context.moveTo(0, Math.floor(canvas.height / 2));
        context.lineTo(canvas.width, Math.floor(canvas.height / 2));
        context.stroke();
        context.globalAlpha = 1;
        context.strokeStyle = baseColor;
        for (const widget of this.currentRuntime.widgets) {
          if (!widget.positionInfo)
            continue;
          const [x1, y1, x22, y22] = widget.positionInfo;
          if (x4 > x1 && x4 < x22 && y3 > y1 && y3 < y22) {
            context.beginPath();
            context.rect(x1, y1 - this.renderScroll, x22 - x1, y22 - y1);
            context.stroke();
          }
        }
        context.strokeStyle = "#0099FF";
        for (let data of this.currentRuntime.events) {
          let hasNoNull = false;
          for (let i3 in data.events) {
            if (data.events[i3] !== null) {
              hasNoNull = true;
              break;
            }
          }
          if (!hasNoNull)
            continue;
          const { x1, y1, x2: x22, y2: y22 } = data;
          if (x4 > x1 && x4 < x22 && y3 > y1 && y3 < y22) {
            context.beginPath();
            context.rect(x1, y1 - this.renderScroll, x22 - x1, y22 - y1);
            context.stroke();
            break;
          }
        }
        context.strokeStyle = baseColor;
        context.beginPath();
        context.setLineDash([10, 2]);
        context.moveTo(0, y3 - this.renderScroll);
        context.lineTo(canvas.width, y3 - this.renderScroll);
        context.moveTo(x4, 0);
        context.lineTo(x4, canvas.height);
        context.stroke();
        context.font = "12px monospace";
        context.fillStyle = baseColor;
        const text2 = `${x4}, ${y3 - this.renderScroll}`;
        const metrics = context.measureText(text2);
        const tx = x4 > canvas.width / 2 ? x4 - metrics.width - 6 : x4 + 6;
        const ty = y3 - this.renderScroll > canvas.height / 2 ? y3 - 4 : y3 + 14;
        context.fillText(text2, tx, ty - this.renderScroll);
        context.restore();
      }
      return canvas;
    }
    newCanvas() {
      return document.createElement("canvas");
    }
    _fetchCoordinates(e3) {
      const rect = e3.target.getBoundingClientRect();
      let x4, y3;
      switch (this.rotation) {
        case 90:
          x4 = e3.clientY - rect.top;
          y3 = rect.width - (e3.clientX - rect.left);
          break;
        case 180:
          x4 = rect.width - (e3.clientX - rect.left);
          y3 = rect.height - (e3.clientY - rect.top);
          break;
        case 270:
          x4 = rect.height - (e3.clientY - rect.top);
          y3 = e3.clientX - rect.left;
          break;
        default:
          x4 = e3.clientX - rect.left;
          y3 = e3.clientY - rect.top;
      }
      return [Math.floor(x4), Math.floor(y3)];
    }
    _loadPNG(data) {
      return new Promise((resolve, reject) => {
        const blob = new Blob([data]);
        const url = URL.createObjectURL(blob);
        const img = document.createElement("img");
        img.onload = () => resolve(img);
        img.onerror = (e3) => reject(e3);
        img.src = url;
      });
    }
  };

  // node_modules/preact/dist/preact.module.js
  var n;
  var l;
  var u;
  var i;
  var t;
  var r;
  var o;
  var f;
  var e;
  var c = {};
  var s = [];
  var a = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function h(n2, l3) {
    for (var u3 in l3)
      n2[u3] = l3[u3];
    return n2;
  }
  function v(n2) {
    var l3 = n2.parentNode;
    l3 && l3.removeChild(n2);
  }
  function y(l3, u3, i3) {
    var t3, r3, o3, f3 = {};
    for (o3 in u3)
      "key" == o3 ? t3 = u3[o3] : "ref" == o3 ? r3 = u3[o3] : f3[o3] = u3[o3];
    if (arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), "function" == typeof l3 && null != l3.defaultProps)
      for (o3 in l3.defaultProps)
        void 0 === f3[o3] && (f3[o3] = l3.defaultProps[o3]);
    return p(l3, f3, t3, r3, null);
  }
  function p(n2, i3, t3, r3, o3) {
    var f3 = { type: n2, props: i3, key: t3, ref: r3, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == o3 ? ++u : o3 };
    return null == o3 && null != l.vnode && l.vnode(f3), f3;
  }
  function d() {
    return { current: null };
  }
  function _(n2) {
    return n2.children;
  }
  function k(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function b(n2, l3) {
    if (null == l3)
      return n2.__ ? b(n2.__, n2.__.__k.indexOf(n2) + 1) : null;
    for (var u3; l3 < n2.__k.length; l3++)
      if (null != (u3 = n2.__k[l3]) && null != u3.__e)
        return u3.__e;
    return "function" == typeof n2.type ? b(n2) : null;
  }
  function g(n2) {
    var l3, u3;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l3 = 0; l3 < n2.__k.length; l3++)
        if (null != (u3 = n2.__k[l3]) && null != u3.__e) {
          n2.__e = n2.__c.base = u3.__e;
          break;
        }
      return g(n2);
    }
  }
  function m(n2) {
    (!n2.__d && (n2.__d = true) && t.push(n2) && !w.__r++ || r !== l.debounceRendering) && ((r = l.debounceRendering) || o)(w);
  }
  function w() {
    var n2, l3, u3, i3, r3, o3, e3, c3;
    for (t.sort(f); n2 = t.shift(); )
      n2.__d && (l3 = t.length, i3 = void 0, r3 = void 0, e3 = (o3 = (u3 = n2).__v).__e, (c3 = u3.__P) && (i3 = [], (r3 = h({}, o3)).__v = o3.__v + 1, L(c3, o3, r3, u3.__n, void 0 !== c3.ownerSVGElement, null != o3.__h ? [e3] : null, i3, null == e3 ? b(o3) : e3, o3.__h), M(i3, o3), o3.__e != e3 && g(o3)), t.length > l3 && t.sort(f));
    w.__r = 0;
  }
  function x(n2, l3, u3, i3, t3, r3, o3, f3, e3, a3) {
    var h3, v3, y3, d3, k4, g4, m3, w4 = i3 && i3.__k || s, x4 = w4.length;
    for (u3.__k = [], h3 = 0; h3 < l3.length; h3++)
      if (null != (d3 = u3.__k[h3] = null == (d3 = l3[h3]) || "boolean" == typeof d3 || "function" == typeof d3 ? null : "string" == typeof d3 || "number" == typeof d3 || "bigint" == typeof d3 ? p(null, d3, null, null, d3) : Array.isArray(d3) ? p(_, { children: d3 }, null, null, null) : d3.__b > 0 ? p(d3.type, d3.props, d3.key, d3.ref ? d3.ref : null, d3.__v) : d3)) {
        if (d3.__ = u3, d3.__b = u3.__b + 1, null === (y3 = w4[h3]) || y3 && d3.key == y3.key && d3.type === y3.type)
          w4[h3] = void 0;
        else
          for (v3 = 0; v3 < x4; v3++) {
            if ((y3 = w4[v3]) && d3.key == y3.key && d3.type === y3.type) {
              w4[v3] = void 0;
              break;
            }
            y3 = null;
          }
        L(n2, d3, y3 = y3 || c, t3, r3, o3, f3, e3, a3), k4 = d3.__e, (v3 = d3.ref) && y3.ref != v3 && (m3 || (m3 = []), y3.ref && m3.push(y3.ref, null, d3), m3.push(v3, d3.__c || k4, d3)), null != k4 ? (null == g4 && (g4 = k4), "function" == typeof d3.type && d3.__k === y3.__k ? d3.__d = e3 = A(d3, e3, n2) : e3 = C(n2, d3, y3, w4, k4, e3), "function" == typeof u3.type && (u3.__d = e3)) : e3 && y3.__e == e3 && e3.parentNode != n2 && (e3 = b(y3));
      }
    for (u3.__e = g4, h3 = x4; h3--; )
      null != w4[h3] && ("function" == typeof u3.type && null != w4[h3].__e && w4[h3].__e == u3.__d && (u3.__d = $(i3).nextSibling), S(w4[h3], w4[h3]));
    if (m3)
      for (h3 = 0; h3 < m3.length; h3++)
        O(m3[h3], m3[++h3], m3[++h3]);
  }
  function A(n2, l3, u3) {
    for (var i3, t3 = n2.__k, r3 = 0; t3 && r3 < t3.length; r3++)
      (i3 = t3[r3]) && (i3.__ = n2, l3 = "function" == typeof i3.type ? A(i3, l3, u3) : C(u3, i3, i3, t3, i3.__e, l3));
    return l3;
  }
  function P(n2, l3) {
    return l3 = l3 || [], null == n2 || "boolean" == typeof n2 || (Array.isArray(n2) ? n2.some(function(n3) {
      P(n3, l3);
    }) : l3.push(n2)), l3;
  }
  function C(n2, l3, u3, i3, t3, r3) {
    var o3, f3, e3;
    if (void 0 !== l3.__d)
      o3 = l3.__d, l3.__d = void 0;
    else if (null == u3 || t3 != r3 || null == t3.parentNode)
      n:
        if (null == r3 || r3.parentNode !== n2)
          n2.appendChild(t3), o3 = null;
        else {
          for (f3 = r3, e3 = 0; (f3 = f3.nextSibling) && e3 < i3.length; e3 += 1)
            if (f3 == t3)
              break n;
          n2.insertBefore(t3, r3), o3 = r3;
        }
    return void 0 !== o3 ? o3 : t3.nextSibling;
  }
  function $(n2) {
    var l3, u3, i3;
    if (null == n2.type || "string" == typeof n2.type)
      return n2.__e;
    if (n2.__k) {
      for (l3 = n2.__k.length - 1; l3 >= 0; l3--)
        if ((u3 = n2.__k[l3]) && (i3 = $(u3)))
          return i3;
    }
    return null;
  }
  function H(n2, l3, u3, i3, t3) {
    var r3;
    for (r3 in u3)
      "children" === r3 || "key" === r3 || r3 in l3 || T(n2, r3, null, u3[r3], i3);
    for (r3 in l3)
      t3 && "function" != typeof l3[r3] || "children" === r3 || "key" === r3 || "value" === r3 || "checked" === r3 || u3[r3] === l3[r3] || T(n2, r3, l3[r3], u3[r3], i3);
  }
  function I(n2, l3, u3) {
    "-" === l3[0] ? n2.setProperty(l3, null == u3 ? "" : u3) : n2[l3] = null == u3 ? "" : "number" != typeof u3 || a.test(l3) ? u3 : u3 + "px";
  }
  function T(n2, l3, u3, i3, t3) {
    var r3;
    n:
      if ("style" === l3)
        if ("string" == typeof u3)
          n2.style.cssText = u3;
        else {
          if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3)
            for (l3 in i3)
              u3 && l3 in u3 || I(n2.style, l3, "");
          if (u3)
            for (l3 in u3)
              i3 && u3[l3] === i3[l3] || I(n2.style, l3, u3[l3]);
        }
      else if ("o" === l3[0] && "n" === l3[1])
        r3 = l3 !== (l3 = l3.replace(/Capture$/, "")), l3 = l3.toLowerCase() in n2 ? l3.toLowerCase().slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + r3] = u3, u3 ? i3 || n2.addEventListener(l3, r3 ? z : j, r3) : n2.removeEventListener(l3, r3 ? z : j, r3);
      else if ("dangerouslySetInnerHTML" !== l3) {
        if (t3)
          l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" !== l3 && "height" !== l3 && "href" !== l3 && "list" !== l3 && "form" !== l3 && "tabIndex" !== l3 && "download" !== l3 && l3 in n2)
          try {
            n2[l3] = null == u3 ? "" : u3;
            break n;
          } catch (n3) {
          }
        "function" == typeof u3 || (null == u3 || false === u3 && "-" !== l3[4] ? n2.removeAttribute(l3) : n2.setAttribute(l3, u3));
      }
  }
  function j(n2) {
    return this.l[n2.type + false](l.event ? l.event(n2) : n2);
  }
  function z(n2) {
    return this.l[n2.type + true](l.event ? l.event(n2) : n2);
  }
  function L(n2, u3, i3, t3, r3, o3, f3, e3, c3) {
    var s3, a3, v3, y3, p3, d3, b3, g4, m3, w4, A4, P3, C3, $3, H3, I3 = u3.type;
    if (void 0 !== u3.constructor)
      return null;
    null != i3.__h && (c3 = i3.__h, e3 = u3.__e = i3.__e, u3.__h = null, o3 = [e3]), (s3 = l.__b) && s3(u3);
    try {
      n:
        if ("function" == typeof I3) {
          if (g4 = u3.props, m3 = (s3 = I3.contextType) && t3[s3.__c], w4 = s3 ? m3 ? m3.props.value : s3.__ : t3, i3.__c ? b3 = (a3 = u3.__c = i3.__c).__ = a3.__E : ("prototype" in I3 && I3.prototype.render ? u3.__c = a3 = new I3(g4, w4) : (u3.__c = a3 = new k(g4, w4), a3.constructor = I3, a3.render = q), m3 && m3.sub(a3), a3.props = g4, a3.state || (a3.state = {}), a3.context = w4, a3.__n = t3, v3 = a3.__d = true, a3.__h = [], a3._sb = []), null == a3.__s && (a3.__s = a3.state), null != I3.getDerivedStateFromProps && (a3.__s == a3.state && (a3.__s = h({}, a3.__s)), h(a3.__s, I3.getDerivedStateFromProps(g4, a3.__s))), y3 = a3.props, p3 = a3.state, a3.__v = u3, v3)
            null == I3.getDerivedStateFromProps && null != a3.componentWillMount && a3.componentWillMount(), null != a3.componentDidMount && a3.__h.push(a3.componentDidMount);
          else {
            if (null == I3.getDerivedStateFromProps && g4 !== y3 && null != a3.componentWillReceiveProps && a3.componentWillReceiveProps(g4, w4), !a3.__e && null != a3.shouldComponentUpdate && false === a3.shouldComponentUpdate(g4, a3.__s, w4) || u3.__v === i3.__v) {
              for (u3.__v !== i3.__v && (a3.props = g4, a3.state = a3.__s, a3.__d = false), a3.__e = false, u3.__e = i3.__e, u3.__k = i3.__k, u3.__k.forEach(function(n3) {
                n3 && (n3.__ = u3);
              }), A4 = 0; A4 < a3._sb.length; A4++)
                a3.__h.push(a3._sb[A4]);
              a3._sb = [], a3.__h.length && f3.push(a3);
              break n;
            }
            null != a3.componentWillUpdate && a3.componentWillUpdate(g4, a3.__s, w4), null != a3.componentDidUpdate && a3.__h.push(function() {
              a3.componentDidUpdate(y3, p3, d3);
            });
          }
          if (a3.context = w4, a3.props = g4, a3.__P = n2, P3 = l.__r, C3 = 0, "prototype" in I3 && I3.prototype.render) {
            for (a3.state = a3.__s, a3.__d = false, P3 && P3(u3), s3 = a3.render(a3.props, a3.state, a3.context), $3 = 0; $3 < a3._sb.length; $3++)
              a3.__h.push(a3._sb[$3]);
            a3._sb = [];
          } else
            do {
              a3.__d = false, P3 && P3(u3), s3 = a3.render(a3.props, a3.state, a3.context), a3.state = a3.__s;
            } while (a3.__d && ++C3 < 25);
          a3.state = a3.__s, null != a3.getChildContext && (t3 = h(h({}, t3), a3.getChildContext())), v3 || null == a3.getSnapshotBeforeUpdate || (d3 = a3.getSnapshotBeforeUpdate(y3, p3)), H3 = null != s3 && s3.type === _ && null == s3.key ? s3.props.children : s3, x(n2, Array.isArray(H3) ? H3 : [H3], u3, i3, t3, r3, o3, f3, e3, c3), a3.base = u3.__e, u3.__h = null, a3.__h.length && f3.push(a3), b3 && (a3.__E = a3.__ = null), a3.__e = false;
        } else
          null == o3 && u3.__v === i3.__v ? (u3.__k = i3.__k, u3.__e = i3.__e) : u3.__e = N(i3.__e, u3, i3, t3, r3, o3, f3, c3);
      (s3 = l.diffed) && s3(u3);
    } catch (n3) {
      u3.__v = null, (c3 || null != o3) && (u3.__e = e3, u3.__h = !!c3, o3[o3.indexOf(e3)] = null), l.__e(n3, u3, i3);
    }
  }
  function M(n2, u3) {
    l.__c && l.__c(u3, n2), n2.some(function(u4) {
      try {
        n2 = u4.__h, u4.__h = [], n2.some(function(n3) {
          n3.call(u4);
        });
      } catch (n3) {
        l.__e(n3, u4.__v);
      }
    });
  }
  function N(l3, u3, i3, t3, r3, o3, f3, e3) {
    var s3, a3, h3, y3 = i3.props, p3 = u3.props, d3 = u3.type, _3 = 0;
    if ("svg" === d3 && (r3 = true), null != o3) {
      for (; _3 < o3.length; _3++)
        if ((s3 = o3[_3]) && "setAttribute" in s3 == !!d3 && (d3 ? s3.localName === d3 : 3 === s3.nodeType)) {
          l3 = s3, o3[_3] = null;
          break;
        }
    }
    if (null == l3) {
      if (null === d3)
        return document.createTextNode(p3);
      l3 = r3 ? document.createElementNS("http://www.w3.org/2000/svg", d3) : document.createElement(d3, p3.is && p3), o3 = null, e3 = false;
    }
    if (null === d3)
      y3 === p3 || e3 && l3.data === p3 || (l3.data = p3);
    else {
      if (o3 = o3 && n.call(l3.childNodes), a3 = (y3 = i3.props || c).dangerouslySetInnerHTML, h3 = p3.dangerouslySetInnerHTML, !e3) {
        if (null != o3)
          for (y3 = {}, _3 = 0; _3 < l3.attributes.length; _3++)
            y3[l3.attributes[_3].name] = l3.attributes[_3].value;
        (h3 || a3) && (h3 && (a3 && h3.__html == a3.__html || h3.__html === l3.innerHTML) || (l3.innerHTML = h3 && h3.__html || ""));
      }
      if (H(l3, p3, y3, r3, e3), h3)
        u3.__k = [];
      else if (_3 = u3.props.children, x(l3, Array.isArray(_3) ? _3 : [_3], u3, i3, t3, r3 && "foreignObject" !== d3, o3, f3, o3 ? o3[0] : i3.__k && b(i3, 0), e3), null != o3)
        for (_3 = o3.length; _3--; )
          null != o3[_3] && v(o3[_3]);
      e3 || ("value" in p3 && void 0 !== (_3 = p3.value) && (_3 !== l3.value || "progress" === d3 && !_3 || "option" === d3 && _3 !== y3.value) && T(l3, "value", _3, y3.value, false), "checked" in p3 && void 0 !== (_3 = p3.checked) && _3 !== l3.checked && T(l3, "checked", _3, y3.checked, false));
    }
    return l3;
  }
  function O(n2, u3, i3) {
    try {
      "function" == typeof n2 ? n2(u3) : n2.current = u3;
    } catch (n3) {
      l.__e(n3, i3);
    }
  }
  function S(n2, u3, i3) {
    var t3, r3;
    if (l.unmount && l.unmount(n2), (t3 = n2.ref) && (t3.current && t3.current !== n2.__e || O(t3, null, u3)), null != (t3 = n2.__c)) {
      if (t3.componentWillUnmount)
        try {
          t3.componentWillUnmount();
        } catch (n3) {
          l.__e(n3, u3);
        }
      t3.base = t3.__P = null, n2.__c = void 0;
    }
    if (t3 = n2.__k)
      for (r3 = 0; r3 < t3.length; r3++)
        t3[r3] && S(t3[r3], u3, i3 || "function" != typeof n2.type);
    i3 || null == n2.__e || v(n2.__e), n2.__ = n2.__e = n2.__d = void 0;
  }
  function q(n2, l3, u3) {
    return this.constructor(n2, u3);
  }
  function B(u3, i3, t3) {
    var r3, o3, f3;
    l.__ && l.__(u3, i3), o3 = (r3 = "function" == typeof t3) ? null : t3 && t3.__k || i3.__k, f3 = [], L(i3, u3 = (!r3 && t3 || i3).__k = y(_, null, [u3]), o3 || c, c, void 0 !== i3.ownerSVGElement, !r3 && t3 ? [t3] : o3 ? null : i3.firstChild ? n.call(i3.childNodes) : null, f3, !r3 && t3 ? t3 : o3 ? o3.__e : i3.firstChild, r3), M(f3, u3);
  }
  function D(n2, l3) {
    B(n2, l3, D);
  }
  function E(l3, u3, i3) {
    var t3, r3, o3, f3 = h({}, l3.props);
    for (o3 in u3)
      "key" == o3 ? t3 = u3[o3] : "ref" == o3 ? r3 = u3[o3] : f3[o3] = u3[o3];
    return arguments.length > 2 && (f3.children = arguments.length > 3 ? n.call(arguments, 2) : i3), p(l3.type, f3, t3 || l3.key, r3 || l3.ref, null);
  }
  function F(n2, l3) {
    var u3 = { __c: l3 = "__cC" + e++, __: n2, Consumer: function(n3, l4) {
      return n3.children(l4);
    }, Provider: function(n3) {
      var u4, i3;
      return this.getChildContext || (u4 = [], (i3 = {})[l3] = this, this.getChildContext = function() {
        return i3;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && u4.some(function(n5) {
          n5.__e = true, m(n5);
        });
      }, this.sub = function(n4) {
        u4.push(n4);
        var l4 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          u4.splice(u4.indexOf(n4), 1), l4 && l4.call(n4);
        };
      }), n3.children;
    } };
    return u3.Provider.__ = u3.Consumer.contextType = u3;
  }
  n = s.slice, l = { __e: function(n2, l3, u3, i3) {
    for (var t3, r3, o3; l3 = l3.__; )
      if ((t3 = l3.__c) && !t3.__)
        try {
          if ((r3 = t3.constructor) && null != r3.getDerivedStateFromError && (t3.setState(r3.getDerivedStateFromError(n2)), o3 = t3.__d), null != t3.componentDidCatch && (t3.componentDidCatch(n2, i3 || {}), o3 = t3.__d), o3)
            return t3.__E = t3;
        } catch (l4) {
          n2 = l4;
        }
    throw n2;
  } }, u = 0, i = function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, k.prototype.setState = function(n2, l3) {
    var u3;
    u3 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = h({}, this.state), "function" == typeof n2 && (n2 = n2(h({}, u3), this.props)), n2 && h(u3, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), m(this));
  }, k.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), m(this));
  }, k.prototype.render = _, t = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, f = function(n2, l3) {
    return n2.__v.__b - l3.__v.__b;
  }, w.__r = 0, e = 0;

  // node_modules/preact/hooks/dist/hooks.module.js
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = 0;
  var f2 = [];
  var c2 = [];
  var e2 = l.__b;
  var a2 = l.__r;
  var v2 = l.diffed;
  var l2 = l.__c;
  var m2 = l.unmount;
  function d2(t3, u3) {
    l.__h && l.__h(r2, t3, o2 || u3), o2 = 0;
    var i3 = r2.__H || (r2.__H = { __: [], __h: [] });
    return t3 >= i3.__.length && i3.__.push({ __V: c2 }), i3.__[t3];
  }
  function h2(n2) {
    return o2 = 1, s2(B2, n2);
  }
  function s2(n2, u3, i3) {
    var o3 = d2(t2++, 2);
    if (o3.t = n2, !o3.__c && (o3.__ = [i3 ? i3(u3) : B2(void 0, u3), function(n3) {
      var t3 = o3.__N ? o3.__N[0] : o3.__[0], r3 = o3.t(t3, n3);
      t3 !== r3 && (o3.__N = [r3, o3.__[1]], o3.__c.setState({}));
    }], o3.__c = r2, !r2.u)) {
      var f3 = function(n3, t3, r3) {
        if (!o3.__c.__H)
          return true;
        var u4 = o3.__c.__H.__.filter(function(n4) {
          return n4.__c;
        });
        if (u4.every(function(n4) {
          return !n4.__N;
        }))
          return !c3 || c3.call(this, n3, t3, r3);
        var i4 = false;
        return u4.forEach(function(n4) {
          if (n4.__N) {
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), !(!i4 && o3.__c.props === n3) && (!c3 || c3.call(this, n3, t3, r3));
      };
      r2.u = true;
      var c3 = r2.shouldComponentUpdate, e3 = r2.componentWillUpdate;
      r2.componentWillUpdate = function(n3, t3, r3) {
        if (this.__e) {
          var u4 = c3;
          c3 = void 0, f3(n3, t3, r3), c3 = u4;
        }
        e3 && e3.call(this, n3, t3, r3);
      }, r2.shouldComponentUpdate = f3;
    }
    return o3.__N || o3.__;
  }
  function p2(u3, i3) {
    var o3 = d2(t2++, 3);
    !l.__s && z2(o3.__H, i3) && (o3.__ = u3, o3.i = i3, r2.__H.__h.push(o3));
  }
  function y2(u3, i3) {
    var o3 = d2(t2++, 4);
    !l.__s && z2(o3.__H, i3) && (o3.__ = u3, o3.i = i3, r2.__h.push(o3));
  }
  function _2(n2) {
    return o2 = 5, F2(function() {
      return { current: n2 };
    }, []);
  }
  function A2(n2, t3, r3) {
    o2 = 6, y2(function() {
      return "function" == typeof n2 ? (n2(t3()), function() {
        return n2(null);
      }) : n2 ? (n2.current = t3(), function() {
        return n2.current = null;
      }) : void 0;
    }, null == r3 ? r3 : r3.concat(n2));
  }
  function F2(n2, r3) {
    var u3 = d2(t2++, 7);
    return z2(u3.__H, r3) ? (u3.__V = n2(), u3.i = r3, u3.__h = n2, u3.__V) : u3.__;
  }
  function T2(n2, t3) {
    return o2 = 8, F2(function() {
      return n2;
    }, t3);
  }
  function q2(n2) {
    var u3 = r2.context[n2.__c], i3 = d2(t2++, 9);
    return i3.c = n2, u3 ? (null == i3.__ && (i3.__ = true, u3.sub(r2)), u3.props.value) : n2.__;
  }
  function x2(t3, r3) {
    l.useDebugValue && l.useDebugValue(r3 ? r3(t3) : t3);
  }
  function V() {
    var n2 = d2(t2++, 11);
    if (!n2.__) {
      for (var u3 = r2.__v; null !== u3 && !u3.__m && null !== u3.__; )
        u3 = u3.__;
      var i3 = u3.__m || (u3.__m = [0, 0]);
      n2.__ = "P" + i3[0] + "-" + i3[1]++;
    }
    return n2.__;
  }
  function b2() {
    for (var t3; t3 = f2.shift(); )
      if (t3.__P && t3.__H)
        try {
          t3.__H.__h.forEach(k2), t3.__H.__h.forEach(w2), t3.__H.__h = [];
        } catch (r3) {
          t3.__H.__h = [], l.__e(r3, t3.__v);
        }
  }
  l.__b = function(n2) {
    r2 = null, e2 && e2(n2);
  }, l.__r = function(n2) {
    a2 && a2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.forEach(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.__V = c2, n3.__N = n3.i = void 0;
    })) : (i3.__h.forEach(k2), i3.__h.forEach(w2), i3.__h = [])), u2 = r2;
  }, l.diffed = function(t3) {
    v2 && v2(t3);
    var o3 = t3.__c;
    o3 && o3.__H && (o3.__H.__h.length && (1 !== f2.push(o3) && i2 === l.requestAnimationFrame || ((i2 = l.requestAnimationFrame) || j2)(b2)), o3.__H.__.forEach(function(n2) {
      n2.i && (n2.__H = n2.i), n2.__V !== c2 && (n2.__ = n2.__V), n2.i = void 0, n2.__V = c2;
    })), u2 = r2 = null;
  }, l.__c = function(t3, r3) {
    r3.some(function(t4) {
      try {
        t4.__h.forEach(k2), t4.__h = t4.__h.filter(function(n2) {
          return !n2.__ || w2(n2);
        });
      } catch (u3) {
        r3.some(function(n2) {
          n2.__h && (n2.__h = []);
        }), r3 = [], l.__e(u3, t4.__v);
      }
    }), l2 && l2(t3, r3);
  }, l.unmount = function(t3) {
    m2 && m2(t3);
    var r3, u3 = t3.__c;
    u3 && u3.__H && (u3.__H.__.forEach(function(n2) {
      try {
        k2(n2);
      } catch (n3) {
        r3 = n3;
      }
    }), u3.__H = void 0, r3 && l.__e(r3, u3.__v));
  };
  var g2 = "function" == typeof requestAnimationFrame;
  function j2(n2) {
    var t3, r3 = function() {
      clearTimeout(u3), g2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u3 = setTimeout(r3, 100);
    g2 && (t3 = requestAnimationFrame(r3));
  }
  function k2(n2) {
    var t3 = r2, u3 = n2.__c;
    "function" == typeof u3 && (n2.__c = void 0, u3()), r2 = t3;
  }
  function w2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function z2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function B2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // node_modules/preact/compat/dist/compat.module.js
  function g3(n2, t3) {
    for (var e3 in t3)
      n2[e3] = t3[e3];
    return n2;
  }
  function C2(n2, t3) {
    for (var e3 in n2)
      if ("__source" !== e3 && !(e3 in t3))
        return true;
    for (var r3 in t3)
      if ("__source" !== r3 && n2[r3] !== t3[r3])
        return true;
    return false;
  }
  function E2(n2, t3) {
    return n2 === t3 && (0 !== n2 || 1 / n2 == 1 / t3) || n2 != n2 && t3 != t3;
  }
  function w3(n2) {
    this.props = n2;
  }
  function x3(n2, e3) {
    function r3(n3) {
      var t3 = this.props.ref, r4 = t3 == n3.ref;
      return !r4 && t3 && (t3.call ? t3(null) : t3.current = null), e3 ? !e3(this.props, n3) || !r4 : C2(this.props, n3);
    }
    function u3(e4) {
      return this.shouldComponentUpdate = r3, y(n2, e4);
    }
    return u3.displayName = "Memo(" + (n2.displayName || n2.name) + ")", u3.prototype.isReactComponent = true, u3.__f = true, u3;
  }
  (w3.prototype = new k()).isPureReactComponent = true, w3.prototype.shouldComponentUpdate = function(n2, t3) {
    return C2(this.props, n2) || C2(this.state, t3);
  };
  var R = l.__b;
  l.__b = function(n2) {
    n2.type && n2.type.__f && n2.ref && (n2.props.ref = n2.ref, n2.ref = null), R && R(n2);
  };
  var N2 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
  function k3(n2) {
    function t3(t4) {
      var e3 = g3({}, t4);
      return delete e3.ref, n2(e3, t4.ref || null);
    }
    return t3.$$typeof = N2, t3.render = t3, t3.prototype.isReactComponent = t3.__f = true, t3.displayName = "ForwardRef(" + (n2.displayName || n2.name) + ")", t3;
  }
  var A3 = function(n2, t3) {
    return null == n2 ? null : P(P(n2).map(t3));
  };
  var O2 = { map: A3, forEach: A3, count: function(n2) {
    return n2 ? P(n2).length : 0;
  }, only: function(n2) {
    var t3 = P(n2);
    if (1 !== t3.length)
      throw "Children.only";
    return t3[0];
  }, toArray: P };
  var T3 = l.__e;
  l.__e = function(n2, t3, e3, r3) {
    if (n2.then) {
      for (var u3, o3 = t3; o3 = o3.__; )
        if ((u3 = o3.__c) && u3.__c)
          return null == t3.__e && (t3.__e = e3.__e, t3.__k = e3.__k), u3.__c(n2, t3);
    }
    T3(n2, t3, e3, r3);
  };
  var I2 = l.unmount;
  function L2(n2, t3, e3) {
    return n2 && (n2.__c && n2.__c.__H && (n2.__c.__H.__.forEach(function(n3) {
      "function" == typeof n3.__c && n3.__c();
    }), n2.__c.__H = null), null != (n2 = g3({}, n2)).__c && (n2.__c.__P === e3 && (n2.__c.__P = t3), n2.__c = null), n2.__k = n2.__k && n2.__k.map(function(n3) {
      return L2(n3, t3, e3);
    })), n2;
  }
  function U(n2, t3, e3) {
    return n2 && (n2.__v = null, n2.__k = n2.__k && n2.__k.map(function(n3) {
      return U(n3, t3, e3);
    }), n2.__c && n2.__c.__P === t3 && (n2.__e && e3.insertBefore(n2.__e, n2.__d), n2.__c.__e = true, n2.__c.__P = e3)), n2;
  }
  function D2() {
    this.__u = 0, this.t = null, this.__b = null;
  }
  function F3(n2) {
    var t3 = n2.__.__c;
    return t3 && t3.__a && t3.__a(n2);
  }
  function M2(n2) {
    var e3, r3, u3;
    function o3(o4) {
      if (e3 || (e3 = n2()).then(function(n3) {
        r3 = n3.default || n3;
      }, function(n3) {
        u3 = n3;
      }), u3)
        throw u3;
      if (!r3)
        throw e3;
      return y(r3, o4);
    }
    return o3.displayName = "Lazy", o3.__f = true, o3;
  }
  function V2() {
    this.u = null, this.o = null;
  }
  l.unmount = function(n2) {
    var t3 = n2.__c;
    t3 && t3.__R && t3.__R(), t3 && true === n2.__h && (n2.type = null), I2 && I2(n2);
  }, (D2.prototype = new k()).__c = function(n2, t3) {
    var e3 = t3.__c, r3 = this;
    null == r3.t && (r3.t = []), r3.t.push(e3);
    var u3 = F3(r3.__v), o3 = false, i3 = function() {
      o3 || (o3 = true, e3.__R = null, u3 ? u3(l3) : l3());
    };
    e3.__R = i3;
    var l3 = function() {
      if (!--r3.__u) {
        if (r3.state.__a) {
          var n3 = r3.state.__a;
          r3.__v.__k[0] = U(n3, n3.__c.__P, n3.__c.__O);
        }
        var t4;
        for (r3.setState({ __a: r3.__b = null }); t4 = r3.t.pop(); )
          t4.forceUpdate();
      }
    }, c3 = true === t3.__h;
    r3.__u++ || c3 || r3.setState({ __a: r3.__b = r3.__v.__k[0] }), n2.then(i3, i3);
  }, D2.prototype.componentWillUnmount = function() {
    this.t = [];
  }, D2.prototype.render = function(n2, e3) {
    if (this.__b) {
      if (this.__v.__k) {
        var r3 = document.createElement("div"), o3 = this.__v.__k[0].__c;
        this.__v.__k[0] = L2(this.__b, r3, o3.__O = o3.__P);
      }
      this.__b = null;
    }
    var i3 = e3.__a && y(_, null, n2.fallback);
    return i3 && (i3.__h = null), [y(_, null, e3.__a ? null : n2.children), i3];
  };
  var W = function(n2, t3, e3) {
    if (++e3[1] === e3[0] && n2.o.delete(t3), n2.props.revealOrder && ("t" !== n2.props.revealOrder[0] || !n2.o.size))
      for (e3 = n2.u; e3; ) {
        for (; e3.length > 3; )
          e3.pop()();
        if (e3[1] < e3[0])
          break;
        n2.u = e3 = e3[2];
      }
  };
  function P2(n2) {
    return this.getChildContext = function() {
      return n2.context;
    }, n2.children;
  }
  function j3(n2) {
    var e3 = this, r3 = n2.i;
    e3.componentWillUnmount = function() {
      B(null, e3.l), e3.l = null, e3.i = null;
    }, e3.i && e3.i !== r3 && e3.componentWillUnmount(), n2.__v ? (e3.l || (e3.i = r3, e3.l = { nodeType: 1, parentNode: r3, childNodes: [], appendChild: function(n3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, insertBefore: function(n3, t3) {
      this.childNodes.push(n3), e3.i.appendChild(n3);
    }, removeChild: function(n3) {
      this.childNodes.splice(this.childNodes.indexOf(n3) >>> 1, 1), e3.i.removeChild(n3);
    } }), B(y(P2, { context: e3.context }, n2.__v), e3.l)) : e3.l && e3.componentWillUnmount();
  }
  function z3(n2, e3) {
    var r3 = y(j3, { __v: n2, i: e3 });
    return r3.containerInfo = e3, r3;
  }
  (V2.prototype = new k()).__a = function(n2) {
    var t3 = this, e3 = F3(t3.__v), r3 = t3.o.get(n2);
    return r3[0]++, function(u3) {
      var o3 = function() {
        t3.props.revealOrder ? (r3.push(u3), W(t3, n2, r3)) : u3();
      };
      e3 ? e3(o3) : o3();
    };
  }, V2.prototype.render = function(n2) {
    this.u = null, this.o = /* @__PURE__ */ new Map();
    var t3 = P(n2.children);
    n2.revealOrder && "b" === n2.revealOrder[0] && t3.reverse();
    for (var e3 = t3.length; e3--; )
      this.o.set(t3[e3], this.u = [1, 0, this.u]);
    return n2.children;
  }, V2.prototype.componentDidUpdate = V2.prototype.componentDidMount = function() {
    var n2 = this;
    this.o.forEach(function(t3, e3) {
      W(n2, e3, t3);
    });
  };
  var B3 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
  var H2 = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
  var Z = /^on(Ani|Tra|Tou|BeforeInp|Compo)/;
  var Y = /[A-Z0-9]/g;
  var $2 = "undefined" != typeof document;
  var q3 = function(n2) {
    return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(n2);
  };
  function G(n2, t3, e3) {
    return null == t3.__k && (t3.textContent = ""), B(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  function J(n2, t3, e3) {
    return D(n2, t3), "function" == typeof e3 && e3(), n2 ? n2.__c : null;
  }
  k.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t3) {
    Object.defineProperty(k.prototype, t3, { configurable: true, get: function() {
      return this["UNSAFE_" + t3];
    }, set: function(n2) {
      Object.defineProperty(this, t3, { configurable: true, writable: true, value: n2 });
    } });
  });
  var K = l.event;
  function Q() {
  }
  function X() {
    return this.cancelBubble;
  }
  function nn() {
    return this.defaultPrevented;
  }
  l.event = function(n2) {
    return K && (n2 = K(n2)), n2.persist = Q, n2.isPropagationStopped = X, n2.isDefaultPrevented = nn, n2.nativeEvent = n2;
  };
  var tn;
  var en = { enumerable: false, configurable: true, get: function() {
    return this.class;
  } };
  var rn = l.vnode;
  l.vnode = function(n2) {
    "string" == typeof n2.type && function(n3) {
      var t3 = n3.props, e3 = n3.type, u3 = {};
      for (var o3 in t3) {
        var i3 = t3[o3];
        if (!("value" === o3 && "defaultValue" in t3 && null == i3 || $2 && "children" === o3 && "noscript" === e3 || "class" === o3 || "className" === o3)) {
          var l3 = o3.toLowerCase();
          "defaultValue" === o3 && "value" in t3 && null == t3.value ? o3 = "value" : "download" === o3 && true === i3 ? i3 = "" : "ondoubleclick" === l3 ? o3 = "ondblclick" : "onchange" !== l3 || "input" !== e3 && "textarea" !== e3 || q3(t3.type) ? "onfocus" === l3 ? o3 = "onfocusin" : "onblur" === l3 ? o3 = "onfocusout" : Z.test(o3) ? o3 = l3 : -1 === e3.indexOf("-") && H2.test(o3) ? o3 = o3.replace(Y, "-$&").toLowerCase() : null === i3 && (i3 = void 0) : l3 = o3 = "oninput", "oninput" === l3 && u3[o3 = l3] && (o3 = "oninputCapture"), u3[o3] = i3;
        }
      }
      "select" == e3 && u3.multiple && Array.isArray(u3.value) && (u3.value = P(t3.children).forEach(function(n4) {
        n4.props.selected = -1 != u3.value.indexOf(n4.props.value);
      })), "select" == e3 && null != u3.defaultValue && (u3.value = P(t3.children).forEach(function(n4) {
        n4.props.selected = u3.multiple ? -1 != u3.defaultValue.indexOf(n4.props.value) : u3.defaultValue == n4.props.value;
      })), t3.class && !t3.className ? (u3.class = t3.class, Object.defineProperty(u3, "className", en)) : (t3.className && !t3.class || t3.class && t3.className) && (u3.class = u3.className = t3.className), n3.props = u3;
    }(n2), n2.$$typeof = B3, rn && rn(n2);
  };
  var un = l.__r;
  l.__r = function(n2) {
    un && un(n2), tn = n2.__c;
  };
  var on = l.diffed;
  l.diffed = function(n2) {
    on && on(n2);
    var t3 = n2.props, e3 = n2.__e;
    null != e3 && "textarea" === n2.type && "value" in t3 && t3.value !== e3.value && (e3.value = null == t3.value ? "" : t3.value), tn = null;
  };
  var ln = { ReactCurrentDispatcher: { current: { readContext: function(n2) {
    return tn.__n[n2.__c].props.value;
  } } } };
  function fn(n2) {
    return y.bind(null, n2);
  }
  function an(n2) {
    return !!n2 && n2.$$typeof === B3;
  }
  function sn(n2) {
    return an(n2) ? E.apply(null, arguments) : n2;
  }
  function hn(n2) {
    return !!n2.__k && (B(null, n2), true);
  }
  function vn(n2) {
    return n2 && (n2.base || 1 === n2.nodeType && n2) || null;
  }
  var dn = function(n2, t3) {
    return n2(t3);
  };
  var pn = function(n2, t3) {
    return n2(t3);
  };
  var mn = _;
  function yn(n2) {
    n2();
  }
  function _n(n2) {
    return n2;
  }
  function bn() {
    return [false, yn];
  }
  var Sn = y2;
  function gn(n2, t3) {
    var e3 = t3(), r3 = h2({ h: { __: e3, v: t3 } }), u3 = r3[0].h, o3 = r3[1];
    return y2(function() {
      u3.__ = e3, u3.v = t3, E2(u3.__, t3()) || o3({ h: u3 });
    }, [n2, e3, t3]), p2(function() {
      return E2(u3.__, u3.v()) || o3({ h: u3 }), n2(function() {
        E2(u3.__, u3.v()) || o3({ h: u3 });
      });
    }, [n2]), e3;
  }
  var Cn = { useState: h2, useId: V, useReducer: s2, useEffect: p2, useLayoutEffect: y2, useInsertionEffect: Sn, useTransition: bn, useDeferredValue: _n, useSyncExternalStore: gn, startTransition: yn, useRef: _2, useImperativeHandle: A2, useMemo: F2, useCallback: T2, useContext: q2, useDebugValue: x2, version: "17.0.2", Children: O2, render: G, hydrate: J, unmountComponentAtNode: hn, createPortal: z3, createElement: y, createContext: F, createFactory: fn, cloneElement: sn, createRef: d, Fragment: _, isValidElement: an, findDOMNode: vn, Component: k, PureComponent: w3, memo: x3, forwardRef: k3, flushSync: pn, unstable_batchedUpdates: dn, StrictMode: mn, Suspense: D2, SuspenseList: V2, lazy: M2, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: ln };

  // src/ui_next/ServerDirectoryPicker.tsx
  var import_path_normalize = __toESM(require_lib());

  // src/ui_next/base/Backdrop.tsx
  function Backdrop(props) {
    const [rendered, setRendered] = Cn.useState(false);
    const rootRef = Cn.createRef();
    Cn.useEffect(() => {
      if (props.open) {
        if (!rendered) {
          setRendered(true);
          return;
        }
        if (rootRef.current && !rootRef.current.classList.contains("ui-backdrop__visible")) {
          rootRef.current.classList.add("ui-backdrop__visible");
        }
      } else if (!props.open && rendered && rootRef.current.classList.contains("ui-backdrop__visible")) {
        rootRef.current.classList.remove("ui-backdrop__visible");
        setTimeout(() => setRendered(false), 200);
      }
    });
    if (!rendered)
      return null;
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-backdrop",
      ref: rootRef,
      onMouseUp: props.onCancel
    }, props.children);
  }

  // src/ui_next/palette/CommandPaletteItem.tsx
  function CommandPaletteItem(props) {
    const ctx = Cn.useContext(CommandPaletteContext);
    const ref = Cn.useRef();
    let cn = "ui-command-palette__items__item";
    if (ctx.value == props.value)
      cn += " ui-command-palette__items__item--active";
    Cn.useEffect(() => {
      if (!ref.current)
        return;
      if (ctx.value == props.value)
        ref.current.scrollIntoView(false);
    });
    return /* @__PURE__ */ Cn.createElement("div", {
      className: cn,
      ref,
      onClick: () => ctx.onSelect(props.value)
    }, props.children);
  }

  // src/ui_next/palette/withFilteredPaletteItems.tsx
  function searchAll(children, output) {
    const allItems = O2.toArray(children);
    for (let item of allItems) {
      if (item.type == CommandPaletteItem) {
        output.push(item);
      } else if (item.props && item.props.children) {
        searchAll(item.props.children, output);
      }
    }
  }
  function withFilteredPaletteItems(search, children) {
    const [data, setNewData] = Cn.useState({
      search: null,
      items: [],
      children
    });
    Cn.useEffect(() => {
      if (data == null || data.search != search || data.children != children) {
        const allItems = [];
        searchAll(children, allItems);
        const searchLower = search.toLowerCase();
        const items = [];
        for (let item of allItems) {
          if (item.props.children.toLowerCase().indexOf(searchLower) > -1)
            items.push(item);
        }
        setNewData({ items, search, children });
      }
    });
    return data.items;
  }

  // src/ui_next/palette/CommandPalette.tsx
  var CommandPaletteContext = Cn.createContext({});
  function CommandPalette(props) {
    const [{ search, localIndex }, setState] = Cn.useState({
      search: "",
      localIndex: -1
    });
    const rootRef = Cn.createRef();
    const inputRef = Cn.createRef();
    const items = withFilteredPaletteItems(search, props.children);
    const value = items[localIndex] ? items[localIndex].props.value : "";
    Cn.useEffect(() => {
      if (!inputRef.current)
        return;
      const input = inputRef.current;
      input.focus();
      input.oninput = () => {
        setState({ localIndex: 0, search: input.value });
      };
      input.onkeyup = (e3) => {
        e3.stopPropagation();
      };
      input.onkeydown = (e3) => {
        switch (e3.key) {
          case "ArrowUp":
            e3.preventDefault();
            if (localIndex > 0) {
              setState({ search, localIndex: localIndex - 1 });
            } else {
              setState({ search, localIndex: items.length - 1 });
            }
            break;
          case "ArrowDown":
            e3.preventDefault();
            if (localIndex < items.length - 1) {
              setState({ search, localIndex: localIndex + 1 });
            } else {
              setState({ search, localIndex: 0 });
            }
            break;
          case "Enter":
            e3.preventDefault();
            const itemProps = items[localIndex].props;
            if (itemProps.onSelect)
              itemProps.onSelect(itemProps.value);
            if (props.onSelect)
              props.onSelect(itemProps.value);
            break;
          case "Escape":
            e3.preventDefault();
            if (props.onCancel)
              props.onCancel();
            break;
        }
      };
    });
    return /* @__PURE__ */ Cn.createElement(CommandPaletteContext.Provider, {
      value: {
        value,
        onSelect: props.onSelect
      }
    }, /* @__PURE__ */ Cn.createElement("div", {
      className: "ui-command-palette",
      ref: rootRef,
      onClick: (e3) => e3.stopPropagation()
    }, /* @__PURE__ */ Cn.createElement("input", {
      type: "text",
      ref: inputRef,
      placeholder: "Filter...",
      value: search
    }), /* @__PURE__ */ Cn.createElement("div", {
      className: "ui-command-palette__items"
    }, items)));
  }

  // src/ui_next/ServerDirectoryPicker.tsx
  function ServerDirectoryPicker(props) {
    const [{ path, currentPath, items }, setState] = Cn.useState({
      path: "",
      currentPath: "",
      items: null
    });
    Cn.useEffect(() => {
      if (!props.open)
        return;
      if (items == null) {
        reload();
      }
    });
    async function reload() {
      const resp = await fetch("/api/folder_chooser/" + path);
      const data = await resp.json();
      setState({
        path,
        currentPath: data.current_path,
        items: [
          "..",
          ...data.contents
        ]
      });
    }
    async function handleSelect(v3) {
      if (v3 == "$$apply$$") {
        const resp = await fetch(`/api/set_projects_dir/${path}`);
        if (resp.status == 200) {
          location.reload();
        }
        return;
      }
      let newPath = (0, import_path_normalize.default)(`${path}/${v3}`);
      if (newPath[0] == "/")
        newPath = newPath.substring(1);
      setState({
        path: newPath,
        currentPath: "",
        items: null
      });
    }
    if (!items)
      return null;
    return /* @__PURE__ */ Cn.createElement(Backdrop, {
      open: props.open
    }, /* @__PURE__ */ Cn.createElement(CommandPalette, {
      onSelect: handleSelect,
      onCancel: props.onCancel
    }, /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      value: "$$apply$$"
    }, `Use ${currentPath} directory`), items.map((v3) => /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      value: v3
    }, v3))));
  }

  // src/ui_next/panels/prop_editor/PropEditorGroup.tsx
  function PropEditorGroup(props) {
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "props-group"
    }, /* @__PURE__ */ Cn.createElement("span", {
      class: "props-group__icon material-symbols-outlined"
    }, props.icon), /* @__PURE__ */ Cn.createElement("div", {
      class: "props-group__content"
    }, props.children));
  }

  // src/ui_next/panels/prop_editor/preventPropagation.ts
  function preventPropagation(e3) {
    if (e3.key !== "Shift")
      e3.stopPropagation();
  }

  // src/ui_next/panels/prop_editor/withPlayerStateInputHandler.ts
  function withPlayerStateInputHandler(props) {
    const [value, setValue] = Cn.useState(props.entry.value);
    function onInput(e3) {
      let value2 = e3.target.value;
      if (props.entry.type === "number")
        value2 = Number(value2);
      props.player.setDeviceState(props.name, value2);
      setValue(value2);
      if (props.player instanceof ChromeZeppPlayer)
        props.player.saveDeviceStates();
    }
    return [value, onInput];
  }

  // src/ui_next/panels/prop_editor/PropSelectInput.tsx
  function PropSelectInput(props) {
    const [value, onInput] = withPlayerStateInputHandler(props);
    return /* @__PURE__ */ Cn.createElement("select", {
      value,
      onInput,
      onKeyUp: preventPropagation
    }, props.entry.options.map((v3) => /* @__PURE__ */ Cn.createElement("option", null, v3)));
  }

  // src/ui_next/panels/prop_editor/PropInput.tsx
  function PropInput(props) {
    const [value, onInput] = withPlayerStateInputHandler(props);
    let type = "number";
    if (props.entry.type == "string")
      type = "string";
    if (props.entry.type == "boolean")
      type = "checkbox";
    const maxLength = 14 * (props.entry.maxLength ? props.entry.maxLength : 1) + 14;
    return /* @__PURE__ */ Cn.createElement("input", {
      type,
      style: { width: props.entry.type !== "boolean" ? maxLength : "initial" },
      value: String(value),
      onKeyUp: preventPropagation,
      onInput
    });
  }

  // src/ui_next/panels/prop_editor/PropCheckboxInput.tsx
  function PropCheckboxInput(props) {
    const [value, setValue] = Cn.useState(props.entry.value);
    function onChange(e3) {
      const value2 = e3.target.checked;
      console.log(value2);
      props.player.setDeviceState(props.name, value2);
      setValue(value2);
      if (props.player instanceof ChromeZeppPlayer)
        props.player.saveDeviceStates();
    }
    return /* @__PURE__ */ Cn.createElement("input", {
      type: "checkbox",
      checked: value,
      onKeyUp: preventPropagation,
      onChange
    });
  }

  // src/ui_next/panels/prop_editor/PropEditorEntry.tsx
  function PropEditorEntry(props) {
    const prettyName = props.name.charAt(0).toUpperCase() + props.name.slice(1).replaceAll("_", " ").toLowerCase();
    let view = null;
    switch (props.entry.type) {
      case "select":
        view = /* @__PURE__ */ Cn.createElement(PropSelectInput, {
          ...props
        });
        break;
      case "boolean":
        view = /* @__PURE__ */ Cn.createElement(PropCheckboxInput, {
          ...props
        });
        break;
      default:
        view = /* @__PURE__ */ Cn.createElement(PropInput, {
          ...props
        });
    }
    return /* @__PURE__ */ Cn.createElement("div", {
      className: "props-entry"
    }, /* @__PURE__ */ Cn.createElement("span", {
      className: "props-entry__title"
    }, props.entry.displayName || prettyName), /* @__PURE__ */ Cn.createElement("span", null, view));
  }

  // node_modules/uuid/dist/esm-browser/rng.js
  var getRandomValues;
  var rnds8 = new Uint8Array(16);
  function rng() {
    if (!getRandomValues) {
      getRandomValues = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
      if (!getRandomValues) {
        throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
      }
    }
    return getRandomValues(rnds8);
  }

  // node_modules/uuid/dist/esm-browser/stringify.js
  var byteToHex = [];
  for (let i3 = 0; i3 < 256; ++i3) {
    byteToHex.push((i3 + 256).toString(16).slice(1));
  }
  function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  }

  // node_modules/uuid/dist/esm-browser/native.js
  var randomUUID = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
  var native_default = {
    randomUUID
  };

  // node_modules/uuid/dist/esm-browser/v4.js
  function v4(options, buf, offset) {
    if (native_default.randomUUID && !buf && !options) {
      return native_default.randomUUID();
    }
    options = options || {};
    const rnds = options.random || (options.rng || rng)();
    rnds[6] = rnds[6] & 15 | 64;
    rnds[8] = rnds[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (let i3 = 0; i3 < 16; ++i3) {
        buf[offset + i3] = rnds[i3];
      }
      return buf;
    }
    return unsafeStringify(rnds);
  }
  var v4_default = v4;

  // src/ui_next/base/Checkbox.tsx
  function Checkbox(props) {
    const [ident, _3] = Cn.useState(v4_default());
    return /* @__PURE__ */ Cn.createElement("input", {
      id: props.id ? props.id : ident,
      type: "checkbox",
      checked: props.checked,
      onChange: props.onChange
    });
  }

  // src/ui_next/base/CheckboxWithLabel.tsx
  function CheckboxWithLabel(props) {
    const [ident, _3] = Cn.useState(v4_default());
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-cb-with-label"
    }, /* @__PURE__ */ Cn.createElement(Checkbox, {
      ...props,
      id: ident
    }), /* @__PURE__ */ Cn.createElement("label", {
      htmlFor: ident,
      class: "ui-cb-with-label__label"
    }, props.label));
  }

  // src/zepp_player/tools/RealTimeTicker.ts
  var RealTimeTicker = class {
    static start(player2) {
      RealTimeTicker.player = player2;
      RealTimeTicker.onTick();
      RealTimeTicker.timerIdent = setInterval(() => {
        RealTimeTicker.onTick();
      }, 1e3);
    }
    static onTick() {
      const date = new Date();
      RealTimeTicker.player.setDeviceStateMany({
        HOUR: date.getHours(),
        MINUTE: date.getMinutes(),
        SECOND: date.getSeconds(),
        DAY: date.getDate(),
        MONTH: date.getMonth(),
        YEAR: date.getFullYear(),
        WEEKDAY: (date.getDay() + 6) % 7
      });
    }
    static stop() {
      clearInterval(RealTimeTicker.timerIdent);
    }
  };

  // src/ui_next/panels/prop_editor/RealTimeSwitch.tsx
  function RealTimeSwitch(props) {
    function toggle(e3) {
      e3.target.checked ? RealTimeTicker.start(props.player) : RealTimeTicker.stop();
    }
    return /* @__PURE__ */ Cn.createElement("div", {
      style: { padding: "0 8px" }
    }, /* @__PURE__ */ Cn.createElement(CheckboxWithLabel, {
      onChange: toggle,
      label: "Real-time clock"
    }), /* @__PURE__ */ Cn.createElement("hr", null));
  }

  // src/ui_next/panels/PropEditorPanel.tsx
  function withGroupedPlayerProps(player2) {
    const [data, setData] = Cn.useState(null);
    Cn.useEffect(() => {
      if (data != null)
        return;
      const groupedStates = {};
      for (const key in player2._deviceState) {
        const entry = player2.getStateEntry(key);
        const group = entry.groupIcon ? entry.groupIcon : "inventory_2";
        if (!groupedStates.hasOwnProperty(group))
          groupedStates[group] = {};
        groupedStates[group][key] = entry;
      }
      setData(groupedStates);
    });
    return data;
  }
  function PropEditorPanel(props) {
    const states = withGroupedPlayerProps(props.player);
    if (!states)
      return null;
    return /* @__PURE__ */ Cn.createElement(Cn.Fragment, null, /* @__PURE__ */ Cn.createElement(RealTimeSwitch, {
      player: props.player
    }), Object.keys(states).map((group) => /* @__PURE__ */ Cn.createElement(PropEditorGroup, {
      icon: group
    }, Object.keys(states[group]).map((name) => /* @__PURE__ */ Cn.createElement(PropEditorEntry, {
      entry: states[group][name],
      name,
      player: props.player
    })))));
  }

  // src/ui_next/command_palette/getChangeProjectCommands.tsx
  function getChangeProjectCommands(onSelect) {
    const projects = ProjectPicker.projects;
    const applyProject = (url) => {
      console.log(url);
      ProjectPicker.applyProjectUrl(url);
      onSelect();
    };
    return projects.map((v3, i3) => /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      key: i3,
      value: v3.url,
      onSelect: () => applyProject(v3.url)
    }, `Set project: ${v3.title}`));
  }

  // src/ui_next/command_palette/getChangeProfileCommands.tsx
  function getChangeProfileCommands(onCancel) {
    function applyProfile(name) {
      const picker = document.getElementById("player_profile_select");
      picker.value = name;
      picker.onchange(null);
      onCancel();
    }
    return Object.keys(DeviceProfiles).map((name) => /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      value: `profile_${name}`,
      onSelect: () => applyProfile(name)
    }, `Set profile: ${name}`));
  }

  // src/ui_next/CommandPicker.tsx
  function CommandPicker(props) {
    const onCancel = () => props.changePane("");
    return /* @__PURE__ */ Cn.createElement(Backdrop, {
      open: props.open
    }, /* @__PURE__ */ Cn.createElement(CommandPalette, {
      onCancel
    }, /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      value: "ch_dir",
      onSelect: () => props.changePane("change_projects_dir")
    }, "Change projects directory"), /* @__PURE__ */ Cn.createElement(CommandPaletteItem, {
      value: "p_cfg",
      onSelect: () => props.changePane("settings")
    }, "Open player settings"), ...getChangeProjectCommands(onCancel), ...getChangeProfileCommands(onCancel)));
  }

  // src/ui_next/base/Modal.tsx
  function Dialog(props) {
    const onMouseUp = (e3) => e3.stopPropagation();
    return /* @__PURE__ */ Cn.createElement(Backdrop, {
      ...props
    }, /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-modal",
      onMouseUp,
      style: { maxWidth: props.maxWidth || "80vw", minWidth: props.minWidth }
    }, props.children));
  }
  function DialogTitle(props) {
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-modal__title"
    }, props.children);
  }
  function DialogContent(props) {
    let classes = "ui-modal__content";
    if (!props.noMargin)
      classes += " ui-modal__content--margin";
    return /* @__PURE__ */ Cn.createElement("div", {
      class: classes
    }, props.children);
  }
  function DialogActions(props) {
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-modal__actions"
    }, props.children);
  }

  // src/ui_next/base/Button.tsx
  function Button(props) {
    let classes = "ui-button";
    if (props.primary)
      classes += " ui-button--primary";
    return /* @__PURE__ */ Cn.createElement("span", {
      class: classes,
      onClick: props.onClick
    }, props.children);
  }

  // src/ui_next/settings_pane/SettingsListItem.tsx
  function SettingsListItem(props) {
    return /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-settings-item"
    }, /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-settings-item__info"
    }, /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-settings-item__title"
    }, props.title), /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-settings-item__description"
    }, props.description)), /* @__PURE__ */ Cn.createElement("div", {
      class: "ui-settings-item__content"
    }, props.children), !props.noClickHandler && /* @__PURE__ */ Cn.createElement("div", {
      className: "ui-settings-item__click-handler",
      onClick: props.onClick
    }));
  }

  // src/ui_next/settings_pane/BooleanSettingsOption.tsx
  function BooleanSettingsOption(props) {
    const [value, setValue] = Cn.useState(AppSettingsManager.getObject(props.configKey, props.fallback));
    const handler = () => {
      const val = !AppSettingsManager.getObject(props.configKey, props.fallback);
      AppSettingsManager.setObject(props.configKey, val);
      console.log(props.configKey, val);
      setValue(val);
      if (props.onChange)
        props.onChange(val);
    };
    return /* @__PURE__ */ Cn.createElement(SettingsListItem, {
      title: props.title,
      description: props.description,
      onClick: handler
    }, /* @__PURE__ */ Cn.createElement(Checkbox, {
      checked: value
    }));
  }

  // src/ui_next/settings_pane/CssSettingsOption.tsx
  function CssSettingsOption(props) {
    const configKey = `css_${props.cssPropName}`;
    const [current, setCurrent] = Cn.useState(AppSettingsManager.getString(configKey, null));
    Cn.useEffect(() => {
      if (current == null)
        return;
      document.documentElement.style.setProperty(`--${props.cssPropName}`, current);
      AppSettingsManager.setString(configKey, current);
    });
    return /* @__PURE__ */ Cn.createElement(SettingsListItem, {
      title: props.title,
      description: props.description,
      noClickHandler: true
    }, /* @__PURE__ */ Cn.createElement("input", {
      type: "color",
      value: current,
      onChange: (e3) => setCurrent(e3.target.value)
    }));
  }

  // src/ui_next/settings_pane/CssColorOptions.tsx
  var CSS_OPTIONS = {
    "accent": "Accent color",
    "background": "Page background color",
    "foreground": "Page text color",
    "panel": "Panels background color",
    "panel-text": "Panels text color",
    "editor": "Editor color",
    "editor-text": "Editor text color",
    "input": "Inputs and buttons background color",
    "input-text": "Inputs and buttons text color"
  };
  function CssColorOptions() {
    return /* @__PURE__ */ Cn.createElement(Cn.Fragment, null, Object.keys(CSS_OPTIONS).map((key) => /* @__PURE__ */ Cn.createElement(CssSettingsOption, {
      title: CSS_OPTIONS[key],
      description: "",
      cssPropName: key
    })));
  }

  // src/ui_next/settings_pane/PlayerSettingsPane.tsx
  function PlayerSettingsPane(props) {
    const performWipe = () => {
      if (confirm("Restore default player settings? Project files won't be deleted")) {
        localStorage.clear();
        location.reload();
      }
    };
    return /* @__PURE__ */ Cn.createElement(Dialog, {
      ...props,
      maxWidth: "500px"
    }, /* @__PURE__ */ Cn.createElement(DialogTitle, null, "ZeppPlayer Settings"), /* @__PURE__ */ Cn.createElement(DialogContent, {
      noMargin: true
    }, /* @__PURE__ */ Cn.createElement(BooleanSettingsOption, {
      title: "Keep & restore editor state",
      description: 'If enabled, all changes made in "Editor" pane will be kept since player reload',
      configKey: "cfgKeepState",
      fallback: true
    }), /* @__PURE__ */ Cn.createElement(BooleanSettingsOption, {
      title: "Auto-restart on project files change",
      description: "If enabled, any changes made in project assets/code will trigger player to reload it",
      configKey: "cfgAutoRefresh",
      fallback: true
    }), /* @__PURE__ */ Cn.createElement(BooleanSettingsOption, {
      title: 'Prefer "build" directory if they exists',
      description: 'If enabled and current project has "build" directory, them player will run preview from this directory instead of main project root.',
      configKey: "preferBuildDir",
      fallback: true
    }), /* @__PURE__ */ Cn.createElement("hr", null), /* @__PURE__ */ Cn.createElement(CssColorOptions, null)), /* @__PURE__ */ Cn.createElement(DialogActions, null, /* @__PURE__ */ Cn.createElement(Button, {
      primary: true,
      onClick: props.onCancel
    }, "Close"), /* @__PURE__ */ Cn.createElement(Button, {
      onClick: performWipe
    }, "Restore defaults")));
  }

  // src/ui_next/RootComponent.tsx
  function RootComponent() {
    const [pane, setPane] = Cn.useState("");
    window._setReactPane = setPane;
    return /* @__PURE__ */ Cn.createElement(Cn.Fragment, null, /* @__PURE__ */ Cn.createElement(ServerDirectoryPicker, {
      open: pane == "change_projects_dir",
      onCancel: () => setPane("")
    }), /* @__PURE__ */ Cn.createElement(CommandPicker, {
      open: pane == "command_picker",
      changePane: setPane
    }), /* @__PURE__ */ Cn.createElement(PlayerSettingsPane, {
      open: pane == "settings",
      onCancel: () => setPane("")
    }));
  }
  function start(node, player2) {
    B(/* @__PURE__ */ Cn.createElement(RootComponent, null), node);
    B(/* @__PURE__ */ Cn.createElement(PropEditorPanel, {
      player: player2
    }), document.getElementById("view_edit"));
  }

  // src/ui_next/PlayerSettingsLoader.ts
  var PlayerSettingsLoader = class {
    static loadAll(player2) {
      for (const key in CSS_OPTIONS) {
        const value = AppSettingsManager.getString(`css_${key}`, null);
        console.log(key, value);
        if (value != null)
          document.documentElement.style.setProperty(`--${key}`, value);
      }
      if (AppSettingsManager.getObject("cfgKeepState", true)) {
        try {
          const data = AppSettingsManager.getObject("deviceState", {});
          for (const type in data) {
            player2.setDeviceState(type, data[type]);
          }
        } catch (e3) {
          console.warn(e3);
        }
      }
    }
  };

  // src/index.browser.js
  var DISPLAY_FPS = 60;
  var DISPLAY_DELTA = 1e3 / DISPLAY_FPS;
  var start2 = async () => {
    const root = document.getElementById("display");
    const ctx = root.getContext("2d");
    const font = new FontFace("allfont", "url(/app/allfont-Medium.ttf)");
    await font.load();
    document.fonts.add(font);
    const player2 = new ChromeZeppPlayer();
    PlayerSettingsLoader.loadAll(player2);
    start(document.getElementById("ng-root"), player2);
    window.PersistentStorage = PersistentStorage;
    window.player = player2;
    await ProjectPicker.setup(player2);
    ToolbarManager.initProfileSelect(player2);
    await player2.setProject(ProjectPicker.getProject());
    await ChangesWatcher.init(player2);
    ToolbarManager.init(player2);
    ConsoleManager.init(player2);
    ExplorerManager.init(player2);
    await player2.init();
    root.width = player2.screen[0];
    root.height = player2.screen[1];
    player2.setupHTMLEvents(root);
    let lastRender = 0;
    const refresh = async () => {
      try {
        requestAnimationFrame(refresh);
        if (Date.now() - lastRender > DISPLAY_DELTA) {
          await performRefresh();
          lastRender = Date.now();
        }
      } catch (e3) {
        console.error("Refresh failed...", e3);
        setTimeout(() => {
          refresh();
        }, 2500);
      }
    };
    const performRefresh = async () => {
      if (!player2.currentRuntime)
        return;
      if (document.hidden || player2.currentRuntime.uiPause || !player2.currentRuntime.refresh_required)
        return;
      let canvas;
      try {
        canvas = await player2.render();
      } catch (e3) {
        console.error("Render err", e3);
        player2.refresh_required = false;
      }
      const rotation = player2.rotation;
      let [w4, h3] = [canvas.width, canvas.height];
      if (rotation % 180 === 90)
        [h3, w4] = [w4, h3];
      if (root.width !== w4)
        root.width = w4;
      if (root.height !== h3)
        root.height = h3;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.translate(w4 / 2, h3 / 2);
      ctx.rotate(rotation * Math.PI / 180);
      ctx.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
      ctx.restore();
    };
    refresh();
  };
  initVersionUI();
  start2();
})();
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
